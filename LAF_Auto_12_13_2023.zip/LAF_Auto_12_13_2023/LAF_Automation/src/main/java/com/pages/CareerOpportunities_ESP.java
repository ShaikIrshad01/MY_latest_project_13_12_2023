package com.pages;

import com.BasePackage.Base_Class;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import com.BasePackage.Base_Class;
import com.Utility.Log;
import com.aventstack.extentreports.Status;
import com.extentReports.ExtentTestManager;

public class CareerOpportunities_ESP extends Base_Class{
	
	Home home= new Home();

	private static By About = By.xpath("//a[@class='drop-down-arrow']");
	private static By Carer_Opp = By.xpath("//div[@class='nav-drop-down']//a[contains(text(),'Career Opportunities')]");
	private static By Career_Opportunity_text = By.xpath("//h1[contains(text(),'Career Opportunity')]");
	private static By Employment_Application_text = By.xpath("//h1[contains(text(),'Employment Application')]");
	private static By video = By.xpath("//iframe[@class='embed-responsive-item ae-media ae-youtube']");
	private static By club_positions = By.id("LinkButtonClubJobAds");
	private static By corp_positions = By.id("LinkButtonCorpJobAds");
	private static By Group_Fitness_moreinfo = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][1]//a[@class='moreinfo']");
	private static By Personal_T_moreinfo = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][2]//a[@class='moreinfo']");
	private static By Pil_T_moreinfo = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][3]//a[@class='moreinfo']");
	private static By Hiit_c_moreinfo = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][3]//a[@class='moreinfo']");
	private static By Group_F_apply_here_button = By.id("ctl00_MainContent_JobAdsFeatured_ctl01_btnApplyFeatJob");
	private static By Personal_T_apply_here_button = By.id("ctl00_MainContent_JobAdsFeatured_ctl00_btnApplyFeatJob");
	private static By Pilates_T_apply_here_button = By.xpath("//button[@data-ae-blurbtype='button'][contains(text(),'Pilates Teacher')]");
	private static By Hiit_c_apply_here_button = By.id("ctl00_MainContent_JobAdsFeatured_ctl02_btnApplyFeatJob");
	private static By Group_Fitness_job_details = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][1]//div[@class='text-center']");
	private static By Personal_T_job_details = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][2]//div[@class='text-center']");
	private static By pilates_T_job_details = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][3]//div[@class='text-center']");
	private static By Hiit_c_job_details = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][3]//div[@class='text-center']");
	private static By Group_F_apply_here_image = By.id("ctl00_MainContent_JobAdsFeatured_ctl00_ImageJobAd");
	private static By Accounting_image = By.id("ctl00_MainContent_JobAdsCorporate_ctl00_ImageJobAd");
	private static By F_and_T_image = By.id("ctl00_MainContent_JobAdsCorporate_ctl01_ImageJobAd");
	private static By HS_image = By.id("ctl00_MainContent_JobAdsCorporate_ctl02_ImageJobAd");
	private static By IT_image = By.id("ctl00_MainContent_JobAdsCorporate_ctl03_ImageJobAd");
	private static By L_and_A_image = By.id("ctl00_MainContent_JobAdsCorporate_ctl04_ImageJobAd");
	private static By RE_and_D_image = By.id("ctl00_MainContent_JobAdsCorporate_ctl05_ImageJobAd");
//	private static By Group_F_apply_here_image = By.id("ctl00_MainContent_JobAdsFeatured_ctl00_ImageJobAd");
	
	private static By Personal_T_apply_here_image = By.id("ctl00_MainContent_JobAdsFeatured_ctl01_ImageJobAd");
	private static By Pilates_T_apply_here_image = By.id("ctl00_MainContent_JobAdsFeatured_ctl02_ImageJobAd");
	private static By HIIT_C__apply_here_image = By.id("ctl00_MainContent_JobAdsFeatured_ctl02_ImageJobAd");
	private static By Grp_jobtitle= By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][1]//div[@class='jobTitle']");
	
	
	private static By per_T_jobtitle= By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][2]//div[@class='jobTitle']");
	private static By Pil_T_jobtitle= By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][3]//div[@class='jobTitle']");
	private static By Hiit_c_jobtitle= By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][3]//div[@class='jobTitle']");
	private static By moreinfo_list_club_pos= By.xpath("//div[@class='btnInfo text-center']//a[@class='moreinfo']");
	private static By moreinfo_list_corp_pos= By.xpath("//div[@class='row text-center']//a[@class='moreinfo']");
	
	private static By moreinfo_popup= By.xpath("//body/form[@id='aspnetForm']/div[3]/div[2]/div[2]/div[1]/div[1]");
	private static By moreinfo_popup_close = By.id("btnclose");
	private static By moreinfo_popup_title = By.id("iTitle");
	private static By club_jobs_content = By.id("ctl00_MainContent_trClubPositionsDescVsCorpPositions");
	
	private static By corp_jobs_content = By.xpath("//td[contains(text(),'Corporate Positions are located in Irvine, Califor')]");
	private static By corp_jobs = By.className("laJobSelector");
	
	private static By moreinfo_popup_group_image = By.xpath("//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsFeatured_ctl00_ImageURLPopup']");
	private static By club_jobs_list = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector']");												 
	private static By club_jobs_titles = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector']//div[@class='jobTitle']");
	private static By corp_jobs_title=By.xpath("//div[@class='laJobSelector']//strong");
	private static By moreinfo_link_Accounting=By.xpath("//div[@class='laJobSelector'][1]//a[@class='moreinfo']");
	private static By moreinfo_link_F_and_T=By.xpath("//div[@class='laJobSelector'][2]//a[@class='moreinfo']");
	private static By moreinfo_link_HR=By.xpath("//div[@class='laJobSelector'][3]//a[@class='moreinfo']");
	private static By moreinfo_link_IT=By.xpath("//div[@class='laJobSelector'][4]//a[@class='moreinfo']");
	private static By moreinfo_link_L_and_A=By.xpath("//div[@class='laJobSelector'][5]//a[@class='moreinfo']");
	private static By moreinfo_link_RE_and_D=By.xpath("//div[@class='laJobSelector'][6]//a[@class='moreinfo']");
	
	
	private static By Accounting_corp_jobs_title=By.xpath("//div[@class='laJobHolder']//div[@class='laJobSelector'][1]//strong");
	private static By F_and_T_corp_jobs_title=By.xpath("//div[@class='laJobHolder']//div[@class='laJobSelector'][2]//strong");
	private static By HR_corp_jobs_title=By.xpath("//div[@class='laJobHolder']//div[@class='laJobSelector'][3]//strong");
	private static By IT_corp_jobs_title=By.xpath("//div[@class='laJobHolder']//div[@class='laJobSelector'][4]//strong");
	private static By L_and_A_corp_jobs_title=By.xpath("//div[@class='laJobHolder']//div[@class='laJobSelector'][5]//strong");
	private static By RE_and_D_corp_jobs_title=By.xpath("//div[@class='laJobHolder']//div[@class='laJobSelector'][6]//strong");
	private static By Accounting_short_des_corp_jobs=By.xpath("//div[@class='laJobHolder']//div[@class='laJobSelector'][1]//div[@class='col-xs-12']");
	private static By F_and_T_short_des_corp_jobs=By.xpath("//div[@class='laJobHolder']//div[@class='laJobSelector'][2]//div[@class='col-xs-12']");
	private static By HR_corp_short_des_corp_jobs=By.xpath("//div[@class='laJobHolder']//div[@class='laJobSelector'][3]//div[@class='col-xs-12']");
	private static By IT_corp_short_des_corp_jobs=By.xpath("//div[@class='laJobHolder']//div[@class='laJobSelector'][4]//div[@class='col-xs-12']");
	private static By L_and_A_short_des_corp_jobs=By.xpath("//div[@class='laJobHolder']//div[@class='laJobSelector'][5]//div[@class='col-xs-12']");
	private static By RE_and_D_short_des_corp_jobs=By.xpath("//div[@class='laJobHolder']//div[@class='laJobSelector'][6]//div[@class='col-xs-12']");
	
	private static By grp_fis_moreinfo_des = By.id("Modalbody");
	private static By Emp_app_txt = By.xpath("//h1[contains(text(),'Employment Application')]");
	private static By employment_para = By.xpath("//body/form[@id='aspnetForm']/div[3]/div[2]/div[1]/div[1]/div[2]/div[1]");
	private static By app_info = By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[4]/div[1]/div[1]");
	private static By HowDidYouHear_abt_us = By.id("ctl00_MainContent_ApplicantContactLocationInfo_cboHowDidYouHear");
	private static By RadioButtonList18YearsOld_yes = By.id("ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_0");
	private static By RadioButtonList18YearsOld_No = By.id("ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_1");
	private static By RadioButtonList18YearsOld_No_label = By.xpath("//label[@for='ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_1']");
	private static By RadioButtonList18YearsOld_Yes_label = By.xpath("//label[@for='ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_0']");
	
	private static By LabelAtLeast18Error = By.id("ctl00_MainContent_ApplicantContactLocationInfo_LabelAtLeast18Error");
	private static By firstname = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxFirstName");
	private static By lastname = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxLastName");
	private static By Email = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxEmail");
	private static By con_Email = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxConfirmEmail");
	private static By phone = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxPhone");
	private static By address = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxAddress");
	private static By zipcode = By.id("TextBoxZipCode");
	private static By City = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxCity");
	
	private static By State = By.id("ctl00_MainContent_ApplicantContactLocationInfo_DropDownListState");
									 
	private static By travel_radius_dropdown = By.id("ctl00_MainContent_ApplicantContactLocationInfo_DropDownListTravelRadius");
	private static By consenttoreceive_calls_texts = By.xpath("//span[contains(text(),'By providing your cell phone number, you consent t')]");
	private static By youtube_video_play = By.xpath("//body/form[@id='aspnetForm']/div[3]/div[2]/div[1]/div[2]/div[2]/div[1]/iframe[1]");
	private static By career_description_p = By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[3]");
	private static By Applyhere_button = By.id("ctl00_MainContent_ImageButtonApplyCorpJob");													
	private static By btn_next = By.id("btn_next");
	private static By btn_prev = By.id("btn_prev");
	private static By Applyhere_button1 = By.xpath("//tbody/tr[4]/td[1]/button[1]");
	private static By add_emplr_2 = By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");
	private static By following_pos_text = By.xpath("//tbody/tr[4]/td");
	private static By PT_image = By.id("ctl00_MainContent_JobAdsFeatured_ctl00_ImageJobAd");
	private static By GF_image = By.id("ctl00_MainContent_JobAdsFeatured_ctl01_ImageJobAd");
	private static By HC_image = By.id("ctl00_MainContent_JobAdsFeatured_ctl02_ImageJobAd");
	private static By PT_title = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][1]//div[@class='jobTitle']");
	private static By GF_title = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][2]//div[@class='jobTitle']");
	private static By HC_title = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][3]//div[@class='jobTitle']");
	
	private static By PT_J_details = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][1]//div[@class='text-center']");
	private static By GF_J_details = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][2]//div[@class='text-center']");
	private static By HC_J_details = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][3]//div[@class='text-center']");
	
	private static By PT_moreinfoL = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][1]//a[@class='moreinfo']");
	private static By GF_moreinfoL = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][2]//a[@class='moreinfo']");
	private static By HC_moreinfoL = By.xpath("//div[@class='col-md-3 col-sm-6 job-feature-selector'][3]//a[@class='moreinfo']");
	
	private static By PT_A_H_btn= By.id("ctl00_MainContent_JobAdsFeatured_ctl00_btnApplyFeatJob");
	private static By GF_A_H_btn = By.id("ctl00_MainContent_JobAdsFeatured_ctl01_btnApplyFeatJob");
	private static By HC_A_H_btn = By.id("ctl00_MainContent_JobAdsFeatured_ctl02_btnApplyFeatJob");
	
	private static By A_H_btn = By.xpath("//button[@class='featjobbutton small'][contains(text(),'Apply Here')]");
	private static By following_positions_text = By.xpath("//td[@class='padding-t-md padding-b-md text-center'][contains(text(),'For the Following Positions')]");
	
	

	private static By linkCP = By.xpath("//div[@class='nav-drop-down']/ul/li/a[text()='Career Opportunities']");
	private static By Button_personaltAH = By.id("ctl00_MainContent_JobAdsFeatured_ctl00_btnApplyFeatJob");
	private static By Btn_PilitiesTecher = By.id("ctl00_MainContent_JobAdsFeatured_ctl02_btnApplyFeatJob");
	private static By Text_EmploymentApp = By.xpath("//div[@class='col-xs-12']/h1");
	private static By Text_Below_EmpAp1 = By.xpath("//div[@class='col-sm-12']/p");
	private static By Text_Below_EmpAp2= By.xpath("//div[@class='col-sm-12']/p[2]");
	private static By Text_Miles = By.xpath("//div[@class='col-sm-10 col-xs-8 padding-t-sm']");
	private static By Text_ApplicantInfo = By.xpath("//div[@class='panel-heading']/span[@title='Applicant Information']");
	private static By Text_CandLInfo = By.xpath("//div[@class='panel-heading']/i[@title='Contact and Location Information']");
	private static By Field_HowDIdYouHAUs = By.xpath("//label[@title='How did you hear about us?']");
	private static By Field_RU18Yrs = By.xpath("//div[@class='col-sm-3 col-xs-8 padding-xs']");
	private static By Field_FirstLastName = By.xpath("//label[@title='First and Last Name']");
	private static By Field_EmailAdd = By.xpath("//label[@title='Email Address']");
	private static By Field_ConfmEmailAdd = By.xpath("//label[@title='Confirm Email Address']");
	private static By Field_CellPhone = By.xpath("//label[@title='Cell Phone']");
	private static By Field_Address = By.xpath("//label[@for='ctl00_MainContent_ApplicantContactLocationInfo_TextBoxAddress']");
	private static By Field_ZipPostal = By.xpath("//label[@for='TextBoxZipCode']");
	private static By Field_CityState = By.xpath("//label[@for='ctl00_MainContent_ApplicantContactLocationInfo_TextBoxCity']");
	private static By Field_RadiusUTravel = By.xpath("//label[@for='ctl00_MainContent_ApplicantContactLocationInfo_DropDownListTravelRadius']");
	private static By Field_CulbinUrRadius = By.xpath("//span[text()=' Clubs in Your Radius:']");
	private static By Dropdownv_HowDidUHUs = By.id("ctl00_MainContent_ApplicantContactLocationInfo_cboHowDidYouHear");
	private static By Link_NoticeatCollection = By.xpath("//a[text()='Notice at Collection']");
	private static By Link_UrPrivacyChoise = By.xpath("(//a[text()='Your Privacy Choices'])[1]");
	private static By Radio_Yes = By.xpath("(//table[@id='ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld']/tbody/tr/td)[1]");
	private static By Radio_No = By.xpath("(//table[@id='ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld']/tbody/tr/td)[2]");
	private static By Text_FormatUS92 = By.id("ctl00_MainContent_ApplicantContactLocationInfo_LabelZipCodeFormat");
	private static By ErrorText_CellPhoneField = By.xpath("//div[@class='col-sm-7']/span[@class='errorLabel']");
	private static By Button_NextStep = By.id("btn_next");
	private static By E_FirstNameInput = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxFirstName");
	private static By E_LastNameInput = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxLastName");
	private static By E_RadioYes = By.id("ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_0");
	private static By E_RadioNo = By.id("ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_1");
	private static By E_EmailInput = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxEmail");
	private static By E_ConfEmailInput = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxConfirmEmail");
	private static By E_CellPhInput = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxPhone");
	private static By E_AddressInput = By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxAddress");
	private static By E_CityStateInput = By.id("TextBoxZipCode");
	private static By Auto_City = By.xpath("//input[@name='ctl00$MainContent$ApplicantContactLocationInfo$TextBoxCity']");
	private static By Auto_State = By.name("ctl00$MainContent$ApplicantContactLocationInfo$DropDownListState");
			//By.xpath("//select[@name='ctl00$MainContent$ApplicantContactLocationInfo$DropDownListState']");
	private static By Auto_ClubsRadious = By.id("ctl00_MainContent_ApplicantContactLocationInfo_DataListClubs");
	private static By Auto_Radious = By.name("ctl00$MainContent$ApplicantContactLocationInfo$DropDownListTravelRadius");
			//By.xpath("//select[@name='ctl00$MainContent$ApplicantContactLocationInfo$DropDownListTravelRadius']");
	
	private static By Applicant_NextStep = By.id("btn_next");
	private static By Text_Educatin_info = By.xpath("//span[text()='Education Information']");
	private static By field_Education_level = By.xpath("//label[@for='ctl00_MainContent_ApplicantEducation_DropDownListEducation']");
	private static By EducationLevel_dropdown = By.id("ctl00_MainContent_ApplicantEducation_DropDownListEducation");
	

	public void Career_opportunity_section(String Value, String Car_op_txt, String Para) throws Exception {
		if (Value.equalsIgnoreCase("Career_opportunity_section")) 
		{
		
		home.Navigate_to_Emplyoment_page_ESP("Navigate_to_Emplyoment_page_ESP");	
		
		Element_isdisplayed(Career_Opportunity_text);
		String text=driver.findElement(Career_Opportunity_text).getText();
		Assert.assertEquals(text.toUpperCase().trim(), Car_op_txt.toUpperCase().trim(), "Career opportunities text not validated");
		Log.info(text+" section successfully displayed in Career opportunities page and Career opportunities text validated ");
		ExtentTestManager.getTest().log(Status.PASS, text+" section successfully displayed in Career opportunities page and Career opportunities text  ");
		
		
		Element_isdisplayed(career_description_p);
		String career_description =driver.findElement(career_description_p).getText().replace("\n", " ").trim();
		Assert.assertEquals(career_description.toUpperCase().trim(), Para.toUpperCase().trim(), "Career description paragraph text not validated");
		 Log.info("Career description paragraph is successfully displayed and validated under Career opportunities section: "+career_description);
		ExtentTestManager.getTest().log(Status.PASS, "Career description paragraph is successfully displayed and validated under Career opportunities section: "+career_description);
	
		}
		}
	

	public void Validate_Club_positions(String Value, String pos_txt) throws Exception {
		
		if(Value.equalsIgnoreCase("Validate_Club_positions")) 
		{
			home.Navigate_to_Emplyoment_page_ESP("Navigate_to_Emplyoment_page_ESP");
			
		Element_isdisplayed(club_positions);
		String club_positions_txt=driver.findElement(club_positions).getText().trim();
		assertEquals(club_positions_txt.toUpperCase(), pos_txt.toUpperCase().trim(),"Club Positions text not validated");
		ExtentTestManager.getTest().log(Status.PASS, "Club Positions section text is displayed and validated successfully");
		Log.info("Club Positions section text is displayed and validated successfully");
		
		}
	}
	


	public void Validate_Club_positions_Section(String Value, String jobs_title_ip) throws Exception {
		
		if(Value.equalsIgnoreCase("Validate_Club_positions_Section")) 
		{
			home.Navigate_to_Emplyoment_page_ESP("Navigate_to_Emplyoment_page_ESP");	
			
			Element_isdisplayed(club_positions);
			ExtentTestManager.getTest().log(Status.PASS, "Club Positions section is displayed successfully");
			Log.info("Club Positions section is displayed successfully");
			
			List<WebElement> jobs=driver.findElements(club_jobs_titles);
			ExtentTestManager.getTest().log(Status.PASS, jobs.size()+" Club Positions displayed");
			Log.info(jobs.size()+" Club Positions displayed");
			String[] job_count_ip=jobs_title_ip.split(",");
			String js=jobs_title_ip.trim();
			int js_count_op=0;
			 ArrayList<String> op_jobs = new ArrayList<String>();
			for (WebElement job : jobs) {
				String jobs_title=job.getText();
				if (js.toUpperCase().contains(jobs_title.toUpperCase().trim())) {
					ExtentTestManager.getTest().log(Status.PASS, "Club Positions job "+jobs_title+" is displayed and validated successfully");
					Log.info("Club Positions job "+jobs_title+" is displayed and validated successfully");
					js_count_op++;
					if (!job.getText().isEmpty()) op_jobs.add(job.getText().trim());
				}
				
				else {
					ExtentTestManager.getTest().log(Status.FAIL, "Club Positions job "+jobs_title+" not displayed and not validated successfully");
					Log.error("Club Positions job "+jobs_title+" not displayed and not validated successfully");
					if (!job.getText().isEmpty()) op_jobs.add(job.getText().trim());
//					throw new Exception("Club Positions job "+jobs_title+" not displayed and not validated successfully");
					
				}
				
			}	
			
			String delim = ",";
	        String op_jobs_res = String.join(delim, op_jobs);
			
			if(jobs.size()==job_count_ip.length &&job_count_ip.length  ==js_count_op ) {
				ExtentTestManager.getTest().log(Status.PASS, "All Club Positions are displayed and validated successfully");
				Log.info("All Club Positions are displayed and validated successfully");
				
			}
			else {
				ExtentTestManager.getTest().log(Status.FAIL, "All Club Positions are not displayed and not validated successfully: expected [ "+js+" ] actual [ "+op_jobs_res+" ]");
				Log.error("All Club Positions are not displayed and not validated successfully: expected [ "+js+" ] actual [ "+op_jobs_res+" ]");
				throw new Exception("All Club Positions are not displayed and not validated successfully: expected [ "+js+" ] actual [ "+op_jobs_res+" ]");
			}
			
			}
	}



	public void Validate_details_of_Personal_Trainer_position(String Value, String jobs_title_ip, String job_short_des) throws Exception {
		
		if(Value.equalsIgnoreCase("Validate_details_of_Personal_Trainer_position")) 
		{

			Validate_Club_positions_Section("Validate_Club_positions_Section",   jobs_title_ip);
			
			 Element_isdisplayed(PT_image);
			 Log.info("Personal Trainer image is displayed successfully");
			 ExtentTestManager.getTest().log(Status.PASS, "Personal Trainer image is displayed successfully");
			  
			 Element_isdisplayed(PT_title);
			 String title=driver.findElement(PT_title).getText().trim();
			 String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), job_count_ip[0].toUpperCase().trim(), "Club positons job title: "+title+" is not validated");
				 
			 Log.info("Personal Trainers job title is displayed and validated successfully: "+title);
			 ExtentTestManager.getTest().log(Status.PASS, "Personal Trainer job title is displayed and validated successfully: "+title);
			 
			 Element_isdisplayed(PT_J_details);
			 String details=driver.findElement(PT_J_details).getText().replace(".", "").trim();
			 assertEquals(details.toUpperCase().trim(), job_short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
			 Log.info("Personal Trainers job details displayedand validated successfully: "+details);
			 ExtentTestManager.getTest().log(Status.PASS, "Personal Trainers job details displayed and validated  successfully: "+details);
			 
			 Element_isdisplayed(PT_moreinfoL);
			 Log.info("Personal Trainers moreinfo link displayed Successfully");
			 ExtentTestManager.getTest().log(Status.PASS, "Personal Trainers moreinfo link displayed Successfully");
			 
			 Element_isdisplayed(PT_A_H_btn);
			 validate_get_text(PT_A_H_btn, job_count_ip[0]+" Apply Here");
			 Log.info("Personal Trainers apply here button displayed Successfully");
			 ExtentTestManager.getTest().log(Status.PASS, "Personal Trainers apply here button displayed Successfully");
			
		}
		
	}
	

	public void Validate_details_of_Group_Fitness_position(String Value, String jobs_title_ip, String job_short_des) throws Exception {
		
		if(Value.equalsIgnoreCase("Validate_details_of_Group_Fitness_position")) 
		{

			Validate_Club_positions_Section("Validate_Club_positions_Section",   jobs_title_ip);
			
			 Element_isdisplayed(GF_image);
			 Log.info("Group Fitness image is displayed successfully");
			 ExtentTestManager.getTest().log(Status.PASS, "Group fitness image is displayed successfully");
			  
			 Element_isdisplayed(GF_title);
			 String title=driver.findElement(GF_title).getText().trim();
			 String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), job_count_ip[1].toUpperCase().trim(), "Club positons job title: "+title+" is not validated");
			 Log.info("Group Fitness job title is displayed and validated successfully: "+title);
			 ExtentTestManager.getTest().log(Status.PASS, "Group Fitness job title is displayed and validated successfully: "+title);
			 
			 Element_isdisplayed(GF_J_details);
			 String details=driver.findElement(GF_J_details).getText().replace(".", "").trim();
			 assertEquals(details.toUpperCase().trim(), job_short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
			 Log.info("Group Fitness job details displayedand validated successfully: "+details);
			 ExtentTestManager.getTest().log(Status.PASS, "Group Fitness job details displayed and validated  successfully: "+details);
			 
			 Element_isdisplayed(GF_moreinfoL);
			 Log.info("Group Fitness moreinfo link displayed Successfully");
			 ExtentTestManager.getTest().log(Status.PASS, "Group Fitness moreinfo link displayed Successfully");
			 
			 Element_isdisplayed(GF_A_H_btn);
			 validate_get_text(GF_A_H_btn, job_count_ip[1]+" Apply Here");
			 Log.info("Group Fitness apply here button displayed Successfully");
			 ExtentTestManager.getTest().log(Status.PASS, "Group Fitness apply here button displayed Successfully");
			
		}
		
	}
	

	public void Validate_details_of_HIIT_Coach_position(String Value, String jobs_title_ip, String job_short_des) throws Exception {
		
		if(Value.equalsIgnoreCase("Validate_details_of_HIIT_Coach_position")) 
		{

			Validate_Club_positions_Section("Validate_Club_positions_Section",   jobs_title_ip);
			
			 Element_isdisplayed(HC_image);
			 Log.info("HIIT Coach image is displayed successfully");
			 ExtentTestManager.getTest().log(Status.PASS, "HIIT Coach image is displayed successfully");
			  
			 Element_isdisplayed(HC_title);
			 String title=driver.findElement(HC_title).getText().trim();
			 String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), job_count_ip[2].toUpperCase().trim(), "Club positons job title: "+title+" is not validated");
			 Log.info("HIIT Coach job title is displayed and validated successfully: "+title);
			 ExtentTestManager.getTest().log(Status.PASS, "HIIT Coach job title is displayed and validated successfully: "+title);
			 
			 Element_isdisplayed(HC_J_details);
			 String details=driver.findElement(HC_J_details).getText().replace(".", "").trim();
			 assertEquals(details.toUpperCase().trim(), job_short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
			 Log.info("HIIT Coach job details displayedand validated successfully: "+details);
			 ExtentTestManager.getTest().log(Status.PASS, "HIIT Coach job details displayed and validated  successfully: "+details);
			 
			 Element_isdisplayed(HC_moreinfoL);
			 Log.info("HIIT Coach moreinfo link displayed Successfully");
			 ExtentTestManager.getTest().log(Status.PASS, "HIIT Coach moreinfo link displayed Successfully");
			 
			 Element_isdisplayed(HC_A_H_btn);
			 validate_get_text(HC_A_H_btn, job_count_ip[2]+" Apply Here");
			 Log.info("HIIT Coach apply here button displayed Successfully");
			 ExtentTestManager.getTest().log(Status.PASS, "HIIT Coach apply here button displayed Successfully");
			
		}
		
	}
	

	
	public void validate_get_text(By element, String text_ip) throws Exception {
		Element_isdisplayed(element);
		MoveToElement(element);
		String text=	driver.findElement(element).getText().toUpperCase().replace("\n", " ").trim();
		Assert.assertEquals(text, text_ip.toUpperCase().trim(), text_ip.trim()+" text not validated");
		Log.info(text_ip.trim()+" element text is validated successfully");
		ExtentTestManager.getTest().log(Status.PASS, text_ip.trim()+" element text is validated successfully");
		
	}
	
	
	public void validate_get_attribute_text(By element, String value_ip) throws Exception {
		Element_isdisplayed(element);
		MoveToElement(element);
		String text=	driver.findElement(element).getAttribute("value").toUpperCase().replace("\n", " ").trim();
		Assert.assertEquals(text, value_ip.toUpperCase().trim(), value_ip.trim()+" text not validated");
		Log.info(value_ip.trim()+" element is validated successfully");
		ExtentTestManager.getTest().log(Status.PASS, value_ip.trim()+" element is validated successfully");
		
	}
	
	
	public void Select_radio_button(By locator, String value, String radiobutton_name) throws Exception {
		
		Element_isdisplayed(locator);
		ExtentTestManager.getTest().log(Status.PASS, radiobutton_name+ "radio buttons displayed successfully" );
		Log.info(radiobutton_name+ "radio buttons displayed successfully");
		
	
		
	if(value.equalsIgnoreCase(driver.findElement(RadioButtonList18YearsOld_Yes_label).getText().trim()) && value.equalsIgnoreCase("yes")) {
//		String s=driver.findElement(locator).getText().trim();
		if(!driver.findElement(locator).isSelected()) click(locator);
		ExtentTestManager.getTest().log(Status.PASS, radiobutton_name+"Radio button "+value+" selected");
		Log.info(radiobutton_name+"Radio button "+value+" selected");
	}
	else if (value.equalsIgnoreCase(driver.findElement(RadioButtonList18YearsOld_No_label).getText().trim()) && value.equalsIgnoreCase("No")) {
		
		if(!driver.findElement(locator).isSelected())click(locator);
		Thread.sleep(100);
		driver.switchTo().alert().accept();
		Thread.sleep(200);
		ExtentTestManager.getTest().log(Status.PASS, radiobutton_name+"Radio button "+value+" selected");
		Log.info(radiobutton_name+"Radio button "+value+" selected");
		Element_isdisplayed(LabelAtLeast18Error);
		String err=driver.findElement(LabelAtLeast18Error).getText().trim();
		ExtentTestManager.getTest().log(Status.PASS, "error message: "+err+" displayed successfully");
		Log.info("error message: "+err+" displayed successfully");
	}
	
		
	}
	
	public void click_moreinfo_link(int moreinfo) {
		
		List<WebElement> moreinfo_links=driver.findElements(moreinfo_list_club_pos);

		moreinfo_links.get(moreinfo).click();
			
	}
	
	
	public void click_moreinfo_link_corp_pos(int moreinfo) {
		
		List<WebElement> moreinfo_links=driver.findElements(moreinfo_list_corp_pos);

		moreinfo_links.get(moreinfo).click();
			
	}
	
	public void Close_moreinfo_popup() throws Exception {
		
		//img[@id='ctl00_MainContent_JobAdsFeatured_ctl00_ImageURLPopup']
		Element_isdisplayed(moreinfo_popup_close);
		Log.info("Close button is displayed Successfully in popup window");
		ExtentTestManager.getTest().log(Status.PASS, "Close button is displayed Successfully in popup windo");
		Thread.sleep(100);
		click(moreinfo_popup_close);
		Thread.sleep(100);
		Log.info("Successfully clicked on close button in popup window");
		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on close button in popup window");
		
	}

	public void moreinfo_popup_title(String jobs_title_ip, int i) throws Exception {
		
		Element_isdisplayed(moreinfo_popup_title);
		String title=driver.findElement(moreinfo_popup_title).getText();
		String[] job_count_ip=jobs_title_ip.split(",");
		 assertEquals(title.toUpperCase().trim(), job_count_ip[i].toUpperCase().trim(), "Club positons job title: "+title+" is not validated"); 
		Log.info("Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
		 ExtentTestManager.getTest().log(Status.PASS,"Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
	}
	
	public void moreinfo_popup_window_image(int img) throws Exception {
		
		int j=img-1;
		By image=By.xpath("//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsFeatured_ctl0"+j+"_ImageURLPopup']");
		Element_isdisplayed(image);
		Element_isdisplayed(moreinfo_popup_title);
		String title=driver.findElement(moreinfo_popup_title).getText();
		Log.info(title+" image in popup window is displayed successfully");
		 ExtentTestManager.getTest().log(Status.PASS,title+" image in popup window is displayed successfully");
		
		
	}
	
	
	public void corp_moreinfo_popup_window_image(int img) throws Exception {
		
//		int j=img-1;
		By image=By.xpath("//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsCorporate_ctl0"+img+"_ImageURLPopup']");
		Element_isdisplayed(image);
		Element_isdisplayed(moreinfo_popup_title);
		String title=driver.findElement(moreinfo_popup_title).getText();
		Log.info(title+" image in popup window is displayed successfully");
		 ExtentTestManager.getTest().log(Status.PASS,title+" image in popup window is displayed successfully");
		
		
	}
	
	
	
	public void club_add_moreinfo_popup_window_image(int img) throws Exception {
		
//		int j=img-1;
		By image=By.xpath("//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsClub_ctl0"+img+"_ImageURLPopup']");
		Element_isdisplayed(image);
		Element_isdisplayed(moreinfo_popup_title);
		String title=driver.findElement(moreinfo_popup_title).getText();
		Log.info(title+" image in popup window is displayed successfully");
		 ExtentTestManager.getTest().log(Status.PASS,title+" image in popup window is displayed successfully");
		
		
	}
	

	public void Validate_moreinfo_popupwindow_of_GFP(String Value, String jobs_title_ip, String job_short_des,  String Job_long_des) throws Exception {
		
		if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_GFP")) 
		{
			Validate_details_of_Group_Fitness_position("Validate_details_of_Group_Fitness_position",  jobs_title_ip,  job_short_des);

			click(GF_moreinfoL);
			 Log.info("Successfully clicked on Group Fitness moreinfo link");
			 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Group Fitness moreinfo link");
	
			 moreinfo_popup_title(jobs_title_ip, 1);
			
			 Element_isdisplayed(grp_fis_moreinfo_des);
			 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
			 String[] tt=jobs_title_ip.split(",");
			 assertEquals(desc.toUpperCase().trim(), Job_long_des.toUpperCase().trim(), tt[1]+" Job description is not validated");
			 Log.info("full job description displayed and validated successfully: "+desc);
			 ExtentTestManager.getTest().log(Status.PASS, "full job description displayed and validated successfully: "+desc);
			 
			 moreinfo_popup_window_image(2);
			 
			 Close_moreinfo_popup();
			 
		}
		
	}


	public void Validate_moreinfo_popupwindow_of_PTP(String Value, String jobs_title_ip, String job_short_des,  String Job_long_des) throws Exception {
		
		if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_PTP")) 
		{
			Validate_details_of_Personal_Trainer_position("Validate_details_of_Personal_Trainer_position",  jobs_title_ip,  job_short_des );
			 click(PT_moreinfoL);
			 Log.info("Successfully clicked on personal trainer moreinfo link");
			 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on personal trainer moreinfo link");
	
			 moreinfo_popup_title(jobs_title_ip,0);
			 
			 Element_isdisplayed(grp_fis_moreinfo_des);
			 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
			 String[] tt=jobs_title_ip.split(",");
			 assertEquals(desc.toUpperCase().trim(), Job_long_des.toUpperCase().trim(), tt[0]+" Job description is not validated");
			 Log.info("full job description displayed and validated successfully: "+desc);
			 ExtentTestManager.getTest().log(Status.PASS, "full job description displayed and validated successfully: "+desc);
			 
			 moreinfo_popup_window_image(1);
			 
			 Close_moreinfo_popup();
			 
		}
		
	}
		

	public void Validate_moreinfo_popupwindow_of_HCP(String Value, String jobs_title_ip, String job_short_des,  String Job_long_des) throws Exception {
		
		if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_HCP")) 
		{
			Validate_details_of_HIIT_Coach_position("Validate_details_of_HIIT_Coach_position",  jobs_title_ip,  job_short_des);

			click(HC_moreinfoL);
			 Log.info("Successfully clicked on HIIT Coach moreinfo link");
			 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on HIIT Coach moreinfo link");
	
			 moreinfo_popup_title(jobs_title_ip, 2);
			
			 Element_isdisplayed(grp_fis_moreinfo_des);
			 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
			 String[] tt=jobs_title_ip.split(",");
			 assertEquals(desc.toUpperCase().trim(), Job_long_des.toUpperCase().trim(), tt[2]+" Job description is not validated");
			 Log.info("full job description displayed and validated successfully: "+desc);
			 ExtentTestManager.getTest().log(Status.PASS, "full job description displayed and validated successfully: "+desc);
			 
			 moreinfo_popup_window_image(3);
			 
			 Close_moreinfo_popup();
			 
		}
		
	}


public void Validate_AH_btn_followingpos_text(String Value, String jobs_title_ip, String text_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_AH_btn_followingpos_text")) 
	{
	
		Validate_Club_positions("Validate_Club_positions", jobs_title_ip );
		Thread.sleep(300);
		 Element_isdisplayed(A_H_btn);
		 MoveToElement(A_H_btn);
		 
		 Element_isdisplayed(following_positions_text);

		 String[] s= driver.findElement(following_positions_text).getText().split("\n");
		 String text=	s[0].toUpperCase().trim();
			
		 Assert.assertEquals(text, text_ip.toUpperCase().trim(), text_ip.trim()+" text not validated");
		 Log.info(text_ip.trim()+" text is validated successfully");
		 ExtentTestManager.getTest().log(Status.PASS, text_ip.trim()+" text is validated successfully");
		 
		 validate_get_text(A_H_btn, "Apply Here");
		 Log.info("Apply here button displayed Successfully");
		 ExtentTestManager.getTest().log(Status.PASS, "Apply here button displayed Successfully");

	
	
	}
}


public void Validate_details_of_GM(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_details_of_GM")) 
	{

		Validate_AH_btn_followingpos_text("Validate_AH_btn_followingpos_text",jobs_title_ip, text_ip);
	
	 By moreinfo = By.xpath("//div[@class='laJobSelector'][1]//a[@class='moreinfo']");
	 Element_isdisplayed(moreinfo);
	 MoveToElement(moreinfo);
	 
	 By image = By.id("ctl00_MainContent_JobAdsClub_ctl00_ImageJobAd");
	 Element_isdisplayed(image);
	 Log.info("General_Manager job image is displayed successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "General_Manager job image is displayed successfully");
	 
	 By GM = By.xpath("//div[@class='laJobSelector'][1]//strong[contains(text(),'General Manager')]");
	 
	 
	 Element_isdisplayed(GM);
	 String title=driver.findElement(GM).getText().trim();
//	 String[] job_count_ip=jobs_title_ip.split(",");
	 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons title: "+title+" is not validated");
	 Log.info("General_Manager title is displayed and validated successfully: "+title);
	 ExtentTestManager.getTest().log(Status.PASS, "General_Manager title is displayed and validated successfully: "+title);
	 
	
	 
	 By jb_des = By.xpath("//div[@class='laJobSelector'][1]//div[@class='col-xs-12']");
	 
	 Element_isdisplayed(jb_des);
	 String details=driver.findElement(jb_des).getText().trim();
	 assertEquals(details.replace(".", "").toUpperCase().trim(), short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
	 Log.info("General_Manager short description is displayed and validated successfully: "+details);
	 ExtentTestManager.getTest().log(Status.PASS, "General_Manager short description displayed and validated successfully: "+details);
	 
//	
//	 By moreinfo = By.xpath("//div[@class='laJobSelector'][1]//a[@class='moreinfo']");
	 
	 
	 Element_isdisplayed(moreinfo);
	 Log.info("General_Manager moreinfo link displayed Successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "General_Manager moreinfo link displayed Successfully");
	 
		
	}
	
}



public void Validate_moreinfo_popupwindow_of_GM(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des, String team_long_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_GM")) 
	{

		Validate_details_of_GM("Validate_details_of_GM",jobs_title_ip, text_ip, jb_title, short_des);
	
		 By moreinfo = By.xpath("//div[@class='laJobSelector'][1]//a[@class='moreinfo']");
		 Element_isdisplayed(moreinfo);
		 MoveToElement(moreinfo);
		
		 click(moreinfo);
		 Log.info("Successfully clicked on "+jb_title+" moreinfo link");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on "+jb_title+" moreinfo link");

//		 moreinfo_popup_title(jobs_title_ip, 5);
		 
		 	Element_isdisplayed(moreinfo_popup_title);
			String title=driver.findElement(moreinfo_popup_title).getText();
//			String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons job title: "+title+" is not validated"); 
			Log.info("Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
			 ExtentTestManager.getTest().log(Status.PASS,"Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
		
		
		 Element_isdisplayed(grp_fis_moreinfo_des);
		 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
//		 String[] tt=jobs_title_ip.split(",");
		 assertEquals(desc.toUpperCase().trim(), team_long_des.toUpperCase().trim(), jb_title+" team description is not validated");
		 Log.info("full description displayed and validated successfully: "+desc);
		 ExtentTestManager.getTest().log(Status.PASS, "full description displayed and validated successfully: "+desc);
		 
//		 corp_moreinfo_popup_window_image(5);
		 club_add_moreinfo_popup_window_image(0);
		//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsClub_ctl00_ImageURLPopup']
		 
		 Close_moreinfo_popup();
		
		
	
	
		
	}
	
}


public void Validate_details_of_OM(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_details_of_OM")) 
	{

		Validate_AH_btn_followingpos_text("Validate_AH_btn_followingpos_text",jobs_title_ip, text_ip);
		
	By moreinfo = By.xpath("//div[@class='laJobSelector'][3]//a[@class='moreinfo']");
	 Element_isdisplayed(moreinfo);
	 MoveToElement(moreinfo);
	
	 By image = By.id("ctl00_MainContent_JobAdsClub_ctl02_ImageJobAd");
	 Element_isdisplayed(image);
	 Log.info("Operation Manager job image is displayed successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Operation Manager job image is displayed successfully");
	 
	 By GM = By.xpath("//div[@class='laJobSelector'][3]//strong[contains(text(),'Operations Manager')]");
	 
	 
	 Element_isdisplayed(GM);
	 String title=driver.findElement(GM).getText().trim();
//	 String[] job_count_ip=jobs_title_ip.split(",");
	 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons title: "+title+" is not validated");
	 Log.info("Operation Manager title is displayed and validated successfully: "+title);
	 ExtentTestManager.getTest().log(Status.PASS, "Operation Manager title is displayed and validated successfully: "+title);
	 
	
	 
	 By jb_des = By.xpath("//div[@class='laJobSelector'][3]//div[@class='col-xs-12']");
	 
	 Element_isdisplayed(jb_des);
	 String details=driver.findElement(jb_des).getText().trim();
	 assertEquals(details.replace(".", "").toUpperCase().trim(), short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
	 Log.info("Operation Manager short description is displayed and validated successfully: "+details);
	 ExtentTestManager.getTest().log(Status.PASS, "Operation Manager short description displayed and validated successfully: "+details);
	
	 Element_isdisplayed(moreinfo);
	 Log.info("Operation Manager moreinfo link displayed Successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Operation Manager moreinfo link displayed Successfully");
	 
		
	}
	
}


public void Validate_moreinfo_popupwindow_of_OM(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des, String team_long_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_OM")) 
	{

		Validate_details_of_OM("Validate_details_of_OM",jobs_title_ip, text_ip, jb_title, short_des);
	
		 By moreinfo = By.xpath("//div[@class='laJobSelector'][3]//a[@class='moreinfo']");
		 Element_isdisplayed(moreinfo);
		 MoveToElement(moreinfo);
		
		 click(moreinfo);
		 Log.info("Successfully clicked on "+jb_title+" moreinfo link");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on "+jb_title+" moreinfo link");

//		 moreinfo_popup_title(jobs_title_ip, 5);
		 
		 	Element_isdisplayed(moreinfo_popup_title);
			String title=driver.findElement(moreinfo_popup_title).getText();
//			String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons job title: "+title+" is not validated"); 
			Log.info("Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
			 ExtentTestManager.getTest().log(Status.PASS,"Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
		
		
		 Element_isdisplayed(grp_fis_moreinfo_des);
		 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
//		 String[] tt=jobs_title_ip.split(",");
		 assertEquals(desc.toUpperCase().trim(), team_long_des.toUpperCase().trim(), jb_title+" team description is not validated");
		 Log.info("full description displayed and validated successfully: "+desc);
		 ExtentTestManager.getTest().log(Status.PASS, "full description displayed and validated successfully: "+desc);
		 
//		 corp_moreinfo_popup_window_image(5);
		 club_add_moreinfo_popup_window_image(2);
		//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsClub_ctl00_ImageURLPopup']
		 
		 Close_moreinfo_popup();
		
		
	}
	
}


public void Validate_details_of_PTD(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_details_of_PTD")) 
	{

		Validate_AH_btn_followingpos_text("Validate_AH_btn_followingpos_text",jobs_title_ip, text_ip);
		
	 By moreinfo = By.xpath("//div[@class='laJobSelector'][2]//a[@class='moreinfo']");
	 Element_isdisplayed(moreinfo);
	 MoveToElement(moreinfo);
	
	 By image = By.id("ctl00_MainContent_JobAdsClub_ctl01_ImageJobAd");
	 Element_isdisplayed(image);
	 Log.info("Personal Training Director job image is displayed successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Director job image is displayed successfully");
	 
	 By GM = By.xpath("//div[@class='laJobSelector'][2]//strong[contains(text(),'Personal Training Director')]");
	 
	 
	 Element_isdisplayed(GM);
	 String title=driver.findElement(GM).getText().trim();
//	 String[] job_count_ip=jobs_title_ip.split(",");
	 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons title: "+title+" is not validated");
	 Log.info("Personal Training Director title is displayed and validated successfully: "+title);
	 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Director title is displayed and validated successfully: "+title);
	 
	
	 
	 By jb_des = By.xpath("//div[@class='laJobSelector'][2]//div[@class='col-xs-12']");
	 
	 Element_isdisplayed(jb_des);
	 String details=driver.findElement(jb_des).getText().trim();
	 assertEquals(details.replace(".", "").toUpperCase().trim(), short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
	 Log.info("Personal Training Director short description is displayed and validated successfully: "+details);
	 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Director short description displayed and validated successfully: "+details);
	 

	 Element_isdisplayed(moreinfo);
	 Log.info("Personal Training Director moreinfo link displayed Successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Director moreinfo link displayed Successfully");
	 
		
	}
	
}


public void Validate_details_of_ET(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_details_of_ET")) 
	{

		Validate_AH_btn_followingpos_text("Validate_AH_btn_followingpos_text",jobs_title_ip, text_ip);
		
	 By moreinfo = By.xpath("//div[@class='laJobSelector'][4]//a[@class='moreinfo']");
	 Element_isdisplayed(moreinfo);
	 MoveToElement(moreinfo);
	
	 By image = By.id("ctl00_MainContent_JobAdsClub_ctl03_ImageJobAd");
	 Element_isdisplayed(image);
	 Log.info("Equipment Tech job image is displayed successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Equipment Tech job image is displayed successfully");
	 
	 By GM = By.xpath("//div[@class='laJobSelector'][4]//strong[contains(text(),'Equipment Tech')]");
	 
	 
	 Element_isdisplayed(GM);
	 String title=driver.findElement(GM).getText().trim();
//	 String[] job_count_ip=jobs_title_ip.split(",");
	 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons title: "+title+" is not validated");
	 Log.info("Equipment Tech title is displayed and validated successfully: "+title);
	 ExtentTestManager.getTest().log(Status.PASS, "Equipment Tech title is displayed and validated successfully: "+title);
	
	 
	 By jb_des = By.xpath("//div[@class='laJobSelector'][4]//div[@class='col-xs-12']");
	 
	 Element_isdisplayed(jb_des);
	 String details=driver.findElement(jb_des).getText().trim();
	 assertEquals(details.replace(".", "").toUpperCase().trim(), short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
	 Log.info("Equipment Tech short description is displayed and validated successfully: "+details);
	 ExtentTestManager.getTest().log(Status.PASS, "Equipment Tech short description displayed and validated successfully: "+details);
	 
	 Element_isdisplayed(moreinfo);
	 Log.info("Equipment Tech moreinfo link displayed Successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Equipment Tech moreinfo link displayed Successfully");
	 
		
	}
	
}


public void Validate_details_of_LSD(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_details_of_LSD")) 
	{

		Validate_AH_btn_followingpos_text("Validate_AH_btn_followingpos_text",jobs_title_ip, text_ip);
		

	 By moreinfo = By.xpath("//div[@class='laJobSelector'][5]//a[@class='moreinfo']");
	 Element_isdisplayed(moreinfo);
	 MoveToElement(moreinfo);
	
	 By image = By.id("ctl00_MainContent_JobAdsClub_ctl04_ImageJobAd");
	 Element_isdisplayed(image);
	 Log.info("League Sports Director job image is displayed successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "League Sports Director job image is displayed successfully");
	 
	 By GM = By.xpath("//div[@class='laJobSelector'][5]//strong[contains(text(),'League Sports Director')]");
	 
	 
	 Element_isdisplayed(GM);
	 String title=driver.findElement(GM).getText().trim();
//	 String[] job_count_ip=jobs_title_ip.split(",");
	 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons title: "+title+" is not validated");
	 Log.info("League Sports Director title is displayed and validated successfully: "+title);
	 ExtentTestManager.getTest().log(Status.PASS, "League Sports Director title is displayed and validated successfully: "+title);
	 
	
	 
	 By jb_des = By.xpath("//div[@class='laJobSelector'][5]//div[@class='col-xs-12']");
	 
	 Element_isdisplayed(jb_des);
	 String details=driver.findElement(jb_des).getText().trim();
	 assertEquals(details.replace(".", "").toUpperCase().trim(), short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
	 Log.info("League Sports Director short description is displayed and validated successfully: "+details);
	 ExtentTestManager.getTest().log(Status.PASS, "League Sports Director short description displayed and validated successfully: "+details);
	 
	 Element_isdisplayed(moreinfo);
	 Log.info("League Sports Director moreinfo link displayed Successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "League Sports Director moreinfo link displayed Successfully");
	 
		
	}
	
}



public void Validate_details_of_MC(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_details_of_MC")) 
	{

		Validate_AH_btn_followingpos_text("Validate_AH_btn_followingpos_text",jobs_title_ip, text_ip);
		
	 By moreinfo = By.xpath("//div[@class='laJobSelector'][6]//a[@class='moreinfo']");
	 Element_isdisplayed(moreinfo);
	 MoveToElement(moreinfo);
	
	 By image = By.id("ctl00_MainContent_JobAdsClub_ctl05_ImageJobAd");
	 Element_isdisplayed(image);
	 Log.info("Membership Counselorjob image is displayed successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Membership Counselor job image is displayed successfully");
	 
	 By GM = By.xpath("//div[@class='laJobSelector'][6]//strong[contains(text(),'Membership Counselor')]");
	 
	 
	 Element_isdisplayed(GM);
	 String title=driver.findElement(GM).getText().trim();
//	 String[] job_count_ip=jobs_title_ip.split(",");
	 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons title: "+title+" is not validated");
	 Log.info("Membership Counselor title is displayed and validated successfully: "+title);
	 ExtentTestManager.getTest().log(Status.PASS, "Membership Counselor title is displayed and validated successfully: "+title);
	 
	
	 
	 By jb_des = By.xpath("//div[@class='laJobSelector'][6]//div[@class='col-xs-12']");
	 
	 Element_isdisplayed(jb_des);
	 String details=driver.findElement(jb_des).getText().trim();
	 assertEquals(details.replace(".", "").toUpperCase().trim(), short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
	 Log.info("Membership Counselor short description is displayed and validated successfully: "+details);
	 ExtentTestManager.getTest().log(Status.PASS, "Membership Counselor short description displayed and validated successfully: "+details);
	 
	
	
	 
	 
	 Element_isdisplayed(moreinfo);
	 Log.info("Membership Counselor moreinfo link displayed Successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Membership Counselor moreinfo link displayed Successfully");
	 
		
	}
	
}



public void Validate_details_of_PTMC(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_details_of_PTMC")) 
	{

		Validate_AH_btn_followingpos_text("Validate_AH_btn_followingpos_text",jobs_title_ip, text_ip);
		
	 By moreinfo = By.xpath("//div[@class='laJobSelector'][7]//a[@class='moreinfo']");
	 Element_isdisplayed(moreinfo);
	 MoveToElement(moreinfo);
	
	 By image = By.id("ctl00_MainContent_JobAdsClub_ctl06_ImageJobAd");
	 Element_isdisplayed(image);
	 Log.info("Personal Training Membership Counselor job image is displayed successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Membership Counselor job image is displayed successfully");
	 
	 By GM = By.xpath("//div[@class='laJobSelector'][7]//strong[contains(text(),'Personal Training Membership Counselor')]");
	 
	 
	 Element_isdisplayed(GM);
	 String title=driver.findElement(GM).getText().trim();
//	 String[] job_count_ip=jobs_title_ip.split(",");
	 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons title: "+title+" is not validated");
	 Log.info("Personal Training Membership Counselor title is displayed and validated successfully: "+title);
	 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Membership Counselor title is displayed and validated successfully: "+title);
	 
	
	 
	 By jb_des = By.xpath("//div[@class='laJobSelector'][7]//div[@class='col-xs-12']");
	 
	 Element_isdisplayed(jb_des);
	 String details=driver.findElement(jb_des).getText().trim();
	 assertEquals(details.replace(".", "").toUpperCase().trim(), short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
	 Log.info("Personal Training Membership Counselor short description is displayed and validated successfully: "+details);
	 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Membership Counselor short description displayed and validated successfully: "+details);

	 Element_isdisplayed(moreinfo);
	 Log.info("Personal Training Membership Counselor moreinfo link displayed Successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Membership Counselor moreinfo link displayed Successfully");
	 
		
	}
	
}



public void Validate_details_of_CS(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_details_of_CS")) 
	{

		Validate_AH_btn_followingpos_text("Validate_AH_btn_followingpos_text",jobs_title_ip, text_ip);
		
	 By moreinfo = By.xpath("//div[@class='laJobSelector'][8]//a[@class='moreinfo']");
	 Element_isdisplayed(moreinfo);
	 MoveToElement(moreinfo);
	
	 By image = By.id("ctl00_MainContent_JobAdsClub_ctl07_ImageJobAd");
	 Element_isdisplayed(image);
	 Log.info("Club Staff job image is displayed successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Club Staff job image is displayed successfully");
	 
	 By GM = By.xpath("//div[@class='laJobSelector'][8]//strong[contains(text(),'Club Staff')]");
	 
	 
	 Element_isdisplayed(GM);
	 String title=driver.findElement(GM).getText().trim();
//	 String[] job_count_ip=jobs_title_ip.split(",");
	 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons title: "+title+" is not validated");
	 Log.info("Club Staff title is displayed and validated successfully: "+title);
	 ExtentTestManager.getTest().log(Status.PASS, "Club Staff title is displayed and validated successfully: "+title);
	 
	
	 
	 By jb_des = By.xpath("//div[@class='laJobSelector'][8]//div[@class='col-xs-12']");
	 
	 Element_isdisplayed(jb_des);
	 String details=driver.findElement(jb_des).getText().trim();
	 assertEquals(details.replace(".", "").toUpperCase().trim(), short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
	 Log.info("Club Staff short description is displayed and validated successfully: "+details);
	 ExtentTestManager.getTest().log(Status.PASS, "Club Staff short description displayed and validated successfully: "+details);

	 Element_isdisplayed(moreinfo);
	 Log.info("Club Staff moreinfo link displayed Successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Club Staff moreinfo link displayed Successfully");
	 
		
	}
	
}



public void Validate_details_of_HVAC_BM(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_details_of_HVAC_BM")) 
	{

		Validate_AH_btn_followingpos_text("Validate_AH_btn_followingpos_text",jobs_title_ip, text_ip);
		
	 By moreinfo = By.xpath("//div[@class='laJobSelector'][9]//a[@class='moreinfo']");
	 Element_isdisplayed(moreinfo);
	 MoveToElement(moreinfo);
	
	 By image = By.id("ctl00_MainContent_JobAdsClub_ctl08_ImageJobAd");
	 Element_isdisplayed(image);
	 Log.info("HVAC/Building Maintenance job image is displayed successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "HVAC/Building Maintenance job image is displayed successfully");
	 
	 By GM = By.xpath("//div[@class='laJobSelector'][9]//strong[contains(text(),'HVAC/Building Maintenance')]");
	 
	 
	 Element_isdisplayed(GM);
	 String title=driver.findElement(GM).getText().trim();
//	 String[] job_count_ip=jobs_title_ip.split(",");
	 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons title: "+title+" is not validated");
	 Log.info("HVAC/Building Maintenance title is displayed and validated successfully: "+title);
	 ExtentTestManager.getTest().log(Status.PASS, "HVAC/Building Maintenance title is displayed and validated successfully: "+title);
	 
	
	 
	 By jb_des = By.xpath("//div[@class='laJobSelector'][9]//div[@class='col-xs-12']");
	 
	 Element_isdisplayed(jb_des);
	 String details=driver.findElement(jb_des).getText().trim();
	 assertEquals(details.replace(".", "").toUpperCase().trim(), short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
	 Log.info("HVAC/Building Maintenance short description is displayed and validated successfully: "+details);
	 ExtentTestManager.getTest().log(Status.PASS, "HVAC/Building Maintenance short description displayed and validated successfully: "+details);
	 
	 Element_isdisplayed(moreinfo);
	 Log.info("HVAC/Building Maintenance moreinfo link displayed Successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "HVAC/Building Maintenance moreinfo link displayed Successfully");
	 
		
	}
	
}



public void Validate_details_of_CP_J(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_details_of_CP_J")) 
	{

		Validate_AH_btn_followingpos_text("Validate_AH_btn_followingpos_text",jobs_title_ip, text_ip);
		
	 By moreinfo = By.xpath("//div[@class='laJobSelector'][10]//a[@class='moreinfo']");
	 Element_isdisplayed(moreinfo);
	 MoveToElement(moreinfo);
	
	 By image = By.id("ctl00_MainContent_JobAdsClub_ctl09_ImageJobAd");
	 Element_isdisplayed(image);
	 Log.info("Club Pride/Janitor job image is displayed successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Club Pride/Janitor job image is displayed successfully");
	 
	 By GM = By.xpath("//div[@class='laJobSelector'][10]//strong[contains(text(),'Club Pride/Janitor')]");
	 
	 
	 Element_isdisplayed(GM);
	 String title=driver.findElement(GM).getText().trim();
//	 String[] job_count_ip=jobs_title_ip.split(",");
	 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons title: "+title+" is not validated");
	 Log.info("Club Pride/Janitor title is displayed and validated successfully: "+title);
	 ExtentTestManager.getTest().log(Status.PASS, "Club Pride/Janitor title is displayed and validated successfully: "+title);
	 
	
	 
	 By jb_des = By.xpath("//div[@class='laJobSelector'][10]//div[@class='col-xs-12']");
	 
	 Element_isdisplayed(jb_des);
	 String details=driver.findElement(jb_des).getText().trim();
	 assertEquals(details.replace(".", "").toUpperCase().trim(), short_des.toUpperCase().replace(".", "").trim(), title+" short description is not validated");
	 Log.info("Club Pride/Janitor short description is displayed and validated successfully: "+details);
	 ExtentTestManager.getTest().log(Status.PASS, "Club Pride/Janitor short description displayed and validated successfully: "+details);
	 
	 Element_isdisplayed(moreinfo);
	 Log.info("Club Pride/Janitor moreinfo link displayed Successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Club Pride/Janitor moreinfo link displayed Successfully");
	 
		
	}
	
}


public void Validate_moreinfo_popupwindow_of_PTD(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des, String team_long_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_PTD")) 
	{

		Validate_details_of_PTD("Validate_details_of_PTD",jobs_title_ip, text_ip, jb_title, short_des);
	
		 By moreinfo = By.xpath("//div[@class='laJobSelector'][2]//a[@class='moreinfo']");
		 Element_isdisplayed(moreinfo);
		 MoveToElement(moreinfo);
		
		 click(moreinfo);
		 Log.info("Successfully clicked on "+jb_title+" moreinfo link");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on "+jb_title+" moreinfo link");

//		 moreinfo_popup_title(jobs_title_ip, 5);
		 
		 	Element_isdisplayed(moreinfo_popup_title);
			String title=driver.findElement(moreinfo_popup_title).getText();
//			String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons job title: "+title+" is not validated"); 
			Log.info("Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
			 ExtentTestManager.getTest().log(Status.PASS,"Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
		
		
		 Element_isdisplayed(grp_fis_moreinfo_des);
		 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
//		 String[] tt=jobs_title_ip.split(",");
		 assertEquals(desc.toUpperCase().trim(), team_long_des.toUpperCase().trim(), jb_title+" team description is not validated");
		 Log.info("full description displayed and validated successfully: "+desc);
		 ExtentTestManager.getTest().log(Status.PASS, "full description displayed and validated successfully: "+desc);
		 
//		 corp_moreinfo_popup_window_image(5);
		 club_add_moreinfo_popup_window_image(1);
		//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsClub_ctl00_ImageURLPopup']
		 
		 Close_moreinfo_popup();
		
		
	
	
		
	}
	
}


public void Validate_moreinfo_popupwindow_of_MC(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des, String team_long_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_MC")) 
	{

		Validate_details_of_MC("Validate_details_of_MC",jobs_title_ip, text_ip, jb_title, short_des);
	
		 By moreinfo = By.xpath("//div[@class='laJobSelector'][6]//a[@class='moreinfo']");
		 Element_isdisplayed(moreinfo);
		 MoveToElement(moreinfo);
		
		 click(moreinfo);
		 Log.info("Successfully clicked on "+jb_title+" moreinfo link");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on "+jb_title+" moreinfo link");

//		 moreinfo_popup_title(jobs_title_ip, 5);
		 
		 	Element_isdisplayed(moreinfo_popup_title);
			String title=driver.findElement(moreinfo_popup_title).getText();
//			String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons job title: "+title+" is not validated"); 
			Log.info("Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
			 ExtentTestManager.getTest().log(Status.PASS,"Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
		
		
		 Element_isdisplayed(grp_fis_moreinfo_des);
		 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
//		 String[] tt=jobs_title_ip.split(",");
		 assertEquals(desc.toUpperCase().trim(), team_long_des.toUpperCase().trim(), jb_title+" team description is not validated");
		 Log.info("full description displayed and validated successfully: "+desc);
		 ExtentTestManager.getTest().log(Status.PASS, "full description displayed and validated successfully: "+desc);
		 
//		 corp_moreinfo_popup_window_image(5);
		 club_add_moreinfo_popup_window_image(5);
		//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsClub_ctl00_ImageURLPopup']
		 
		 Close_moreinfo_popup();
		
		
	
	
		
	}
	
}


public void Validate_moreinfo_popupwindow_of_PTMC(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des, String team_long_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_PTMC")) 
	{

		Validate_details_of_PTMC("Validate_details_of_PTMC",jobs_title_ip, text_ip, jb_title, short_des);
	
		 By moreinfo = By.xpath("//div[@class='laJobSelector'][7]//a[@class='moreinfo']");
		 Element_isdisplayed(moreinfo);
		 MoveToElement(moreinfo);
		
		 click(moreinfo);
		 Log.info("Successfully clicked on "+jb_title+" moreinfo link");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on "+jb_title+" moreinfo link");

//		 moreinfo_popup_title(jobs_title_ip, 5);
		 
		 	Element_isdisplayed(moreinfo_popup_title);
			String title=driver.findElement(moreinfo_popup_title).getText();
//			String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons job title: "+title+" is not validated"); 
			Log.info("Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
			 ExtentTestManager.getTest().log(Status.PASS,"Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
		
		
		 Element_isdisplayed(grp_fis_moreinfo_des);
		 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
//		 String[] tt=jobs_title_ip.split(",");
		 assertEquals(desc.toUpperCase().trim(), team_long_des.toUpperCase().trim(), jb_title+" team description is not validated");
		 Log.info("full description displayed and validated successfully: "+desc);
		 ExtentTestManager.getTest().log(Status.PASS, "full description displayed and validated successfully: "+desc);
		 
//		 corp_moreinfo_popup_window_image(5);
		 club_add_moreinfo_popup_window_image(6);
		//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsClub_ctl00_ImageURLPopup']
		 
		 Close_moreinfo_popup();
		
		
	
	
		
	}
	
}


public void Validate_moreinfo_popupwindow_of_CS(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des, String team_long_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_CS")) 
	{

		Validate_details_of_CS("Validate_details_of_CS",jobs_title_ip, text_ip, jb_title, short_des);
	
		 By moreinfo = By.xpath("//div[@class='laJobSelector'][8]//a[@class='moreinfo']");
		 Element_isdisplayed(moreinfo);
		 MoveToElement(moreinfo);
		
		 click(moreinfo);
		 Log.info("Successfully clicked on "+jb_title+" moreinfo link");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on "+jb_title+" moreinfo link");

//		 moreinfo_popup_title(jobs_title_ip, 5);
		 
		 	Element_isdisplayed(moreinfo_popup_title);
			String title=driver.findElement(moreinfo_popup_title).getText();
//			String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons job title: "+title+" is not validated"); 
			Log.info("Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
			 ExtentTestManager.getTest().log(Status.PASS,"Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
		
		
		 Element_isdisplayed(grp_fis_moreinfo_des);
		 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
//		 String[] tt=jobs_title_ip.split(",");
		 assertEquals(desc.toUpperCase().trim(), team_long_des.toUpperCase().trim(), jb_title+" team description is not validated");
		 Log.info("full description displayed and validated successfully: "+desc);
		 ExtentTestManager.getTest().log(Status.PASS, "full description displayed and validated successfully: "+desc);
		 
//		 corp_moreinfo_popup_window_image(5);
		 club_add_moreinfo_popup_window_image(7);
		//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsClub_ctl00_ImageURLPopup']
		 
		 Close_moreinfo_popup();
		
		
	
	
		
	}
	
}


public void Validate_moreinfo_popupwindow_of_LSD(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des, String team_long_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_LSD")) 
	{

		Validate_details_of_LSD("Validate_details_of_LSD",jobs_title_ip, text_ip, jb_title, short_des);
	
		 By moreinfo = By.xpath("//div[@class='laJobSelector'][5]//a[@class='moreinfo']");
		 Element_isdisplayed(moreinfo);
		 MoveToElement(moreinfo);
		
		 click(moreinfo);
		 Log.info("Successfully clicked on "+jb_title+" moreinfo link");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on "+jb_title+" moreinfo link");

//		 moreinfo_popup_title(jobs_title_ip, 5);
		 
		 	Element_isdisplayed(moreinfo_popup_title);
			String title=driver.findElement(moreinfo_popup_title).getText();
//			String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons job title: "+title+" is not validated"); 
			Log.info("Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
			 ExtentTestManager.getTest().log(Status.PASS,"Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
		
		
		 Element_isdisplayed(grp_fis_moreinfo_des);
		 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
//		 String[] tt=jobs_title_ip.split(",");
		 assertEquals(desc.toUpperCase().trim(), team_long_des.toUpperCase().trim(), jb_title+" team description is not validated");
		 Log.info("full description displayed and validated successfully: "+desc);
		 ExtentTestManager.getTest().log(Status.PASS, "full description displayed and validated successfully: "+desc);
		 
//		 corp_moreinfo_popup_window_image(5);
		 club_add_moreinfo_popup_window_image(4);
		//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsClub_ctl00_ImageURLPopup']
		 
		 Close_moreinfo_popup();
		
		
	
	
		
	}
	
}



public void Validate_moreinfo_popupwindow_of_ET(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des, String team_long_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_ET")) 
	{

		Validate_details_of_ET("Validate_details_of_ET",jobs_title_ip, text_ip, jb_title, short_des);
	
		 By moreinfo = By.xpath("//div[@class='laJobSelector'][4]//a[@class='moreinfo']");
		 Element_isdisplayed(moreinfo);
		 MoveToElement(moreinfo);
		
		 click(moreinfo);
		 Log.info("Successfully clicked on "+jb_title+" moreinfo link");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on "+jb_title+" moreinfo link");

//		 moreinfo_popup_title(jobs_title_ip, 5);
		 
		 	Element_isdisplayed(moreinfo_popup_title);
			String title=driver.findElement(moreinfo_popup_title).getText();
//			String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons job title: "+title+" is not validated"); 
			Log.info("Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
			 ExtentTestManager.getTest().log(Status.PASS,"Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
		
		
		 Element_isdisplayed(grp_fis_moreinfo_des);
		 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
//		 String[] tt=jobs_title_ip.split(",");
		 assertEquals(desc.toUpperCase().trim(), team_long_des.toUpperCase().trim(), jb_title+" team description is not validated");
		 Log.info("full description displayed and validated successfully: "+desc);
		 ExtentTestManager.getTest().log(Status.PASS, "full description displayed and validated successfully: "+desc);
		 
//		 corp_moreinfo_popup_window_image(5);
		 club_add_moreinfo_popup_window_image(3);
		//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsClub_ctl00_ImageURLPopup']
		 
		 Close_moreinfo_popup();
		
		
	}
	
}


public void Validate_moreinfo_popupwindow_of_HVAC_BM(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des, String team_long_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_HVAC_BM")) 
	{

		Validate_details_of_HVAC_BM("Validate_details_of_HVAC_BM",jobs_title_ip, text_ip, jb_title, short_des);
	
		 By moreinfo = By.xpath("//div[@class='laJobSelector'][9]//a[@class='moreinfo']");
		 Element_isdisplayed(moreinfo);
		 MoveToElement(moreinfo);
		
		 click(moreinfo);
		 Log.info("Successfully clicked on "+jb_title+" moreinfo link");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on "+jb_title+" moreinfo link");

//		 moreinfo_popup_title(jobs_title_ip, 5);
		 
		 	Element_isdisplayed(moreinfo_popup_title);
			String title=driver.findElement(moreinfo_popup_title).getText();
//			String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons job title: "+title+" is not validated"); 
			Log.info("Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
			 ExtentTestManager.getTest().log(Status.PASS,"Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
		
		
		 Element_isdisplayed(grp_fis_moreinfo_des);
		 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
//		 String[] tt=jobs_title_ip.split(",");
		 assertEquals(desc.toUpperCase().trim(), team_long_des.toUpperCase().trim(), jb_title+" team description is not validated");
		 Log.info("full description displayed and validated successfully: "+desc);
		 ExtentTestManager.getTest().log(Status.PASS, "full description displayed and validated successfully: "+desc);
		 
//		 corp_moreinfo_popup_window_image(5);
		 club_add_moreinfo_popup_window_image(8);
		//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsClub_ctl00_ImageURLPopup']
		 
		 Close_moreinfo_popup();
		
		
	
	
		
	}
	
}



public void Validate_moreinfo_popupwindow_of_CP_J(String Value,String jobs_title_ip, String text_ip, String jb_title,String short_des, String team_long_des) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_moreinfo_popupwindow_of_CP_J")) 
	{

		Validate_details_of_CP_J("Validate_details_of_CP_J",jobs_title_ip, text_ip, jb_title, short_des);
	
		 By moreinfo = By.xpath("//div[@class='laJobSelector'][10]//a[@class='moreinfo']");
		 Element_isdisplayed(moreinfo);
		 MoveToElement(moreinfo);
		
		 click(moreinfo);
		 Log.info("Successfully clicked on "+jb_title+" moreinfo link");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on "+jb_title+" moreinfo link");

//		 moreinfo_popup_title(jobs_title_ip, 5);
		 
		 	Element_isdisplayed(moreinfo_popup_title);
			String title=driver.findElement(moreinfo_popup_title).getText();
//			String[] job_count_ip=jobs_title_ip.split(",");
			 assertEquals(title.toUpperCase().trim(), jb_title.toUpperCase().trim(), "Club positons job title: "+title+" is not validated"); 
			Log.info("Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
			 ExtentTestManager.getTest().log(Status.PASS,"Moreinfo pop up window is displayed and "+title+" title in popup window is displayed and validated successfully");
		
		
		 Element_isdisplayed(grp_fis_moreinfo_des);
		 String desc=driver.findElement(grp_fis_moreinfo_des).getText().trim();
//		 String[] tt=jobs_title_ip.split(",");
		 assertEquals(desc.toUpperCase().trim(), team_long_des.toUpperCase().trim(), jb_title+" team description is not validated");
		 Log.info("full description displayed and validated successfully: "+desc);
		 ExtentTestManager.getTest().log(Status.PASS, "full description displayed and validated successfully: "+desc);
		 
//		 corp_moreinfo_popup_window_image(5);
		 club_add_moreinfo_popup_window_image(9);
		//div[@class='modal-content']//img[@id='ctl00_MainContent_JobAdsClub_ctl00_ImageURLPopup']
		 
		 Close_moreinfo_popup();
		
		
	}
	
}



public void Validate_GF_applyhere_button(String Value) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_GF_applyhere_button")) 
	{
		
		home.Navigate_to_Emplyoment_page_ESP("Navigate_to_Emplyoment_page_ESP");	
		
		 Element_isdisplayed(Group_F_apply_here_button);
		 MoveToElement(Group_F_apply_here_button);
		 validate_get_text(Group_F_apply_here_button, "Group Fitness Apply Here");
		 Log.info("Group Fitness apply here button displayed Successfully");
		 ExtentTestManager.getTest().log(Status.PASS, "Group Fitness apply here button displayed Successfully");
		 
		 click(Group_F_apply_here_button);
		 Log.info("Successfully clicked on Group Fitness apply here button displayed ");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Group Fitness apply here button displayed ");
		 Thread.sleep(200);
		 String t=driver.getTitle();
		Assert.assertEquals(t.toUpperCase().trim(), "Esporta Fitness | Submit Application".toUpperCase().trim(), "Esporta Fitness | Submit Application title not validated and not navigatd to Emplyoment_page");
		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Submit Application page: "+t);
		Log.info("Successfully navigated to Submit Application page: "+t);
		
	}
	
}
	

public void Validate_Personal_T_applyhere_button(String Value) throws Exception {

if(Value.equalsIgnoreCase("Validate_Personal_T_applyhere_button")) 
{
	
	home.Navigate_to_Emplyoment_page_ESP("Navigate_to_Emplyoment_page_ESP");	
	
	 Element_isdisplayed(Personal_T_apply_here_button);
	 MoveToElement(Personal_T_apply_here_button);
	 validate_get_text(Personal_T_apply_here_button, "Personal Trainer Apply Here");
	 Log.info("Personal Trainer apply here button displayed Successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "Personal Trainer apply here button displayed Successfully");
	 
	 click(Personal_T_apply_here_button);
	 Log.info("Successfully clicked on Personal Trainer apply here button displayed ");
	 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Personal Trainer apply here button displayed ");
	 Thread.sleep(200);
	 String t=driver.getTitle();
	Assert.assertEquals(t.toUpperCase().trim(), "Esporta Fitness | Submit Application".toUpperCase().trim(), "Esporta Fitness | Submit Application title not validated and not navigatd to Emplyoment_page");
	ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Submit Application page: "+t);
	Log.info("Successfully navigated to Submit Application page: "+t);
	
}



}


public void Validate_HIIT_C_applyhere_button(String Value) throws Exception {

if(Value.equalsIgnoreCase("Validate_HIIT_C_applyhere_button")) 
{
	
	home.Navigate_to_Emplyoment_page_ESP("Navigate_to_Emplyoment_page_ESP");	
	
	 Element_isdisplayed(Hiit_c_apply_here_button);
	 MoveToElement(Hiit_c_apply_here_button);
	 validate_get_text(Hiit_c_apply_here_button, "HIIT Coach Apply Here");
	 Log.info("HIIT Coach apply here button displayed Successfully");
	 ExtentTestManager.getTest().log(Status.PASS, "HIIT Coach apply here button displayed Successfully");
	 
	 click(Hiit_c_apply_here_button);
	 Log.info("Successfully clicked on HIIT Coach apply here button displayed ");
	 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on HIIT Coach apply here button displayed ");
	 Thread.sleep(200);
	 String t=driver.getTitle();
	Assert.assertEquals(t.toUpperCase().trim(), "Esporta Fitness | Submit Application".toUpperCase().trim(), "Esporta Fitness | Submit Application title not validated and not navigatd to Emplyoment_page");
	ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Submit Application page: "+t);
	Log.info("Successfully navigated to Submit Application page: "+t);
	
}



}


public void Validate_Apply_Here_button(String Value) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Apply_Here_button")) 
	{
		
//		Validate_AH_btn_followingpos_text("Validate_AH_btn_followingpos_text",jobs_title_ip, text_ip);	
		home.Navigate_to_Emplyoment_page_ESP("Navigate_to_Emplyoment_page_ESP");
		Thread.sleep(300);
		 Element_isdisplayed(A_H_btn);
		 MoveToElement(A_H_btn);
		 validate_get_text(A_H_btn, "Apply Here");
		 Log.info("Apply here button displayed Successfully");
		 ExtentTestManager.getTest().log(Status.PASS, "Apply here button displayed Successfully");

		 click(A_H_btn);
		 Log.info("Successfully clicked on Apply Here button displayed ");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Apply Here button displayed ");
		 Thread.sleep(200);
		 String t=driver.getTitle();
		Assert.assertEquals(t.toUpperCase().trim(), "Esporta Fitness | Submit Application".toUpperCase().trim(), "Esporta Fitness | Submit Application title not validated and not navigatd to Emplyoment_page");
		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Submit Application page: "+t);
		Log.info("Successfully navigated to Submit Application page: "+t);
		
	}
	
}
	
public void Validate_emp_para_AH(String Value, String para_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_emp_para_AH")) 
	{

		Validate_Apply_Here_button("Validate_Apply_Here_button");
		
//		By para = By.xpath("//div[@id='centerContent1']//div[@class='col-sm-12']/p");
		  By para = By.xpath("//p[contains(text(),'Fitness International, LLC, is an equal opportunity employer who recogniz')]/..");
		
//		List<WebElement> para_op=driver.findElements(para);
		Element_isdisplayed(para);
		String Text_FitnessFull = driver.findElement(para).getText().replaceAll("\n+", " ").trim();
		
		Assert.assertEquals(Text_FitnessFull.toUpperCase(),para_ip.trim().toUpperCase(),"Employment Application paragraph text not validated");
		Log.info("Employment Application paragraph text validated successfully : " + para_ip);
		ExtentTestManager.getTest().log(Status.PASS, "Employment Application paragraph text validated successfully : " + para_ip);
	
	
	}
}


public void Validate_App_info_text_AH(String Value, String Text_input) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_App_info_text_AH")) 
	{
		Validate_Apply_Here_button("Validate_Apply_Here_button");
//		Validate_AH_btn_under_club_pos("Validate_AH_btn_under_club_pos",jobs_title_ip, text_ip);
		
		By app_infotext= By.xpath("//div[@id='pnl_contact_info']//div[@class='panel-heading']");
		Element_isdisplayed(app_infotext);
		String Text_AppInfo = driver.findElement(app_infotext).getText().replaceAll("\n+", " ").trim();
//		String Text_ContLocinfo = driver.findElement(Text_CandLInfo).getText();
//		String Text_Appinfo_COnInfo = Text_AppInfo+" "+ Text_ContLocinfo;
		Assert.assertEquals(Text_AppInfo.toUpperCase(),Text_input.trim().toUpperCase(),Text_input+" text not validated");
		Log.info(Text_input+" text validated successfully");
		ExtentTestManager.getTest().log(Status.PASS, Text_input+" text validated successfully");
	
	}
}

public void Validate_all_ip_fields_in_emp_page_AH(String Value) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_ip_fields_in_emp_page_AH")) 
	{
		Validate_Apply_Here_button("Validate_Apply_Here_button");
//	Validate_AH_btn_under_club_pos("Validate_AH_btn_under_club_pos",jobs_title_ip, text_ip);
		
	By HowDIdYouHAUs_dd= By.id("ctl00_MainContent_ApplicantContactLocationInfo_cboHowDidYouHear");
	By yes_rdobtn= By.id("ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_0");
	By no_rdobtn= By.id("ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_1");
	By F_name= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxFirstName");
	By L_name= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxLastName");
	By Email= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxEmail");
	By Confirm_email= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxConfirmEmail");
	By phone= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxPhone");
	By address= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxAddress");
	By Zipcoe= By.id("TextBoxZipCode");
	By City= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxCity");
	By State_dd= By.id("ctl00_MainContent_ApplicantContactLocationInfo_DropDownListState");
	By Radius= By.id("ctl00_MainContent_ApplicantContactLocationInfo_DropDownListTravelRadius");
	By clubs_inradius= By.xpath("//table[@id='ctl00_MainContent_ApplicantContactLocationInfo_DataListClubs']//tbody//tr");
	
	By Next_btn= By.id("btn_next");
	
	
	Element_isdisplayed(Field_HowDIdYouHAUs);
	Element_isdisplayed(HowDIdYouHAUs_dd);
	ExtentTestManager.getTest().log(Status.PASS, "*How did you hear about us?  field is displayed successfully");
	Log.info("*How did you hear about us? field is displayed successfully");
	
	Element_isdisplayed(Field_RU18Yrs);
	Element_isdisplayed(yes_rdobtn);
	Element_isdisplayed(no_rdobtn);
	ExtentTestManager.getTest().log(Status.PASS, "*Are You at Least 18 Years Old? radio buttons (yes, no) are displayed successfully");
	Log.info("*Are You at Least 18 Years Old? radio buttons (yes, no) are displayed successfully");

	Element_isdisplayed(Field_FirstLastName);
	Element_isdisplayed(F_name);
	Element_isdisplayed(L_name);
	ExtentTestManager.getTest().log(Status.PASS, "*First and Last Name fields are displayed successfully");
	Log.info("*First and Last Name field fields are displayed successfully");
	
	Element_isdisplayed(Field_EmailAdd);
	Element_isdisplayed(Email);
	ExtentTestManager.getTest().log(Status.PASS, "*Email Address field is displayed successfully");
	Log.info("*Email Address field is displayed successfully");
	
	Element_isdisplayed(Field_ConfmEmailAdd);
	Element_isdisplayed(Confirm_email);
	ExtentTestManager.getTest().log(Status.PASS, "*Confirm Email Address  field is displayed successfully");
	Log.info("*Confirm Email Address field is displayed successfully");
	
	MoveToElement(Next_btn);
	Element_isdisplayed(Field_CellPhone);
	Element_isdisplayed(phone);
	ExtentTestManager.getTest().log(Status.PASS, "*Cell Phone  field is displayed successfully");
	Log.info("*CellPhone field is displayed successfully");
	
	Element_isdisplayed(Field_Address);
	Element_isdisplayed(address);
	ExtentTestManager.getTest().log(Status.PASS, "*Address  field is displayed successfully");
	Log.info("*Address field is displayed successfully");
	
	Element_isdisplayed(Field_ZipPostal);
	Element_isdisplayed(Zipcoe);
	ExtentTestManager.getTest().log(Status.PASS, "*Zip/Postal Code  field is displayed successfully");
	Log.info("**Zip/Postal Code field is displayed successfully");
	
	Element_isdisplayed(Field_CityState);
	Element_isdisplayed(City);
	Element_isdisplayed(State_dd);
	ExtentTestManager.getTest().log(Status.PASS, "*City / State / Province:  field is displayed successfully");
	Log.info("*City / State / Province: field is displayed successfully");
	
	Element_isdisplayed(Field_RadiusUTravel);
	Element_isdisplayed(Radius);
	ExtentTestManager.getTest().log(Status.PASS, "*Radius you will Travel to Work:  field is displayed successfully");
	Log.info("*Radius you will Travel to Work: field is displayed successfully");
	
	Element_isdisplayed(Field_CulbinUrRadius);
//	Element_isdisplayed(Field_HowDIdYouHAUs);
	ExtentTestManager.getTest().log(Status.PASS, "*Clubs in Your Radius:  field is displayed successfully");
	Log.info("*Clubs in Your Radius: field is displayed successfully");
	Thread.sleep(500);

}
}


public void Validate_Howdidyouhearaboutus_dd_AH(String Value, String aboutus_dd_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Howdidyouhearaboutus_dd_AH")) 
	{
		Validate_Apply_Here_button("Validate_Apply_Here_button");
//	Validate_AH_btn_under_club_pos("Validate_AH_btn_under_club_pos",jobs_title_ip, text_ip);
		
	By HowDIdYouHAUs_dd= By.id("ctl00_MainContent_ApplicantContactLocationInfo_cboHowDidYouHear");
	By yes_rdobtn= By.id("ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_0");
	By no_rdobtn= By.id("ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_1");
	By F_name= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxFirstName");
	By L_name= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxLastName");
	By Email= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxEmail");
	By Confirm_email= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxConfirmEmail");
	By phone= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxPhone");
	By address= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxAddress");
	By Zipcoe= By.id("TextBoxZipCode");
	By City= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxCity");
	By State_dd= By.id("ctl00_MainContent_ApplicantContactLocationInfo_DropDownListState");
	By Radius= By.id("ctl00_MainContent_ApplicantContactLocationInfo_DropDownListTravelRadius");
	By clubs_inradius= By.xpath("//table[@id='ctl00_MainContent_ApplicantContactLocationInfo_DataListClubs']//tbody//tr");
	
	By Next_btn= By.id("btn_next");
	

			 	Element_isdisplayed(HowDIdYouHAUs_dd);
			 	ExtentTestManager.getTest().log(Status.PASS,  "How did you hear about us dropdown displayed successfully" );
				Log.info("How did you hear about us dropdown displayed successfully");
				String[] aboutus_dd=aboutus_dd_ip.split(",");

				
				 Select select = new Select(driver.findElement(HowDIdYouHAUs_dd));  
				 int count=0;
				 List<WebElement> options = select.getOptions();  
				 
				 ArrayList<String> mylist = new ArrayList<String>();
				 
				 for(WebElement we:options)  
				 	{  
					 
					 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
				 	}
				 	String delim = ",";
			        String res = String.join(delim, mylist);
					 
				  for (int i=0; i<aboutus_dd.length; i++)
				  	{
					  
					  if(res.trim().toUpperCase().contains(aboutus_dd[i].trim().toUpperCase()))
					  	{
						  count++;
						  Log.info(aboutus_dd[i].trim()+" value matched");
						  ExtentTestManager.getTest().log(Status.PASS, aboutus_dd[i].trim()+" value matched");
						  
					  	}
					  else
					  {
						  
						  Log.error(aboutus_dd[i].trim()+" value not matched with the values in How Did You Hear abt us dropdown list"); 
						  ExtentTestManager.getTest().log(Status.FAIL, aboutus_dd[i].trim()+" value not matched with the values in How Did You Hear abt us dropdown list");
						  
						 
						  }
					  
				  		}	 
				
				   if (aboutus_dd.length == count &&  mylist.size()==aboutus_dd.length) 
				    {	
					  
					   	Log.info("All values matched successfully in the How Did You Hear abt us dropdown as Expected");
				        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the How Did You Hear abt us dropdown as Expected");

				    } else 
				    {	
				    	Log.error("All values not matched successfully in the How Did You Hear abt us dropdown. Expected dropdown list [ "+aboutus_dd_ip +" ] Actual dropdown list [ "+res+" ]");
			        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the How Did You Hear abt us dropdown. Expected dropdown list [ "+aboutus_dd_ip +" ] Actual dropdown list [ "+res+" ]");
			        	throw new Exception("All values not matched successfully in the How Did You Hear abt us dropdown");
				    }
				 } 
				Thread.sleep(100);
			
	}
	
public void Validate_Radiobtn18YearsOld_options_AH(String Value) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Radiobtn18YearsOld_options_AH")) 
	{
		Validate_Apply_Here_button("Validate_Apply_Here_button");
//		Validate_AH_btn_under_club_pos("Validate_AH_btn_under_club_pos",jobs_title_ip, text_ip);
		
	
	 By RadioButtonList18YearsOld_No_label = By.xpath("//label[@for='ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_1']");
	 By RadioButtonList18YearsOld_Yes_label = By.xpath("//label[@for='ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_0']");
	
	Element_isdisplayed(RadioButtonList18YearsOld_Yes_label);
	 Log.info("Radio Button List 18 Years Old Yes label successfully displayed and validated in Employment Submit Application page");
	 ExtentTestManager.getTest().log(Status.PASS, "Radio Button List 18 Years Old Yes label successfully displayed and validated in Employment Submit Application page");

	 Element_isdisplayed(RadioButtonList18YearsOld_No_label);
	 Log.info("Radio Button List 18 Years Old No label successfully displayed and validated in Employment Submit Application page");
	 ExtentTestManager.getTest().log(Status.PASS, "Radio Button List 18 Years Old No label successfully displayed and validated in Employment Submit Application page");

}
	}

public void  Validate_US_format_text_AH(String Value,String Us_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_US_format_text_AH")) 
	{
		Validate_Apply_Here_button("Validate_Apply_Here_button");
//		Validate_AH_btn_under_club_pos("Validate_AH_btn_under_club_pos",jobs_title_ip, text_ip);
		
	
	By format= By.id("ctl00_MainContent_ApplicantContactLocationInfo_LabelZipCodeFormat");
	Element_isdisplayed(format);
	MoveToElement(format);
	 String US_ca_format=driver.findElement(format).getText().replace("\n", " ");
	 Assert.assertEquals(US_ca_format.toUpperCase().trim(), Us_ip.toUpperCase().trim(), "'(Format: US - 92612)' text in Employment Submit Application page not validated");
	 Log.info(US_ca_format+" text successfully displayed and validated in Employment Submit Application page");
	 ExtentTestManager.getTest().log(Status.PASS, US_ca_format+" text successfully displayed and validated in Employment Submit Application page");

}
	}


public void  Validate_Miles_text_AH(String Value, String Miles_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Miles_text_AH")) 
	{
		Validate_Apply_Here_button("Validate_Apply_Here_button");
//		Validate_AH_btn_under_club_pos("Validate_AH_btn_under_club_pos",jobs_title_ip, text_ip);
		
	By M= By.xpath("//div[contains(text(),'Miles')]");
	Element_isdisplayed(M);
	MoveToElement(M);
	 String text=driver.findElement(M).getText().replace("\n", " ");
	 Assert.assertEquals(text.toUpperCase().trim(), Miles_ip.toUpperCase().trim(), "Text 'Miles' beside Radius you will Travel to Work: dropdown in Employment Submit Application page not validated");
	 Log.info(text+" text beside Radius you will Travel to Work: dropdown successfully displayed and validated in Employment Submit Application page");
	 ExtentTestManager.getTest().log(Status.PASS, text+" text beside Radius you will Travel to Work: dropdown successfully displayed and validated in Employment Submit Application page");

}
	}

public void Validate_phone_errorlabel_AH(String Value, String error_label) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_phone_errorlabel_AH")) 
	{
		Validate_Apply_Here_button("Validate_Apply_Here_button");
//		Validate_AH_btn_under_club_pos("Validate_AH_btn_under_club_pos",jobs_title_ip, text_ip);
		
	By error= By.xpath("//span[contains(text(),'By providing your cell phone number, you consent t')]");
	Element_isdisplayed(error);
	MoveToElement(error);
	 String error_labe=driver.findElement(error).getText().replace("\n", " ");
	 Assert.assertEquals(error_labe.toUpperCase().trim(), error_label.toUpperCase().trim(), " Error text 'By providing your cell phone number, you consent to receive calls or texts from us relating to your application materials.' in Employment Submit Application page not validated");
	 Log.info(error_label+"error text successfully displayed and validated in Employment Submit Application page");
	 ExtentTestManager.getTest().log(Status.PASS, error_label+" error text successfully displayed and validated in Employment Submit Application page");
	
	}

}

public void Validate_Next_step_btn_in_l1_AH(String Value) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Next_step_btn_in_l1_AH")) 
	{
		Validate_Apply_Here_button("Validate_Apply_Here_button");
//		Validate_AH_btn_under_club_pos("Validate_AH_btn_under_club_pos",jobs_title_ip, text_ip);
		
	By Next_btn= By.id("btn_next");
	Element_isdisplayed(Next_btn);
	 MoveToElement(Next_btn);
	 Log.info(" Next Step button is successfully displayed in Employment Submit Application page");
	 ExtentTestManager.getTest().log(Status.PASS, "Next Step button is successfully displayed in Employment Submit Application page");

	}

}


public void Select_radio_button1(By locator, String value, String radiobutton_name) throws Exception {
	
	Element_isdisplayed(locator);
	ExtentTestManager.getTest().log(Status.PASS, radiobutton_name+ "radio buttons displayed successfully" );
	Log.info(radiobutton_name+ "radio buttons displayed successfully");
	
	 By RadioButtonList18YearsOld_No_label = By.xpath("//label[@for='ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_1']");
	 By RadioButtonList18YearsOld_Yes_label = By.xpath("//label[@for='ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_0']");
	 By LabelAtLeast18Error = By.id("ctl00_MainContent_ApplicantContactLocationInfo_LabelAtLeast18Error");
		
	
if(value.equalsIgnoreCase(driver.findElement(RadioButtonList18YearsOld_Yes_label).getText().trim()) && value.equalsIgnoreCase("yes")) {
//	String s=driver.findElement(locator).getText().trim();
	if(!driver.findElement(locator).isSelected()) click(locator);
	ExtentTestManager.getTest().log(Status.PASS, radiobutton_name+"Radio button "+value+" selected");
	Log.info(radiobutton_name+"Radio button "+value+" selected");
}
else if (value.equalsIgnoreCase(driver.findElement(RadioButtonList18YearsOld_No_label).getText().trim()) && value.equalsIgnoreCase("No")) {
	
	if(!driver.findElement(locator).isSelected())click(locator);
	Thread.sleep(100);
	driver.switchTo().alert().accept();
	Thread.sleep(200);
	ExtentTestManager.getTest().log(Status.PASS, radiobutton_name+"Radio button "+value+" selected");
	Log.info(radiobutton_name+"Radio button "+value+" selected");
	Element_isdisplayed(LabelAtLeast18Error);
	String err=driver.findElement(LabelAtLeast18Error).getText().trim();
	ExtentTestManager.getTest().log(Status.PASS, "error message: "+err+" displayed successfully");
	Log.info("error message: "+err+" displayed successfully");

}

	
}


public void Validate_input_in_all_fields_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_input_in_all_fields_AH")) 
	{
		Validate_Apply_Here_button("Validate_Apply_Here_button");
//		Validate_AH_btn_under_club_pos("Validate_AH_btn_under_club_pos",jobs_title_ip, text_ip);
		
		
		By HowDIdYouHAUs_dd= By.id("ctl00_MainContent_ApplicantContactLocationInfo_cboHowDidYouHear");
		By yes_rdobtn= By.id("ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_0");
		By no_rdobtn= By.id("ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_1");
		By F_name1= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxFirstName");
		By L_name1= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxLastName");
		By Email= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxEmail");
		By Confirm_email= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxConfirmEmail");
		By phone= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxPhone");
		By address= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxAddress");
		By Zipcoe= By.id("TextBoxZipCode");
		By City= By.id("ctl00_MainContent_ApplicantContactLocationInfo_TextBoxCity");
		By State_dd= By.id("ctl00_MainContent_ApplicantContactLocationInfo_DropDownListState");
		By Radius= By.id("ctl00_MainContent_ApplicantContactLocationInfo_DropDownListTravelRadius");
		By clubs_inradius= By.xpath("//table[@id='ctl00_MainContent_ApplicantContactLocationInfo_DataListClubs']//tbody//tr");
		
		By Next_btn= By.id("btn_next");
		
		
		select_dropdown(HowDIdYouHAUs_dd, How_hear_abt_us.trim(), "How did you hear about us");
		
		 
		 Select_radio_button(yes_rdobtn, Radiobtn18YearsOld.trim(), "Are You at Least 18 Years Old?");
		 
//		 Select_radio_button(RadioButtonList18YearsOld_No, "No", "Are You at Least 18 Years Old?");

		
		 Element_isdisplayed(F_name1);
		 Log.info("First name field is displayed successfully");
		 ExtentTestManager.getTest().log(Status.PASS, "First name field is displayed successfully");
		 
		 input(F_name1, F_name);
		 Log.info("first name entered successfully: "+F_name);
		 ExtentTestManager.getTest().log(Status.PASS, "first name entered successfully: "+F_name);
		 
		 Element_isdisplayed(L_name1);
		 Log.info("Last name field is displayed successfully");
		 ExtentTestManager.getTest().log(Status.PASS, "Last name field is displayed successfully");
		 
		 input(L_name1, L_name.trim());
		 Log.info("Last name entered successfully: "+L_name);
		 ExtentTestManager.getTest().log(Status.PASS, "Last name entered successfully: " +L_name);
		 
		 Element_isdisplayed(Email);
		 Log.info("Email field is displayed successfully");
		 ExtentTestManager.getTest().log(Status.PASS, "Email field is displayed successfully");
//		 
		 input(Email, email.trim());
		 Log.info("Email entered successfully: "+email.trim());
		 ExtentTestManager.getTest().log(Status.PASS, "Email entered successfully: "+email.trim());
		 
		 Element_isdisplayed(Confirm_email);
		 Log.info("Confirm Email field is displayed successfully: ");
		 ExtentTestManager.getTest().log(Status.PASS, "Confirm Email field is displayed successfully");
		 
		 input(Confirm_email, email.trim());
		 Log.info("Confirm Email entered successfully: "+email.trim());
		 ExtentTestManager.getTest().log(Status.PASS, "Confirm Email entered successfully: "+email.trim());
		 
		 Element_isdisplayed(phone);
		 Log.info("phone field is displayed successfully");
		 ExtentTestManager.getTest().log(Status.PASS, "phone field is displayed successfully");
		 
//		 Element_isdisplayed(consenttoreceive_calls_texts);
//		 
//		 Log.info("Consent to receive calls and texts message is displayed successfully: ");
//		 ExtentTestManager.getTest().log(Status.PASS, "Consent to receive calls and texts message is displayed successfully: ");
		 
		 input(phone, Phone);
		 Log.info("phone number entered successfully: "+Phone);
		 ExtentTestManager.getTest().log(Status.PASS, "phone number entered successfully: "+Phone);
		 
		 Element_isdisplayed(address);
		 Log.info("Address field is displayed successfully");
		 ExtentTestManager.getTest().log(Status.PASS, "Address field is displayed successfully");
		 
		 input(address, Address);
		 Log.info("address entered successfully: "+Address);
		 ExtentTestManager.getTest().log(Status.PASS, "address entered successfully: "+Address);
		 
		 
		 Element_isdisplayed(Zipcoe);
		 Log.info("zipcode field is displayed successfully");
		 ExtentTestManager.getTest().log(Status.PASS, "zipcode field is displayed successfully");
		 
		 
		 input(Zipcoe, Zipcode);
		 Log.info("zipcode entered successfully: "+Zipcode);
		 ExtentTestManager.getTest().log(Status.PASS, "zipcode entered successfully: "+Zipcode);
		 
		 Thread.sleep(200);
		 driver.findElement(Zipcoe).sendKeys(Keys.TAB);
//		 
		 Thread.sleep(1500);
		 
		 MoveToElement(Next_btn);
		 
		 Element_isdisplayed(City);
		 Log.info("City field is displayed successfully");
		 ExtentTestManager.getTest().log(Status.PASS, "City field is displayed successfully");
		 
//		 driver.findElement(City).clear();
		 String city_text=driver.findElement(City).getAttribute("value");
		 Log.info("Auto populated/selected City: "+city_text);
		 ExtentTestManager.getTest().log(Status.PASS, "Auto populated/selected City: "+city_text);
//		 input(City, city);
		 
//		 Log.info("City entered successfully: "+city);
//		 ExtentTestManager.getTest().log(Status.PASS, "City entered successfully: "+city);

		 Thread.sleep(400);
		 Element_isdisplayed(State_dd);
		 ExtentTestManager.getTest().log(Status.PASS,  "State / Province dropdown displayed successfully" );
		 Log.info("State / Province dropdown displayed successfully");
		 Thread.sleep(200);
//		 select_dropdown(State, state.trim(), "State");
		 Select state_select = new Select(driver.findElement(State_dd));
		 String state_text=state_select.getFirstSelectedOption().getText();
//		 String state_text=driver.findElement(State).getAttribute("value");
		 Log.info("Auto populated/selected State: "+state_text);
		 ExtentTestManager.getTest().log(Status.PASS, "Auto populated/selected State: "+state_text);
		 
//		 select_dropdown(travel_radius_dropdown, Radius_travel_to_work.trim(), "Radius you will Travel to Work");
		 	
			Element_isdisplayed(Radius);
			ExtentTestManager.getTest().log(Status.PASS,  "Radius you will Travel to Work displayed successfully" );
			Log.info("Radius you will Travel to Work displayed successfully");
//			Thread.sleep(200);
//			Select select1 = ;
			 String travel_radius_text=new Select(driver.findElement(Radius)).getFirstSelectedOption().getText();
			 Log.info("Auto populated/selected Radius you will Travel to Work: "+travel_radius_text);
			 ExtentTestManager.getTest().log(Status.PASS, "Auto populated/selected Radius you will Travel to Work: "+travel_radius_text);

			By radius= By.xpath("//span[contains(text(),'Clubs in Your Radius:')]");
			By radius_c= By.xpath("//td[@class='alignLeft alignTop']/a");
			By Edu_info= By.xpath("//span[contains(text(),'Education Information')]");
			
			Element_isdisplayed(radius);
			MoveToElement(radius);
			ExtentTestManager.getTest().log(Status.PASS,  "Clubs in Your Radius text displayed successfully" );
			Log.info("Clubs in Your Radius text displayed successfully");
	
			List<WebElement> radius_clubs =driver.findElements(radius_c);
			
			for (WebElement clubs_in_radius : radius_clubs) {
				
				String club=clubs_in_radius.getText();
				ExtentTestManager.getTest().log(Status.PASS,  "Auto populated/selected Club in Your Radius: "+club );
				Log.info("Auto populated/selected Club in Your Radius: "+club);
				
			}
			
			MoveToElement(Next_btn);

		
	}
	
}


public void Validate_List18YrsOld_No_popupalrt_AH(String Value, String Radiobtn18YearsOld) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_List18YrsOld_No_popupalrt_AH")) 
	{
		Validate_Apply_Here_button("Validate_Apply_Here_button");
//		Validate_AH_btn_under_club_pos("Validate_AH_btn_under_club_pos",jobs_title_ip, text_ip);
		
		By no_rdobtn= By.id("ctl00_MainContent_ApplicantContactLocationInfo_RadioButtonList18YearsOld_1");
		
		 Select_radio_button(no_rdobtn, Radiobtn18YearsOld.trim(), "Are You at Least 18 Years Old?");

		//You must be at least 18 years old to apply.
	}
	
}


public void Validate_Next_step_l1_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Next_step_l1_AH")) 
	{
		
		Validate_input_in_all_fields_AH("Validate_input_in_all_fields_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode );
		
		By Next_btn= By.id("btn_next");
		By radius= By.xpath("//span[contains(text(),'Clubs in Your Radius:')]");
		By radius_c= By.xpath("//td[@class='alignLeft alignTop']/a");
		By Edu_info= By.xpath("//span[contains(text(),'Education Information')]");
		
			Element_isdisplayed(Next_btn);
			MoveToElement(Next_btn);
			ExtentTestManager.getTest().log(Status.PASS,  "Next button  displayed successfully" );
			Log.info("Next button  displayed successfully");
			
			click(Next_btn);
			ExtentTestManager.getTest().log(Status.PASS,  "Successfully clicked Next button" );
			Log.info("Successfully clicked Next button");
			Thread.sleep(500);
			 Element_isdisplayed(Edu_info);
			 String edu_info_txt=driver.findElement(Edu_info).getText().replace("\n", " ");
			 Assert.assertEquals(edu_info_txt.toUpperCase().trim(), L2_txt.toUpperCase().trim(), "Education Information text in Employment Submit Application level 2 page not validated");
			 Log.info(edu_info_txt+" text successfully displayed and navigated to Employment Submit Application Education Information level 2 page");
			 ExtentTestManager.getTest().log(Status.PASS, edu_info_txt+" text successfully displayed and navigated to Employment Submit Application Education Information level 2 page");
			 
			 Thread.sleep(200);

		
	}
	
}




public void Validate_education_level_dd_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_education_level_dd_AH")) 
	{
		
		Validate_Next_step_l1_AH("Validate_Next_step_l1_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt );
		
		By edu_dd= By.id("ctl00_MainContent_ApplicantEducation_DropDownListEducation");
		 
		 Element_isdisplayed(edu_dd);
		 Log.info("Education level dropdown field is displayed successfully in Education Information level 20% page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Education level dropdown field is displayed successfully in Education Information level 20% page");

		
	}
	
}



public void Validate_edu_level_dd_allvalues_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String edu_level_dd_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_edu_level_dd_allvalues_AH")) 
	{
		
		Validate_Next_step_l1_AH("Validate_Next_step_l1_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt );
		
		By edu_dd= By.id("ctl00_MainContent_ApplicantEducation_DropDownListEducation");
		 
		 Element_isdisplayed(edu_dd);
		 Log.info("Education level dropdown field is displayed successfully in Education Information level 20% page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Education level dropdown field is displayed successfully in Education Information level 20% page");
		 Select edu_level = new Select(driver.findElement(edu_dd));
		 
		 String[] edu_level_dd=edu_level_dd_ip.split(",");
		 int count=0;
		 List<WebElement> options = edu_level.getOptions();  
		 
		 ArrayList<String> mylist = new ArrayList<String>();
		 
		 for(WebElement we:options)  
		 	{  
			 
			 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
		 	}
		 	String delim = ",";
	        String res = String.join(delim, mylist);
			 
		  for (int i=0; i<edu_level_dd.length; i++)
		  	{
			  
			  if(res.trim().toUpperCase().contains(edu_level_dd[i].trim().toUpperCase()))
			  	{
				  count++;
				  Log.info(edu_level_dd[i].trim()+" value matched");
				  ExtentTestManager.getTest().log(Status.PASS, edu_level_dd[i].trim()+" value matched");
				  
			  	}
			  else
			  {
				  
				  Log.error(edu_level_dd[i].trim()+" value not matched with the values in Education level dropdown list"); 
				  ExtentTestManager.getTest().log(Status.FAIL, edu_level_dd[i].trim()+" value not matched with the values in Education level dropdown list");
				  
				 
				  }
			  
		  		}	 
		
		   if (edu_level_dd.length == count &&  mylist.size()==edu_level_dd.length) 
		    {	
			  
			   	Log.info("All values matched successfully in the Education level dropdown as Expected");
		        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the Education level dropdown as Expected");

		    } else 
		    {	
		    	Log.error("All values not matched successfully in the Education level dropdown. Expected dropdown list [ "+edu_level_dd +" ] Actual dropdown list [ "+res+" ]");
	        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the Education level dropdown. Expected dropdown list [ "+edu_level_dd +" ] Actual dropdown list [ "+res+" ]");
	        	throw new Exception("All values not matched successfully in the Education level dropdown");
		    }

		
	}
	
}


public void Validate_previous_next_step_btns_l2_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_previous_next_step_btns_l2_AH")) 
	{
		
		Validate_Next_step_l1_AH("Validate_Next_step_l1_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt );
		
		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		
		 Element_isdisplayed(btn_prev);
		 MoveToElement(btn_prev);
		 Log.info("Previous step button is displayed successfully in Education Information level 2 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Education Information level 2 page");
		
		 Element_isdisplayed(btn_next);
		 Log.info("Next step button is displayed successfully in Education Information level 2 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Education Information level 2 page");

	}
	
}


public void Validate_previous_step_btn_l2_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_previous_step_btn_l2_AH")) 
	{
		
		Validate_Next_step_l1_AH("Validate_Next_step_l1_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt );
		
		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		
		By emp_app = By.xpath("//h1[contains(text(),'Employment Application')]");
		
		 Element_isdisplayed(btn_prev);
		 MoveToElement(btn_prev);
		 Log.info("Previous step button is displayed successfully in Education Information level 2 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Education Information level 2 page");
		
		 click(btn_prev);
		 Thread.sleep(500);
		 Log.info("Successfully clicked on Previous step button in Education Information level 2 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Previous step button in Education Information level 2 page ");
		 
		 Element_isdisplayed(emp_app);
		 String app_info_txt=driver.findElement(emp_app).getText().replace("\n", " ");
		 Assert.assertEquals(app_info_txt.toUpperCase().trim(), "Employment Application".toUpperCase().trim(), "Employment Application text in Employment Submit Application level 1 page not validated");
		 ExtentTestManager.getTest().log(Status.PASS, app_info_txt+" text successfully displayed, validated and navigated to Employment Submit Application level 1 page");
		 Log.info(app_info_txt+" text successfully displayed, validated and navigated to Employment Submit Application level 1 page");
		 
		 
	}
	
}



public void Validate_Next_step_btn_l2_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Next_step_btn_l2_AH")) 
	{
		
		Validate_previous_next_step_btns_l2_AH("Validate_previous_next_step_btns_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt );
		
		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		 By Experience_info= By.xpath("//span[@class='h4'][contains(text(),'Experience Information')]");
		 
		 By edu_dd= By.id("ctl00_MainContent_ApplicantEducation_DropDownListEducation");
		 Element_isdisplayed(edu_dd);
		 Select edu_level = new Select(driver.findElement(edu_dd));
		 edu_level.selectByVisibleText(Edu_level_ip);
		 
		 
//				 "No High School Diploma");
		
		 Log.info(Edu_level_ip+" value option is selected for Education level dropdown in Education Information level 2 page ");
		 ExtentTestManager.getTest().log(Status.PASS, Edu_level_ip+" value option is selected for Education level dropdown in Education Information level 2 page ");

		
		 Element_isdisplayed(btn_next);
		 Log.info("Next step button is displayed successfully in Education Information level 2 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Education Information level 2 page");
		
		 click(btn_next);
		 Thread.sleep(200);
		 
		 Log.info("Successfully clicked on Next step button in Education Information level 2 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Next step button in Education Information level 2 page ");
		 	 
		 Element_isdisplayed(Experience_info);
		 String Experience_txt=driver.findElement(Experience_info).getText().replace("\n", " ");
		 Assert.assertEquals(Experience_txt.toUpperCase().trim(), "Experience Information".toUpperCase().trim(), "Experience Information text in Employment Submit Application level 3 page not validated");
		 ExtentTestManager.getTest().log(Status.PASS, Experience_txt+" text successfully displayed, validated and navigated to Employment Submit Application level 3 page");
		 Log.info(Experience_txt+" text successfully displayed, validated and navigated to Employment Submit Application level 3 page");
		 
	}
	
}




public void Validate_Exp_info_text_in_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_info_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Exp_info_text_in_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
		 
		 By Experience_text= By.id("ctl00_MainContent_LabelYourResponses");
		 
//		 By edu_dd= By.id("ctl00_MainContent_ApplicantEducation_DropDownListEducation");
		 
		 Element_isdisplayed(Experience_text);
		 String Experience_txt=driver.findElement(Experience_text).getText().replace("\n", " ");
		 Assert.assertEquals(Experience_txt.toUpperCase().trim(), Exp_info_ip.toUpperCase().trim(), Exp_info_ip+" text in Employment Submit Application Experience Information level 3 page not validated");
		 ExtentTestManager.getTest().log(Status.PASS, Experience_txt+" text successfully displayed and validated in Employment Submit Application Experience Information level 3 page");
		 Log.info(Experience_txt+" text successfully displayed and validated in Employment Submit Application Experience Information level 3 page");

		
	}
	
}


public void Validate_sales_mngnt_exp_text_in_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_info_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_sales_mngnt_exp_text_in_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
		 
		 By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantSalesMgmtExperience_UpdatePanelEducationAndExperience']/div/b");
		 
//		 By edu_dd= By.id("ctl00_MainContent_ApplicantEducation_DropDownListEducation");
		 
		 Element_isdisplayed(Experience_text);
		 MoveToElement(Experience_text);
		 String Experience_txt=driver.findElement(Experience_text).getText().replace("\n", " ");
		 Assert.assertEquals(Experience_txt.toUpperCase().trim(), Exp_info_ip.toUpperCase().trim(), Exp_info_ip+" text in Employment Submit Application Experience Information level 3 page not validated");
		 ExtentTestManager.getTest().log(Status.PASS, Experience_txt+" text successfully displayed and validated in Employment Submit Application Experience Information level 3 page");
		 Log.info(Experience_txt+" text successfully displayed and validated Employment Submit Application Experience Information level 3 page");

		
	}
	
}



public void Validate_Equipment_Techn_exp_heading_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_info_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Equipment_Techn_exp_heading_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
//		 By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantSalesMgmtExperience_UpdatePanelEducationAndExperience']/div/b");
		 By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			
//		 By edu_dd= By.id("ctl00_MainContent_ApplicantEducation_DropDownListEducation");
		 
		 Element_isdisplayed(Experience_text);
		 MoveToElement(Experience_text);
		 String Experience_txt=driver.findElement(Experience_text).getText().replace("\n", " ");
		 Assert.assertEquals(Experience_txt.toUpperCase().trim(), Exp_info_ip.toUpperCase().trim(), Exp_info_ip+" heading text in Employment Submit Application Experience Information level 3 page not validated");
		 ExtentTestManager.getTest().log(Status.PASS, Experience_txt+" heading text successfully displayed and validated in Employment Submit Application Experience Information level 3 page");
		 Log.info(Experience_txt+" heading text successfully displayed and validated in Employment Submit Application Experience Information level 3 page");

		
	}
	
}


public void Validate_all_dropdowns_in_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_dropdowns_in_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
			By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
		 	By FSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListSalesExperience");
			By PTSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListPTSalesExperience");
			By ME_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListManagementExperience");
			By BE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListBuildingExperience");
			By ETE= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			By YE_dd= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_DropDownListEquipmentTechExperience");
						
		 
		 Element_isdisplayed(FSE_dd);
//		 MoveToElement(FSE_dd);
		 ExtentTestManager.getTest().log(Status.PASS, "Fitness Sales Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
		 Log.info("Fitness Sales Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");

		 Element_isdisplayed(PTSE_dd);
//		 MoveToElement(FSE_dd);
		 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Sales Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
		 Log.info("Personal Training Sales Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
		
		 Element_isdisplayed(ME_dd);
//		 MoveToElement(FSE_dd);
		 ExtentTestManager.getTest().log(Status.PASS, "Management Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
		 Log.info("Management Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
		
		 Element_isdisplayed(BE_dd);
//		 MoveToElement(FSE_dd);
		 ExtentTestManager.getTest().log(Status.PASS, "Building Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
		 Log.info("Building Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
		 
		 Element_isdisplayed(YE_dd);
		 MoveToElement(YE_dd);
		 ExtentTestManager.getTest().log(Status.PASS, "Years of Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
		 Log.info("Years of Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
		 Thread.sleep(200);
	}
	
}



public void Validate_all_options_FSE_dd_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String exp_dd_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_options_FSE_dd_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
			By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
		 	By FSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListSalesExperience");
			By PTSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListPTSalesExperience");
			By ME_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListManagementExperience");
			By BE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListBuildingExperience");
			By ETE= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			By YE_dd= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_DropDownListEquipmentTechExperience");
						
		 
		 Element_isdisplayed(FSE_dd);
//		 MoveToElement(FSE_dd);
		 ExtentTestManager.getTest().log(Status.PASS, "Fitness Sales Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
		 Log.info("Fitness Sales Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");


		 Select Exp_dd = new Select(driver.findElement(FSE_dd));
		 
		 String[] exp_options_ip=exp_dd_ip.split(",");
		 int count=0;
		 List<WebElement> options = Exp_dd.getOptions();  
		 
		 ArrayList<String> mylist = new ArrayList<String>();
		 
		 for(WebElement we:options)  
		 	{  
			 
			 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
		 	}
		 	String delim = ",";
	        String res = String.join(delim, mylist);
			 
		  for (int i=0; i<exp_options_ip.length; i++)
		  	{
			  
			  if(res.trim().toUpperCase().contains(exp_options_ip[i].trim().toUpperCase()))
			  	{
				  count++;
				  Log.info(exp_options_ip[i].trim()+" value matched");
				  ExtentTestManager.getTest().log(Status.PASS, exp_options_ip[i].trim()+" value matched");
				  
			  	}
			  else
			  {
				  
				  Log.error(exp_options_ip[i].trim()+" value not matched with the values in Fitness Sales Experience dropdown list"); 
				  ExtentTestManager.getTest().log(Status.FAIL, exp_options_ip[i].trim()+" value not matched with the values in Fitness Sales Experience dropdown list");
				  
				 
				  }
			  
		  		}	 
		
		   if (exp_options_ip.length == count &&  mylist.size()==exp_options_ip.length) 
		    {	
			  
			   	Log.info("All values matched successfully in the Fitness Sales Experience dropdown as Expected");
		        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the Fitness Sales Experience dropdown as Expected");

		    } else 
		    {	
		    	Log.error("All values not matched successfully in the Fitness Sales Experience dropdown. Expected dropdown list [ "+exp_options_ip +" ] Actual dropdown list [ "+res+" ]");
	        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the Fitness Sales Experience dropdown. Expected dropdown list [ "+exp_options_ip +" ] Actual dropdown list [ "+res+" ]");
	        	throw new Exception("All values not matched successfully in the Fitness Sales Experience dropdown");
		    }


		 
	}
	
}


public void Validate_all_options_PTSE_dd_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String exp_dd_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_options_PTSE_dd_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
			By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
		 	By FSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListSalesExperience");
			By PTSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListPTSalesExperience");
			By ME_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListManagementExperience");
			By BE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListBuildingExperience");
			By ETE= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			By YE_dd= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_DropDownListEquipmentTechExperience");
						
		 
		 Element_isdisplayed(PTSE_dd);
//		 MoveToElement(FSE_dd);
		 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Sales Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
		 Log.info("Personal Training Sales Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
		

		 Select Exp_dd = new Select(driver.findElement(PTSE_dd));
		 
		 String[] exp_options_ip=exp_dd_ip.split(",");
		 int count=0;
		 List<WebElement> options = Exp_dd.getOptions();  
		 
		 ArrayList<String> mylist = new ArrayList<String>();
		 
		 for(WebElement we:options)  
		 	{  
			 
			 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
		 	}
		 	String delim = ",";
	        String res = String.join(delim, mylist);
			 
		  for (int i=0; i<exp_options_ip.length; i++)
		  	{
			  
			  if(res.trim().toUpperCase().contains(exp_options_ip[i].trim().toUpperCase()))
			  	{
				  count++;
				  Log.info(exp_options_ip[i].trim()+" value matched");
				  ExtentTestManager.getTest().log(Status.PASS, exp_options_ip[i].trim()+" value matched");
				  
			  	}
			  else
			  {
				  
				  Log.error(exp_options_ip[i].trim()+" value not matched with the values in Personal Training Sales Experience dropdown list"); 
				  ExtentTestManager.getTest().log(Status.FAIL, exp_options_ip[i].trim()+" value not matched with the values in Personal Training Sales Experience dropdown list");
				  
				 
				  }
			  
		  		}	 
		
		   if (exp_options_ip.length == count &&  mylist.size()==exp_options_ip.length) 
		    {	
			  
			   	Log.info("All values matched successfully in the Personal Training Sales Experience dropdown as Expected");
		        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the Personal Training Sales Experience dropdown as Expected");

		    } else 
		    {	
		    	Log.error("All values not matched successfully in the Personal Training Sales Experience dropdown. Expected dropdown list [ "+exp_options_ip +" ] Actual dropdown list [ "+res+" ]");
	        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the Personal Training Sales Experience dropdown. Expected dropdown list [ "+exp_options_ip +" ] Actual dropdown list [ "+res+" ]");
	        	throw new Exception("All values not matched successfully in the Personal Training Sales Experience dropdown");
		    }


		 
	}
	
}


public void Validate_all_options_ME_dd_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String exp_dd_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_options_ME_dd_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
			By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
		 	By FSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListSalesExperience");
			By PTSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListPTSalesExperience");
			By ME_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListManagementExperience");
			By BE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListBuildingExperience");
			By ETE= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			By YE_dd= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_DropDownListEquipmentTechExperience");
						
		 
			Element_isdisplayed(ME_dd);
//			 MoveToElement(FSE_dd);
			 ExtentTestManager.getTest().log(Status.PASS, "Management Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			 Log.info("Management Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			

		 Select Exp_dd = new Select(driver.findElement(ME_dd));
		 
		 String[] exp_options_ip=exp_dd_ip.split(",");
		 int count=0;
		 List<WebElement> options = Exp_dd.getOptions();  
		 
		 ArrayList<String> mylist = new ArrayList<String>();
		 
		 for(WebElement we:options)  
		 	{  
			 
			 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
		 	}
		 	String delim = ",";
	        String res = String.join(delim, mylist);
			 
		  for (int i=0; i<exp_options_ip.length; i++)
		  	{
			  
			  if(res.trim().toUpperCase().contains(exp_options_ip[i].trim().toUpperCase()))
			  	{
				  count++;
				  Log.info(exp_options_ip[i].trim()+" value matched");
				  ExtentTestManager.getTest().log(Status.PASS, exp_options_ip[i].trim()+" value matched");
				  
			  	}
			  else
			  {
				  
				  Log.error(exp_options_ip[i].trim()+" value not matched with the values in Management Experience dropdown list"); 
				  ExtentTestManager.getTest().log(Status.FAIL, exp_options_ip[i].trim()+" value not matched with the values in Management Experience dropdown list");
				  
				 
				  }
			  
		  		}	 
		
		   if (exp_options_ip.length == count &&  mylist.size()==exp_options_ip.length) 
		    {	
			  
			   	Log.info("All values matched successfully in the Management Experience dropdown as Expected");
		        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the Management Experience dropdown as Expected");

		    } else 
		    {	
		    	Log.error("All values not matched successfully in the Management Experience dropdown. Expected dropdown list [ "+exp_options_ip +" ] Actual dropdown list [ "+res+" ]");
	        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the Management Experience dropdown. Expected dropdown list [ "+exp_options_ip +" ] Actual dropdown list [ "+res+" ]");
	        	throw new Exception("All values not matched successfully in the Management Experience dropdown");
		    }


		 
	}
	
}


public void Validate_all_options_BE_dd_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String exp_dd_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_options_BE_dd_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
			By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
		 	By FSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListSalesExperience");
			By PTSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListPTSalesExperience");
			By ME_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListManagementExperience");
			By BE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListBuildingExperience");
			By ETE= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			By YE_dd= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_DropDownListEquipmentTechExperience");
						
		 
			 Element_isdisplayed(BE_dd);
//			 MoveToElement(FSE_dd);
			 ExtentTestManager.getTest().log(Status.PASS, "Building Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			 Log.info("Building Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			

		 Select Exp_dd = new Select(driver.findElement(BE_dd));
		 
		 String[] exp_options_ip=exp_dd_ip.split(",");
		 int count=0;
		 List<WebElement> options = Exp_dd.getOptions();  
		 
		 ArrayList<String> mylist = new ArrayList<String>();
		 
		 for(WebElement we:options)  
		 	{  
			 
			 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
		 	}
		 	String delim = ",";
	        String res = String.join(delim, mylist);
			 
		  for (int i=0; i<exp_options_ip.length; i++)
		  	{
			  
			  if(res.trim().toUpperCase().contains(exp_options_ip[i].trim().toUpperCase()))
			  	{
				  count++;
				  Log.info(exp_options_ip[i].trim()+" value matched");
				  ExtentTestManager.getTest().log(Status.PASS, exp_options_ip[i].trim()+" value matched");
				  
			  	}
			  else
			  {
				  
				  Log.error(exp_options_ip[i].trim()+" value not matched with the values in Building Experience dropdown list"); 
				  ExtentTestManager.getTest().log(Status.FAIL, exp_options_ip[i].trim()+" value not matched with the values in Building Experience dropdown list");
				  
				 
				  }
			  
		  		}	 
		
		   if (exp_options_ip.length == count &&  mylist.size()==exp_options_ip.length) 
		    {	
			  
			   	Log.info("All values matched successfully in the Building Experience dropdown as Expected");
		        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the Building Experience dropdown as Expected");

		    } else 
		    {	
		    	Log.error("All values not matched successfully in the Building Experience dropdown. Expected dropdown list [ "+exp_options_ip +" ] Actual dropdown list [ "+res+" ]");
	        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the Building Experience dropdown. Expected dropdown list [ "+exp_options_ip +" ] Actual dropdown list [ "+res+" ]");
	        	throw new Exception("All values not matched successfully in the Building Experience dropdown");
		    }


		 
	}
	
}


public void Validate_all_options_YE_dd_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String exp_dd_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_options_YE_dd_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
			By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
		 	By FSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListSalesExperience");
			By PTSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListPTSalesExperience");
			By ME_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListManagementExperience");
			By BE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListBuildingExperience");
			By ETE= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			By YE_dd= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_DropDownListEquipmentTechExperience");
						
		 
			Element_isdisplayed(YE_dd);
			 MoveToElement(YE_dd);
			 ExtentTestManager.getTest().log(Status.PASS, "Years of Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			 Log.info("Years of Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			
		 Select Exp_dd = new Select(driver.findElement(YE_dd));
		 
		 String[] exp_options_ip=exp_dd_ip.split(",");
		 int count=0;
		 List<WebElement> options = Exp_dd.getOptions();  
		 
		 ArrayList<String> mylist = new ArrayList<String>();
		 
		 for(WebElement we:options)  
		 	{  
			 
			 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
		 	}
		 	String delim = ",";
	        String res = String.join(delim, mylist);
			 
		  for (int i=0; i<exp_options_ip.length; i++)
		  	{
			  
			  if(res.trim().toUpperCase().contains(exp_options_ip[i].trim().toUpperCase()))
			  	{
				  count++;
				  Log.info(exp_options_ip[i].trim()+" value matched");
				  ExtentTestManager.getTest().log(Status.PASS, exp_options_ip[i].trim()+" value matched");
				  
			  	}
			  else
			  {
				  
				  Log.error(exp_options_ip[i].trim()+" value not matched with the values in Years of Experience dropdown list"); 
				  ExtentTestManager.getTest().log(Status.FAIL, exp_options_ip[i].trim()+" value not matched with the values in Years of Experience dropdown list");
				  
				 
				  }
			  
		  		}	 
		
		   if (exp_options_ip.length == count &&  mylist.size()==exp_options_ip.length) 
		    {	
			  
			   	Log.info("All values matched successfully in the Years of Experience dropdown as Expected");
		        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the Years of  Experience dropdown as Expected");

		    } else 
		    {	
		    	Log.error("All values not matched successfully in the Years of Experience dropdown. Expected dropdown list [ "+exp_options_ip +" ] Actual dropdown list [ "+res+" ]");
	        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the Years of Experience dropdown. Expected dropdown list [ "+exp_options_ip +" ] Actual dropdown list [ "+res+" ]");
	        	throw new Exception("All values not matched successfully in the Years of Experience dropdown");
		    }


		 
	}
	
}


public void Validate_selecting_all_dds_in_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_selecting_all_dds_in_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
			By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
		 	By FSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListSalesExperience");
			By PTSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListPTSalesExperience");
			By ME_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListManagementExperience");
			By BE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListBuildingExperience");
			By ETE= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			By YE_dd= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_DropDownListEquipmentTechExperience");
		
			String[] Experience_ip=Exp_ip.split(",");
		 
		 Element_isdisplayed(FSE_dd);
		 Select FSE= new Select(driver.findElement(FSE_dd));
		 if(FSE.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip[0].trim())) {
			 ExtentTestManager.getTest().log(Status.PASS, "Fitness Sales Experience dropdown option : "+Experience_ip[0]+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Fitness Sales Experience dropdown option : "+Experience_ip[0]+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		 }else {
			 
			 FSE.selectByVisibleText(Experience_ip[0].trim());
			 ExtentTestManager.getTest().log(Status.PASS, "Fitness Sales Experience dropdown option : "+Experience_ip[0]+" selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Fitness Sales Experience dropdown option : "+Experience_ip[0]+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		}
		 Thread.sleep(200);
		 Element_isdisplayed(PTSE_dd);
		 Select PTSE= new Select(driver.findElement(PTSE_dd));
		 
		 if(PTSE.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip[1].trim())) {
			 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Sales Experience dropdown option : "+Experience_ip[1]+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Personal Training Sales Experience dropdown option : "+Experience_ip[1]+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		 }else {
			 
			 PTSE.selectByVisibleText(Experience_ip[1].trim());
			 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Sales Experience dropdown option : "+Experience_ip[1]+" selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Personal Training Sales Experience dropdown option : "+Experience_ip[1]+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		}
		 Thread.sleep(200);
		 Element_isdisplayed(ME_dd);
		 Select ME= new Select(driver.findElement(ME_dd));
		 
		 if(ME.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip[2].trim())) {
			 ExtentTestManager.getTest().log(Status.PASS, "Management Experience dropdown option : "+Experience_ip[2]+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Management Experience dropdown option : "+Experience_ip[2]+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		 }else {
			 
			 ME.selectByVisibleText(Experience_ip[2].trim());
			 ExtentTestManager.getTest().log(Status.PASS, "Management Experience dropdown option : "+Experience_ip[2]+" selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Management Experience dropdown option : "+Experience_ip[2]+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");
		}

		 Thread.sleep(200);
		 Element_isdisplayed(BE_dd);
		 
		 Select BE= new Select(driver.findElement(BE_dd));
		 
		 if(BE.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip[3].trim())) {
			 ExtentTestManager.getTest().log(Status.PASS, "Building Experience dropdown option : "+Experience_ip[3]+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Building Experience dropdown option : "+Experience_ip[3]+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		 }else {
			 
			 BE.selectByVisibleText(Experience_ip[3].trim());
			 ExtentTestManager.getTest().log(Status.PASS, "Building Experience dropdown option : "+Experience_ip[3]+" selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Building Experience dropdown option : "+Experience_ip[3]+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");
		}

		 Thread.sleep(300);
		 Element_isdisplayed(YE_dd);
		 MoveToElement(YE_dd);
		Thread.sleep(200);
		 
		 Select YE= new Select(driver.findElement(YE_dd));
		 
		 if(YE.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip[4].trim())) {
			 ExtentTestManager.getTest().log(Status.PASS, "Years of Experience dropdown option : "+Experience_ip[4]+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Years of Experience dropdown option : "+Experience_ip[4]+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		 }else {
			 
			 YE.selectByVisibleText(Experience_ip[4].trim());
			 ExtentTestManager.getTest().log(Status.PASS, "Years of Experience dropdown option : "+Experience_ip[4]+" selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Years of Experience dropdown option : "+Experience_ip[4]+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");
		}

		 
	}
	
}


public void Validate_Skills_section_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Experience_ip, String Exp_info_ip, String checkboxes_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Skills_section_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
			By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
		 	By FSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListSalesExperience");
			By PTSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListPTSalesExperience");
			By ME_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListManagementExperience");
			By BE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListBuildingExperience");
			By ETE= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			By Skills_heading= By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantSalesMgmtExperience_trBuildingSkills']/td[1]/div[1]/div[1]");
						
		 
			 Element_isdisplayed(BE_dd);
			 MoveToElement(BE_dd);
			 ExtentTestManager.getTest().log(Status.PASS, "Building Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			 Log.info("Building Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			
			 Select BE= new Select(driver.findElement(BE_dd));
			 
			 if(BE.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip.trim())) {
				 ExtentTestManager.getTest().log(Status.PASS, "Building Experience dropdown option : "+Experience_ip+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
				 Log.info("Building Experience dropdown option : "+Experience_ip+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

			 }else {
				 
				 BE.selectByVisibleText(Experience_ip.trim());
				 ExtentTestManager.getTest().log(Status.PASS, "Building Experience dropdown option : "+Experience_ip+" selected successfully in Employment Submit Application Experience Information level 3 page");
				 Log.info("Building Experience dropdown option : "+Experience_ip+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");
			}

			 
			 Thread.sleep(300);
			 
			 int count=0;
			 By CPO= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_0");
			 By Electrical= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_1");
			 By HVAC= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_2");
			 By Painter= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_3");
			 By Plumbing= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_4");
			 By Tiles= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_5");
			 By Wood_Floors= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_6");
			 By Skills_1= By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_trEquipmentTechSkills']/td[1]/div[1]/div[1]");
			 By Fitness_Equipment= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_0");
			 By Spin_Bike= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_1");
			 By Upholstery= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_2");
//			 By Zumba= By.id("ctl00_MainContent_ApplicantAerobicsExperience_AerobicsEmploymentDetailItem1_CheckBoxListGroupFitness_Formats_13");
//			 By Bodyworks= By.id("ctl00_MainContent_ApplicantAerobicsExperience_AerobicsEmploymentDetailItem1_CheckBoxListGroupFitness_Formats_3");
			 
//			 By Hip= By.id("ctl00_MainContent_ApplicantAerobicsExperience_AerobicsEmploymentDetailItem1_CheckBoxListGroupFitness_Formats_7");
			 
			 Element_isdisplayed(Skills_heading);
			 MoveToElement(Skills_heading);
			 String Experience_txt=driver.findElement(Skills_heading).getText().replace("\n", " ");
			 Assert.assertEquals(Experience_txt.toUpperCase().trim(), Exp_info_ip.toUpperCase().trim(), Exp_info_ip+" heading text in Employment Submit Application Experience Information level 3 page not validated");
			 ExtentTestManager.getTest().log(Status.PASS, Experience_txt+" heading text successfully displayed and validated in Employment Submit Application Experience Information level 3 page");
			 Log.info(Experience_txt+" heading text successfully displayed and validated in Employment Submit Application Experience Information level 3 page");

			 
			 String[] check_boxes_ip=checkboxes_ip.split(",");
			 
			 for (String cb : check_boxes_ip) {
				 
				 String checkbox=cb.trim();
				 switch (checkbox) {
				 
				case "CPO":
					Element_isdisplayed(CPO);
//					click(CPO);
					Log.info(checkbox+" check box successfully displayed and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					count++;
					break;
					
					
				case "Electrical":
					Element_isdisplayed(Electrical);
//					click(Electrical);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					 count++;
					break;
					

				case "HVAC":
					Element_isdisplayed(HVAC);
//					click(Latin);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully ďisplayed and validated");
					 count++;
					break;
					
				case "Painter":
					Element_isdisplayed(Painter);
//					click(Painter);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box  displayed and validated");
					 count++;
					break;
					
					
				case "Plumbing":
					Element_isdisplayed(Plumbing);
//					click(Plumbing);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					 count++;
					break;
					

				case "Tiles":
					Element_isdisplayed(Tiles);
//					click(Tiles);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					 count++;
					break;
					
				case "Wood Floors":
					 Element_isdisplayed(Wood_Floors);
					 MoveToElement(Wood_Floors);
//					 click(Wood_Floors);
					 Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					 count++;
					 break;
					

					
				default:
					break;
				}
				
			}
			 
			 
		 
	}
	
}


public void Validate_select_Skills_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Experience_ip, String checkboxes_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_select_Skills_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
			By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
		 	By FSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListSalesExperience");
			By PTSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListPTSalesExperience");
			By ME_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListManagementExperience");
			By BE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListBuildingExperience");
			By ETE= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			By Skills_heading= By.id("//tbody/tr[@id='ctl00_MainContent_ApplicantSalesMgmtExperience_trBuildingSkills']/td[1]/div[1]/div[1]");
						
		 
			 Element_isdisplayed(BE_dd);
			 MoveToElement(BE_dd);
			 ExtentTestManager.getTest().log(Status.PASS, "Building Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			 Log.info("Building Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			
			 Select BE= new Select(driver.findElement(BE_dd));
			 
			 if(BE.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip.trim())) {
				 ExtentTestManager.getTest().log(Status.PASS, "Building Experience dropdown option : "+Experience_ip+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
				 Log.info("Building Experience dropdown option : "+Experience_ip+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

			 }else {
				 
				 BE.selectByVisibleText(Experience_ip.trim());
				 ExtentTestManager.getTest().log(Status.PASS, "Building Experience dropdown option : "+Experience_ip+" selected successfully in Employment Submit Application Experience Information level 3 page");
				 Log.info("Building Experience dropdown option : "+Experience_ip+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");
			}

			 
			 
			 Thread.sleep(300);
			 
			 int count=0;
			 By CPO= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_0");
			 By Electrical= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_1");
			 By HVAC= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_2");
			 By Painter= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_3");
			 By Plumbing= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_4");
			 By Tiles= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_5");
			 By Wood_Floors= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_6");
			 By Skills_1= By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_trEquipmentTechSkills']/td[1]/div[1]/div[1]");
			 By Fitness_Equipment= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_0");
			 By Spin_Bike= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_1");
			 By Upholstery= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_2");
//			 By Zumba= By.id("ctl00_MainContent_ApplicantAerobicsExperience_AerobicsEmploymentDetailItem1_CheckBoxListGroupFitness_Formats_13");
//			 By Bodyworks= By.id("ctl00_MainContent_ApplicantAerobicsExperience_AerobicsEmploymentDetailItem1_CheckBoxListGroupFitness_Formats_3");
			 
//			 By Hip= By.id("ctl00_MainContent_ApplicantAerobicsExperience_AerobicsEmploymentDetailItem1_CheckBoxListGroupFitness_Formats_7");
			 
			 
			 String[] check_boxes_ip=checkboxes_ip.split(",");
			 
			 for (String cb : check_boxes_ip) {
				 
				 String checkbox=cb.trim();
				 switch (checkbox) {
				 
				case "CPO":
					Element_isdisplayed(CPO);
					click(CPO);
					if(!driver.findElement(CPO).isSelected()) {click(CPO);Thread.sleep(10);}
					Log.info(checkbox+" check box successfully displayed and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					count++;
					break;
					
					
				case "Electrical":
					Element_isdisplayed(Electrical);
					click(Electrical);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					 count++;
					break;
					

				case "HVAC":
					Element_isdisplayed(HVAC);
					click(HVAC);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully ďisplayed and validated");
					 count++;
					break;
					
				case "Painter":
					Element_isdisplayed(Painter);
					click(Painter);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box  displayed and validated");
					 count++;
					break;
					
					
				case "Plumbing":
					Element_isdisplayed(Plumbing);
					click(Plumbing);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					 count++;
					break;
					

				case "Tiles":
					Element_isdisplayed(Tiles);
					click(Tiles);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					 count++;
					break;
					
				case "Wood Floors":
					 Element_isdisplayed(Wood_Floors);
					 MoveToElement(Wood_Floors);
					 click(Wood_Floors);
					 Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					 count++;
					 break;
					
									
					
				default:
					break;
				}
				
			}
			 
			 
		 
	}
	
}


public void Validate_Skills_2_section_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Experience_ip, String Exp_info_ip, String checkboxes_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Skills_2_section_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
			By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
		 	By FSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListSalesExperience");
			By PTSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListPTSalesExperience");
			By ME_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListManagementExperience");
			By BE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListBuildingExperience");
			By ETE= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			By Skills_heading= By.id("//tbody/tr[@id='ctl00_MainContent_ApplicantSalesMgmtExperience_trBuildingSkills']/td[1]/div[1]/div[1]");
			By YE_dd= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_DropDownListEquipmentTechExperience");
			
			Element_isdisplayed(YE_dd);
			 MoveToElement(YE_dd);
			 ExtentTestManager.getTest().log(Status.PASS, "Years of Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			 Log.info("Years of Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			
			Select YE= new Select(driver.findElement(YE_dd));
			 
			 if(YE.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip.trim())) {
				 ExtentTestManager.getTest().log(Status.PASS, "Years of Experience dropdown option : "+Experience_ip+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
				 Log.info("Years of Experience dropdown option : "+Experience_ip+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

			 }else {
				 
				 YE.selectByVisibleText(Experience_ip.trim());
				 ExtentTestManager.getTest().log(Status.PASS, "Years of Experience dropdown option : "+Experience_ip+" selected successfully in Employment Submit Application Experience Information level 3 page");
				 Log.info("Years of Experience dropdown option : "+Experience_ip+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");
			}

			 
			 Thread.sleep(300);
			 
			 int count=0;
			 By CPO= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_0");
			 By Electrical= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_1");
			 By HVAC= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_2");
			 By Painter= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_3");
			 By Plumbing= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_4");
			 By Tiles= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_5");
			 By Wood_Floors= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_6");
			 By Skills_1= By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_trEquipmentTechSkills']/td[1]/div[1]/div[1]");
			 By Fitness_Equipment= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_0");
			 By Spin_Bike= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_1");
			 By Upholstery= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_2");
//			 By Zumba= By.id("ctl00_MainContent_ApplicantAerobicsExperience_AerobicsEmploymentDetailItem1_CheckBoxListGroupFitness_Formats_13");
//			 By Bodyworks= By.id("ctl00_MainContent_ApplicantAerobicsExperience_AerobicsEmploymentDetailItem1_CheckBoxListGroupFitness_Formats_3");
			 
//			 By Hip= By.id("ctl00_MainContent_ApplicantAerobicsExperience_AerobicsEmploymentDetailItem1_CheckBoxListGroupFitness_Formats_7");
			 
			 Element_isdisplayed(Skills_1);
			 MoveToElement(Skills_1);
			 String Experience_txt=driver.findElement(Skills_1).getText().replace("\n", " ");
			 Assert.assertEquals(Experience_txt.toUpperCase().trim(), Exp_info_ip.toUpperCase().trim(), Exp_info_ip+" heading text in Employment Submit Application Experience Information level 3 page not validated");
			 ExtentTestManager.getTest().log(Status.PASS, Experience_txt+" heading text successfully displayed and validated in Employment Submit Application Experience Information level 3 page");
			 Log.info(Experience_txt+" heading text successfully displayed and validated in Employment Submit Application Experience Information level 3 page");

			 
			 String[] check_boxes_ip=checkboxes_ip.split(",");
			 
			 for (String cb : check_boxes_ip) {
				 
				 String checkbox=cb.trim();
				 switch (checkbox) {
				 
					
				case "Fitness Equipment":
					Element_isdisplayed(Fitness_Equipment);
					MoveToElement(Fitness_Equipment);
//					click(Fitness_Equipment);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					 count++;
					break;
					

				case "Spin Bike":
					Element_isdisplayed(Spin_Bike);
//					click(Spin_Bike);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					 count++;
					break;
					
				case "Upholstery":
					Element_isdisplayed(Upholstery);
//					click(Upholstery);
					Log.info(checkbox+" check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully displayed and validated");
					 count++;
					break; 			
					
				default:
					break;
				}
				
			}
			 
			 
		 
	}
	
}


public void Validate_select_Skills_2_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Experience_ip, String checkboxes_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_select_Skills_2_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
			By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
		 	By FSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListSalesExperience");
			By PTSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListPTSalesExperience");
			By ME_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListManagementExperience");
			By BE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListBuildingExperience");
			By ETE= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			By Skills_heading= By.id("//tbody/tr[@id='ctl00_MainContent_ApplicantSalesMgmtExperience_trBuildingSkills']/td[1]/div[1]/div[1]");
			By YE_dd= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_DropDownListEquipmentTechExperience");
			
			Element_isdisplayed(YE_dd);
			 MoveToElement(YE_dd);
			 ExtentTestManager.getTest().log(Status.PASS, "Years of Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			 Log.info("Years of Experience dropdown successfully displayed in Employment Submit Application Experience Information level 3 page");
			
			Select YE= new Select(driver.findElement(YE_dd));
			 
			 if(YE.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip.trim())) {
				 ExtentTestManager.getTest().log(Status.PASS, "Years of Experience dropdown option : "+Experience_ip+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
				 Log.info("Years of Experience dropdown option : "+Experience_ip+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

			 }else {
				 
				 YE.selectByVisibleText(Experience_ip.trim());
				 ExtentTestManager.getTest().log(Status.PASS, "Years of Experience dropdown option : "+Experience_ip+" selected successfully in Employment Submit Application Experience Information level 3 page");
				 Log.info("Years of Experience dropdown option : "+Experience_ip+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");
			}

			 
			 Thread.sleep(300);
			 
			 int count=0;
			 By CPO= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_0");
			 By Electrical= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_1");
			 By HVAC= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_2");
			 By Painter= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_3");
			 By Plumbing= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_4");
			 By Tiles= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_5");
			 By Wood_Floors= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_6");
			 By Skills_1= By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_trEquipmentTechSkills']/td[1]/div[1]/div[1]");
			 By Fitness_Equipment= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_0");
			 By Spin_Bike= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_1");
			 By Upholstery= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_2");
			 
			 String[] check_boxes_ip=checkboxes_ip.split(",");
			 
			 for (String cb : check_boxes_ip) {
				 
				 String checkbox=cb.trim();
				 switch (checkbox) {
				 
					
				case "Fitness Equipment":
					Element_isdisplayed(Fitness_Equipment);
					MoveToElement(Fitness_Equipment);
					click(Fitness_Equipment);
					if(!driver.findElement(Fitness_Equipment).isSelected()) {click(Fitness_Equipment);Thread.sleep(10);}
					Log.info(checkbox+" check box successfully validated and selected");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully validated and selected");
					 count++;
					break;
					

				case "Spin Bike":
					Element_isdisplayed(Spin_Bike);
					click(Spin_Bike);
					Log.info(checkbox+" check box successfully validated and selected");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully validated and selected");
					 count++;
					break;
					
				case "Upholstery":
					Element_isdisplayed(Upholstery);
					click(Upholstery);
					Log.info(checkbox+" check box successfully validated and selected");
					 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully validated and selected");
					 count++;
					break; 			
					
				default:
					break;
				}
				
			}
			 
	}
	
}


public void Validate_Prev_next_btns_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Prev_next_btns_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
		By btn_prev= By.id("btn_prev");
			By btn_next= By.id("btn_next")
					;
		 Element_isdisplayed(btn_prev);
		 MoveToElement(btn_prev);
		 Log.info("Previous step button is displayed successfully in Experience Information level 3 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Experience Information level 3 page");
		
		 Element_isdisplayed(btn_next);
		 Log.info("Next step button is displayed successfully in Experience Information level 3 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Experience Information level 3 page");


	}
	
}


public void Validate_Next_step_in_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Next_step_in_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
			By Experience_text= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
		 	By FSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListSalesExperience");
			By PTSE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListPTSalesExperience");
			By ME_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListManagementExperience");
			By BE_dd= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_DropDownListBuildingExperience");
			By ETE= By.xpath("//div[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_UpdatePanelEquipmentTech']//div//b[contains(text(),'Equipment Technician Experience:')]");
			By YE_dd= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_DropDownListEquipmentTechExperience");
		
			String[] Experience_ip=Exp_ip.split(",");
		 
		 Element_isdisplayed(FSE_dd);
		 Select FSE= new Select(driver.findElement(FSE_dd));
		 if(FSE.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip[0].trim())) {
			 ExtentTestManager.getTest().log(Status.PASS, "Fitness Sales Experience dropdown option : "+Experience_ip[0]+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Fitness Sales Experience dropdown option : "+Experience_ip[0]+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		 }else {
			 
			 FSE.selectByVisibleText(Experience_ip[0].trim());
			 ExtentTestManager.getTest().log(Status.PASS, "Fitness Sales Experience dropdown option : "+Experience_ip[0]+" selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Fitness Sales Experience dropdown option : "+Experience_ip[0]+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		}
		 Thread.sleep(200);
		 Element_isdisplayed(PTSE_dd);
		 Select PTSE= new Select(driver.findElement(PTSE_dd));
		 
		 if(PTSE.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip[1].trim())) {
			 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Sales Experience dropdown option : "+Experience_ip[1]+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Personal Training Sales Experience dropdown option : "+Experience_ip[1]+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		 }else {
			 
			 PTSE.selectByVisibleText(Experience_ip[1].trim());
			 ExtentTestManager.getTest().log(Status.PASS, "Personal Training Sales Experience dropdown option : "+Experience_ip[1]+" selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Personal Training Sales Experience dropdown option : "+Experience_ip[1]+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		}
		 Thread.sleep(300);
		 Element_isdisplayed(ME_dd);
		 Select ME= new Select(driver.findElement(ME_dd));
		 
		 if(ME.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip[2].trim())) {
			 ExtentTestManager.getTest().log(Status.PASS, "Management Experience dropdown option : "+Experience_ip[2]+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Management Experience dropdown option : "+Experience_ip[2]+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		 }else {
			 
			 ME.selectByVisibleText(Experience_ip[2].trim());
			 ExtentTestManager.getTest().log(Status.PASS, "Management Experience dropdown option : "+Experience_ip[2]+" selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Management Experience dropdown option : "+Experience_ip[2]+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");
		}

		 Thread.sleep(200);
		 Element_isdisplayed(BE_dd);
		 
		 Select BE= new Select(driver.findElement(BE_dd));
		 
		 if(BE.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip[3].trim())) {
			 ExtentTestManager.getTest().log(Status.PASS, "Building Experience dropdown option : "+Experience_ip[3]+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Building Experience dropdown option : "+Experience_ip[3]+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		 }else {
			 Thread.sleep(300);
			 BE.selectByVisibleText(Experience_ip[3].trim());
			 ExtentTestManager.getTest().log(Status.PASS, "Building Experience dropdown option : "+Experience_ip[3]+" selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Building Experience dropdown option : "+Experience_ip[3]+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");
		}
		 
		 Thread.sleep(300);
		 
		 int count=0;
		 By CPO= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_0");
		 By Electrical= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_1");
		 By HVAC= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_2");
		 By Painter= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_3");
		 By Plumbing= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_4");
		 By Tiles= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_5");
		 By Wood_Floors= By.id("ctl00_MainContent_ApplicantSalesMgmtExperience_CheckBoxListBuildingSkills_6");
		 By Skills_1= By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantEquipmentTechExperience_trEquipmentTechSkills']/td[1]/div[1]/div[1]");
		 By Fitness_Equipment= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_0");
		 By Spin_Bike= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_1");
		 By Upholstery= By.id("ctl00_MainContent_ApplicantEquipmentTechExperience_CheckBoxListEquipmentTechSkills_2");
//		 By Zumba= By.id("ctl00_MainContent_ApplicantAerobicsExperience_AerobicsEmploymentDetailItem1_CheckBoxListGroupFitness_Formats_13");
//		 By Bodyworks= By.id("ctl00_MainContent_ApplicantAerobicsExperience_AerobicsEmploymentDetailItem1_CheckBoxListGroupFitness_Formats_3");
		 
//		 By Hip= By.id("ctl00_MainContent_ApplicantAerobicsExperience_AerobicsEmploymentDetailItem1_CheckBoxListGroupFitness_Formats_7");
		 
		 
		 String[] check_boxes_ip=checkboxes_ip.split(",");
		 
		 for (String cb : check_boxes_ip) {
			 
			 String checkbox=cb.trim();
			 switch (checkbox) {
			 
			case "CPO":
				Element_isdisplayed(CPO);
				click(CPO);
				if(!driver.findElement(CPO).isSelected()) {click(CPO);Thread.sleep(10);}
				Log.info(checkbox+" check box successfully selected and validated");
				ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
				count++;
				break;
				
				
			case "Electrical":
				Element_isdisplayed(Electrical);
				click(Electrical);
				Log.info(checkbox+" check box successfully selected and validated");
				 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
				 count++;
				break;
				

			case "HVAC":
				Element_isdisplayed(HVAC);
				click(HVAC);
				Log.info(checkbox+" check box successfully selected and validated");
				 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
				 count++;
				break;
				
			case "Painter":
				Element_isdisplayed(Painter);
				click(Painter);
				Log.info(checkbox+" check box successfully selected and validated");
				 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box  selected and validated");
				 count++;
				break;
				
				
			case "Plumbing":
				Element_isdisplayed(Plumbing);
				click(Plumbing);
				Log.info(checkbox+" check box successfully selected and validated");
				 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
				 count++;
				break;
				

			case "Tiles":
				Element_isdisplayed(Tiles);
				click(Tiles);
				Log.info(checkbox+" check box successfully selected and validated");
				 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
				 count++;
				break;
				
			case "Wood Floors":
				 Element_isdisplayed(Wood_Floors);
				 MoveToElement(Wood_Floors);
				 click(Wood_Floors);
				 Log.info(checkbox+" check box successfully selected and validated");
				 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
				 count++;
				 break;
				
								
				
			default:
				break;
			}
			
		}
		 


		 Thread.sleep(300);
		 Element_isdisplayed(YE_dd);
		 MoveToElement(YE_dd);
		Thread.sleep(200);
		 
		 Select YE= new Select(driver.findElement(YE_dd));
		 
		 if(YE.getFirstSelectedOption().getText().toString().trim().equalsIgnoreCase(Experience_ip[4].trim())) {
			 ExtentTestManager.getTest().log(Status.PASS, "Years of Experience dropdown option : "+Experience_ip[4]+" is by default selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Years of Experience dropdown option : "+Experience_ip[4]+" is by default selected successfully successfully in Employment Submit Application Experience Information level 3 page");

		 }else {
			 
			 YE.selectByVisibleText(Experience_ip[4].trim());
			 ExtentTestManager.getTest().log(Status.PASS, "Years of Experience dropdown option : "+Experience_ip[4]+" selected successfully in Employment Submit Application Experience Information level 3 page");
			 Log.info("Years of Experience dropdown option : "+Experience_ip[4]+" selected successfully successfully in Employment Submit Application Experience Information level 3 page");
		}
		 Thread.sleep(300);
		 
		 
		 String[] check_boxes_ip_1=checkboxes_ip_1.split(",");
		 
		 for (String cb : check_boxes_ip_1) {
			 
			 String checkbox=cb.trim();
			 switch (checkbox) {
			 
				
			case "Fitness Equipment":
				Element_isdisplayed(Fitness_Equipment);
				MoveToElement(Fitness_Equipment);
				click(Fitness_Equipment);
				if(!driver.findElement(Fitness_Equipment).isSelected()) {click(Fitness_Equipment);Thread.sleep(10);}
				Log.info(checkbox+" check box successfully validated and selected");
				 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully validated and selected");
				 count++;
				break;
				

			case "Spin Bike":
				Element_isdisplayed(Spin_Bike);
				click(Spin_Bike);
				Log.info(checkbox+" check box successfully validated and selected");
				 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully validated and selected");
				 count++;
				break;
				
			case "Upholstery":
				Element_isdisplayed(Upholstery);
				click(Upholstery);
				Log.info(checkbox+" check box successfully validated and selected");
				 ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully validated and selected");
				 count++;
				break; 			
				
			default:
				break;
			}
			
		}

		 By btn_prev= By.id("btn_prev");
		By btn_next= By.id("btn_next");
		By emp_his= By.xpath("//span[contains(text(),'Employment History')]");
			 
			
		
		 Element_isdisplayed(btn_next);
		 MoveToElement(btn_prev);
		 click(btn_next);
		 Thread.sleep(500);
		 Log.info("Next step button is clicked successfully in Experience Information level 3 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Next step button is clicked successfully in Experience Information level 3 page");

		 Element_isdisplayed(emp_his);
		 String emp_his_txt=driver.findElement(emp_his).getText().replace("\n", " ");
		 Assert.assertEquals(emp_his_txt.toUpperCase().trim(), "Employment History".toUpperCase().trim(), "Employment History text in Employment Submit Application level 4 page not validated");
		 Log.info(emp_his_txt+" text successfully displayed and navigated to Employment Submit Application Employment History level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, emp_his_txt+" text successfully displayed and navigated to Employment Submit Application Employment History level 4 page");
	
	}
	
}


public void Validate_Prev_step_in_l3_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Prev_step_in_l3_AH")) 
	{
		
		Validate_Next_step_btn_l2_AH("Validate_Next_step_btn_l2_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip);
		
		By btn_prev= By.id("btn_prev");
		By btn_next= By.id("btn_next");
		By Edu_info= By.xpath("//span[contains(text(),'Education Information')]");
			
		 Element_isdisplayed(btn_prev);
		 MoveToElement(btn_prev);
		 Log.info("Previous step button is displayed successfully in Experience Information level 3 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Experience Information level 3 page");
		
		
		 	click(btn_prev);
			ExtentTestManager.getTest().log(Status.PASS,  "Successfully clicked on Previous button" );
			Log.info("Successfully clicked on Previous button");
			Thread.sleep(500);
			 Element_isdisplayed(Edu_info);
			 String edu_info_txt=driver.findElement(Edu_info).getText().replace("\n", " ");
			 Assert.assertEquals(edu_info_txt.toUpperCase().trim(), L2_txt.toUpperCase().trim(), "Education Information text in Employment Submit Application level 2 page not validated");
			 Log.info(edu_info_txt+" text successfully displayed and navigated to Employment Submit Application Education Information level 2 page");
			 ExtentTestManager.getTest().log(Status.PASS, edu_info_txt+" text successfully displayed and navigated to Employment Submit Application Education Information level 2 page");
			
	}
	
}



public void Validate_EmpHis_PreEmp_texts_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_EmpHis_PreEmp_texts_in_l4_AH")) 
	{
		
		Validate_Next_step_in_l3_AH("Validate_Next_step_in_l3_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
//		 By emp_his= By.xpath("//span[contains(text(),'Employment History')]");
		
		 By hist=By.xpath("//span[contains(text(),'Employment History')]");
		 By prev_emp=By.xpath("//div[contains(text(),'Previous Employment:')]");
//		 By emp_gap=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxEmploymentGapExplanation");
//		 By empr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerName1");
//		 By spr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerSupervisor1");
//		 By phone=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerPhone1");
//		 By from_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentFrom1");
//		 By to_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentTo1");
//		 By job_title=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentJobTitle1");
//		 By reason=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentReason1");
//		 By emp_details=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentDetail1");
//		 By cancontact_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_0");
//		 By cancontact_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_1");
//		 
//		 By add_empr_2=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");
//		 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
//		 By wiil_upload_resume=By.id("ctl00_MainContent_ApplicantPreviousEmployment_CheckBoxResume");
//		 By resume_text=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_TableFileUploadItem");
		 
		 
		 
		 Element_isdisplayed(hist);
		 String hist_txt=driver.findElement(hist).getText().replace("\n", " ");
		 Assert.assertEquals(hist_txt.toUpperCase().trim(), "Employment History".toUpperCase().trim(), "Employment History text in Employment Submit Application level 4 page not validated");
		 Log.info(hist_txt+" text successfully displayed and navigated to Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, hist_txt+" text successfully displayed and navigated to Employment History Application level 4 page");
		 
		 Element_isdisplayed(prev_emp);
		 String pre_emp_txt=driver.findElement(prev_emp).getText().replace("*", "");
		 Assert.assertEquals(pre_emp_txt.toUpperCase().trim(), "Previous Employment:".toUpperCase().trim(), "Previous Employment text not validated");
		 Log.info(pre_emp_txt+" text successfully displayed and validated ");
		 ExtentTestManager.getTest().log(Status.PASS, pre_emp_txt+" text successfully displayed and validated ");
		 
			

		
	}
	

}


public void Validate_rdobtns_of_EmpHis_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_rdobtns_of_EmpHis_in_l4_AH")) 
	{
		
		Validate_Next_step_in_l3_AH("Validate_Next_step_in_l3_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
//		 By emp_his= By.xpath("//span[contains(text(),'Employment History')]");
		
//		 By hist=By.xpath("//span[contains(text(),'Employment History')]");
//		 By prev_emp=By.xpath("//div[contains(text(),'Previous Employment:')]");
//		 By emp_gap=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxEmploymentGapExplanation");
//		 By empr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerName1");
//		 By spr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerSupervisor1");
//		 By phone=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerPhone1");
//		 By from_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentFrom1");
//		 By to_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentTo1");
//		 By job_title=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentJobTitle1");
//		 By reason=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentReason1");
//		 By emp_details=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentDetail1");
//		 By cancontact_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_0");
//		 By cancontact_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_1");
//		 
//		 By add_empr_2=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");
//		 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
//		 By wiil_upload_resume=By.id("ctl00_MainContent_ApplicantPreviousEmployment_CheckBoxResume");
//		 By resume_text=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_TableFileUploadItem");
//		 By emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
		 By Emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
		 By Emp_his_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpExists");
		 
		 
		 
		 Element_isdisplayed(Emp_his_no);
//		 String hist_txt=driver.findElement(hist).getText().replace("\n", " ");
//		 Assert.assertEquals(hist_txt.toUpperCase().trim(), "Employment History".toUpperCase().trim(), "Employment History text in Employment Submit Application level 4 page not validated");
		 Log.info("No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
		 
//		 Element_isdisplayed(prev_emp);
//		 String pre_emp_txt=driver.findElement(prev_emp).getText().replace("*", "");
//		 Assert.assertEquals(pre_emp_txt.toUpperCase().trim(), "Previous Employment:".toUpperCase().trim(), "Previous Employment text not validated");
//		 Log.info(pre_emp_txt+" text successfully displayed and validated ");
//		 ExtentTestManager.getTest().log(Status.PASS, pre_emp_txt+" text successfully displayed and validated ");
//		 
			
		 Element_isdisplayed(Emp_his_yes);
		 Assert.assertTrue(driver.findElement(Emp_his_yes).isSelected());
		 Log.info("Have An Employment History radio button is displayed successfully and by default selected in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Have An Employment History radio button is displayed and by default selected successfully in Employment History Application level 4 page");
		 
		
	}
	

}


public void Validate_upload_res_chkbx_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_upload_res_chkbx_in_l4_AH")) 
	{
		
		Validate_Next_step_in_l3_AH("Validate_Next_step_in_l3_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
//		 By emp_his= By.xpath("//span[contains(text(),'Employment History')]");
//		I Will Upload My Resume:
		
//		 By hist=By.xpath("//span[contains(text(),'Employment History')]");
//		 By prev_emp=By.xpath("//div[contains(text(),'Previous Employment:')]");
//		 By emp_gap=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxEmploymentGapExplanation");
//		 By empr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerName1");
//		 By spr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerSupervisor1");
//		 By phone=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerPhone1");
//		 By from_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentFrom1");
//		 By to_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentTo1");
//		 By job_title=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentJobTitle1");
//		 By reason=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentReason1");
//		 By emp_details=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentDetail1");
//		 By cancontact_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_0");
//		 By cancontact_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_1");
		 
//		 By add_empr_2=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");
//		 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
		 By wiil_upload_resume=By.id("ctl00_MainContent_ApplicantPreviousEmployment_CheckBoxResume");
//		 By resume_text=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_TableFileUploadItem");
//		 By emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
//		 By Emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
//		 By Emp_his_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpExists");
		 
		 
		 
//		 Element_isdisplayed(Emp_his_no);
//		 String hist_txt=driver.findElement(hist).getText().replace("\n", " ");
//		 Assert.assertEquals(hist_txt.toUpperCase().trim(), "Employment History".toUpperCase().trim(), "Employment History text in Employment Submit Application level 4 page not validated");
//		 Log.info("No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
		 
//		 Element_isdisplayed(prev_emp);
//		 String pre_emp_txt=driver.findElement(prev_emp).getText().replace("*", "");
//		 Assert.assertEquals(pre_emp_txt.toUpperCase().trim(), "Previous Employment:".toUpperCase().trim(), "Previous Employment text not validated");
//		 Log.info(pre_emp_txt+" text successfully displayed and validated ");
//		 ExtentTestManager.getTest().log(Status.PASS, pre_emp_txt+" text successfully displayed and validated ");
//		 
			
		 Element_isdisplayed(wiil_upload_resume);
		 Assert.assertTrue(!driver.findElement(wiil_upload_resume).isSelected());
		 Log.info("I Will Upload My Resume checkbox is displayed successfully and by default not selected in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "I Will Upload My Resume checkbox is displayed successfully and by default not selected in Employment History Application level 4 page");
		 
		
	}
	

}


public void Validate_upload_res_section_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1, String Resume_format_txt) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_upload_res_section_in_l4_AH")) 
	{
		
		Validate_upload_res_chkbx_in_l4_AH("Validate_upload_res_chkbx_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
			 
		 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
		 By wiil_upload_resume=By.id("ctl00_MainContent_ApplicantPreviousEmployment_CheckBoxResume");
		 By resume_text=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_TableFileUploadItem");
			
		 click(wiil_upload_resume);
//		 Assert.assertTrue(!driver.findElement(wiil_upload_resume).isSelected());
		 Thread.sleep(200);
		 Log.info("Successfully clicked on I Will Upload My Resume checkbox in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on I Will Upload My Resume checkbox in Employment History Application level 4 page");
		 
		 Element_isdisplayed(resume_text);
		 String resume_t=driver.findElement(resume_text).getText().replace("\n", " ");
		 Assert.assertEquals(resume_t.toUpperCase().trim(), Resume_format_txt.toUpperCase().trim(), "Resume files format text ("+ Resume_format_txt +") in Employment Submit Application level 4 page not validated");
		 Log.info("Resume files format text ("+ Resume_format_txt +") successfully displayed and validated in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Resume files format text ("+ Resume_format_txt +") successfully displayed and validated in Employment History Application level 4 page");
		 
		 Element_isdisplayed(choose_file);
		 Log.info("Choose file input button displayed Successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Choose file input button displayed Successfully in Employment History Application level 4 page");
		 
	}
	

}


public void Validate_upload_res_file_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1, String Resume_format_txt, String doc_name) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_upload_res_file_l4_AH")) 
	{
		
		Validate_upload_res_section_in_l4_AH("Validate_upload_res_section_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1, Resume_format_txt);
		
	 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
		 
		 Element_isdisplayed(choose_file);
		 Log.info("Choose file input button displayed Successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Choose file input button displayed Successfully in Employment History Application level 4 page");
		 
		 upload_file(choose_file, doc_name);
		 Log.info("Successfully uploaded the file: "+doc_name);
		ExtentTestManager.getTest().log(Status.PASS, "Successfully uploaded the file: "+doc_name);
		
		
			}
	

}


public void Validate_cur_prev_emp_texts_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1, String emp_txts) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_cur_prev_emp_texts_in_l4_AH")) 
	{
		
		Validate_Next_step_in_l3_AH("Validate_Next_step_in_l3_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
		
		By curr_txt=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantPreviousEmployment_trEmpHistoryTitle1']/td[1]/div[1]");
			
			 By begi_txt=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[8]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/table[2]/tbody[1]/tr[1]/td[1]/div[2]/div[1]/div[1]");
			 
			 
				String[] txt= emp_txts.split(",");
			 
			 Element_isdisplayed(begi_txt);
			 MoveToElement(begi_txt);
			 String beginning=driver.findElement(begi_txt).getText().replace("\n", " ");
			 Assert.assertEquals(beginning.toUpperCase().trim(), txt[0].toUpperCase().trim(), beginning +"text in Employment Submit Application level 4 page not validated");
			 Log.info(beginning +" text successfully displayed and validated in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, beginning +"text  successfully displayed and validated in Employment History Application level 4 page");
			
			 Element_isdisplayed(curr_txt);
			 MoveToElement(curr_txt);
			 String current=driver.findElement(curr_txt).getText().replace("\n", " ");
			 Assert.assertEquals(current.toUpperCase().trim(), txt[1].toUpperCase().trim(), current +"text in Employment Submit Application level 4 page not validated");
			 Log.info(current +" text successfully displayed and validated in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, current +"text  successfully displayed and validated in Employment History Application level 4 page");

	}

}


public void Validate_all_ip_fields_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_ip_fields_in_l4_AH")) 
	{
		
		Validate_Next_step_in_l3_AH("Validate_Next_step_in_l3_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
		
		
		 By hist=By.xpath("//span[contains(text(),'Employment History')]");
		 By prev_emp=By.xpath("//div[contains(text(),'Previous Employment:')]");
		 By emp_gap=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxEmploymentGapExplanation");
		 By empr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerName1");
		 By spr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerSupervisor1");
		 By phone=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerPhone1");
		 By from_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentFrom1");
		 By to_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentTo1");
		 By job_title=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentJobTitle1");
		 By reason=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentReason1");
		 By emp_details=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentDetail1");
		 By cancontact_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_0");
		 By cancontact_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_1");
		 
		 By add_empr_2=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");
		 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
		 By wiil_upload_resume=By.id("ctl00_MainContent_ApplicantPreviousEmployment_CheckBoxResume");
		 By resume_text=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_TableFileUploadItem");
		 By emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
		 By Emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
		 By Emp_his_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpExists");
		 By curr_txt=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantPreviousEmployment_trEmpHistoryTitle1']/td[1]/div[1]");
		
		 By begi_txt=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[8]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/table[2]/tbody[1]/tr[1]/td[1]/div[2]/div[1]/div[1]");
		 
		 
		 Element_isdisplayed(emp_gap);
		 Log.info("Employment Gap Explanation input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Gap Explanation input field is displayed successfully in Employment History Application level 4 page");
		 
//		 input(emp_gap, "Due to some family issues");
		 
		 Element_isdisplayed(empr_name);
		 Log.info("Employer Name input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employer Name input field is displayed successfully in Employment History Application level 4 page");
		 
//		 input(empr_name, "LA Fitness");
		 
		 Element_isdisplayed(spr_name);
		 
		 Log.info("Supervisor Name input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Supervisor Name input field is displayed successfully in Employment History Application level 4 page");
		 
//		 input(spr_name, "Karan");
		 
		 Element_isdisplayed(phone);
		 Log.info("Phone input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Phone input field is displayed successfully in Employment History Application level 4 page");
		 
		 
//		 input(phone, "9848022337");
		 
		 Element_isdisplayed(from_date);
		 Log.info("Employment Dates From input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates From input field is displayed successfully in Employment History Application level 4 page");
		 
//		 input(from_date, "10/12/2020");
		 
		 Element_isdisplayed(to_date);
		 Log.info("Employment Dates To input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates To input field is displayed successfully in Employment History Application level 4 page");
		 
//		 input(to_date, "10/12/2021");
		 
		 Element_isdisplayed(job_title);
		 Log.info("Last Job Title input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Last Job Title input field is displayed successfully in Employment History Application level 4 page");
		 
		 
//		 input(job_title, "Trainer");
		 
		 Element_isdisplayed(reason);
		 Log.info("Reason for Leaving: (be specific) input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Reason for Leaving: (be specific) input field is displayed successfully in Employment History Application level 4 page");
		 
//		 input(reason, "some emergency");

		 Element_isdisplayed(emp_details);
		 Log.info("Employment Detail input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Detail input field is displayed successfully in Employment History Application level 4 page");
		 
//		 input(emp_details, "Trainer, La Fitness club");
		 
		 Element_isdisplayed(cancontact_yes);
		 MoveToElement(cancontact_yes);
		 Log.info("Can be Contacted yes radio button is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted yes radio button is displayed successfully in Employment History Application level 4 page");
		 
		 Element_isdisplayed(cancontact_no);
//		 MoveToElement(cancontact_no);
		 Log.info("Can be Contacted no radio button is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button is displayed successfully in Employment History Application level 4 page");
		 
//		 Element_isdisplayed(emp_details);
//		 input(emp_details, "Trainer, La Fitness club");
//		 click(cancontact_yes);

		
	}
	

}


public void Validate_input_inallfields_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_input_inallfields_in_l4_AH")) 
	{
		
		Validate_Next_step_in_l3_AH("Validate_Next_step_in_l3_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
		
		
		 By hist=By.xpath("//span[contains(text(),'Employment History')]");
		 By prev_emp=By.xpath("//div[contains(text(),'Previous Employment:')]");
		 By emp_gap=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxEmploymentGapExplanation");
		 By empr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerName1");
		 By spr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerSupervisor1");
		 By phone=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerPhone1");
		 By from_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentFrom1");
		 By to_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentTo1");
		 By job_title=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentJobTitle1");
		 By reason=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentReason1");
		 By emp_details=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentDetail1");
		 By cancontact_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_0");
		 By cancontact_yes_txt=By.xpath("//label[@for='ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_0']");
		 By cancontact_no_txt=By.xpath("//label[@for='ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_1']");
		 By cancontact_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_1");
		 
		 By add_empr_2=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");
		 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
		 By wiil_upload_resume=By.id("ctl00_MainContent_ApplicantPreviousEmployment_CheckBoxResume");
		 By resume_text=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_TableFileUploadItem");
		 By emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
		 By Emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
		 By Emp_his_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpExists");
		 By curr_txt=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantPreviousEmployment_trEmpHistoryTitle1']/td[1]/div[1]");
		
		 By begi_txt=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[8]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/table[2]/tbody[1]/tr[1]/td[1]/div[2]/div[1]/div[1]");
		 
		 
		 Element_isdisplayed(emp_gap);
		 Log.info("Employment Gap Explanation input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Gap Explanation input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(emp_gap, Gap_ip.trim());
		 Log.info("Successfully Entered '"+Gap_ip.trim()+"' input in Employment Gap Explanation input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+Gap_ip.trim()+"' input in Employment Gap Explanation input field in Employment History Application level 4 page");
		 
	
		 Element_isdisplayed(empr_name);
		 Log.info("Employer Name input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employer Name input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(empr_name, emplr_name.trim());
		 Log.info("Successfully Entered '"+emplr_name.trim()+"' input in Employer Name input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+emplr_name.trim()+"' input in Employer Name input field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(spr_name);
		 Log.info("Supervisor Name input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Supervisor Name input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(spr_name, supr_name.trim());
		 Log.info("Successfully Entered '"+supr_name.trim()+"' input in Supervisor Name input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+supr_name.trim()+"' input in Supervisor Name input field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(phone);
		 Log.info("Phone input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Phone input field is displayed successfully in Employment History Application level 4 page");
		 
		 
		 input(phone, Phone.trim());
		 Log.info("Successfully Entered '"+Phone.trim()+"' input in Phone input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+Phone.trim()+"' input in Phone field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(from_date);
		 Log.info("Employment Dates From input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates From input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(from_date, emp_from_date.trim());
		 Log.info("Successfully Entered '"+emp_from_date.trim()+"' input in Employment Dates From input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+emp_from_date.trim()+"' input in Employment Dates From field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(to_date);
		 Log.info("Employment Dates To input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates To input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(to_date, emp_to_date.trim());
		 Log.info("Successfully Entered '"+emp_to_date.trim()+"' input in Employment Dates To input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+emp_to_date.trim()+"' input in Employment Dates To field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(job_title);
		 Log.info("Last Job Title input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Last Job Title input field is displayed successfully in Employment History Application level 4 page");
		 	 
		 input(job_title, title.trim());
		 Log.info("Successfully Entered '"+title.trim()+"' input in Last Job Title input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+title.trim()+"' input in Last Job Title input field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(reason);
		 Log.info("Reason for Leaving: (be specific) input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Reason for Leaving: (be specific) input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(reason, leaving_reason.trim());
		 Log.info("Successfully Entered '"+leaving_reason.trim()+"' input in Reason for Leaving input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+leaving_reason.trim()+"' input in Reason for Leaving input field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(emp_details);
		 Log.info("Employment Detail input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Detail input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(emp_details, emp_details_ip.trim());
		 Log.info("Successfully Entered '"+emp_details_ip.trim()+"' input in Employment Detail input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+emp_details_ip.trim()+"' input in Employment Detail input field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(cancontact_yes);
		 Log.info("Can be Contacted yes radio button is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted yes radio button is displayed successfully in Employment History Application level 4 page");
		 
		 Element_isdisplayed(cancontact_no);
		 Log.info("Can be Contacted no radio button is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button is displayed successfully in Employment History Application level 4 page");
		 
		 if(driver.findElement(cancontact_yes_txt).getText().equalsIgnoreCase(can_contact_ip)) {
			 click(cancontact_yes);
			 Log.info("Can be Contacted yes radio button is selected in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted yes radio button is selected in Employment History Application level 4 page");
			 
		 }
		 
		else if(driver.findElement(cancontact_no_txt).getText().equalsIgnoreCase(can_contact_ip)) {
		
			if(!driver.findElement(cancontact_no).isSelected()) {
				
				click(cancontact_no);
				Log.info("Can be Contacted no radio button is selected in Employment History Application level 4 page");
				ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button is selected in Employment History Application level 4 page");
				 
				
			}
			else {
				 Log.info("Can be Contacted no radio button is by default selected in Employment History Application level 4 page");
				 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button is by default selected in Employment History Application level 4 page");
				 
			}
			
			
			
		}

		
	}
	

}


public void Validate_input_inallfields_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_input_inallfields_in_l4_AH")) 
	{
		
		Validate_Next_step_in_l3_AH("Validate_Next_step_in_l3_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
		
		 By hist=By.xpath("//span[contains(text(),'Employment History')]");
		 By prev_emp=By.xpath("//div[contains(text(),'Previous Employment:')]");
		 By emp_gap=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxEmploymentGapExplanation");
		 By empr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerName1");
		 By spr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerSupervisor1");
		 By phone=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerPhone1");
		 By from_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentFrom1");
		 By to_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentTo1");
		 By job_title=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentJobTitle1");
		 By reason=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentReason1");
		 By emp_details=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentDetail1");
		 By cancontact_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_0");
		 By cancontact_yes_txt=By.xpath("//label[@for='ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_0']");
		 By cancontact_no_txt=By.xpath("//label[@for='ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_1']");
		 By cancontact_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_1");
		 
		 By add_empr_2=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");
		 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
		 By wiil_upload_resume=By.id("ctl00_MainContent_ApplicantPreviousEmployment_CheckBoxResume");
		 By resume_text=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_TableFileUploadItem");
		 By emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
		 By Emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
		 By Emp_his_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpExists");
		 By curr_txt=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantPreviousEmployment_trEmpHistoryTitle1']/td[1]/div[1]");
		
		 By begi_txt=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[8]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/table[2]/tbody[1]/tr[1]/td[1]/div[2]/div[1]/div[1]");
		 
		 
//	 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
//		 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
//		 By wiil_upload_resume=By.id("ctl00_MainContent_ApplicantPreviousEmployment_CheckBoxResume");
//		 By resume_text=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_TableFileUploadItem");
//			
		 click(wiil_upload_resume);
//		 Assert.assertTrue(!driver.findElement(wiil_upload_resume).isSelected());
		 Thread.sleep(500);
		 Log.info("Successfully clicked on I Will Upload My Resume checkbox in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on I Will Upload My Resume checkbox in Employment History Application level 4 page");
		 
		 Element_isdisplayed(choose_file);
		 Log.info("Choose file input button displayed Successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Choose file input button displayed Successfully in Employment History Application level 4 page");
		 
		 upload_file(choose_file, doc_name);
		 Log.info("Successfully uploaded the file: "+doc_name);
		ExtentTestManager.getTest().log(Status.PASS, "Successfully uploaded the file: "+doc_name);
		
		Thread.sleep(500);
		 Element_isdisplayed(emp_gap);
		 Log.info("Employment Gap Explanation input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Gap Explanation input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(emp_gap, Gap_ip.trim());
		 Log.info("Successfully Entered '"+Gap_ip.trim()+"' input in Employment Gap Explanation input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+Gap_ip.trim()+"' input in Employment Gap Explanation input field in Employment History Application level 4 page");
		 
	
		 Element_isdisplayed(empr_name);
		 Log.info("Employer Name input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employer Name input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(empr_name, emplr_name.trim());
		 Log.info("Successfully Entered '"+emplr_name.trim()+"' input in Employer Name input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+emplr_name.trim()+"' input in Employer Name input field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(spr_name);
		 Log.info("Supervisor Name input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Supervisor Name input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(spr_name, supr_name.trim());
		 Log.info("Successfully Entered '"+supr_name.trim()+"' input in Supervisor Name input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+supr_name.trim()+"' input in Supervisor Name input field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(phone);
		 Log.info("Phone input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Phone input field is displayed successfully in Employment History Application level 4 page");
		 
		 
		 input(phone, Phone.trim());
		 Log.info("Successfully Entered '"+Phone.trim()+"' input in Phone input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+Phone.trim()+"' input in Phone field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(from_date);
		 Log.info("Employment Dates From input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates From input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(from_date, emp_from_date.trim());
		 Log.info("Successfully Entered '"+emp_from_date.trim()+"' input in Employment Dates From input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+emp_from_date.trim()+"' input in Employment Dates From field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(to_date);
		 Log.info("Employment Dates To input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates To input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(to_date, emp_to_date.trim());
		 Log.info("Successfully Entered '"+emp_to_date.trim()+"' input in Employment Dates To input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+emp_to_date.trim()+"' input in Employment Dates To field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(job_title);
		 Log.info("Last Job Title input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Last Job Title input field is displayed successfully in Employment History Application level 4 page");
		 	 
		 input(job_title, title.trim());
		 Log.info("Successfully Entered '"+title.trim()+"' input in Last Job Title input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+title.trim()+"' input in Last Job Title input field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(reason);
		 Log.info("Reason for Leaving: (be specific) input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Reason for Leaving: (be specific) input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(reason, leaving_reason.trim());
		 Log.info("Successfully Entered '"+leaving_reason.trim()+"' input in Reason for Leaving input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+leaving_reason.trim()+"' input in Reason for Leaving input field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(emp_details);
		 Log.info("Employment Detail input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Detail input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(emp_details, emp_details_ip.trim());
		 Log.info("Successfully Entered '"+emp_details_ip.trim()+"' input in Employment Detail input field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+emp_details_ip.trim()+"' input in Employment Detail input field in Employment History Application level 4 page");
		  
		 Element_isdisplayed(cancontact_yes);
		 Log.info("Can be Contacted yes radio button is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted yes radio button is displayed successfully in Employment History Application level 4 page");
		 
		 Element_isdisplayed(cancontact_no);
		 Log.info("Can be Contacted no radio button is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button is displayed successfully in Employment History Application level 4 page");
		 
		 if(driver.findElement(cancontact_yes_txt).getText().equalsIgnoreCase(can_contact_ip)) {
			 click(cancontact_yes);
			 Log.info("Can be Contacted yes radio button is selected in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted yes radio button is selected in Employment History Application level 4 page");
			 
		 }
		 
		else if(driver.findElement(cancontact_no_txt).getText().equalsIgnoreCase(can_contact_ip)) {
		
			if(!driver.findElement(cancontact_no).isSelected()) {
				
				click(cancontact_no);
				Log.info("Can be Contacted no radio button is selected in Employment History Application level 4 page");
				ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button is selected in Employment History Application level 4 page");
				 
				
			}
			else {
				 Log.info("Can be Contacted no radio button is by default selected in Employment History Application level 4 page");
				 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button is by default selected in Employment History Application level 4 page");
				 
			}
			
			
			
		}

		
	}
	

}


public void Validate_prev_next_step_btns_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_prev_next_step_btns_in_l4_AH")) 
	{
		
		Validate_Next_step_in_l3_AH("Validate_Next_step_in_l3_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
		
		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		
		Element_isdisplayed(btn_prev);
		MoveToElement(btn_prev);
		Log.info("Previous step button is displayed successfully in Employment History Application level 4 page ");
		ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Employment History Application level 4 page");

		Element_isdisplayed(btn_next);
		Log.info("Next step button is displayed successfully in Employment History Application level 4 page ");
		ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Employment History Application level 4 page");


		
	}
	

}


public void Validate_AddEmployer_2_btn_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_AddEmployer_2_btn_in_l4_AH")) 
	{
		
		Validate_Next_step_in_l3_AH("Validate_Next_step_in_l3_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
		By add_emplr_2 = By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");
		
		
		Element_isdisplayed(add_emplr_2);
		MoveToElement(add_emplr_2);
		Log.info("Add Employer #2 button is displayed successfully in Employment History Application level 4 page ");
		ExtentTestManager.getTest().log(Status.PASS, "Add Employer #2 button is displayed successfully in Employment History Application level 4 page");


		
	}
	

}


public void Validate_Next_btn_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Next_btn_in_l4_AH")) 
	{
		
		Validate_input_inallfields_in_l4_AH("Validate_input_inallfields_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1,Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip);
	 	 
		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		
		 
		  By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
		 		 
			Element_isdisplayed(btn_prev);
			MoveToElement(btn_prev);
			Log.info("Previous step button is displayed successfully in Employment History Application level 4 page ");
			ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Employment History Application level 4 page");

			Element_isdisplayed(btn_next);
			Log.info("Next step button is displayed successfully in Employment History Application level 4 page ");
			ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Employment History Application level 4 page");
			
			MoveToElement(btn_next);
			
			click(btn_next);
			ExtentTestManager.getTest().log(Status.PASS,  "Successfully clicked on Next button" );
			Log.info("Successfully clicked on Next button");
			Thread.sleep(200);
			 Element_isdisplayed(Lang_skills);
			 String LK=driver.findElement(Lang_skills).getText().replace("\n", " ");
			 Assert.assertEquals(LK.toUpperCase().trim(), "Language Skills".toUpperCase().trim(), "Language Skills text in Submit Application Language Skills level 5 page not validated");
			 Log.info(LK+" text successfully displayed and navigated to Submit Application Language Skills level 5 page");
			 ExtentTestManager.getTest().log(Status.PASS, LK+" text successfully displayed and navigated to Submit Application Language Skills level 5 page");
		
	}
	

}


public void Validate_No_Prev_Emp_RdoBtn_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_No_Prev_Emp_RdoBtn_in_l4_AH")) 
	{
		
		Validate_Next_step_in_l3_AH("Validate_Next_step_in_l3_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
		
//		 By emp_his= By.xpath("//span[contains(text(),'Employment History')]");
		
		 By hist=By.xpath("//span[contains(text(),'Employment History')]");
		 By prev_emp=By.xpath("//div[contains(text(),'Previous Employment:')]");
		 By emp_gap=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxEmploymentGapExplanation");
		 By empr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerName1");
		 By spr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerSupervisor1");
		 By phone=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerPhone1");
		 By from_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentFrom1");
		 By to_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentTo1");
		 By job_title=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentJobTitle1");
		 By reason=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentReason1");
		 By emp_details=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentDetail1");
		 By cancontact_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_0");
		 By cancontact_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact1_1");
		 
		 By add_empr_2=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");
		 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
		 By wiil_upload_resume=By.id("ctl00_MainContent_ApplicantPreviousEmployment_CheckBoxResume");
		 By resume_text=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_TableFileUploadItem");
//		 By emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
		 By Emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
		 By Emp_his_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpExists");
		 
		 
		 
		 Element_isdisplayed(Emp_his_no);
//		 String hist_txt=driver.findElement(hist).getText().replace("\n", " ");
//		 Assert.assertEquals(hist_txt.toUpperCase().trim(), "Employment History".toUpperCase().trim(), "Employment History text in Employment Submit Application level 4 page not validated");
		 Log.info("No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
		 
//		 Element_isdisplayed(prev_emp);
//		 String pre_emp_txt=driver.findElement(prev_emp).getText().replace("*", "");
//		 Assert.assertEquals(pre_emp_txt.toUpperCase().trim(), "Previous Employment:".toUpperCase().trim(), "Previous Employment text not validated");
//		 Log.info(pre_emp_txt+" text successfully displayed and validated ");
//		 ExtentTestManager.getTest().log(Status.PASS, pre_emp_txt+" text successfully displayed and validated ");
		 
//		 Assert.assertFalse(driver.findElement(Emp_his_no).isDisplayed(), "");
			
		 click(Emp_his_no);
		 Log.info("No Previous Employment radio button is selected successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "No Previous Employment radio button is selected successfully in Employment History Application level 4 page");
		 
		 
		 Element_isdisplayed(Emp_his_yes);
//		 Assert.assertTrue(driver.findElement(Emp_his_yes).isSelected());
		 Log.info("Have An Employment History radio button is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Have An Employment History radio button is displayed successfully in Employment History Application level 4 page");
		 
		 
		 
		 By curr_txt=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantPreviousEmployment_trEmpHistoryTitle1']/td[1]/div[1]");
		
		 By begi_txt=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[8]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/table[2]/tbody[1]/tr[1]/td[1]/div[2]/div[1]/div[1]");
		 
//		 Element_isdisplayed(Emp_his_no);
//		 String hist_txt=driver.findElement(hist).getText().replace("\n", " ");
//		 Assert.assertEquals(hist_txt.toUpperCase().trim(), "Employment History".toUpperCase().trim(), "Employment History text in Employment Submit Application level 4 page not validated");
//		 Log.info("No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
		 
//		 Element_isdisplayed(prev_emp);
//		 String pre_emp_txt=driver.findElement(prev_emp).getText().replace("*", "");
//		 Assert.assertEquals(pre_emp_txt.toUpperCase().trim(), "Previous Employment:".toUpperCase().trim(), "Previous Employment text not validated");
//		 Log.info(pre_emp_txt+" text successfully displayed and validated ");
//		 ExtentTestManager.getTest().log(Status.PASS, pre_emp_txt+" text successfully displayed and validated ");
//		 
//			String[] txt= emp_txts.split(",");
//		 
//		 Element_isdisplayed(begi_txt);
//		 String beginning=driver.findElement(begi_txt).getText().replace("\n", " ");
//		 Assert.assertEquals(beginning.toUpperCase().trim(), txt[0].toUpperCase().trim(), beginning +"text in Employment Submit Application level 4 page not validated");
//		 Log.info(beginning +" text successfully displayed and validated in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, beginning +"text  successfully displayed and validated in Employment History Application level 4 page");
//		
//		 Element_isdisplayed(curr_txt);
//		 String current=driver.findElement(curr_txt).getText().replace("\n", " ");
//		 Assert.assertEquals(current.toUpperCase().trim(), txt[1].toUpperCase().trim(), current +"text in Employment Submit Application level 4 page not validated");
//		 Log.info(current +" text successfully displayed and validated in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, current +"text  successfully displayed and validated in Employment History Application level 4 page");
//		 
		 Assert.assertFalse(driver.findElement(emp_gap).isDisplayed(), "Employment Gap Explanation input field is displayed successfully in Employment History Application level 4 page");
		
		 Log.info("Employment Gap Explanation input field is not displayed in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Gap Explanation input field is not displayed in Employment History Application level 4 page");
		 
		 
		 
//		 input(emp_gap, "Due to some family issues");
		 
		 Assert.assertFalse(driver.findElement(empr_name).isDisplayed(), "Employer Name input field is displayed successfully in Employment History Application level 4 page");
			
		 Log.info("Employer Name input field is not displayed in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employer Name input field is not displayed in Employment History Application level 4 page");
		 
//		 input(empr_name, "LA Fitness");
		 Assert.assertFalse(driver.findElement(spr_name).isDisplayed(), "Supervisor Name input field is displayed successfully in Employment History Application level 4 page");
			
//		 Element_isdisplayed(spr_name);
		 
		 Log.info("Supervisor Name input field is not displayed in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Supervisor Name input field is not displayed in Employment History Application level 4 page");
		 
//		 input(spr_name, "Karan");
		 Assert.assertFalse(driver.findElement(phone).isDisplayed(), "Phone input field is displayed successfully in Employment History Application level 4 page");
			
		 
//		 Element_isdisplayed(phone);
		 Log.info("Phone input field is not displayed in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Phone input field is not displayed in Employment History Application level 4 page");
		 
		 
//		 input(phone, "9848022337");
		 
		 Assert.assertFalse(driver.findElement(from_date).isDisplayed(), "Employment Dates From input field is displayed successfully in Employment History Application level 4 page");
			
		 
//		 Element_isdisplayed(from_date);
		 Log.info("Employment Dates From input field is not displayed in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates From input field is not displayed in Employment History Application level 4 page");
		 
//		 input(from_date, "10/12/2020");
		 
//		 Element_isdisplayed(to_date);
		 
		 Assert.assertFalse(driver.findElement(to_date).isDisplayed(), "Employment Dates To input field is displayed successfully in Employment History Application level 4 page");
			
		 
		 Log.info("Employment Dates To input field is not displayed in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates To input field is not displayed in Employment History Application level 4 page");
		 
//		 input(to_date, "10/12/2021");
		 Assert.assertFalse(driver.findElement(job_title).isDisplayed(), "Last Job Title input field is displayed successfully in Employment History Application level 4 page");
			
//		 Element_isdisplayed(job_title);
		 Log.info("Last Job Title input field is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Last Job Title input field is displayed successfully in Employment History Application level 4 page");
		 
		 
//		 input(job_title, "Trainer");
		 Assert.assertFalse(driver.findElement(reason).isDisplayed(), "Reason for Leaving: (be specific)  input field is displayed successfully in Employment History Application level 4 page");
			 
//		 Element_isdisplayed(reason);
		 Log.info("Reason for Leaving: (be specific) input field is not displayed in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Reason for Leaving: (be specific) input field is not displayed in Employment History Application level 4 page");
		 
//		 input(reason, "some emergency");
		 Assert.assertFalse(driver.findElement(emp_details).isDisplayed(), "Employment Detail  input field is displayed successfully in Employment History Application level 4 page");
			
//		 Element_isdisplayed(emp_details);
		 
		 Log.info("Employment Detail input field is not displayed in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Detail input field is not displayed in Employment History Application level 4 page");
		 
//		 input(emp_details, "Trainer, La Fitness club");
		 
//		 Element_isdisplayed(cancontact_yes);
		 Assert.assertFalse(driver.findElement(cancontact_yes).isDisplayed(), "Can be Contacted yes radio button is displayed successfully in Employment History Application level 4 page");
			
		 Log.info("Can be Contacted yes radio button is not displayed in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted yes radio button is not displayed in Employment History Application level 4 page");
		 
//		 Element_isdisplayed(cancontact_no);
		 Assert.assertFalse(driver.findElement(cancontact_no).isDisplayed(), "Can be Contacted no radio button is displayed successfully in Employment History Application level 4 page");
			
		 Log.info("Can be Contacted no radio button is not displayed in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button is not displayed in Employment History Application level 4 page");
		
		 Log.info("I Have An Employment History whole section is collapsed / not displayed in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "I Have An Employment History whole section is collapsed / not displayed in Employment History Application level 4 page");


		
	}
	

}


public void Validate_prev_step_btn_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_prev_step_btn_in_l4_AH")) 
	{
		
		Validate_Next_step_in_l3_AH("Validate_Next_step_in_l3_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
		 By Experience_info= By.xpath("//span[@class='h4'][contains(text(),'Experience Information')]");
		 
		 By btn_next = By.id("btn_next");
			By btn_prev = By.id("btn_prev");
			
		 
		Element_isdisplayed(btn_prev);
		MoveToElement(btn_prev);
		Log.info("Previous step button is displayed successfully in Employment History Application level 4 page ");
		ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Employment History Application level 4 page");

//		Element_isdisplayed(btn_next);
//		Log.info("Next step button is displayed successfully in Employment History Application level 4 page ");
//		ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Employment History Application level 4 page");

		 click(btn_prev);
		 Thread.sleep(200);
		 
		 Log.info("Successfully clicked on Previous step button in Employment History Application level 4 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Previous step button in Employment History Application level 4 page ");
		 	 
		 Element_isdisplayed(Experience_info);
		 String Experience_txt=driver.findElement(Experience_info).getText().replace("\n", " ");
		 Assert.assertEquals(Experience_txt.toUpperCase().trim(), "Experience Information".toUpperCase().trim(), "Experience Information text in Employment Submit Application level 3 page not validated");
		 ExtentTestManager.getTest().log(Status.PASS, Experience_txt+" text successfully displayed, validated and navigated to Employment Submit Application level 3 page");
		 Log.info(Experience_txt+" text successfully displayed, validated and navigated to Employment Submit Application level 3 page");
		 

		
	}
	

}


public void Validate_all_ip_fieldsofAddemplr2_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_ip_fieldsofAddemplr2_in_l4_AH")) 
	{
		
		Validate_all_ip_fields_in_l4_AH("Validate_all_ip_fields_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
		
		
		 By add_emplr_2 = By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");

		 By empr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerName2");
		 By spr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerSupervisor2");
		 By phone=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerPhone2");
		 By from_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentFrom2");
		 By to_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentTo2");
		 By job_title=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentJobTitle2");
		 By reason=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentReason2");
		 By emp_details=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentDetail2");
		 By cancontact_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact2_0");
		 By cancontact_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact2_1");
		 
		 By add_empr_3=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer3");
		 By RemoveEmployer2=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonRemoveEmployer2");
		 
//		 input(emp_gap, "Due to some family issues");
		 Element_isdisplayed(add_emplr_2);
		 MoveToElement(add_emplr_2);
		 click(add_emplr_2);
		 Log.info("Successfully clicked on 'Add Employer #2' button in Employment History Application level 4 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on 'Add Employer #2' button in Employment History Application level 4 page");
	
		 Thread.sleep(500);
		 Element_isdisplayed(RemoveEmployer2);
		 Log.info("Remove Employer #2 button is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Remove Employer #2 button is displayed successfully in Employment History Application level 4 page");
		 
		 
		 Element_isdisplayed(empr_name);
		 Log.info("Employer Name input field-2 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employer Name input field-2 is displayed successfully in Employment History Application level 4 page");
		 
//		 input(empr_name, "LA Fitness");
		 
		 Element_isdisplayed(spr_name);
		 
		 Log.info("Supervisor Name input field-2 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Supervisor Name input field-2 is displayed successfully in Employment History Application level 4 page");
		 
//		 input(spr_name, "Karan");
		 
		 Element_isdisplayed(phone);
		 Log.info("Phone input field-2 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Phone input field-2 is displayed successfully in Employment History Application level 4 page");
		 
		 
//		 input(phone, "9848022337");
		 
		 Element_isdisplayed(from_date);
		 Log.info("Employment Dates From input field-2 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates From input field-2 is displayed successfully in Employment History Application level 4 page");
		 
//		 input(from_date, "10/12/2020");
		 
		 Element_isdisplayed(to_date);
		 Log.info("Employment Dates To input field-2 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates To input field-2 is displayed successfully in Employment History Application level 4 page");
		 
//		 input(to_date, "10/12/2021");
		 
		 Element_isdisplayed(job_title);
		 Log.info("Last Job Title input field-2 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Last Job Title input field-2 is displayed successfully in Employment History Application level 4 page");
		 
		 
//		 input(job_title, "Trainer");
		 
		 Element_isdisplayed(reason);
		 Log.info("Reason for Leaving: (be specific) input field-2 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Reason for Leaving: (be specific) input field-2 is displayed successfully in Employment History Application level 4 page");
		 
//		 input(reason, "some emergency");

		 Element_isdisplayed(emp_details);
		 Log.info("Employment Detail input field-2 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Detail input field-2 is displayed successfully in Employment History Application level 4 page");
		 
//		 input(emp_details, "Trainer, La Fitness club");
		 
		 Element_isdisplayed(cancontact_yes);
		 Log.info("Can be Contacted yes radio button-2 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted yes radio button-2 is displayed successfully in Employment History Application level 4 page");
		 
		 Element_isdisplayed(cancontact_no);
		 Log.info("Can be Contacted no radio button-2 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button-2 is displayed successfully in Employment History Application level 4 page");
		
		 Element_isdisplayed(add_empr_3);
		 MoveToElement(add_empr_3);
		 Log.info("Add Employer #3 button is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Add Employer #3 button is displayed successfully in Employment History Application level 4 page");
		 
//		 Element_isdisplayed(emp_details);
//		 input(emp_details, "Trainer, La Fitness club");
//		 click(cancontact_yes);

		
	}
	

}


public void Validate_all_ip_fieldsofAddemplr3_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_ip_fieldsofAddemplr3_in_l4_AH")) 
	{
		
		Validate_all_ip_fieldsofAddemplr2_in_l4_AH("Validate_all_ip_fieldsofAddemplr2_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
	 	 
		 By add_emplr_2 = By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");
			 
		//		 By emp_his= By.xpath("//span[contains(text(),'Employment History')]");
//		I Will Upload My Resume:
		
//		 By hist=By.xpath("//span[contains(text(),'Employment History')]");
//		 By prev_emp=By.xpath("//div[contains(text(),'Previous Employment:')]");
//		 By emp_gap=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxEmploymentGapExplanation");
		 By empr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerName3");
		 By spr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerSupervisor3");
		 By phone=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerPhone3");
		 By from_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentFrom3");
		 By to_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentTo3");
		 By job_title=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentJobTitle3");
		 By reason=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentReason3");
		 By emp_details=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentDetail3");
		 By cancontact_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact3_0");
		 By cancontact_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact3_1");
		 
		 By add_empr_3=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer3");
		 By RemoveEmployer3=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonRemoveEmployer3");
		 
//		 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
//		 By wiil_upload_resume=By.id("ctl00_MainContent_ApplicantPreviousEmployment_CheckBoxResume");
//		 By resume_text=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_TableFileUploadItem");
//		 By emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
//		 By Emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
//		 By Emp_his_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpExists");
//		 By curr_txt=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantPreviousEmployment_trEmpHistoryTitle1']/td[1]/div[1]");
//		
//		 By begi_txt=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[8]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/table[2]/tbody[1]/tr[1]/td[1]/div[2]/div[1]/div[1]");
		 
//		 Element_isdisplayed(Emp_his_no);
//		 String hist_txt=driver.findElement(hist).getText().replace("\n", " ");
//		 Assert.assertEquals(hist_txt.toUpperCase().trim(), "Employment History".toUpperCase().trim(), "Employment History text in Employment Submit Application level 4 page not validated");
//		 Log.info("No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
		 
//		 Element_isdisplayed(prev_emp);
//		 String pre_emp_txt=driver.findElement(prev_emp).getText().replace("*", "");
//		 Assert.assertEquals(pre_emp_txt.toUpperCase().trim(), "Previous Employment:".toUpperCase().trim(), "Previous Employment text not validated");
//		 Log.info(pre_emp_txt+" text successfully displayed and validated ");
//		 ExtentTestManager.getTest().log(Status.PASS, pre_emp_txt+" text successfully displayed and validated ");
//		 
//			String[] txt= emp_txts.split(",");
//		 
//		 Element_isdisplayed(begi_txt);
//		 String beginning=driver.findElement(begi_txt).getText().replace("\n", " ");
//		 Assert.assertEquals(beginning.toUpperCase().trim(), txt[0].toUpperCase().trim(), beginning +"text in Employment Submit Application level 4 page not validated");
//		 Log.info(beginning +" text successfully displayed and validated in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, beginning +"text  successfully displayed and validated in Employment History Application level 4 page");
//		
//		 Element_isdisplayed(curr_txt);
//		 String current=driver.findElement(curr_txt).getText().replace("\n", " ");
//		 Assert.assertEquals(current.toUpperCase().trim(), txt[1].toUpperCase().trim(), current +"text in Employment Submit Application level 4 page not validated");
//		 Log.info(current +" text successfully displayed and validated in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, current +"text  successfully displayed and validated in Employment History Application level 4 page");
//		 
		 
//		 Element_isdisplayed(emp_gap);
//		 Log.info("Employment Gap Explanation input field is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Employment Gap Explanation input field is displayed successfully in Employment History Application level 4 page");
//		 
//		 input(emp_gap, "Due to some family issues");
//		 Element_isdisplayed(add_empr_3);
//		 MoveToElement(add_empr_3);
		 click(add_empr_3);
		 Log.info("Successfully clicked on 'Add Employer #3' button in Employment History Application level 4 page ");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on 'Add Employer #3' button in Employment History Application level 4 page");
	
		 Thread.sleep(500);
		 Element_isdisplayed(RemoveEmployer3);
		 Log.info("Remove Employer #3 button is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Remove Employer #3 button is displayed successfully in Employment History Application level 4 page");
		 
		 
		 Element_isdisplayed(empr_name);
		 Log.info("Employer Name input field-3 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employer Name input field-3 is displayed successfully in Employment History Application level 4 page");
		 
//		 input(empr_name, "LA Fitness");
		 
		 Element_isdisplayed(spr_name);
		 
		 Log.info("Supervisor Name input field-3 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Supervisor Name input field-3 is displayed successfully in Employment History Application level 4 page");
		 
//		 input(spr_name, "Karan");
		 
		 Element_isdisplayed(phone);
		 Log.info("Phone input field-3 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Phone input field-3 is displayed successfully in Employment History Application level 4 page");
		 
		 
//		 input(phone, "9848022337");
		 
		 Element_isdisplayed(from_date);
		 Log.info("Employment Dates From input field-3 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates From input field-3 is displayed successfully in Employment History Application level 4 page");
		 
//		 input(from_date, "10/12/2020");
		 
		 Element_isdisplayed(to_date);
		 Log.info("Employment Dates To input field-3 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates To input field-3 is displayed successfully in Employment History Application level 4 page");
		 
//		 input(to_date, "10/12/2021");
		 
		 Element_isdisplayed(job_title);
		 Log.info("Last Job Title input field-3 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Last Job Title input field-3 is displayed successfully in Employment History Application level 4 page");
		 
		 
//		 input(job_title, "Trainer");
		 
		 Element_isdisplayed(reason);
		 Log.info("Reason for Leaving: (be specific) input field-3 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Reason for Leaving: (be specific) input field-3 is displayed successfully in Employment History Application level 4 page");
		 
//		 input(reason, "some emergency");

		 Element_isdisplayed(emp_details);
		 Log.info("Employment Detail input field-3 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Employment Detail input field-3 is displayed successfully in Employment History Application level 4 page");
		 
//		 input(emp_details, "Trainer, La Fitness club");
		 
		 Element_isdisplayed(cancontact_yes);
		 Log.info("Can be Contacted yes radio button-3 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted yes radio button-3 is displayed successfully in Employment History Application level 4 page");
		 
		 Element_isdisplayed(cancontact_no);
		 Log.info("Can be Contacted no radio button-3 is displayed successfully in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button-3 is displayed successfully in Employment History Application level 4 page");
		 MoveToElement(cancontact_no);
		 
//		 Element_isdisplayed(add_empr_3);
//		 MoveToElement(add_empr_3);
//		 Log.info("Add Employer #3 button is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Add Employer #3 button is displayed successfully in Employment History Application level 4 page");
		 
//		 Element_isdisplayed(emp_details);
//		 input(emp_details, "Trainer, La Fitness club");
//		 click(cancontact_yes);

		
	}
	

}


public void Validate_removebtn2_by_ipingempr2_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_removebtn2_by_ipingempr2_in_l4_AH")) 
	{
		
		Validate_all_ip_fieldsofAddemplr2_in_l4_AH("Validate_all_ip_fieldsofAddemplr2_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
	 	 
		 By add_emplr_2 = By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");
		 
//		 By emp_his= By.xpath("//span[contains(text(),'Employment History')]");
//		I Will Upload My Resume:
		
//		 By hist=By.xpath("//span[contains(text(),'Employment History')]");
//		 By prev_emp=By.xpath("//div[contains(text(),'Previous Employment:')]");
//		 By emp_gap=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxEmploymentGapExplanation");
		 By empr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerName2");
		 By spr_name=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerSupervisor2");
		 By phone=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmployerPhone2");
		 By from_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentFrom2");
		 By to_date=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentTo2");
		 By job_title=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentJobTitle2");
		 By reason=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentReason2");
		 By emp_details=By.id("ctl00_MainContent_ApplicantPreviousEmployment_TextBoxPreviousEmploymentDetail2");
		 By cancontact_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact2_0");
		 By cancontact_yes_txt=By.xpath("//label[@for='ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact2_0']");
		 By cancontact_no_txt=By.xpath("//label[@for='ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact2_1']");
		 By cancontact_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonListPreviousEmploymentCanContact2_1");
		 By RemoveEmployer2=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonRemoveEmployer2");
		 
		 By add_empr_2=By.id("ctl00_MainContent_ApplicantPreviousEmployment_LinkButtonAddEmployer2");
//		 By choose_file=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_FileUploadAttachment");
//		 By wiil_upload_resume=By.id("ctl00_MainContent_ApplicantPreviousEmployment_CheckBoxResume");
//		 By resume_text=By.id("ctl00_MainContent_ApplicantPreviousEmployment_FileUploadItemResume_TableFileUploadItem");
//		 By emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
//		 By Emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
//		 By Emp_his_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpExists");
//		 By curr_txt=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantPreviousEmployment_trEmpHistoryTitle2']/td[1]/div[1]");
		
//		 By begi_txt=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[8]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/table[2]/tbody[1]/tr[1]/td[1]/div[2]/div[1]/div[1]");
		 
//		 Element_isdisplayed(Emp_his_no);
//		 String hist_txt=driver.findElement(hist).getText().replace("\n", " ");
//		 Assert.assertEquals(hist_txt.toUpperCase().trim(), "Employment History".toUpperCase().trim(), "Employment History text in Employment Submit Application level 4 page not validated");
//		 Log.info("No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
		 
//		 Element_isdisplayed(prev_emp);
//		 String pre_emp_txt=driver.findElement(prev_emp).getText().replace("*", "");
//		 Assert.assertEquals(pre_emp_txt.toUpperCase().trim(), "Previous Employment:".toUpperCase().trim(), "Previous Employment text not validated");
//		 Log.info(pre_emp_txt+" text successfully displayed and validated ");
//		 ExtentTestManager.getTest().log(Status.PASS, pre_emp_txt+" text successfully displayed and validated ");
//		 
//			String[] txt= emp_txts.split(",");
//		 
//		 Element_isdisplayed(begi_txt);
//		 String beginning=driver.findElement(begi_txt).getText().replace("\n", " ");
//		 Assert.assertEquals(beginning.toUpperCase().trim(), txt[0].toUpperCase().trim(), beginning +"text in Employment Submit Application level 4 page not validated");
//		 Log.info(beginning +" text successfully displayed and validated in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, beginning +"text  successfully displayed and validated in Employment History Application level 4 page");
//		
//		 Element_isdisplayed(curr_txt);
//		 String current=driver.findElement(curr_txt).getText().replace("\n", " ");
//		 Assert.assertEquals(current.toUpperCase().trim(), txt[1].toUpperCase().trim(), current +"text in Employment Submit Application level 4 page not validated");
//		 Log.info(current +" text successfully displayed and validated in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, current +"text  successfully displayed and validated in Employment History Application level 4 page");
		 
		 
//		 Element_isdisplayed(emp_gap);
//		 Log.info("Employment Gap Explanation input field is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Employment Gap Explanation input field is displayed successfully in Employment History Application level 4 page");
//		 
//		 input(emp_gap, Gap_ip.trim());
//		 Log.info("Successfully Entered '"+Gap_ip.trim()+"' input in Employment Gap Explanation input field in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+Gap_ip.trim()+"' input in Employment Gap Explanation input field in Employment History Application level 4 page");
		 
	
//		 MoveToElement(empr_name);
		 scrolltotop();
		 MoveToElement(empr_name);
		 input(empr_name, emplr_name.trim());
		 Log.info("Successfully Entered '"+emplr_name.trim()+"' input in Employer Name input field-2 in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+emplr_name.trim()+"' input in Employer Name input field-2 in Employment History Application level 4 page");
		  
//		 Element_isdisplayed(spr_name);
//		 Log.info("Supervisor Name input field-2 is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Supervisor Name input field-2 is displayed successfully in Employment History Application level 4 page");
		 
		 input(spr_name, supr_name.trim());
		 Log.info("Successfully Entered '"+supr_name.trim()+"' input in Supervisor Name input field-2 in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+supr_name.trim()+"' input in Supervisor Name input field-2 in Employment History Application level 4 page");
		  
//		 Element_isdisplayed(phone);
//		 Log.info("Phone input field is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Phone input field is displayed successfully in Employment History Application level 4 page");
		 
		 
		 input(phone, Phone.trim());
		 Log.info("Successfully Entered '"+Phone.trim()+"' input in Phone input-2 field in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+Phone.trim()+"' input in Phone field-2 in Employment History Application level 4 page");
		  
//		 Element_isdisplayed(from_date);
//		 Log.info("Employment Dates From input field-2 is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates From input field-2 is displayed successfully in Employment History Application level 4 page");
		 
		 input(from_date, emp_from_date.trim());
		 Log.info("Successfully Entered '"+emp_from_date.trim()+"' input in Employment Dates From input field-2 in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+emp_from_date.trim()+"' input in Employment Dates From field-2 in Employment History Application level 4 page");
		  
//		 Element_isdisplayed(to_date);
//		 Log.info("Employment Dates To input field is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates To input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(to_date, emp_to_date.trim());
		 Log.info("Successfully Entered '"+emp_to_date.trim()+"' input in Employment Dates To input field-2 in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+emp_to_date.trim()+"' input in Employment Dates To field-2 in Employment History Application level 4 page");
		  
//		 Element_isdisplayed(job_title);
//		 Log.info("Last Job Title input field is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Last Job Title input field is displayed successfully in Employment History Application level 4 page");
		 	 
		 input(job_title, title.trim());
		 Log.info("Successfully Entered '"+title.trim()+"' input in Last Job Title input field-2 in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+title.trim()+"' input in Last Job Title input field-2 in Employment History Application level 4 page");
		  
//		 Element_isdisplayed(reason);
//		 Log.info("Reason for Leaving: (be specific) input field is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Reason for Leaving: (be specific) input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(reason, leaving_reason.trim());
		 Log.info("Successfully Entered '"+leaving_reason.trim()+"' input in Reason for Leaving input field-2 in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+leaving_reason.trim()+"' input in Reason for Leaving input field-2 in Employment History Application level 4 page");
		  
//		 Element_isdisplayed(emp_details);
//		 Log.info("Employment Detail input field is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Employment Detail input field is displayed successfully in Employment History Application level 4 page");
		 
		 input(emp_details, emp_details_ip.trim());
		 Log.info("Successfully Entered '"+emp_details_ip.trim()+"' input in Employment Detail input field-2 in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered '"+emp_details_ip.trim()+"' input in Employment Detail input field-2 in Employment History Application level 4 page");
		  
//		 Element_isdisplayed(cancontact_yes);
//		 Log.info("Can be Contacted yes radio button is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted yes radio button is displayed successfully in Employment History Application level 4 page");
		 
//		 Element_isdisplayed(cancontact_no);
//		 Log.info("Can be Contacted no radio button is displayed successfully in Employment History Application level 4 page");
//		 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button is displayed successfully in Employment History Application level 4 page");
		 
		 if(driver.findElement(cancontact_yes_txt).getText().equalsIgnoreCase(can_contact_ip)) {
			 click(cancontact_yes);
			 Log.info("Can be Contacted yes radio button-2 is selected in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted yes radio button-2 is selected in Employment History Application level 4 page");
			 
		 }
		 
		else if(driver.findElement(cancontact_no_txt).getText().equalsIgnoreCase(can_contact_ip)) {
		
			if(!driver.findElement(cancontact_no).isSelected()) {
				
				click(cancontact_no);
				Log.info("Can be Contacted no radio button-2 is selected in Employment History Application level 4 page");
				ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button-2 is selected in Employment History Application level 4 page");
				 
				
			}
			else {
				 Log.info("Can be Contacted no radio button-2 is by default selected in Employment History Application level 4 page");
				 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button-2 is by default selected in Employment History Application level 4 page");
				 
			}
		}
			scrolltotop();
			Element_isdisplayed(RemoveEmployer2);
			MoveToElement(RemoveEmployer2);
			click(RemoveEmployer2);
			Log.info("Successfully clicked on Remove Employer #2 button in Employment History Application level 4 page");
			ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Remove Employer #2 button in Employment History Application level 4 page");
			Thread.sleep(500);
			
			Element_isdisplayed(add_empr_2);
			Log.info("'Add Employer #2' button is displayed successfully in Employment History Application level 4 page ");
			ExtentTestManager.getTest().log(Status.PASS, "'Add Employer #2' button is displayed successfully in Employment History Application level 4 page");
			
			try
			{
			 Assert.assertFalse(driver.findElements(empr_name).size()!=0, "Employer Name input field-2 is not collapsed/hidden in Employment Submit Application level 4 page");
			 Log.info("Employer Name input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Employer Name input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 
			 Assert.assertFalse(driver.findElements(spr_name).size()!=0, "Supervisor Name input field-2 is not collapsed/hidden in Employment Submit Application level 4 page");
			 Log.info("Supervisor Name input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Supervisor Name input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 
			 Assert.assertFalse(driver.findElements(phone).size()!=0, "Phone input field-2 is not collapsed/hidden in Employment Submit Application level 4 page");

			 Log.info("Phone input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Phone input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 
			 
			 Assert.assertFalse(driver.findElements(from_date).size()!=0, "Employment Dates From input field-2 is not collapsed/hidden in Employment Submit Application level 4 page");

			 Log.info("Employment Dates From input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates From input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			
			 Assert.assertFalse(driver.findElements(to_date).size()!=0, "Employment Dates To input field-2 is not collapsed/hidden in Employment Submit Application level 4 page");
			 Log.info("Employment Dates To input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Employment Dates To input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 
			 Assert.assertFalse(driver.findElements(job_title).size()!=0, "Last Job Title input field-2 is not collapsed/hidden in Employment Submit Application level 4 page");
			 
			 Log.info("Last Job Title input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Last Job Title input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 	
			 Assert.assertFalse(driver.findElements(reason).size()!=0, "Reason for Leaving: (be specific) input field-2 is not collapsed/hidden in Employment Submit Application level 4 page");
		
			 Log.info("Reason for Leaving: (be specific) input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Reason for Leaving: (be specific) input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			
			 Assert.assertFalse(driver.findElements(emp_details).size()!=0, "Employment Detail input field-2 is not collapsed/hidden in Employment Submit Application level 4 page");
				
			 Log.info("Employment Detail input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Employment Detail input field-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 
			 Assert.assertFalse(driver.findElements(cancontact_yes).size()!=0, "Can be Contacted yes radio button-2 is not collapsed/hidden in Employment Submit Application level 4 page");
			 Log.info("Can be Contacted yes radio button-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted yes radio button-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 
			 Assert.assertFalse(driver.findElements(cancontact_no).size()!=0, "Can be Contacted No radio button-2 is not collapsed/hidden in Employment Submit Application level 4 page");
			 Log.info("Can be Contacted no radio button-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Can be Contacted no radio button-2 is successfully collapsed/hidden in Employment History Application level 4 page");
			
	}
	
	catch (NoSuchElementException e) {
		Log.info("All fields of Add Employer 2 section are successfully collapsed/hidden in Employment History Application level 4 page");
		 ExtentTestManager.getTest().log(Status.PASS, "All fields of Add Employer 2 section are successfully collapsed/hidden in Employment History Application level 4 page");
		
	}
	}
	

}


public void Validate_Next_btn_in_l4_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Next_btn_in_l4_AH")) 
	{
		
		
		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		
		if(Emp_checkbox_ip.trim().equalsIgnoreCase("Yes"))
		{
			Validate_input_inallfields_in_l4_AH("Validate_input_inallfields_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1,Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip, doc_name);

		} 
		
		else if(Emp_checkbox_ip.trim().equalsIgnoreCase("No"))
		{

			Validate_Next_step_in_l3_AH("Validate_Next_step_in_l3_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode, L2_txt , Edu_level_ip,Exp_ip,  checkboxes_ip,  checkboxes_ip_1);
					 		
			 By Emp_his_no=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpNone");
			 By Emp_his_yes=By.id("ctl00_MainContent_ApplicantPreviousEmployment_RadioButtonPrevEmpExists");
			 By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
	 		 
			 Element_isdisplayed(Emp_his_no);
			 Log.info("No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "No Previous Employment radio button is displayed successfully in Employment History Application level 4 page");
			
			 click(Emp_his_no);
			 Log.info("No Previous Employment radio button is selected successfully in Employment History Application level 4 page");
			 ExtentTestManager.getTest().log(Status.PASS, "No Previous Employment radio button is selected successfully in Employment History Application level 4 page");
			 Thread.sleep(500);
			 
		}
		

			 	 
		 By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
		 		 
			Element_isdisplayed(btn_prev);
			MoveToElement(btn_prev);
			Log.info("Previous step button is displayed successfully in Employment History Application level 4 page ");
			ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Employment History Application level 4 page");

			Element_isdisplayed(btn_next);
			Log.info("Next step button is displayed successfully in Employment History Application level 4 page ");
			ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Employment History Application level 4 page");
			
			MoveToElement(btn_next);
			
			click(btn_next);
			ExtentTestManager.getTest().log(Status.PASS,  "Successfully clicked on Next button" );
			Log.info("Successfully clicked on Next button");
			Thread.sleep(500);
			 Element_isdisplayed(Lang_skills);
			 String LK=driver.findElement(Lang_skills).getText().replace("\n", " ");
			 Assert.assertEquals(LK.toUpperCase().trim(), "Language Skills".toUpperCase().trim(), "Language Skills text in Submit Application Language Skills level 5 page not validated");
			 Log.info(LK+" text successfully displayed and navigated to Submit Application Language Skills level 5 page");
			 ExtentTestManager.getTest().log(Status.PASS, LK+" text successfully displayed and navigated to Submit Application Language Skills level 5 page");
				 

		
	}
	

}


public void Validate_Ind_langs_text_l5_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String L_Text) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Ind_langs_text_l5_AH")) 
	{
		
		Validate_Next_btn_in_l4_AH( "Validate_Next_btn_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip );
		
			By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
			By Text1=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[9]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]/div[1]");
		
		  	Element_isdisplayed(Text1);
			 String LText=driver.findElement(Text1).getText().replace("\n", " ");
			 Assert.assertEquals(LText.toUpperCase().trim(), L_Text.toUpperCase().trim(), LText+" text in Submit Application Language Skills level 5 page not validated");
			 Log.info(LText+" text successfully validated in Submit Application Language Skills level 5 page");
			 ExtentTestManager.getTest().log(Status.PASS, LText+" text successfully validated in Submit Application Language Skills level 5 page");
				
	
	}
	
	}


public void Validate_all_langs_in_l5_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_langs_in_l5_AH")) 
	{
		
		Validate_Next_btn_in_l4_AH( "Validate_Next_btn_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip );
		
		  By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
		  By chceck_boxes=By.xpath("//table[@id='ctl00_MainContent_ApplicantLanguageSkills_CheckBoxListLanguageSkills']//input");
		  By chceck_boxes_labels=By.xpath("//table[@id='ctl00_MainContent_ApplicantLanguageSkills_CheckBoxListLanguageSkills']//label");
//		  By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
	 		 

		  String[] check_boxes_ip=CB_ip.split(",");
		  
			 List<WebElement> checkboxs=driver.findElements(chceck_boxes);
			 List<WebElement> checkboxs_labels=driver.findElements(chceck_boxes_labels);
			 ArrayList<String> mylist = new ArrayList<String>();
			 int count=0;
			 for(int i=0; i< checkboxs.size(); i++)  
			 {  
				 String lang_val=checkboxs_labels.get(i).getText();
				
				 if(!lang_val.isEmpty() &&  CB_ip.trim().contains(lang_val.trim()))
				 {
					
					 mylist.add(lang_val);
//					 checkboxs.get(i).click();	 
					 Log.info(check_boxes_ip[i].trim()+" Language check box successfully validated");
					 ExtentTestManager.getTest().log(Status.PASS, check_boxes_ip[i].trim()+"  Language check box successfully validated");
					 count++;
					 
				 }
				 
				
		} 
			 Thread.sleep(500);
			 String delim = ",";
		        String res = String.join(delim, mylist);
			 if (check_boxes_ip.length == count ) 
			    {	
				  
				   	Log.info("All values successfully matched with the given check boxes list of Languages as Expected");
			        ExtentTestManager.getTest().log(Status.PASS, "All values successfully matched with the given check boxes list of Languages as Expected");

			    } else 
			    {	
			    	Log.error("All values not matched with the given check boxes list of Languages. Expected list [ "+CB_ip +" ] Actual list [ "+res+" ]");
		        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched with the given check boxes list of Languages. Expected list [ "+CB_ip +" ] Actual list [ "+res+" ]");
		        	throw new Exception("All values not matched with the given check boxes list of Languages.");
			    }
	}

}


public void Validate_bydefault_Eng_lang_sltd_in_l5_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_bydefault_Eng_lang_sltd_in_l5_AH")) 
	{
		
		Validate_Next_btn_in_l4_AH( "Validate_Next_btn_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip );
		
		  By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
		  By chceck_boxes=By.xpath("//table[@id='ctl00_MainContent_ApplicantLanguageSkills_CheckBoxListLanguageSkills']//input");
		  By chceck_boxes_labels=By.xpath("//table[@id='ctl00_MainContent_ApplicantLanguageSkills_CheckBoxListLanguageSkills']//label");
//		  By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
	 		   
		  String[] check_boxes_ip=CB_ip.split(",");
		  
			 List<WebElement> checkboxs=driver.findElements(chceck_boxes);
			 List<WebElement> checkboxs_labels=driver.findElements(chceck_boxes_labels);
			 ArrayList<String> mylist = new ArrayList<String>();
//			 int count=0;
			 for(int i=0; i< checkboxs.size(); i++)  
			 {  
				 String lang_val=checkboxs_labels.get(i).getText();
				 if(!lang_val.isEmpty() && CB_ip.trim().contains(lang_val.trim()))
				 {
					 
					if (lang_val.equalsIgnoreCase("English") && checkboxs.get(i).isSelected())
					{
						
						mylist.add(lang_val.trim());
//						 checkboxs.get(i).click();	 
						 Log.info(lang_val.trim()+" Language check box successfully validated and by default selected");
						 ExtentTestManager.getTest().log(Status.PASS, lang_val.trim()+" Language  check box successfully validated and by default selected");
						 
						
					}
					else {
						
					
					 mylist.add(lang_val.trim());
					 checkboxs.get(i).click();	 
					 Log.info(lang_val.trim()+" Language check box successfully validated and selected");
					 ExtentTestManager.getTest().log(Status.PASS, lang_val.trim()+"  Language check box successfully validated and selected");
//					 count++;
					 
						} 
				 }
	
			 }		
	}
	
	}


public void Validate_slt_desired_langs_in_l5_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_slt_desired_langs_in_l5_AH")) 
	{
		
		Validate_Next_btn_in_l4_AH( "Validate_Next_btn_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip );
		
		  By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
		  By chceck_boxes=By.xpath("//table[@id='ctl00_MainContent_ApplicantLanguageSkills_CheckBoxListLanguageSkills']//input");
		  By chceck_boxes_labels=By.xpath("//table[@id='ctl00_MainContent_ApplicantLanguageSkills_CheckBoxListLanguageSkills']//label");
//		  By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");

		  String[] check_boxes_ip=CB_ip.split(",");
		  
			 List<WebElement> checkboxs=driver.findElements(chceck_boxes);
			 List<WebElement> checkboxs_labels=driver.findElements(chceck_boxes_labels);
			 ArrayList<String> mylist = new ArrayList<String>();
			 int count =0;
			 for(int i=0; i< checkboxs.size(); i++)  
			 {  
				 WebElement langchkbx=checkboxs_labels.get(i);
				 String lang_val=langchkbx.getText();
				 if(!lang_val.isEmpty() && CB_ip.trim().contains(lang_val.trim()))
				 {
					if (lang_val.equalsIgnoreCase("English") && checkboxs.get(i).isSelected())
					{
						mylist.add(lang_val);
//						 checkboxs.get(i).click();	 
						 Log.info(lang_val.trim()+" Language check box successfully validated and by default selected");
						 ExtentTestManager.getTest().log(Status.PASS, lang_val.trim()+" Language  check box successfully validated and by default selected");
						 ++count;
					}
					else 
					{
						
					 mylist.add(lang_val);
					 checkboxs.get(i).click();	 
					 Log.info(lang_val.trim()+" Language check box successfully validated and selected");
					 ExtentTestManager.getTest().log(Status.PASS, lang_val.trim()+"  Language check box successfully validated and selected");

					 ++count;
						} 
					
					if (count==check_boxes_ip.length) break;
						
						
				 }
				 
				 
//				 if(i+1==check_boxes_ip.length)break;
				
		} 
			 Thread.sleep(500);
//			 String delim = ",";
		        String res = String.join(",", mylist);
			 if (check_boxes_ip.length ==mylist.size()  ) 
			    {	
				   	Log.info("All given check boxes list of Languages selected successfully");
			        ExtentTestManager.getTest().log(Status.PASS, "All given check boxes list of Languages selected successfully");

			    } else 
			    {	
			    	Log.error("All values not matched with the given check boxes list of Languages. Expected list [ "+CB_ip +" ] Actual list [ "+res+" ]");
		        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched with the given check boxes list of Languages. Expected list [ "+CB_ip +" ] Actual list [ "+res+" ]");
		        	throw new Exception("All values not matched with the given check boxes list of Languages.");
			    }
	}
	
	}


public void Validate_prev_next_step_btns_in_l5_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_prev_next_step_btns_in_l5_AH")) 
	{
		
		Validate_Next_btn_in_l4_AH( "Validate_Next_btn_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip );
		

			By btn_next = By.id("btn_next");
			By btn_prev = By.id("btn_prev");
		
			Element_isdisplayed(btn_prev);
			MoveToElement(btn_prev);
			Log.info("Previous step button is displayed successfully in Submit Application Language Skills level 5 page ");
			ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Submit Application Language Skills level 5 page");

			Element_isdisplayed(btn_next);
			Log.info("Next step button is displayed successfully in Submit Application Language Skills level 5 page ");
			ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Submit Application Language Skills level 5 page");
			MoveToElement(btn_next);
	
	}
	
	}


public void Validate_prev_step_btn_in_l5_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_prev_step_btn_in_l5_AH")) 
	{
		
		Validate_Next_btn_in_l4_AH( "Validate_Next_btn_in_l4_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip );
		

			By btn_next = By.id("btn_next");
			By btn_prev = By.id("btn_prev");
		
			  By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
			  By chceck_boxes=By.xpath("//table[@id='ctl00_MainContent_ApplicantLanguageSkills_CheckBoxListLanguageSkills']//input");
			  By chceck_boxes_labels=By.xpath("//table[@id='ctl00_MainContent_ApplicantLanguageSkills_CheckBoxListLanguageSkills']//label");
//			  By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
			  By emp_his= By.xpath("//span[contains(text(),'Employment History')]");
				
				Element_isdisplayed(btn_prev);
				MoveToElement(btn_prev);
				Log.info("Previous step button is displayed successfully in Submit Application Language Skills level 5 page ");
				ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Submit Application Language Skills level 5 page");
				MoveToElement(btn_next);
				click(btn_prev);
//				Thread.sleep(200);
				Log.info("Successfully clicked on Previous step button in Submit Application Language Skills level 5 page ");
				ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Previous step button in Submit Application Language Skills level 5 page");
				
				Thread.sleep(200);
				 Element_isdisplayed(emp_his);
				 String emp_his_txt=driver.findElement(emp_his).getText().replace("\n", " ");
				 Assert.assertEquals(emp_his_txt.toUpperCase().trim(), "Employment History".toUpperCase().trim(), "Employment History text in Employment Submit Application level 4 page not validated");
				 Log.info(emp_his_txt+" text successfully displayed and navigated to Employment Submit Application Employment History level 4 page");
				 ExtentTestManager.getTest().log(Status.PASS, emp_his_txt+" text successfully displayed and navigated to Employment Submit Application Employment History level 4 page");
				 
	}
	
	}


public void Validate_Next_step_btn_in_l5_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Next_step_btn_in_l5_AH")) 
	{
		
		Validate_slt_desired_langs_in_l5_AH( "Validate_slt_desired_langs_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		

		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		By Car_op=By.xpath("//span[contains(text(),'Career Options')]");
	 	
		Element_isdisplayed(btn_next);
		Log.info("Next step button is displayed successfully in Submit Application Language Skills level 5 page ");
		ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Submit Application Language Skills level 5 page");
		MoveToElement(btn_next);
		click(btn_next);
//		Thread.sleep(200);
		Log.info("Successfully clicked on Next step button in Submit Application Language Skills level 5 page ");
		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Next step button in Submit Application Language Skills level 5 page");
		

		Thread.sleep(500);
		 Element_isdisplayed(Car_op);
		 String Car_op_txt=driver.findElement(Car_op).getText().replace("\n", " ");
		 Assert.assertEquals(Car_op_txt.toUpperCase().trim(), "Career Options".toUpperCase().trim(), "Career Options text in Employment Submit Application Career Options level 6 page not validated");
		 Log.info(Car_op_txt+" text successfully displayed and navigated to Employment Submit Application Career Options level 6 page");
		 ExtentTestManager.getTest().log(Status.PASS, Car_op_txt+" text successfully displayed and navigated to Employment Submit Application Career Options level 6 page");
		  
		
	}
	
	}


public void Validate_text_COqualify_in_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String CO_Q_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_text_COqualify_in_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
		
			  By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
			  By chceck_boxes=By.xpath("//table[@id='ctl00_MainContent_ApplicantLanguageSkills_CheckBoxListLanguageSkills']//input");
			  By chceck_boxes_labels=By.xpath("//table[@id='ctl00_MainContent_ApplicantLanguageSkills_CheckBoxListLanguageSkills']//label");
			  By Car_op_q=By.xpath("//b[contains(text(),'Career Opportunities You Qualify For')]");
		 	

			 Thread.sleep(500);
			 Element_isdisplayed(Car_op_q);
			 String Car_op_q_txt=driver.findElement(Car_op_q).getText().replace("\n", " ");
			 Assert.assertEquals(Car_op_q_txt.toUpperCase().trim(), CO_Q_ip.toUpperCase().trim(), Car_op_q_txt.trim()+" text in Employment Submit Application Career Options level 6 page not validated");
			 Log.info(Car_op_q_txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
			 ExtentTestManager.getTest().log(Status.PASS, Car_op_q_txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
					  
		
	}
	
	}


public void Validate_all_fields_in_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String consider_chkbx_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_fields_in_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
		  By Full_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[1]");
		  By Part_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[2]");
//		  By Consider_for_GF=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/span[1]");
//		  By Consider_for_GF_cb=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
		  By Clb_loc=By.xpath("//td[contains(text(),'Club Locations:')]");
		  By Car_opp=By.xpath("//td[contains(text(),'Career Opportunities:')]");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentNo");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		
		  By chceck_boxes=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor']//tbody//tr//td//input");
		  By chceck_boxes_labels=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor']//tbody//tr//td//label");
		  
		  
		  Element_isdisplayed(Full_time);
		  Log.info("I am Interested in Working: Full Time check box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"I am Interested in Working: Full Time check box is successfully displayed in Employment Submit Application Career Options level 6 page");
			  

		  Element_isdisplayed(Part_time);
		  Log.info("I am Interested in Working: Part Time check box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"I am Interested in Working: Part Time check box is successfully displayed in Employment Submit Application Career Options level 6 page");
			  
		  

		  String[] check_boxes_ip=consider_chkbx_ip.split(",");
		  
			 List<WebElement> checkboxs=driver.findElements(chceck_boxes);
			 List<WebElement> checkboxs_labels=driver.findElements(chceck_boxes_labels);
			 ArrayList<String> mylist = new ArrayList<String>();
			 int count =0;
			 for(int i=0; i< checkboxs.size(); i++)  
			 {  
				 WebElement langchkbx=checkboxs_labels.get(i);
				 String lang_val=langchkbx.getText();
				 if(!lang_val.isEmpty() && consider_chkbx_ip.trim().contains(lang_val.trim()))
				 {
					 mylist.add(lang_val);
//					 checkboxs.get(i).click();	 
					 Log.info(lang_val.trim()+" I would like to be Considered for check box successfully displayed and validated");
					 ExtentTestManager.getTest().log(Status.PASS, lang_val.trim()+" I would like to be Considered for check box successfully displayed and validated");

					 ++count;
					
					if (count==check_boxes_ip.length) break;
						
						
				 }
//				 if(i+1==check_boxes_ip.length)break;
				
		} 
			 Thread.sleep(500);
//			 String delim = ",";
		        String res = String.join(",", mylist);
			 if (check_boxes_ip.length ==mylist.size()  ) 
			    {	
				   	Log.info("All given check boxes list of I would like to be Considered for are successfully displayed and validated");
			        ExtentTestManager.getTest().log(Status.PASS, "All given check boxes list of I would like to be Considered for are successfully displayed and validated");

			    } else 
			    {	
			    	Log.error("All values not matched with the given check boxes list of I would like to be Considered for. Expected list [ "+consider_chkbx_ip +" ] Actual list [ "+res+" ]");
		        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched with the given check boxes list of I would like to be Considered for. Expected list [ "+consider_chkbx_ip +" ] Actual list [ "+res+" ]");
		        	throw new Exception("All values not matched with the given check boxes list of I would like to be Considered for.");
			    }
			 

		  
		  
//		  
//		  Element_isdisplayed(Consider_for_GF_cb);
//		  Log.info("'I would like to be Considered for' check box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"'I would like to be Considered for' check box is successfully displayed in Employment Submit Application Career Options level 6 page");
//			  
		  Element_isdisplayed(Date);
		  Log.info("Date Available to Begin: input box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Date Available to Begin: input box is successfully displayed in Employment Submit Application Career Options level 6 page");
			  
		  Element_isdisplayed(No_rdobtn);
		  Log.info("Are you now or have you ever been employed with us before? No radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? No radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
			  
		  Element_isdisplayed(yes_rdobtn);
		  Log.info("Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
			  
		  Element_isdisplayed(Clb_loc);
		  Log.info("Club Locations field is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Club Locations field is successfully displayed in Employment Submit Application Career Options level 6 page");
			  
		  Element_isdisplayed(Car_opp);
		  Log.info("Career Opportunities field is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Career Opportunities field is successfully displayed in Employment Submit Application Career Options level 6 page");
		  MoveToElement(Car_opp);
			  
}
}


public void Validate_slt_Worktime_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_slt_Worktime_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
		  By Full_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[1]");
		  By Part_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[2]");
//		  By Consider_for_GF=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/span[1]");
//		  By Consider_for_GF_cb=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
		  By Clb_loc=By.xpath("//td[contains(text(),'Club Locations:')]");
		  By Car_opp=By.xpath("//td[contains(text(),'Career Opportunities:')]");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentNo");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		
		  By chceck_boxes=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor']//tbody//tr//td//input");
		  By chceck_boxes_labels=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor']//tbody//tr//td//label");
		  
		  By Full_time_chkbx=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT_0");
		  By Part_time_chkbx=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT_1");
		  
		  
		  
		  String[] Work_time_ip=Worktime_ip.split(",");
		  Element_isdisplayed(Full_time);
		  Log.info("I am Interested in Working: Full Time check box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"I am Interested in Working: Full Time check box is successfully displayed in Employment Submit Application Career Options level 6 page");
			 
		  Element_isdisplayed(Part_time);
		  Log.info("I am Interested in Working: Part Time check box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"I am Interested in Working: Part Time check box is successfully displayed in Employment Submit Application Career Options level 6 page");
		 
		  
		  if(Work_time_ip.length==2 && Work_time_ip[0].trim().equalsIgnoreCase(driver.findElement(Full_time).getText().trim()) && Work_time_ip[1].trim().equalsIgnoreCase(driver.findElement(Part_time).getText().trim())) {
			  
			  if(driver.findElement(Full_time_chkbx).isSelected()) {
				  
				  Log.info("I am Interested in Working: Full Time check box is successfully by default selected in Employment Submit Application Career Options level 6 page");
				  ExtentTestManager.getTest().log(Status.PASS,"I am Interested in Working: Full Time check box is successfully by default selected in Employment Submit Application Career Options level 6 page");
				  
			  }
			  else {
				
				  click(Full_time_chkbx);
				  Log.info("I am Interested in Working: Full Time check box is successfully selected in Employment Submit Application Career Options level 6 page");
				  ExtentTestManager.getTest().log(Status.PASS,"I am Interested in Working: Full Time check box is successfully selected in Employment Submit Application Career Options level 6 page");
				  
			}
			  if(driver.findElement(Part_time_chkbx).isSelected()) {
				  
				  Log.info("I am Interested in Working: Part Time check box is successfully by default selected in Employment Submit Application Career Options level 6 page");
				  ExtentTestManager.getTest().log(Status.PASS,"I am Interested in Working: Part Time check box is successfully by default selected in Employment Submit Application Career Options level 6 page");
				  
			  }
			  else {
				click(Part_time_chkbx);
			  Log.info("I am Interested in Working: Part Time check box is successfully seleted in Employment Submit Application Career Options level 6 page");
			  ExtentTestManager.getTest().log(Status.PASS,"I am Interested in Working: Part Time check box is successfully selected in Employment Submit Application Career Options level 6 page");
			  } 
			  
		  } 
		  
		  else if(Work_time_ip.length==1) {
			  
			  if(driver.findElement(Full_time).getText().trim().equalsIgnoreCase(Worktime_ip.trim())) {
				  
				  if(driver.findElement(Full_time_chkbx).isSelected()) {
					  
					  Log.info("I am Interested in Working: Full Time check box is successfully by default selected in Employment Submit Application Career Options level 6 page");
					  ExtentTestManager.getTest().log(Status.PASS,"I am Interested in Working: Full Time check box is successfully by default selected in Employment Submit Application Career Options level 6 page");
					  
				  }
				  else {
					
					  click(Full_time_chkbx);
					  Log.info("I am Interested in Working: Full Time check box is successfully selected in Employment Submit Application Career Options level 6 page");
					  ExtentTestManager.getTest().log(Status.PASS,"I am Interested in Working: Full Time check box is successfully selected in Employment Submit Application Career Options level 6 page");
					  
				}
				  
			  }
			  else if(driver.findElement(Part_time).getText().trim().equalsIgnoreCase(Worktime_ip.trim())) {
				 
				  if(driver.findElement(Part_time_chkbx).isSelected()) {
					  
					  Log.info("I am Interested in Working: Part Time check box is successfully by default selected in Employment Submit Application Career Options level 6 page");
					  ExtentTestManager.getTest().log(Status.PASS,"I am Interested in Working: Part Time check box is successfully by default selected in Employment Submit Application Career Options level 6 page");
					  
				  }
				  else {
					click(Part_time_chkbx);
				  Log.info("I am Interested in Working: Part Time check box is successfully seleted in Employment Submit Application Career Options level 6 page");
				  ExtentTestManager.getTest().log(Status.PASS,"I am Interested in Working: Part Time check box is successfully selected in Employment Submit Application Career Options level 6 page");
				  } 
			  }
			  
			  else {
				  
				  Log.error(" Invalid input: "+Worktime_ip+" of 'I am Interested in Working' in Employment Submit Application Career Options level 6 page");
				  ExtentTestManager.getTest().log(Status.FAIL,"Invalid input: "+Worktime_ip+" of 'I am Interested in Working' in Employment Submit Application Career Options level 6 page");
					 throw new Error(" Invalid input: "+Worktime_ip+" of 'I am Interested in Working' in Employment Submit Application Career Options level 6 page");
			
			  }
			
		}
		  else {
			  Log.error(" Invalid input: "+Worktime_ip+" of 'I am Interested in Working' in Employment Submit Application Career Options level 6 page");
			  ExtentTestManager.getTest().log(Status.FAIL,"Invalid input: "+Worktime_ip+" of 'I am Interested in Working' in Employment Submit Application Career Options level 6 page");
				 throw new Error(" Invalid input: "+Worktime_ip+" of 'I am Interested in Working' in Employment Submit Application Career Options level 6 page");
		
		}
		  
		  
//		  Element_isdisplayed(Consider_for_GF_cb);
//		  Log.info("'I would like to be Considered for' check box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"'I would like to be Considered for' check box is successfully displayed in Employment Submit Application Career Options level 6 page");
//			  
//		  Element_isdisplayed(Date);
//		  Log.info("Date Available to Begin: input box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Date Available to Begin: input box is successfully displayed in Employment Submit Application Career Options level 6 page");
//			  
//		  Element_isdisplayed(No_rdobtn);
//		  Log.info("Are you now or have you ever been employed with us before? No radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? No radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
//			  
//		  Element_isdisplayed(yes_rdobtn);
//		  Log.info("Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
//			  
//		  Element_isdisplayed(Clb_loc);
//		  Log.info("Club Locations field is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Club Locations field is successfully displayed in Employment Submit Application Career Options level 6 page");
//			  
//		  Element_isdisplayed(Car_opp);
//		  Log.info("Career Opportunities field is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Career Opportunities field is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  MoveToElement(Car_opp);
		  
		  
}
}


public void Validate_slt_considerfor_chkbxs_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_slt_considerfor_chkbxs_l6_AH")) 
	{
		
		Validate_slt_Worktime_l6_AH( "Validate_slt_Worktime_l6_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip, Worktime_ip);
		
		  By Full_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[1]");
		  By Part_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[2]");

		  
		  	int count=0;
			 By General_Manager= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
			 By Personal_Training_Director= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_1");
			 By Operations_Manager= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_2");
			 By Equipment_Tech= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_3");
			 By League_Sports_Director= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_4");
			 By Membership_Counselor= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_5");
			 By Personal_Training_Membership_Counselor= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_6");
			 By Club_Staff= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_7");
			 By HVAC_Building_Maintenance= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_8");
			 By Club_Pride_Janitor= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_9");
			 By Pilates_Teacher= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_10");
			 
			 
			 String[] check_boxes_ip=consider_chkbx_ip.split(",");
			 
			 for (String cb : check_boxes_ip) {
				 
				 String checkbox=cb.trim();
				 switch (checkbox) {
				 
				case "General Manager":
					Element_isdisplayed(General_Manager);
					
					if(driver.findElement(General_Manager).isSelected()) {
						
						Log.info(checkbox+" check box is by default selected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
						
					}else { 
						
					click(General_Manager);
					Log.info(checkbox+" check box successfully selected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
					
					}
					
					break;
					
					
				case "Personal Training Director":
					Element_isdisplayed(Personal_Training_Director);
					if(driver.findElement(Personal_Training_Director).isSelected()) {
						
						Log.info(checkbox+" check box is by default selected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
						
					}else { 
						
					click(Personal_Training_Director);
					Log.info(checkbox+" check box successfully selected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
					
					}
					break;
					

				case "Operations Manager":
					Element_isdisplayed(Operations_Manager);
					
					if(driver.findElement(Operations_Manager).isSelected()) {
						
						Log.info(checkbox+" check box is by default selected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
						
					}else { 
						
					click(Operations_Manager);
					Log.info(checkbox+" check box successfully selected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
					
					}
					break;
					
				case "Equipment Tech":
					Element_isdisplayed(Equipment_Tech);
					if(driver.findElement(Equipment_Tech).isSelected()) {
						
						Log.info(checkbox+" check box is by default selected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
						
					}else { 
						
					click(Equipment_Tech);
					Log.info(checkbox+" check box successfully selected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
					
					}
					break;
					
					
				case "League Sports Director":
					Element_isdisplayed(League_Sports_Director);
					if(driver.findElement(League_Sports_Director).isSelected()) {
						
						Log.info(checkbox+" check box is by default selected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
						
					}else { 
						
					click(League_Sports_Director);
					Log.info(checkbox+" check box successfully selected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
					
					}
					break;
					

				case "Membership Counselor":
					Element_isdisplayed(Membership_Counselor);
					if(driver.findElement(Membership_Counselor).isSelected()) {
						
						Log.info(checkbox+" check box is by default selected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
						
					}else { 
						
					click(Membership_Counselor);
					Log.info(checkbox+" check box successfully selected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
					
					}
					break;
								
				case "Personal Training Membership Counselor":
					Element_isdisplayed(Personal_Training_Membership_Counselor);
					if(driver.findElement(Personal_Training_Membership_Counselor).isSelected()) {
						
						Log.info(checkbox+" check box is by default selected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
						
					}else { 
						
					click(Personal_Training_Membership_Counselor);
					Log.info(checkbox+" check box successfully selected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
					
					}
					break;
							
				case "Club Staff":
					Element_isdisplayed(Club_Staff);
					if(driver.findElement(Club_Staff).isSelected()) {
						
						Log.info(checkbox+" check box is by default selected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
						
					}else { 
						
					click(Club_Staff);
					Log.info(checkbox+" check box successfully selected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
					
					}
					break;
					
					
					
				case "HVAC/Building Maintenance":
					Element_isdisplayed(HVAC_Building_Maintenance);
					if(driver.findElement(HVAC_Building_Maintenance).isSelected()) {
						
						Log.info(checkbox+" check box is by default selected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
						
					}else { 
						
					click(HVAC_Building_Maintenance);
					Log.info(checkbox+" check box successfully selected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
					
					}
					break;
					
					
				case "Club Pride/Janitor":
					Element_isdisplayed(Club_Pride_Janitor);
					if(driver.findElement(Club_Pride_Janitor).isSelected()) {
						
						Log.info(checkbox+" check box is by default selected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
						
					}else { 
						
					click(Club_Pride_Janitor);
					Log.info(checkbox+" check box successfully selected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
					
					}
					break;
					
					
				case "Pilates Teacher":
					Element_isdisplayed(Pilates_Teacher);
					if(driver.findElement(Pilates_Teacher).isSelected()) {
						
						Log.info(checkbox+" check box is by default selected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
						
					}else { 
						
					click(Pilates_Teacher);
					Log.info(checkbox+" check box successfully selected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box successfully selected and validated");
					
					}
					break;
					
					
				default:
					break;
				}
				
			}

		  
	}
	}




public void Validate_deslt_considerfor_chkbxs_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_deslt_considerfor_chkbxs_l6_AH")) 
	{
		
		Validate_slt_considerfor_chkbxs_l6_AH( "Validate_slt_considerfor_chkbxs_l6_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip, Worktime_ip, consider_chkbx_ip);
				
		  By Full_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[1]");
		  By Part_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[2]");

		  
		  	int count=0;
		  	By General_Manager= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
			 By Personal_Training_Director= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_1");
			 By Operations_Manager= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_2");
			 By Equipment_Tech= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_3");
			 By League_Sports_Director= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_4");
			 By Membership_Counselor= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_5");
			 By Personal_Training_Membership_Counselor= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_6");
			 By Club_Staff= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_7");
			 By HVAC_Building_Maintenance= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_8");
			 By Club_Pride_Janitor= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_9");
			 By Pilates_Teacher= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_10");
			  
			 String[] check_boxes_ip=consider_chkbx_ip.split(",");
			 
			 for (String cb : check_boxes_ip) {
				 
				 String checkbox=cb.trim();
				 switch (checkbox) {
				 
				case "General Manager":
					Element_isdisplayed(General_Manager);
					
					if(driver.findElement(General_Manager).isSelected()) {
						click(General_Manager);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					
					break;
					
					
				case "Personal Training Director":
					Element_isdisplayed(Personal_Training_Director);
					if(driver.findElement(Personal_Training_Director).isSelected()) {
						click(Personal_Training_Director);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					
					break;
					

				case "Operations Manager":
					Element_isdisplayed(Operations_Manager);
					
					if(driver.findElement(Operations_Manager).isSelected()) {
						click(Operations_Manager);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
				case "Equipment Tech":
					Element_isdisplayed(Equipment_Tech);
					if(driver.findElement(Equipment_Tech).isSelected()) {
						click(Equipment_Tech);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
					
				case "League Sports Director":
					Element_isdisplayed(League_Sports_Director);
					if(driver.findElement(League_Sports_Director).isSelected()) {
						click(League_Sports_Director);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					

				case "Membership Counselor":
					Element_isdisplayed(Membership_Counselor);
					if(driver.findElement(Membership_Counselor).isSelected()) {
						click(Membership_Counselor);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
										
						
					
				case "Personal Training Membership Counselor":
					Element_isdisplayed(Personal_Training_Membership_Counselor);
					if(driver.findElement(Personal_Training_Membership_Counselor).isSelected()) {
						click(Personal_Training_Membership_Counselor);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
					
				case "Club Staff":
					Element_isdisplayed(Club_Staff);
					if(driver.findElement(Club_Staff).isSelected()) {
						click(Club_Staff);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
					
				case "HVAC/Building Maintenance":
					Element_isdisplayed(HVAC_Building_Maintenance);
					if(driver.findElement(HVAC_Building_Maintenance).isSelected()) {
						click(HVAC_Building_Maintenance);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
				case "Club Pride/Janitor":
					Element_isdisplayed(Club_Pride_Janitor);
					if(driver.findElement(Club_Pride_Janitor).isSelected()) {
						click(Club_Pride_Janitor);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
				case "Pilates Teacher":
					Element_isdisplayed(Pilates_Teacher);
					if(driver.findElement(Pilates_Teacher).isSelected()) {
						click(Pilates_Teacher);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
				default:
					break;
				}
				
			}

		  
	}
	}




public void deslt_considerfor_chkbxs_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("deslt_considerfor_chkbxs_l6_AH")) 
	{
		
//		Validate_slt_considerfor_chkbxs_l6_AH( "Validate_slt_considerfor_chkbxs_l6_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip, Worktime_ip, consider_chkbx_ip);
				
		  By Full_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[1]");
		  By Part_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[2]");

		  
		  	int count=0;
		  	By General_Manager= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
			 By Personal_Training_Director= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_1");
			 By Operations_Manager= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_2");
			 By Equipment_Tech= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_3");
			 By League_Sports_Director= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_4");
			 By Membership_Counselor= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_5");
			 By Personal_Training_Membership_Counselor= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_6");
			 By Club_Staff= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_7");
			 By HVAC_Building_Maintenance= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_8");
			 By Club_Pride_Janitor= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_9");
			 By Pilates_Teacher= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_10");
			  
			 String[] check_boxes_ip=consider_chkbx_ip.split(",");
			 
			 for (String cb : check_boxes_ip) {
				 
				 String checkbox=cb.trim();
				 switch (checkbox) {
				 
				case "General Manager":
					Element_isdisplayed(General_Manager);
					
					if(driver.findElement(General_Manager).isSelected()) {
						click(General_Manager);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					
					break;
					
					
				case "Personal Training Director":
					Element_isdisplayed(Personal_Training_Director);
					if(driver.findElement(Personal_Training_Director).isSelected()) {
						click(Personal_Training_Director);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					
					break;
					

				case "Operations Manager":
					Element_isdisplayed(Operations_Manager);
					
					if(driver.findElement(Operations_Manager).isSelected()) {
						click(Operations_Manager);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
				case "Equipment Tech":
					Element_isdisplayed(Equipment_Tech);
					if(driver.findElement(Equipment_Tech).isSelected()) {
						click(Equipment_Tech);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
					
				case "League_Sports_Director":
					Element_isdisplayed(League_Sports_Director);
					if(driver.findElement(League_Sports_Director).isSelected()) {
						click(League_Sports_Director);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					

				case "Membership Counselor":
					Element_isdisplayed(Membership_Counselor);
					if(driver.findElement(Membership_Counselor).isSelected()) {
						click(Membership_Counselor);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
										
						
					
				case "Personal Training Membership Counselor":
					Element_isdisplayed(Personal_Training_Membership_Counselor);
					if(driver.findElement(Personal_Training_Membership_Counselor).isSelected()) {
						click(Personal_Training_Membership_Counselor);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
					
				case "Club_Staff":
					Element_isdisplayed(Club_Staff);
					if(driver.findElement(Club_Staff).isSelected()) {
						click(Club_Staff);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
					
				case "HVAC/Building Maintenance":
					Element_isdisplayed(HVAC_Building_Maintenance);
					if(driver.findElement(HVAC_Building_Maintenance).isSelected()) {
						click(HVAC_Building_Maintenance);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
				case "Club Pride/Janitor":
					Element_isdisplayed(Club_Pride_Janitor);
					if(driver.findElement(Club_Pride_Janitor).isSelected()) {
						click(Club_Pride_Janitor);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
				case "Pilates Teacher":
					Element_isdisplayed(Pilates_Teacher);
					if(driver.findElement(Pilates_Teacher).isSelected()) {
						click(Pilates_Teacher);
						Log.info(checkbox+" check box is successfully deselected and validated");
						ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is successfully deselected and validated");
						
					}else { 
						
					
					Log.info(checkbox+" check box is by default deselected and validated");
					ExtentTestManager.getTest().log(Status.PASS, checkbox.trim()+"  check box is by default selected and validated");
					
					}
					break;
					
				default:
					break;
				}
				
			}

		  
	}
	}


public void Validate_COs_asperCFchkbxsltn_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_COs_asperCFchkbxsltn_l6_AH")) 
	{
		
		Validate_slt_considerfor_chkbxs_l6_AH( "Validate_slt_considerfor_chkbxs_l6_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip, Worktime_ip, consider_chkbx_ip);
		
		  By Full_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[1]");
		  By Part_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[2]");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		  By Car_opp_values=By.id("ctl00_MainContent_LabelConfirmJobs");
		
		  
		  	int count=0;
			 By Club_Studio_Club_Crew= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
			 By Club_Studio_Club_Pride= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_1");
			 By Club_Studio_Coordinator= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_2");
			 By Membership_Director= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_3");
			 By Assistant_Membership_Director= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_4");
			 By Membership_Associate= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_5");
			  
			 String[] check_boxes_ip=consider_chkbx_ip.split(",");

			  Thread.sleep(200);
			  Element_isdisplayed(Car_opp_values);
			  MoveToElement(Car_opp_values);
			  String Co_values=driver.findElement(Car_opp_values).getText();
			  int count1=0;
			  for(String val:check_boxes_ip) {
				  
				  if(Co_values.trim().toUpperCase().contains(val.trim().toUpperCase())) {
					  Log.info(" I would like to be Considered for check box selected value: "+val.trim()+" is successfull presnet in Career Opportunities");
					  ExtentTestManager.getTest().log(Status.PASS, "  I would like to be Considered for check box selected value: "+val.trim()+" is successfully presnet in Career Opportunities");
					  ++count1;
					  
				  }
				  else {
					  Log.error(" I would like to be Considered for check box selected value: "+val.trim()+" is not presnet in Career Opportunities");
					  ExtentTestManager.getTest().log(Status.FAIL, "  I would like to be Considered for check box selected value: "+val.trim()+" is not presnet in Career Opportunities");
					  
				}
				  
			  }
			  
				 if (check_boxes_ip.length ==count1  ) 
					    {	
						   	Log.info("All given and selected check boxes list of I would like to be Considered for are successfully present in Career Opportunities");
					        ExtentTestManager.getTest().log(Status.PASS, "All given and selected check boxes list of I would like to be Considered for are successfully present in Career Opportunities");
		
					    } else 
					    {	
					    	Log.error("All given and selected check boxes list of I would like to be Considered for are not present in Career Opportunities. Expected list [ "+consider_chkbx_ip +" ] Actual list [ "+Co_values+" ]");
				        	ExtentTestManager.getTest().log(Status.FAIL, "All given and selected check boxes list of I would like to be Considered for are not present in Career Opportunities. Expected list [ "+consider_chkbx_ip +" ] Actual list [ "+Co_values+" ]");
				        	throw new Exception("All given and selected check boxes list of I would like to be Considered for are not present in Career Opportunities.");
					    }

		  
	}
	}


public void Validate_COs_asperCFchkbxdesltn_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String consider_chkbx_ip_1, String CF_chkbx_ip_with_CO) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_COs_asperCFchkbxdesltn_l6_AH")) 
	{
		
		Validate_slt_considerfor_chkbxs_l6_AH( "Validate_slt_considerfor_chkbxs_l6_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip, Worktime_ip, consider_chkbx_ip);
		
		 deslt_considerfor_chkbxs_l6_AH( "deslt_considerfor_chkbxs_l6_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip, Worktime_ip, consider_chkbx_ip_1);
		
		  By Full_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[1]");
		  By Part_time=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT']//tbody//tr//td[2]");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		  By Car_opp_values=By.id("ctl00_MainContent_LabelConfirmJobs");
		
		  
		  	int count=0;
			 By Club_Studio_Club_Crew= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
			 By Club_Studio_Club_Pride= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_1");
			 By Club_Studio_Coordinator= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_2");
			 By Membership_Director= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_3");
			 By Assistant_Membership_Director= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_4");
			 By Membership_Associate= By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_5");
			  
			 String[] check_boxes_ip=CF_chkbx_ip_with_CO.split(",");

			  Thread.sleep(200);
			  Element_isdisplayed(Car_opp_values);
			  MoveToElement(Car_opp_values);
			  String Co_values=driver.findElement(Car_opp_values).getText();
			  int count1=0;
			  for(String val:check_boxes_ip) {
				  
				  if(Co_values.trim().toUpperCase().contains(val.trim().toUpperCase())) {
					  Log.info(" I would like to be Considered for check box selected value: "+val.trim()+" is successfull presnet in Career Opportunities");
					  ExtentTestManager.getTest().log(Status.PASS, "  I would like to be Considered for check box selected value: "+val.trim()+" is successfully presnet in Career Opportunities");
					  ++count1;
					  
				  }
				  else {
					  Log.error(" I would like to be Considered for check box selected value: "+val.trim()+" is not presnet in Career Opportunities");
					  ExtentTestManager.getTest().log(Status.FAIL, "  I would like to be Considered for check box selected value: "+val.trim()+" is not presnet in Career Opportunities");
					  
				}
				  
			  }
			  
				 if (check_boxes_ip.length ==count1  ) 
					    {	
						   	Log.info("All given and selected check boxes list of I would like to be Considered for are successfully present in Career Opportunities");
					        ExtentTestManager.getTest().log(Status.PASS, "All given and selected check boxes list of I would like to be Considered for are successfully present in Career Opportunities");
		
					    } else 
					    {	
					    	Log.error("All given and selected check boxes list of I would like to be Considered for are not present in Career Opportunities. Expected list [ "+consider_chkbx_ip +" ] Actual list [ "+Co_values+" ]");
				        	ExtentTestManager.getTest().log(Status.FAIL, "All given and selected check boxes list of I would like to be Considered for are not present in Career Opportunities. Expected list [ "+consider_chkbx_ip +" ] Actual list [ "+Co_values+" ]");
				        	throw new Exception("All given and selected check boxes list of I would like to be Considered for are not present in Career Opportunities.");
					    }
	}
	}


public void Validate_defaultvalueofCO_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String CO_defaultvalue) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_defaultvalueofCO_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
	
		  By Full_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[9]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]");
		  By Part_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[9]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]");
		  By Clb_loc=By.xpath("//td[contains(text(),'Club Locations:')]");
		  By Car_opp=By.xpath("//td[contains(text(),'Career Opportunities:')]");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentNo");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		  By Car_opp_values_default=By.xpath("//table[@id='ctl00_MainContent_tableConfirmation']//tbody//tr[3]//td[2]");
		
		
		  By chceck_boxes=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor']//tbody//tr//td/input");
		  By chceck_boxes_labels=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor']//tbody//tr//td/label");
		  
		  Thread.sleep(200);
		  Element_isdisplayed(Car_opp_values_default);
		  MoveToElement(Car_opp_values_default);
		  String Co_values=driver.findElement(Car_opp_values_default).getText();
		  
		  Assert.assertEquals(Co_values.trim().toUpperCase(), CO_defaultvalue.trim().toUpperCase(), "Default Career Opportunities value is not validated");
			  Log.info("Successfully validated the default Career Opportunities value : "+Co_values);
			  ExtentTestManager.getTest().log(Status.PASS, "Successfully validated the default Career Opportunities value : "+Co_values);
			 
			 
		}
}


public void Validate_ip_date_to_begin_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Input) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_ip_date_to_begin_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
		  By Full_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]");
		  By Part_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]");
		  By Consider_for_GF=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/span[1]");
		  By Consider_for_GF_cb=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
		  By Clb_loc=By.xpath("//td[contains(text(),'Club Locations:')]");
		  By Car_opp=By.xpath("//td[contains(text(),'Career Opportunities:')]");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentNo");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		   
		  
		  Element_isdisplayed(Date);
		  Log.info("Date Available to Begin: input box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Date Available to Begin: input box is successfully displayed in Employment Submit Application Career Options level 6 page");
		
		  input(Date, Input);
		  Log.info("Date: "+Input+" is entered successfully in Date Available to Begin input box in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Date: "+Input+"  is entered successfully in Date Available to Begin input box in Employment Submit Application Career Options level 6 page");
		

		  
		  
}
}


public void Validate_empdwithus_no_rdobtn_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Input) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_empdwithus_no_rdobtn_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
		  By Full_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]");
		  By Part_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]");
		  By Consider_for_GF=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/span[1]");
		  By Consider_for_GF_cb=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
		  By Clb_loc=By.xpath("//td[contains(text(),'Club Locations:')]");
		  By Car_opp=By.xpath("//td[contains(text(),'Career Opportunities:')]");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentNo");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		  By If_yes_text=By.id("ctl00_MainContent_ApplicantCareerOpportunities_LabelPriorEmploymentYesPrompt");
		  By Based_on_selections_text=By.xpath("//b[contains(text(),'Based on your selections, you have requested consi')]");
		  
	  
		
		  Element_isdisplayed(No_rdobtn);
		  Assert.assertTrue(driver.findElement(No_rdobtn).isSelected(), "Are you now or have you ever been employed with us before? No radio button is by default not selected in Employment Submit Application Career Options level 6 page");  
		  Log.info("Are you now or have you ever been employed with us before? No radio button is successfully displayed and by default selected in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? No radio button is successfully displayed  and by default selected in Employment Submit Application Career Options level 6 page");
			  
//		  Thread.sleep(200);
			 Element_isdisplayed(If_yes_text);
			 String txt=driver.findElement(If_yes_text).getText().replace("\n", " ");
			 Assert.assertEquals(txt.toUpperCase().trim(), Input.toUpperCase().trim(), Input+" text in Employment Submit Application Career Options level 6 page not validated");
			 Log.info(txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
			 ExtentTestManager.getTest().log(Status.PASS, txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
			  
		  
		  
//		  Element_isdisplayed(yes_rdobtn);
//		  Log.info("Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
			  
//		  Element_isdisplayed(Clb_loc);
//		  Log.info("Club Locations field is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Club Locations field is successfully displayed in Employment Submit Application Career Options level 6 page");
//			  
//		  Element_isdisplayed(Car_opp);
//		  Log.info("Career Opportunities field is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Career Opportunities field is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  MoveToElement(Car_opp);
		  
		  
}
}


public void Validate_basedonsltns_text_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Input) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_basedonsltns_text_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
	
		  By Full_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]");
		  By Part_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]");
		  By Consider_for_GF=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/span[1]");
		  By Consider_for_GF_cb=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
		  By Clb_loc=By.xpath("//td[contains(text(),'Club Locations:')]");
		  By Car_opp=By.xpath("//td[contains(text(),'Career Opportunities:')]");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentNo");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		  By If_yes_text=By.id("ctl00_MainContent_ApplicantCareerOpportunities_LabelPriorEmploymentYesPrompt");
		  By Based_on_selections_text=By.xpath("//b[contains(text(),'Based on your selections, you have requested consi')]");
		  
	  
			 Element_isdisplayed(Based_on_selections_text);
			 MoveToElement(Based_on_selections_text);
			 String txt=driver.findElement(Based_on_selections_text).getText().replace("\n", " ");
			 Assert.assertEquals(txt.toUpperCase().trim(), Input.toUpperCase().trim(), Input+" text in Employment Submit Application Career Options level 6 page not validated");
			 Log.info(txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
			 ExtentTestManager.getTest().log(Status.PASS, txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
			  
		  
	
		  
}
}

public void Validate_Club_locations_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Input) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Club_locations_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
	
		  By Full_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]");
		  By Part_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]");
		  By Consider_for_GF=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/span[1]");
		  By Consider_for_GF_cb=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
		  By Clb_loc=By.xpath("//td[contains(text(),'Club Locations:')]");
		  By Clb_locations=By.id("ctl00_MainContent_LabelConfirmClubs");
		  By Car_opp=By.xpath("//td[contains(text(),'Career Opportunities:')]");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentNo");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		  By If_yes_text=By.id("ctl00_MainContent_ApplicantCareerOpportunities_LabelPriorEmploymentYesPrompt");
		  By Based_on_selections_text=By.xpath("//b[contains(text(),'Based on your selections, you have requested consi')]");
		  
	  
		  
		  Element_isdisplayed(Clb_loc);
		  Log.info("Club Locations field is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Club Locations field is successfully displayed in Employment Submit Application Career Options level 6 page");
			 
//		  Thread.sleep(200);
			 Element_isdisplayed(Clb_locations);
			 MoveToElement(Clb_locations);
			 String txt=driver.findElement(Clb_locations).getText().replace("\n", " ");
			 Assert.assertEquals(txt.toUpperCase().trim(), Input.toUpperCase().trim(), Input+" Club Locations in Employment Submit Application Career Options level 6 page not validated");
			 Log.info("Club Locations "+txt+" successfully displayed and validated in Employment Submit Application Career Options level 6 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Club Locations "+txt+" successfully displayed and validated in Employment Submit Application Career Options level 6 page");
			  
		  
		  
//		  Element_isdisplayed(yes_rdobtn);
//		  Log.info("Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
		 
//		  Element_isdisplayed(Car_opp);
//		  Log.info("Career Opportunities field is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Career Opportunities field is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  MoveToElement(Car_opp);
		  
		  
}
}

public void Validate_RQ_sec_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Input) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_RQ_sec_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
		  By Full_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]");
		  By Part_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]");
		  By Consider_for_GF=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/span[1]");
		  By Consider_for_GF_cb=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
		  By Clb_loc=By.xpath("//td[contains(text(),'Club Locations:')]");
		  By Clb_locations=By.id("ctl00_MainContent_LabelConfirmClubs");
		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
		  By EmploymentHowResigned_dd=By.id("ctl00_MainContent_ApplicantCareerOpportunities_DropDownListPriorEmploymentHowResigned");
		  By PriorEmploymentWhyResigned=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyResigned");
		  By EmploymentWhyLeaveCurrent=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyLeaveCurrent");
		  By EmploymentWhyReapply=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyReapply");
		  By EmploymentWhatLike=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhatLike");
		  By EmploymentWhatDislike=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhatDislike");
		  By EmploymentSuccess=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentSuccess");
		  By EmploymentWhyResignInFuture=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyResignInFuture");
//		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
//		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
//		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
		  
		  By RQ=By.xpath("//b[contains(text(),'Rehire Questionnaire')]");
		  By Car_opp=By.xpath("//td[contains(text(),'Career Opportunities:')]");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentNo");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		  By If_yes_text=By.id("ctl00_MainContent_ApplicantCareerOpportunities_LabelPriorEmploymentYesPrompt");
		  By Based_on_selections_text=By.xpath("//b[contains(text(),'Based on your selections, you have requested consi')]");
		  
	  
		  
//		  Element_isdisplayed(Car_opp);
//		  Log.info("Career Opportunities field is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Career Opportunities field is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  MoveToElement(Car_opp);
////		  Thread.sleep(200);
//			 Element_isdisplayed(Car_opp_val);
//			 String txt=driver.findElement(Car_opp_val).getText().replace("\n", " ");
//			 Assert.assertEquals(txt.toUpperCase().trim(), Input.toUpperCase().trim(), Input+" Career Opportunities in Employment Submit Application Career Options level 6 page not validated");
//			 Log.info("Career Opportunities "+txt+" successfully displayed and validated in Employment Submit Application Career Options level 6 page");
//			 ExtentTestManager.getTest().log(Status.PASS, "Career Opportunities "+txt+" successfully displayed and validated in Employment Submit Application Career Options level 6 page");
//			  
		  
		  
		  Element_isdisplayed(yes_rdobtn);
		  Log.info("Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
		  click(If_yes_text);
		  click(yes_rdobtn);
		  Log.info("Are you now or have you ever been employed with us before? Yes radio button is successfully selected in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? Yes radio button is successfully selected in Employment Submit Application Career Options level 6 page");
		  
		  Element_isdisplayed(RQ);
		  String txt=driver.findElement(RQ).getText().replace("\n", " ");
		  Assert.assertEquals(txt.toUpperCase().trim(), Input.toUpperCase().trim(), Input+" text in Employment Submit Application Career Options level 6 page not validated");
		  Log.info(txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
		  MoveToElement(RQ);
		  
		  Element_isdisplayed(EmploymentHowResigned_dd);
		  Log.info("How did you Resign your employment with us? dropdown is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"How did you Resign your employment with us? dropdown is successfully displayed in Employment Submit Application Career Options level 6 page");
		 
		  Element_isdisplayed(PriorEmploymentWhyResigned);
		  Log.info("Why did you Resign from your employment with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Why did you Resign from your employment with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		 
		  Element_isdisplayed(EmploymentWhyLeaveCurrent);
		  Log.info("Why do you want to Leave your Current Job or why did your last job end? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Why do you want to Leave your Current Job or why did your last job end? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  
		  Element_isdisplayed(EmploymentWhyReapply);
		  Log.info("What prompted you to Re-Apply with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What prompted you to Re-Apply with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  MoveToElement(EmploymentWhyReapply);
		  
		  Element_isdisplayed(EmploymentWhatLike);
		  Log.info("What did you Like the Most about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What did you Like the Most about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  
		  
		  Element_isdisplayed(EmploymentWhatDislike);
		  Log.info("What did you Like the Least about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What did you Like the Least about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  
		  Element_isdisplayed(EmploymentSuccess);
		  Log.info("Do you feel you were Successful when employed here previously and what would you do to be Successful if selected for a position? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Do you feel you were Successful when employed here previously and what would you do to be Successful if selected for a position? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  
		  Element_isdisplayed(EmploymentWhyResignInFuture);
		  Log.info("What would cause you to Resign in the Future? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What would cause you to Resign in the Future? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  MoveToElement(EmploymentWhyResignInFuture);
		  
		  
		  
}
}

public void Validate_Resigned_dd_allvalues_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String EmpHowResigned_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Resigned_dd_allvalues_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
			 
		  By Full_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]");
		  By Part_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]");
		  By Consider_for_GF=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/span[1]");
		  By Consider_for_GF_cb=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
		  By Clb_loc=By.xpath("//td[contains(text(),'Club Locations:')]");
		  By Clb_locations=By.id("ctl00_MainContent_LabelConfirmClubs");
		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
		  By EmploymentHowResigned_dd=By.id("ctl00_MainContent_ApplicantCareerOpportunities_DropDownListPriorEmploymentHowResigned");
		  By PriorEmploymentWhyResigned=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyResigned");
		  By EmploymentWhyLeaveCurrent=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyLeaveCurrent");
		  By EmploymentWhyReapply=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyReapply");
		  By EmploymentWhatLike=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhatLike");
		  By EmploymentWhatDislike=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhatDislike");
		  By EmploymentSuccess=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentSuccess");
		  By EmploymentWhyResignInFuture=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyResignInFuture");
//		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
//		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
//		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
		  
		  By RQ=By.xpath("//b[contains(text(),'Rehire Questionnaire')]");
		  By Car_opp=By.xpath("//td[contains(text(),'Career Opportunities:')]");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentNo");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		  By If_yes_text=By.id("ctl00_MainContent_ApplicantCareerOpportunities_LabelPriorEmploymentYesPrompt");
		  By Based_on_selections_text=By.xpath("//b[contains(text(),'Based on your selections, you have requested consi')]");
		  
	  
		  
//		  Element_isdisplayed(Car_opp);
//		  Log.info("Career Opportunities field is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Career Opportunities field is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  MoveToElement(Car_opp);
////		  Thread.sleep(200);
//			 Element_isdisplayed(Car_opp_val);
//			 String txt=driver.findElement(Car_opp_val).getText().replace("\n", " ");
//			 Assert.assertEquals(txt.toUpperCase().trim(), Input.toUpperCase().trim(), Input+" Career Opportunities in Employment Submit Application Career Options level 6 page not validated");
//			 Log.info("Career Opportunities "+txt+" successfully displayed and validated in Employment Submit Application Career Options level 6 page");
//			 ExtentTestManager.getTest().log(Status.PASS, "Career Opportunities "+txt+" successfully displayed and validated in Employment Submit Application Career Options level 6 page");
//			  
		  
		  
		  Element_isdisplayed(yes_rdobtn);
		  Log.info("Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
		  click(If_yes_text);
		  click(yes_rdobtn);
		  Log.info("Are you now or have you ever been employed with us before? Yes radio button is successfully selected in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? Yes radio button is successfully selected in Employment Submit Application Career Options level 6 page");
		  
//		  Element_isdisplayed(RQ);
//		  String txt=driver.findElement(RQ).getText().replace("\n", " ");
//		  Assert.assertEquals(txt.toUpperCase().trim(), Input.toUpperCase().trim(), Input+" text in Employment Submit Application Career Options level 6 page not validated");
//		  Log.info(txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
//		  MoveToElement(RQ);
//		  
		  Element_isdisplayed(EmploymentHowResigned_dd);
		  Log.info("How did you Resign your employment with us? dropdown is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"How did you Resign your employment with us? dropdown is successfully displayed in Employment Submit Application Career Options level 6 page");
		 

			 String[] EmpHowResigned_ip_values=EmpHowResigned_ip.split(",");

				
			 Select select = new Select(driver.findElement(EmploymentHowResigned_dd));  
			 
			 String default_value=select.getFirstSelectedOption().getText();
			 Assert.assertEquals(default_value.toUpperCase().trim(), EmpHowResigned_ip_values[0].toUpperCase().trim(), default_value+" default option of 'How did you Resign your employment with us?' dropdown in Employment Submit Application level 6 page not validated");
			 ExtentTestManager.getTest().log(Status.PASS, default_value+" option of 'How did you Resign your employment with us?' dropdown by default selected successfully in Employment Submit Application Career Options level 6 page");
			 Log.info(default_value+" option of 'How did you Resign your employment with us?' dropdown by default selected successfully in Employment Submit Application Career Options level 6 page");
		 
			 int count=0;
			 List<WebElement> options = select.getOptions();  
			 
			 ArrayList<String> mylist = new ArrayList<String>();
			 
			 for(WebElement we:options)  
			 	{  
				 
				 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
			 	}
			 	String delim = ",";
		        String res = String.join(delim, mylist);
				 
			  for (int i=0; i<EmpHowResigned_ip_values.length; i++)
			  	{
				  
				  if(res.trim().toUpperCase().contains(EmpHowResigned_ip_values[i].trim().toUpperCase()))
				  	{
					  count++;
					  Log.info(EmpHowResigned_ip_values[i].trim()+" value matched");
					  ExtentTestManager.getTest().log(Status.PASS, EmpHowResigned_ip_values[i].trim()+" value matched");
					  
				  	}
				  else
				  {
					  
					  Log.error(EmpHowResigned_ip_values[i].trim()+" value not matched with the values in 'How did you Resign your employment with us?' dropdown list"); 
					  ExtentTestManager.getTest().log(Status.FAIL, EmpHowResigned_ip_values[i].trim()+" value not matched with the values in 'How did you Resign your employment with us?' dropdown list");
					  
					 
					  }
				  if (EmpHowResigned_ip_values.length == count)break;
			  		}	 
			
			   if (EmpHowResigned_ip_values.length == count &&  mylist.size()==EmpHowResigned_ip_values.length) 
			    {	
				  
				   	Log.info("All values matched successfully in the 'How did you Resign your employment with us?' dropdown as Expected");
			        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the 'How did you Resign your employment with us?' dropdown as Expected");

			    } else 
			    {	
			    	Log.error("All values not matched successfully in the 'How did you Resign your employment with us?' dropdown. Expected dropdown list [ "+EmpHowResigned_ip +" ] Actual dropdown list [ "+res+" ]");
		        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the 'How did you Resign your employment with us?' dropdown. Expected dropdown list [ "+EmpHowResigned_ip +" ] Actual dropdown list [ "+res+" ]");
		        	throw new Exception("All values not matched successfully in the 'How did you Resign your employment with us?' dropdown");
			    }
			 

		  
//		  Element_isdisplayed(PriorEmploymentWhyResigned);
//		  Log.info("Why did you Resign from your employment with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Why did you Resign from your employment with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		 
//		  Element_isdisplayed(EmploymentWhyLeaveCurrent);
//		  Log.info("Why do you want to Leave your Current Job or why did your last job end? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Why do you want to Leave your Current Job or why did your last job end? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  
//		  Element_isdisplayed(EmploymentWhyReapply);
//		  Log.info("What prompted you to Re-Apply with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"What prompted you to Re-Apply with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  MoveToElement(EmploymentWhyReapply);
//		  
//		  Element_isdisplayed(EmploymentWhatLike);
//		  Log.info("What did you Like the Most about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"What did you Like the Most about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  
//		  
//		  Element_isdisplayed(EmploymentWhatDislike);
//		  Log.info("What did you Like the Least about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"What did you Like the Least about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  
//		  Element_isdisplayed(EmploymentSuccess);
//		  Log.info("Do you feel you were Successful when employed here previously and what would you do to be Successful if selected for a position? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Do you feel you were Successful when employed here previously and what would you do to be Successful if selected for a position? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  
//		  Element_isdisplayed(EmploymentWhyResignInFuture);
//		  Log.info("What would cause you to Resign in the Future? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"What would cause you to Resign in the Future? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  MoveToElement(EmploymentWhyResignInFuture);
//		  
		  
		  
}
}

public void Validate_ip_in_RQ_sec_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_ip_in_RQ_sec_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
		  By Full_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]");
		  By Part_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]");
		  By Consider_for_GF=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/span[1]");
		  By Consider_for_GF_cb=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
		  By Clb_loc=By.xpath("//td[contains(text(),'Club Locations:')]");
		  By Clb_locations=By.id("ctl00_MainContent_LabelConfirmClubs");
		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
		  By EmploymentHowResigned_dd=By.id("ctl00_MainContent_ApplicantCareerOpportunities_DropDownListPriorEmploymentHowResigned");
		  By PriorEmploymentWhyResigned=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyResigned");
		  By EmploymentWhyLeaveCurrent=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyLeaveCurrent");
		  By EmploymentWhyReapply=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyReapply");
		  By EmploymentWhatLike=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhatLike");
		  By EmploymentWhatDislike=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhatDislike");
		  By EmploymentSuccess=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentSuccess");
		  By EmploymentWhyResignInFuture=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyResignInFuture");
//		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
//		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
//		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
		  
		  By RQ=By.xpath("//b[contains(text(),'Rehire Questionnaire')]");
		  By Car_opp=By.xpath("//td[contains(text(),'Career Opportunities:')]");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentNo");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		  By If_yes_text=By.id("ctl00_MainContent_ApplicantCareerOpportunities_LabelPriorEmploymentYesPrompt");
		  By Based_on_selections_text=By.xpath("//b[contains(text(),'Based on your selections, you have requested consi')]");
		  
	  		  
		  
		  
		  Element_isdisplayed(yes_rdobtn);
		  Log.info("Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
		  click(If_yes_text);
		  click(yes_rdobtn);
		  Log.info("Are you now or have you ever been employed with us before? Yes radio button is successfully selected in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? Yes radio button is successfully selected in Employment Submit Application Career Options level 6 page");
		  
//		  Element_isdisplayed(RQ);
//		  String txt=driver.findElement(RQ).getText().replace("\n", " ");
//		  Assert.assertEquals(txt.toUpperCase().trim(), Input.toUpperCase().trim(), Input+" text in Employment Submit Application Career Options level 6 page not validated");
//		  Log.info(txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
		  MoveToElement(RQ);
		  
		  Element_isdisplayed(EmploymentHowResigned_dd);
		  Log.info("How did you Resign your employment with us? dropdown is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"How did you Resign your employment with us? dropdown is successfully displayed in Employment Submit Application Career Options level 6 page");
		 

//			 String[] EmpHowResigned_ip_values=EmpHowResigned_ip.split(",");

				
			 Select select = new Select(driver.findElement(EmploymentHowResigned_dd));  
			 select.selectByVisibleText(EmpHowResigned_ip.trim());
//			 String default_value=select.getFirstSelectedOption().getText();
//			 Assert.assertEquals(default_value.toUpperCase().trim(), EmpHowResigned_ip_values[0].toUpperCase().trim(), default_value+" default option of 'How did you Resign your employment with us?' dropdown in Employment Submit Application level 3 page not validated");
			 ExtentTestManager.getTest().log(Status.PASS, EmpHowResigned_ip.trim()+" option of 'How did you Resign your employment with us?' dropdown selected successfully in Employment Submit Application Career Options level 6 page");
			 Log.info(EmpHowResigned_ip.trim()+" option of 'How did you Resign your employment with us?' dropdown selected successfully in Employment Submit Application Career Options level 6 page");
		 
			
		  
		  Element_isdisplayed(PriorEmploymentWhyResigned);
		  Log.info("Why did you Resign from your employment with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Why did you Resign from your employment with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		 
		  input(PriorEmploymentWhyResigned, PriorEmploymentWhyResigned_ip);
		  Log.info("Successfully entered ' "+PriorEmploymentWhyResigned_ip+" ' text in 'Why did you Resign from your employment with us?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+PriorEmploymentWhyResigned_ip+" ' text in 'Why did you Resign from your employment with us?' in Employment Submit Application Career Options level 6 page");
		  
		  
		  Element_isdisplayed(EmploymentWhyLeaveCurrent);
		  Log.info("Why do you want to Leave your Current Job or why did your last job end? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Why do you want to Leave your Current Job or why did your last job end? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  
		  input(EmploymentWhyLeaveCurrent, EmploymentWhyLeaveCurrent_ip);
		  Log.info("Successfully entered ' "+EmploymentWhyLeaveCurrent_ip+" ' text in 'Why do you want to Leave your Current Job or why did your last job end?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+EmploymentWhyLeaveCurrent_ip+" ' text in 'Why do you want to Leave your Current Job or why did your last job end?' in Employment Submit Application Career Options level 6 page");
		  
		  
		  Element_isdisplayed(EmploymentWhyReapply);
		  Log.info("What prompted you to Re-Apply with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What prompted you to Re-Apply with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  MoveToElement(EmploymentWhyReapply);
		  
		  input(EmploymentWhyReapply, EmploymentWhyReapply_ip);
		  Log.info("Successfully entered ' "+EmploymentWhyReapply_ip+" ' text in 'What prompted you to Re-Apply with us?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+EmploymentWhyReapply_ip+" ' text in 'What prompted you to Re-Apply with us?' in Employment Submit Application Career Options level 6 page");
		  
		  
		  Element_isdisplayed(EmploymentWhatLike);
		  Log.info("What did you Like the Most about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What did you Like the Most about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  
		  input(EmploymentWhatLike, EmploymentWhatLike_ip);
		  Log.info("Successfully entered ' "+EmploymentWhatLike_ip+" ' text in 'What did you Like the Most about the last time you worked with us?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+EmploymentWhatLike_ip+" ' text in 'What did you Like the Most about the last time you worked with us?' in Employment Submit Application Career Options level 6 page");
		  
		  
		  Element_isdisplayed(EmploymentWhatDislike);
		  Log.info("What did you Like the Least about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What did you Like the Least about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  
		  input(EmploymentWhatDislike, EmploymentWhatDislike_ip);
		  Log.info("Successfully entered ' "+EmploymentWhatDislike_ip+" ' text in 'What did you Like the Least about the last time you worked with us?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+EmploymentWhatDislike_ip+" ' text in 'What did you Like the Least about the last time you worked with us?' in Employment Submit Application Career Options level 6 page");
		  
		  Element_isdisplayed(EmploymentSuccess);
		  Log.info("Do you feel you were Successful when employed here previously and what would you do to be Successful if selected for a position? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Do you feel you were Successful when employed here previously and what would you do to be Successful if selected for a position? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  
		  input(EmploymentSuccess, EmploymentSuccess_ip);
		  Log.info("Successfully entered ' "+EmploymentSuccess_ip+" ' text in 'Do you feel you were Successful when employed here previously and what would you do to be Successful if selected for a position?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+EmploymentSuccess_ip+" ' text in 'Do you feel you were Successful when employed here previously and what would you do to be Successful if selected for a position?' in Employment Submit Application Career Options level 6 page");
		  
		  
		  Element_isdisplayed(EmploymentWhyResignInFuture);
		  Log.info("What would cause you to Resign in the Future? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What would cause you to Resign in the Future? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  MoveToElement(EmploymentWhyResignInFuture);
		  
		  input(EmploymentWhyResignInFuture, EmploymentWhyResignInFuture_ip);
		  Log.info("Successfully entered ' "+EmploymentWhyResignInFuture_ip+" ' text in 'What would cause you to Resign in the Future?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+EmploymentWhyResignInFuture_ip+" ' text in 'What would cause you to Resign in the Future?' in Employment Submit Application Career Options level 6 page");
		  
		  
	}
}

public void ip_in_RQ_sec_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("ip_in_RQ_sec_l6_AH")) 
	{
		
//		Validate_Next_step_btn_in_l5( "Validate_Next_step_btn_in_l5",  ip_title,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,  Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip, Emp_checkbox_ip,doc_name, CB_ip);
			 		 
		  By Full_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]");
		  By Part_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]");
		  By Consider_for_GF=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[10]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/span[1]");
		  By Consider_for_GF_cb=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
		  By Clb_loc=By.xpath("//td[contains(text(),'Club Locations:')]");
		  By Clb_locations=By.id("ctl00_MainContent_LabelConfirmClubs");
		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
		  By EmploymentHowResigned_dd=By.id("ctl00_MainContent_ApplicantCareerOpportunities_DropDownListPriorEmploymentHowResigned");
		  By PriorEmploymentWhyResigned=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyResigned");
		  By EmploymentWhyLeaveCurrent=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyLeaveCurrent");
		  By EmploymentWhyReapply=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyReapply");
		  By EmploymentWhatLike=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhatLike");
		  By EmploymentWhatDislike=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhatDislike");
		  By EmploymentSuccess=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentSuccess");
		  By EmploymentWhyResignInFuture=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxPriorEmploymentWhyResignInFuture");
//		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
//		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
//		  By Car_opp_val=By.id("ctl00_MainContent_LabelConfirmJobs");
		  
		  By RQ=By.xpath("//b[contains(text(),'Rehire Questionnaire')]");
		  By Car_opp=By.xpath("//td[contains(text(),'Career Opportunities:')]");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentNo");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		  By If_yes_text=By.id("ctl00_MainContent_ApplicantCareerOpportunities_LabelPriorEmploymentYesPrompt");
		  By Based_on_selections_text=By.xpath("//b[contains(text(),'Based on your selections, you have requested consi')]");
		  
	  		  
		  
		  
		  Element_isdisplayed(yes_rdobtn);
		  Log.info("Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? Yes radio button is successfully displayed in Employment Submit Application Career Options level 6 page");
		  click(If_yes_text);
		  click(yes_rdobtn);
		  Log.info("Are you now or have you ever been employed with us before? Yes radio button is successfully selected in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? Yes radio button is successfully selected in Employment Submit Application Career Options level 6 page");
		  
//		  Element_isdisplayed(RQ);
//		  String txt=driver.findElement(RQ).getText().replace("\n", " ");
//		  Assert.assertEquals(txt.toUpperCase().trim(), Input.toUpperCase().trim(), Input+" text in Employment Submit Application Career Options level 6 page not validated");
//		  Log.info(txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
//		  ExtentTestManager.getTest().log(Status.PASS,txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
		  MoveToElement(RQ);
		  
		  Element_isdisplayed(EmploymentHowResigned_dd);
		  Log.info("How did you Resign your employment with us? dropdown is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"How did you Resign your employment with us? dropdown is successfully displayed in Employment Submit Application Career Options level 6 page");
		 

//			 String[] EmpHowResigned_ip_values=EmpHowResigned_ip.split(",");

				
			 Select select = new Select(driver.findElement(EmploymentHowResigned_dd));  
			 select.selectByVisibleText(EmpHowResigned_ip.trim());
//			 String default_value=select.getFirstSelectedOption().getText();
//			 Assert.assertEquals(default_value.toUpperCase().trim(), EmpHowResigned_ip_values[0].toUpperCase().trim(), default_value+" default option of 'How did you Resign your employment with us?' dropdown in Employment Submit Application level 3 page not validated");
			 ExtentTestManager.getTest().log(Status.PASS, EmpHowResigned_ip.trim()+" option of 'How did you Resign your employment with us?' dropdown selected successfully in Employment Submit Application Career Options level 6 page");
			 Log.info(EmpHowResigned_ip.trim()+" option of 'How did you Resign your employment with us?' dropdown selected successfully in Employment Submit Application Career Options level 6 page");
		 
			
		  
		  Element_isdisplayed(PriorEmploymentWhyResigned);
		  Log.info("Why did you Resign from your employment with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Why did you Resign from your employment with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		 
		  input(PriorEmploymentWhyResigned, PriorEmploymentWhyResigned_ip);
		  Log.info("Successfully entered ' "+PriorEmploymentWhyResigned_ip+" ' text in 'Why did you Resign from your employment with us?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+PriorEmploymentWhyResigned_ip+" ' text in 'Why did you Resign from your employment with us?' in Employment Submit Application Career Options level 6 page");
		  
		  
		  Element_isdisplayed(EmploymentWhyLeaveCurrent);
		  Log.info("Why do you want to Leave your Current Job or why did your last job end? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Why do you want to Leave your Current Job or why did your last job end? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  
		  input(EmploymentWhyLeaveCurrent, EmploymentWhyLeaveCurrent_ip);
		  Log.info("Successfully entered ' "+EmploymentWhyLeaveCurrent_ip+" ' text in 'Why do you want to Leave your Current Job or why did your last job end?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+EmploymentWhyLeaveCurrent_ip+" ' text in 'Why do you want to Leave your Current Job or why did your last job end?' in Employment Submit Application Career Options level 6 page");
		  
		  
		  Element_isdisplayed(EmploymentWhyReapply);
		  Log.info("What prompted you to Re-Apply with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What prompted you to Re-Apply with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  MoveToElement(EmploymentWhyReapply);
		  
		  input(EmploymentWhyReapply, EmploymentWhyReapply_ip);
		  Log.info("Successfully entered ' "+EmploymentWhyReapply_ip+" ' text in 'What prompted you to Re-Apply with us?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+EmploymentWhyReapply_ip+" ' text in 'What prompted you to Re-Apply with us?' in Employment Submit Application Career Options level 6 page");
		  
		  
		  Element_isdisplayed(EmploymentWhatLike);
		  Log.info("What did you Like the Most about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What did you Like the Most about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  
		  input(EmploymentWhatLike, EmploymentWhatLike_ip);
		  Log.info("Successfully entered ' "+EmploymentWhatLike_ip+" ' text in 'What did you Like the Most about the last time you worked with us?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+EmploymentWhatLike_ip+" ' text in 'What did you Like the Most about the last time you worked with us?' in Employment Submit Application Career Options level 6 page");
		  
		  
		  Element_isdisplayed(EmploymentWhatDislike);
		  Log.info("What did you Like the Least about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What did you Like the Least about the last time you worked with us? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  
		  input(EmploymentWhatDislike, EmploymentWhatDislike_ip);
		  Log.info("Successfully entered ' "+EmploymentWhatDislike_ip+" ' text in 'What did you Like the Least about the last time you worked with us?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+EmploymentWhatDislike_ip+" ' text in 'What did you Like the Least about the last time you worked with us?' in Employment Submit Application Career Options level 6 page");
		  
		  Element_isdisplayed(EmploymentSuccess);
		  Log.info("Do you feel you were Successful when employed here previously and what would you do to be Successful if selected for a position? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Do you feel you were Successful when employed here previously and what would you do to be Successful if selected for a position? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  
		  input(EmploymentSuccess, EmploymentSuccess_ip);
		  Log.info("Successfully entered ' "+EmploymentSuccess_ip+" ' text in 'Do you feel you were Successful when employed here previously and what would you do to be Successful if selected for a position?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+EmploymentSuccess_ip+" ' text in 'Do you feel you were Successful when employed here previously and what would you do to be Successful if selected for a position?' in Employment Submit Application Career Options level 6 page");
		  
		  
		  Element_isdisplayed(EmploymentWhyResignInFuture);
		  Log.info("What would cause you to Resign in the Future? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What would cause you to Resign in the Future? text box is successfully displayed in Employment Submit Application Career Options level 6 page");
//		  MoveToElement(EmploymentWhyResignInFuture);
		  
		  input(EmploymentWhyResignInFuture, EmploymentWhyResignInFuture_ip);
		  Log.info("Successfully entered ' "+EmploymentWhyResignInFuture_ip+" ' text in 'What would cause you to Resign in the Future?' in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered ' "+EmploymentWhyResignInFuture_ip+" ' text in 'What would cause you to Resign in the Future?' in Employment Submit Application Career Options level 6 page");
		  
		  
	}
}

public void Validate_prev_next_step_btns_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_prev_next_step_btns_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
	 
		Element_isdisplayed(btn_prev);
		  MoveToElement(btn_prev);
		  Log.info("Previous step button is displayed successfully in Employment Submit Application Career Options level 6 page ");
		  ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Employment Submit Application Career Options level 6 page");

		  Element_isdisplayed(btn_next);
		  Log.info("Next step button is displayed successfully in Employment Submit Application Career Options level 6 page ");
		  ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Employment Submit Application Career Options level 6 page");
		  MoveToElement(btn_next);  
			  
		  
}
}

public void Validate_prev_step_btn_in_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_prev_step_btn_in_l6_AH")) 
	{
		
		Validate_Next_step_btn_in_l5_AH( "Validate_Next_step_btn_in_l5_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip);
		
		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
	
		 By Lang_skills=By.xpath("//span[@class='h4'][contains(text(),'Language Skills')]");
		 
		  Element_isdisplayed(btn_prev);
		  MoveToElement(btn_prev);
		  Log.info("Previous step button is displayed successfully in Employment Submit Application Career Options level 6 page ");
		  ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Employment Submit Application Career Options level 6 page");
		  click(btn_prev);
		  Thread.sleep(200);
		  Log.info("Successfully clicked on Previous step button in Employment Submit Application Career Options level 6 page ");
		  ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Previous step button in Employment Submit Application Career Options level 6 page ");
		
		  Element_isdisplayed(Lang_skills);
		  String LK=driver.findElement(Lang_skills).getText().replace("\n", " ");
		  Assert.assertEquals(LK.toUpperCase().trim(), "Language Skills".toUpperCase().trim(), "Language Skills text in Submit Application Language Skills level 5 page not validated");
		  Log.info(LK+" text successfully displayed and navigated to Submit Application Language Skills level 5 page");
		  ExtentTestManager.getTest().log(Status.PASS, LK+" text successfully displayed and navigated to Submit Application Language Skills level 5 page");
				 

		  		  
		  
		  
}
}

public void Validate_next_btn_byipallfields_l6_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_next_btn_byipallfields_l6_AH")) 
	{

		Validate_slt_considerfor_chkbxs_l6_AH( "Validate_slt_considerfor_chkbxs_l6_AH",  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip , CB_ip, Worktime_ip, consider_chkbx_ip);
		
		
		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
	 
//		 By Full_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[9]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]");
//		  By Part_time=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[9]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[2]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[2]");
//		  By Consider_for_GF=By.xpath("//label[@for='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0']");
//		  By Consider_for_GF_cb=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor_0");
		  By Clb_loc=By.xpath("//td[contains(text(),'Club Locations:')]");
		  By Car_opp=By.xpath("//td[contains(text(),'Career Opportunities:')]");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentNo");
		  By EOE=By.xpath("//span[contains(text(),'Equal Opportunity Employment')]");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		  By Date=By.id("ctl00_MainContent_ApplicantCareerOpportunities_TextBoxDateAvailable");
		  By If_yes_text=By.id("ctl00_MainContent_ApplicantCareerOpportunities_LabelPriorEmploymentYesPrompt");
		  By Full_time_chkbx=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT_0");
		  By Part_time_chkbx=By.id("ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListFTandPT_1");

		  By chceck_boxes=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor']//tbody//tr//td/input");
		  By chceck_boxes_labels=By.xpath("//table[@id='ctl00_MainContent_ApplicantCareerOpportunities_CheckBoxListJobsAppliedFor']//tbody//tr//td/label");
	
		  
			 
		  Element_isdisplayed(Date);
		  Log.info("Date Available to Begin: input box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Date Available to Begin: input box is successfully displayed in Employment Submit Application Career Options level 6 page");
		  click(If_yes_text);
		  
		  input(Date, Date_ip);
		  Log.info("Date: "+Date_ip+" is entered successfully in Date Available to Begin input box in Employment Submit Application Career Options level 6 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Date: "+Date_ip+"  is entered successfully in Date Available to Begin input box in Employment Submit Application Career Options level 6 page");
		 Thread.sleep(500);
		 
		  if (radiobtn_ip.trim().equalsIgnoreCase("Yes")) {
			  
			  ip_in_RQ_sec_l6_AH( "ip_in_RQ_sec_l6_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip);

		  }
		  
		  else if(radiobtn_ip.trim().equalsIgnoreCase("No")) {
			  
			  Element_isdisplayed(No_rdobtn);
			  
			  Assert.assertTrue(driver.findElement(No_rdobtn).isSelected(), "Are you now or have you ever been employed with us before? No radio button is by default not selected in Employment Submit Application Career Options level 6 page");  
			  Log.info("Are you now or have you ever been employed with us before? No radio button is successfully displayed and by default selected in Employment Submit Application Career Options level 6 page");
			  ExtentTestManager.getTest().log(Status.PASS,"Are you now or have you ever been employed with us before? No radio button is successfully displayed  and by default selected in Employment Submit Application Career Options level 6 page");
				  
//			  Thread.sleep(200);
//				 Element_isdisplayed(If_yes_text);
//				 String txt=driver.findElement(If_yes_text).getText().replace("\n", " ");
//				 Assert.assertEquals(txt.toUpperCase().trim(), Input.toUpperCase().trim(), Input+" text in Employment Submit Application Career Options level 6 page not validated");
//				 Log.info(txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
//				 ExtentTestManager.getTest().log(Status.PASS, txt+" text successfully displayed and validated in Employment Submit Application Career Options level 6 page");
				  
		}
		  
		  else {
				throw new Exception("Invalid input of 'Are you now or have you ever been employed with us before? No radio button' "+radiobtn_ip.trim()+" in Employment Submit Application Career Options level 6 page ");
			}
		  
		  
		  Element_isdisplayed(btn_next);
		  Log.info("Next step button is displayed successfully in Employment Submit Application Career Options level 6 page ");
		  ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Employment Submit Application Career Options level 6 page");
		  MoveToElement(btn_next); 
		  
		  click(btn_next);
		  Thread.sleep(500);
		  Log.info("Successfully clicked on Next step button in Employment Submit Application Career Options level 6 page ");
		  ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Next step button in Employment Submit Application Career Options level 6 page ");
		

		  Element_isdisplayed(EOE);
		  String EoE_txt=driver.findElement(EOE).getText().replace("\n", " ");
		  Assert.assertEquals(EoE_txt.toUpperCase().trim(), "Equal Opportunity Employment".toUpperCase().trim(), "Equal Opportunity Employment text in Submit Application Equal Opportunity Employment level 7 page not validated");
		  Log.info(EoE_txt+" text successfully displayed and navigated to Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS, EoE_txt+" text successfully displayed and navigated to Submit Application Equal Opportunity Employment level 7 page");
				 

		  
}
}

public void Validate_paras_in_l7_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Paragraph_ips) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_paras_in_l7_AH")) 
	{
	
		Validate_next_btn_byipallfields_l6_AH( "Validate_next_btn_byipallfields_l6_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip);

		 By paras=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[11]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]");
		  By yes_rdobtn=By.id("ctl00_MainContent_ApplicantCareerOpportunities_RadioButtonListPriorEmploymentYes");
		
		  Element_isdisplayed(paras);
		  String para_txt=driver.findElement(paras).getText().replace("\n", " ");
		  Assert.assertEquals(para_txt.toUpperCase().trim(), Paragraph_ips.toUpperCase().trim(), Paragraph_ips.trim()+" text of First two paragraphs in Submit Application Equal Opportunity Employment level 7 page not validated");
		  Log.info(para_txt+" First two paragraphs successfully displayed and Validated in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS, para_txt+" First two paragraphs successfully displayed and Validated in Submit Application Equal Opportunity Employment level 7 page");
				
		
	}}

public void Validate_rdobtns_in_l7_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_rdobtns_in_l7_AH")) 
	{
	
		Validate_next_btn_byipallfields_l6_AH( "Validate_next_btn_byipallfields_l6_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip);

		
		  By Yes_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_0");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_1");
		
		  
		  Element_isdisplayed(Yes_rdobtn);
//		  String para_txt=driver.findElement(paras).getText().replace("\n", " ");
//		  Assert.assertEquals(para_txt.toUpperCase().trim(), Paragraph_ips.toUpperCase().trim(), Paragraph_ips.trim()+" text of First two paragraphs in Submit Application Equal Opportunity Employment level 7 page not validated");
		  Log.info("Yes radio button of 'Do you wish to complete this form?' successfully displayed in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS, "Yes radio button of 'Do you wish to complete this form?' successfully displayed in Submit Application Equal Opportunity Employment level 7 page");
				 
		  Element_isdisplayed(No_rdobtn);
		  Log.info("No radio button of 'Do you wish to complete this form?' successfully displayed in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS, "No radio button of 'Do you wish to complete this form?' successfully displayed in Submit Application Equal Opportunity Employment level 7 page");
			
	
	
	}
	}

public void Validate_all_form_sec_in_l7_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_form_sec_in_l7_AH")) 
	{
	
		Validate_next_btn_byipallfields_l6_AH( "Validate_next_btn_byipallfields_l6_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip);

		
		  By Yes_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_0");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_1");
		  By Gender_dd=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_DropDownListGender");
		  By RaceEthnicity_dd=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_DropDownListRaceEthnicity");
		  By Emp_details_paragraphs=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantEqualOpportunityEmployment_trEEODetail']/td[1]/div[1]/div[1]/div[3]/div[1]	");
		
		  Element_isdisplayed(Yes_rdobtn);
//		  String para_txt=driver.findElement(paras).getText().replace("\n", " ");
//		  Assert.assertEquals(para_txt.toUpperCase().trim(), Paragraph_ips.toUpperCase().trim(), Paragraph_ips.trim()+" text of First two paragraphs in Submit Application Equal Opportunity Employment level 7 page not validated");
		  	 
//		  Element_isdisplayed(No_rdobtn);
//		  Log.info("No radio of 'Do you wish to complete this form?' successfully displayed in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS, "No radio of 'Do you wish to complete this form?' successfully displayed in Submit Application Equal Opportunity Employment level 7 page");
//			
		  Assert.assertTrue(driver.findElement(Yes_rdobtn).isSelected(), "Yes radio button of 'Do you wish to complete this form?'");
		  Log.info("Yes radio button of 'Do you wish to complete this form?' successfully displayed and by default selected in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS, "Yes radio button of 'Do you wish to complete this form?' successfully displayed and by default selected in Submit Application Equal Opportunity Employment level 7 page");
		  
		  Element_isdisplayed(Gender_dd);
		  Log.info("What is your Gender? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What is your Gender? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
		  
		  Element_isdisplayed(RaceEthnicity_dd);
		  Log.info("What is your Race / Ethnic Origin? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What is your Race / Ethnic Origin? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
		  
		  Element_isdisplayed(Emp_details_paragraphs);
		  String paragraphs=driver.findElement(Emp_details_paragraphs).getText().trim();
		  MoveToElement(Emp_details_paragraphs);
		  Log.info("Employee details paragraphs as follows are successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Employee details paragraphs as follows are successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
		  Log.info(paragraphs);
		  ExtentTestManager.getTest().log(Status.PASS,paragraphs);
	
	
	}
	}

public void Validate_all_options_of_Gender_dd_in_l7_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_options_of_Gender_dd_in_l7_AH")) 
	{
	
		Validate_next_btn_byipallfields_l6_AH( "Validate_next_btn_byipallfields_l6_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip);

	
		  By Yes_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_0");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_1");
		  By Gender_dd=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_DropDownListGender");
		  By RaceEthnicity_dd=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_DropDownListRaceEthnicity");
		  By Emp_details_paragraphs=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantEqualOpportunityEmployment_trEEODetail']/td[1]/div[1]/div[1]/div[3]/div[1]	");
		
//		  Element_isdisplayed(Yes_rdobtn);
//		  String para_txt=driver.findElement(paras).getText().replace("\n", " ");
//		  Assert.assertEquals(para_txt.toUpperCase().trim(), Paragraph_ips.toUpperCase().trim(), Paragraph_ips.trim()+" text of First two paragraphs in Submit Application Equal Opportunity Employment level 7 page not validated");
		  	 
//		  Element_isdisplayed(No_rdobtn);
//		  Log.info("No radio of 'Do you wish to complete this form?' successfully displayed in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS, "No radio of 'Do you wish to complete this form?' successfully displayed in Submit Application Equal Opportunity Employment level 7 page");
//			
//		  Assert.assertTrue(driver.findElement(Yes_rdobtn).isSelected(), "Yes radio button of 'Do you wish to complete this form?'");
//		  Log.info("Yes radio button of 'Do you wish to complete this form?' successfully displayed and by default selected in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS, "Yes radio button of 'Do you wish to complete this form?' successfully displayed and by default selected in Submit Application Equal Opportunity Employment level 7 page");
//		  
		  Element_isdisplayed(Gender_dd);
		  Log.info("What is your Gender? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What is your Gender? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
		  MoveToElement(Gender_dd);
//		  Element_isdisplayed(RaceEthnicity_dd);
//		  Log.info("What is your Race / Ethnic Origin? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"What is your Race / Ethnic Origin? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  
//		  Element_isdisplayed(Emp_details_paragraphs);
//		  String paragraphs=driver.findElement(Emp_details_paragraphs).getText().trim();
//		  MoveToElement(Emp_details_paragraphs);
//		  Log.info("Employee details paragraphs as follows are successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Employee details paragraphs as follows are successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  Log.info(paragraphs);
//		  ExtentTestManager.getTest().log(Status.PASS,paragraphs);
//	
	

			 String[] Gender_dd_ip_values=Gender_ip.split(",");

				
			 Select select = new Select(driver.findElement(Gender_dd));  
			 
			 String default_value=select.getFirstSelectedOption().getText();
			 Assert.assertEquals(default_value.toUpperCase().trim(), Gender_dd_ip_values[0].toUpperCase().trim(), default_value+" default option of 'What is your Gender?' dropdown in Employment Submit Application Equal Opportunity Employment level 7 page not validated");
			 ExtentTestManager.getTest().log(Status.PASS, default_value+" option of 'What is your Gender?' dropdown by default selected successfully in Employment Submit Application Equal Opportunity Employment level 7 page");
			 Log.info(default_value+" option of 'What is your Gender?' dropdown by default selected successfully in Employment Submit Application Equal Opportunity Employment level 7 page");
		 
			 int count=0;
			 List<WebElement> options = select.getOptions();  
			 
			 ArrayList<String> mylist = new ArrayList<String>();
			 
			 for(WebElement we:options)  
			 	{  
				 
				 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
			 	}
			 	String delim = ",";
		        String res = String.join(delim, mylist);
				 
			  for (int i=0; i<Gender_dd_ip_values.length; i++)
			  	{
				  
				  if(res.trim().toUpperCase().contains(Gender_dd_ip_values[i].trim().toUpperCase()))
				  	{
					  count++;
					  Log.info(Gender_dd_ip_values[i].trim()+" value matched");
					  ExtentTestManager.getTest().log(Status.PASS, Gender_dd_ip_values[i].trim()+" value matched");
					  
				  	}
				  else
				  {
					  
					  Log.error(Gender_dd_ip_values[i].trim()+" value not matched with the values in 'What is your Gender?' dropdown list"); 
					  ExtentTestManager.getTest().log(Status.FAIL, Gender_dd_ip_values[i].trim()+" value not matched with the values in 'What is your Gender?' dropdown list");
					  
					 
					  }
				  
				  if(Gender_dd_ip_values.length == count) break;
				  
			  		}	 
			
			   if (Gender_dd_ip_values.length == count &&  mylist.size()==Gender_dd_ip_values.length) 
			    {	
				  
				   	Log.info("All values matched successfully in the 'What is your Gender?' dropdown as Expected");
			        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the 'What is your Gender?' dropdown as Expected");

			    } else 
			    {	
			    	Log.error("All values not matched successfully in the 'What is your Gender?' dropdown. Expected dropdown list [ "+Gender_ip +" ] Actual dropdown list [ "+res+" ]");
		        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the 'What is your Gender?' dropdown. Expected dropdown list [ "+Gender_ip +" ] Actual dropdown list [ "+res+" ]");
		        	throw new Exception("All values not matched successfully in the 'What is your Gender?' dropdown");
			    }

		  
	}
	}


public void Validate_all_options_of_RE_dd_in_l7_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String RaceEthnicity_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_all_options_of_RE_dd_in_l7_AH")) 
	{
	
		Validate_next_btn_byipallfields_l6_AH( "Validate_next_btn_byipallfields_l6_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip);

	
	
		  By Yes_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_0");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_1");
		  By Gender_dd=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_DropDownListGender");
		  By RaceEthnicity_dd=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_DropDownListRaceEthnicity");
		  By Emp_details_paragraphs=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantEqualOpportunityEmployment_trEEODetail']/td[1]/div[1]/div[1]/div[3]/div[1]	");
		
//		  Element_isdisplayed(Yes_rdobtn);
//		  String para_txt=driver.findElement(paras).getText().replace("\n", " ");
//		  Assert.assertEquals(para_txt.toUpperCase().trim(), Paragraph_ips.toUpperCase().trim(), Paragraph_ips.trim()+" text of First two paragraphs in Submit Application Equal Opportunity Employment level 7 page not validated");
		  	 
//		  Element_isdisplayed(No_rdobtn);
//		  Log.info("No radio of 'Do you wish to complete this form?' successfully displayed in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS, "No radio of 'Do you wish to complete this form?' successfully displayed in Submit Application Equal Opportunity Employment level 7 page");
//			
//		  Assert.assertTrue(driver.findElement(Yes_rdobtn).isSelected(), "Yes radio button of 'Do you wish to complete this form?'");
//		  Log.info("Yes radio button of 'Do you wish to complete this form?' successfully displayed and by default selected in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS, "Yes radio button of 'Do you wish to complete this form?' successfully displayed and by default selected in Submit Application Equal Opportunity Employment level 7 page");
//		  
//		  Element_isdisplayed(Gender_dd);
//		  Log.info("What is your Gender? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"What is your Gender? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
		 
		  Element_isdisplayed(RaceEthnicity_dd);
		  Log.info("What is your Race / Ethnic Origin? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What is your Race / Ethnic Origin? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
		   MoveToElement(RaceEthnicity_dd);
//		  Element_isdisplayed(Emp_details_paragraphs);
//		  String paragraphs=driver.findElement(Emp_details_paragraphs).getText().trim();
//		  MoveToElement(Emp_details_paragraphs);
//		  Log.info("Employee details paragraphs as follows are successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Employee details paragraphs as follows are successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  Log.info(paragraphs);
//		  ExtentTestManager.getTest().log(Status.PASS,paragraphs);
//	
	

			 String[] RaceEthnicity_ip_values=RaceEthnicity_ip.split(",");

				
			 Select select = new Select(driver.findElement(RaceEthnicity_dd));  
			 
			 String default_value=select.getFirstSelectedOption().getText();
			 Assert.assertEquals(default_value.toUpperCase().trim(), RaceEthnicity_ip_values[0].toUpperCase().trim(), default_value+" default option of 'What is your Race / Ethnic Origin?' dropdown in Employment Submit Application Equal Opportunity Employment level 7 page not validated");
			 ExtentTestManager.getTest().log(Status.PASS, default_value+" option of 'What is your Race / Ethnic Origin?' dropdown by default selected successfully in Employment Submit Application Equal Opportunity Employment level 7 page");
			 Log.info(default_value+" option of 'What is your Race / Ethnic Origin?' dropdown by default selected successfully in Employment Submit Application Equal Opportunity Employment level 7 page");
		 
			 int count=0;
			 List<WebElement> options = select.getOptions();  
			 
			 ArrayList<String> mylist = new ArrayList<String>();
			 
			 for(WebElement we:options)  
			 	{  
				 
				 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
			 	}
			 	String delim = ",";
		        String res = String.join(delim, mylist);
				 
			  for (int i=0; i<RaceEthnicity_ip_values.length; i++)
			  	{
				  
				  if(res.trim().toUpperCase().contains(RaceEthnicity_ip_values[i].trim().toUpperCase()))
				  	{
					  count++;
					  Log.info(RaceEthnicity_ip_values[i].trim()+" value matched");
					  ExtentTestManager.getTest().log(Status.PASS, RaceEthnicity_ip_values[i].trim()+" value matched");
					  
				  	}
				  else
				  {
					  
					  Log.error(RaceEthnicity_ip_values[i].trim()+" value not matched with the values in 'What is your Race / Ethnic Origin?' dropdown list"); 
					  ExtentTestManager.getTest().log(Status.FAIL, RaceEthnicity_ip_values[i].trim()+" value not matched with the values in 'What is your Race / Ethnic Origin?' dropdown list");
					  
					 
					  }
				  
			  		}	 
			
			   if (RaceEthnicity_ip_values.length == count &&  mylist.size()==RaceEthnicity_ip_values.length) 
			    {	
				  
				   	Log.info("All values matched successfully in the 'What is your Race / Ethnic Origin?' dropdown as Expected");
			        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the 'What is your Race / Ethnic Origin?' dropdown as Expected");

			    } else 
			    {	
			    	Log.error("All values not matched successfully in the 'What is your Race / Ethnic Origin?' dropdown. Expected dropdown list [ "+RaceEthnicity_ip_values +" ] Actual dropdown list [ "+res+" ]");
		        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the 'What is your Race / Ethnic Origin?' dropdown. Expected dropdown list [ "+RaceEthnicity_ip_values +" ] Actual dropdown list [ "+res+" ]");
		        	throw new Exception("All values not matched successfully in the 'What is your Race / Ethnic Origin?' dropdown");
			    }

		  
	}
	}

public void Validate_EOE_details_paras_in_l7_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Paragraph_ips) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_EOE_details_paras_in_l7_AH")) 
	{
	
		Validate_next_btn_byipallfields_l6_AH( "Validate_next_btn_byipallfields_l6_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip);

	
		  By Yes_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_0");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_1");
		  By Gender_dd=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_DropDownListGender");
		  By RaceEthnicity_dd=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_DropDownListRaceEthnicity");
		  By Emp_details_paragraphs=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantEqualOpportunityEmployment_trEEODetail']/td[1]/div[1]/div[1]/div[3]/div[1]	");
		
		  Element_isdisplayed(Yes_rdobtn);
//		  String para_txt=driver.findElement(paras).getText().replace("\n", " ");
//		  Assert.assertEquals(para_txt.toUpperCase().trim(), Paragraph_ips.toUpperCase().trim(), Paragraph_ips.trim()+" text of First two paragraphs in Submit Application Equal Opportunity Employment level 7 page not validated");
		  	 
//		  Element_isdisplayed(No_rdobtn);
//		  Log.info("No radio of 'Do you wish to complete this form?' successfully displayed in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS, "No radio of 'Do you wish to complete this form?' successfully displayed in Submit Application Equal Opportunity Employment level 7 page");
//			Element_isdisplayed(Yes_rdobtn);
		  Assert.assertTrue(driver.findElement(Yes_rdobtn).isSelected(), "Yes radio button of 'Do you wish to complete this form?' is not selected");
		  Log.info("Yes radio button of 'Do you wish to complete this form?' successfully displayed and by default selected in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS, "Yes radio button of 'Do you wish to complete this form?' successfully displayed and by default selected in Submit Application Equal Opportunity Employment level 7 page");
		  
//		  Element_isdisplayed(Gender_dd);
//		  Log.info("What is your Gender? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"What is your Gender? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  
//		  Element_isdisplayed(RaceEthnicity_dd);
//		  Log.info("What is your Race / Ethnic Origin? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"What is your Race / Ethnic Origin? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  
		  Element_isdisplayed(Emp_details_paragraphs);
		  String paragraphs=driver.findElement(Emp_details_paragraphs).getText().trim();
		  String paras=paragraphs.replace("\n", " ").trim();
		  MoveToElement(Emp_details_paragraphs);
		  Assert.assertEquals(paras.toUpperCase().trim(), Paragraph_ips.toUpperCase().trim(), " EOE details text of form paragraphs in Submit Application Equal Opportunity Employment level 7 page not validated");
//		  Log.info(para_txt+" First two paragraphs successfully displayed and Validated in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS, para_txt+" First two paragraphs successfully displayed and Validated in Submit Application Equal Opportunity Employment level 7 page");
			
		  Log.info("Employee details paragraphs as follows are successfully displayed and validated under form section in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Employee details paragraphs as follows are successfully displayed and validated under form section in Submit Application Equal Opportunity Employment level 7 page");
		  Log.info(paragraphs);
		  ExtentTestManager.getTest().log(Status.PASS,paragraphs);
	
	
	}
	}

public void Validate_No_rdobtnof_form_sec_in_l7_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_No_rdobtnof_form_sec_in_l7_AH")) 
	{
	
		Validate_next_btn_byipallfields_l6_AH( "Validate_next_btn_byipallfields_l6_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip);

		
		  By Yes_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_0");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_1");
		  By Gender_dd=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_DropDownListGender");
		  By RaceEthnicity_dd=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_DropDownListRaceEthnicity");
		  By Emp_details_paragraphs=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantEqualOpportunityEmployment_trEEODetail']/td[1]/div[1]/div[1]/div[3]/div[1]");
		
//		  Element_isdisplayed(Yes_rdobtn);
//		  String para_txt=driver.findElement(paras).getText().replace("\n", " ");
//		  Assert.assertEquals(para_txt.toUpperCase().trim(), Paragraph_ips.toUpperCase().trim(), Paragraph_ips.trim()+" text of First two paragraphs in Submit Application Equal Opportunity Employment level 7 page not validated");
		  	 
		  Element_isdisplayed(No_rdobtn);
		  click(No_rdobtn);
		  Log.info("No radio of 'Do you wish to complete this form?' successfully displayed and selected in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS, "No radio of 'Do you wish to complete this form?' successfully displayed and selected in Submit Application Equal Opportunity Employment level 7 page");
		  Thread.sleep(500);	
		  Assert.assertFalse(driver.findElement(Gender_dd).isDisplayed(), "What is your Gender? dropdown is not collapsed/disappeared in Submit Application Equal Opportunity Employment level 7 page");
		  Log.info("What is your Gender? dropdown is successfully collapsed/disappeared in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS, "What is your Gender? dropdown is successfully collapsed/disappeared in Submit Application Equal Opportunity Employment level 7 page");
		  
//		  Element_isdisplayed(Gender_dd);
//		  Log.info("What is your Gender? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"What is your Gender? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  
		  Assert.assertFalse(driver.findElement(RaceEthnicity_dd).isDisplayed(), "What is your Race / Ethnic Origin? dropdown is not collapsed/disappeared in Submit Application Equal Opportunity Employment level 7 page");
		  Log.info("What is your Race / Ethnic Origin? dropdown is successfully collapsed/disappeared in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS, "What is your Race / Ethnic Origin? dropdown is successfully collapsed/disappeared in Submit Application Equal Opportunity Employment level 7 page");
		  
		  
//		  Element_isdisplayed(RaceEthnicity_dd);
//		  Log.info("What is your Race / Ethnic Origin? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"What is your Race / Ethnic Origin? dropdown is successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
		  
		  Assert.assertFalse(driver.findElement(Emp_details_paragraphs).isDisplayed(), "Employee details paragraphs is not collapsed/disappeared in Submit Application Equal Opportunity Employment level 7 page");
		  Log.info("Employee details paragraphs is successfully collapsed/disappeared in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS, "Employee details paragraphs is successfully collapsed/disappeared in Submit Application Equal Opportunity Employment level 7 page");
		  
		  
//		  Element_isdisplayed(Emp_details_paragraphs);
//		  String paragraphs=driver.findElement(Emp_details_paragraphs).getText().trim();
//		  MoveToElement(Emp_details_paragraphs);
//		  Log.info("Employee details paragraphs as follows are successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Employee details paragraphs as follows are successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  Log.info(paragraphs);
//		  ExtentTestManager.getTest().log(Status.PASS,paragraphs);
	
	
	}
	}

public void Validate_prev_next_step_btns_in_l7_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_prev_next_step_btns_in_l7_AH")) 
	{
	
		Validate_next_btn_byipallfields_l6_AH( "Validate_next_btn_byipallfields_l6_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip);

		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		
		Element_isdisplayed(btn_prev);
		MoveToElement(btn_prev);
		Log.info("Previous step button is displayed successfully in Submit Application Equal Opportunity Employment level 7 page ");
		ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Submit Application Equal Opportunity Employment level 7 page");

		Element_isdisplayed(btn_next);
		Log.info("Next step button is displayed successfully in Submit Application Equal Opportunity Employment level 7 page ");
		ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Submit Application Equal Opportunity Employment level 7 page");
		MoveToElement(btn_next);
		
	
	}
	}

public void Validate_prev_step_btn_in_l7_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_prev_step_btn_in_l7_AH")) 
	{
	
		Validate_next_btn_byipallfields_l6_AH( "Validate_next_btn_byipallfields_l6_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip);

		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		
	
		By Car_op=By.xpath("//span[contains(text(),'Career Options')]");
	 		
		Element_isdisplayed(btn_prev);
		MoveToElement(btn_prev);
		click(btn_prev);
		Log.info("Successfully clicked on Previous step button in Submit Application Equal Opportunity Employment level 7 page ");
		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Previous step button in Submit Application Equal Opportunity Employment level 7 page");


		Thread.sleep(200);
		 Element_isdisplayed(Car_op);
		 String Car_op_txt=driver.findElement(Car_op).getText().replace("\n", " ");
		 Assert.assertEquals(Car_op_txt.toUpperCase().trim(), "Career Options".toUpperCase().trim(), "Career Options text in Employment Submit Application Career Options level 6 page not validated");
		 Log.info(Car_op_txt+" text successfully displayed and navigated to Employment Submit Application Career Options level 6 page");
		 ExtentTestManager.getTest().log(Status.PASS, Car_op_txt+" text successfully displayed and navigated to Employment Submit Application Career Options level 6 page");
		  
//		Element_isdisplayed(btn_next);
//		Log.info("Next step button is displayed successfully in Submit Application Equal Opportunity Employment level 7 page ");
//		ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Submit Application Equal Opportunity Employment level 7 page");
//		MoveToElement(btn_next);
		
	
	
	}
	}

public void Validate_Next_step_btn_in_l7_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Next_step_btn_in_l7_AH")) 
	{
	
		Validate_No_rdobtnof_form_sec_in_l7_AH( "Validate_No_rdobtnof_form_sec_in_l7_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip);

		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		
		
	
		By app_stmt=By.xpath("//span[contains(text(),'Applicant Statement')]");
	 		
		Element_isdisplayed(btn_next);
		MoveToElement(btn_next);
		click(btn_next);
		Log.info("Successfully clicked on Next step button in Submit Application Equal Opportunity Employment level 7 page ");
		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Next step button in Submit Application Equal Opportunity Employment level 7 page");


		Thread.sleep(200);
		 Element_isdisplayed(app_stmt);
		 String app_stmt_txt=driver.findElement(app_stmt).getText().replace("\n", " ");
		 Assert.assertEquals(app_stmt_txt.toUpperCase().trim(), "Applicant Statement".toUpperCase().trim(), "Applicant Statement text in Employment Submit Application Applicant Statement level 8 page not validated");
		 Log.info(app_stmt_txt+" text successfully displayed and navigated to Employment Submit Application Applicant Statement level 8 page");
		 ExtentTestManager.getTest().log(Status.PASS, app_stmt_txt+" text successfully displayed and navigated to Employment Submit Application Applicant Statement level 8 page");
		  
//		Element_isdisplayed(btn_next);
//		Log.info("Next step button is displayed successfully in Submit Application Equal Opportunity Employment level 7 page ");
//		ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Submit Application Equal Opportunity Employment level 7 page");
//		MoveToElement(btn_next);
		
	
	
	}
	}

public void Validate_Nav_to_l8_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Nav_to_l8_AH")) 
	{
	
		Validate_next_btn_byipallfields_l6_AH( "Validate_next_btn_byipallfields_l6_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip);

		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		
		
		 By app_stmt=By.xpath("//span[contains(text(),'Applicant Statement')]");
		 By Yes_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_0");
		  By No_rdobtn=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_RadioButtonListCompleteEEO_1");
		  By Gender_dd=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_DropDownListGender");
		  By RaceEthnicity_dd=By.id("ctl00_MainContent_ApplicantEqualOpportunityEmployment_DropDownListRaceEthnicity");
		  By Emp_details_paragraphs=By.xpath("//tbody/tr[@id='ctl00_MainContent_ApplicantEqualOpportunityEmployment_trEEODetail']/td[1]/div[1]/div[1]/div[3]/div[1]");
			
		  Element_isdisplayed(Yes_rdobtn);
		  Assert.assertTrue(driver.findElement(Yes_rdobtn).isSelected(), "Yes radio button of 'Do you wish to complete this form?' is not selected");
		  Log.info("Yes radio button of 'Do you wish to complete this form?' successfully displayed and by default selected in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS, "Yes radio button of 'Do you wish to complete this form?' successfully displayed and by default selected in Submit Application Equal Opportunity Employment level 7 page");
		  
		  
		  Element_isdisplayed(Gender_dd);
		  
		  Select gender_s = new Select(driver.findElement(Gender_dd));
		  gender_s.selectByVisibleText(Gender_ip.trim());
		  
		  Log.info("What is your Gender? dropdown is successfully displayed and selected : '"+Gender_ip.trim()+"' option under form section in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What is your Gender? dropdown is successfully displayed  and selected : '"+Gender_ip.trim()+"' option under form section in Submit Application Equal Opportunity Employment level 7 page");
		  
		  Thread.sleep(200);
		  Element_isdisplayed(RaceEthnicity_dd);
		  
		  Select RaceEthnicity_s = new Select(driver.findElement(RaceEthnicity_dd));
		  RaceEthnicity_s.selectByVisibleText(RaceEthnicity_ip.trim());
		  
		  Log.info("What is your Race / Ethnic Origin? dropdown is successfully displayed and selected : '"+RaceEthnicity_ip.trim()+"' option under form section in Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS,"What is your Race / Ethnic Origin? dropdown is successfully displayed and selected : '"+RaceEthnicity_ip.trim()+"' option under form section in Submit Application Equal Opportunity Employment level 7 page");
		  
		  
//		  Element_isdisplayed(Emp_details_paragraphs);
//		  String paragraphs=driver.findElement(Emp_details_paragraphs).getText().trim();
//		  MoveToElement(Emp_details_paragraphs);
//		  Log.info("Employee details paragraphs as follows are successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  ExtentTestManager.getTest().log(Status.PASS,"Employee details paragraphs as follows are successfully displayed under form section in Submit Application Equal Opportunity Employment level 7 page");
//		  Log.info(paragraphs);
//		  ExtentTestManager.getTest().log(Status.PASS,paragraphs);
	
		  
		  
		  
		Element_isdisplayed(btn_next);
		MoveToElement(btn_next);
		click(btn_next);
		Log.info("Successfully clicked on Next step button in Submit Application Equal Opportunity Employment level 7 page ");
		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Next step button in Submit Application Equal Opportunity Employment level 7 page");


		Thread.sleep(200);
		 Element_isdisplayed(app_stmt);
		 String app_stmt_txt=driver.findElement(app_stmt).getText().replace("\n", " ");
		 Assert.assertEquals(app_stmt_txt.toUpperCase().trim(), "Applicant Statement".toUpperCase().trim(), "Applicant Statement text in Employment Submit Application Applicant Statement level 8 page not validated");
		 Log.info(app_stmt_txt+" text successfully displayed and navigated to Employment Submit Application Applicant Statement level 8 page");
		 ExtentTestManager.getTest().log(Status.PASS, app_stmt_txt+" text successfully displayed and navigated to Employment Submit Application Applicant Statement level 8 page");
		
//		Element_isdisplayed(btn_next);
//		Log.info("Next step button is displayed successfully in Submit Application Equal Opportunity Employment level 7 page ");
//		ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Submit Application Equal Opportunity Employment level 7 page");
//		MoveToElement(btn_next);
		
	
	
	}
	}

public void Validate_AS_paras_in_l8_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip, String paragraphs_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_AS_paras_in_l8_AH")) 
	{
	
		Validate_Nav_to_l8_AH( "Validate_Nav_to_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);


		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		
		//		 By paragraphs=By.cssSelector("//div[@class='form-group row'][3]");
		 By paragraphs=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[12]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]/div[1]/p");
		  Thread.sleep(200);
		  List<WebElement> para_txt=driver.findElements(paragraphs);
		 
		  
		  ArrayList<String> mylist = new ArrayList<String>();
        
		 for (WebElement p:para_txt) {
			 if (!p.getText().isEmpty()) mylist.add(p.getText().replace("\n", " ").trim());	
		}
		 String delim = "";
	        String para = String.join(delim, mylist);
//		   para=driver.findElement(paragraphs).getText().replace("\n", " ").trim();
		  Assert.assertEquals(para.toUpperCase().trim(), paragraphs_ip.toUpperCase().trim(), "Applicant Statement details text in Employment Submit Application Applicant Statement level 8 page not validated");
//		  MoveToElement(paragraphs);
		  Log.info("Application Statement details text '"+para+"' is displayed and validated successfully in Employment Submit Application Applicant Statement level 8 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Application Statement details text '"+para+"' is displayed and validated successfully in Employment Submit Application Applicant Statement level 8 page");
		  
		
	}
	}

public void Validate_ackmnt_in_l8_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip, String paragraphs_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_ackmnt_in_l8_AH")) 
	{
	
		Validate_Nav_to_l8_AH( "Validate_Nav_to_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);


		By para=By.xpath("//div[@class='col-sm-12']/strong");
//		 By paragraphs=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[12]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]/div[1]/p");
		  Thread.sleep(200);
		  Element_isdisplayed(para);
		  MoveToElement(para);

//		  String date=
		  String paragraphs=driver.findElement(para).getText().replace("\n", " ").trim();

		  Assert.assertEquals(paragraphs.toUpperCase().trim(), paragraphs_ip.replace("Employment Application as of", "Employment Application as of  "+Get_todays_date()).toUpperCase().trim(), "Applicant Statement acknowledge text in Employment Submit Application Applicant Statement level 8 page not validated");

		  Log.info("Application Statement acknowledge text '"+paragraphs+"' is displayed and validated successfully in Employment Submit Application Applicant Statement level 8 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Application Statement acknowledge text '"+paragraphs+"' is displayed and validated successfully in Employment Submit Application Applicant Statement level 8 page");
		  
	}
	}

public void Validate_ip_in_Signedbyname_in_l8_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_ip_in_Signedbyname_in_l8_AH")) 
	{
	
		Validate_Nav_to_l8_AH( "Validate_Nav_to_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);

		By signedby=By.id("ctl00_MainContent_ApplicantAgreement_wwWebTextBoxSignedBy");
//		 By paragraphs=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[12]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]/div[1]/p");
		  Thread.sleep(200);
		  Element_isdisplayed(signedby);
		  MoveToElement(signedby);
		  String fullname=F_name.trim()+" "+L_name.trim();
		  input(signedby, fullname);
		  Log.info("Successfully entered the  full name: "+fullname+" in Applicant Statement signed by field in Employment Submit Application Applicant Statement level 8 page");
		  ExtentTestManager.getTest().log(Status.PASS,"Successfully entered the  full name: "+fullname+" in Applicant Statement signed by field in Employment Submit Application Applicant Statement level 8 page");

	}
	}

public void Validate_prev_next_step_btns_in_l8_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_prev_next_step_btns_in_l8_AH")) 
	{
	
		Validate_Nav_to_l8_AH( "Validate_Nav_to_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);

		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
		
		Element_isdisplayed(btn_prev);
		MoveToElement(btn_prev);
		Log.info("Previous step button is displayed successfully in Employment Submit Application Applicant Statement level 8 page");
		ExtentTestManager.getTest().log(Status.PASS, "Previous step button is displayed successfully in Employment Submit Application Applicant Statement level 8 page");


		Element_isdisplayed(btn_next);
		Log.info("Next step button is displayed successfully in Employment Submit Application Applicant Statement level 8 page ");
		ExtentTestManager.getTest().log(Status.PASS, "Next step button is displayed successfully in Employment Submit Application Applicant Statement level 8 page");
//		MoveToElement(btn_next);
		
		
	
	}
	}

public void Validate_prev_step_btn_in_l8_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_prev_step_btn_in_l8_AH")) 
	{
	
		Validate_Nav_to_l8_AH( "Validate_Nav_to_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);

		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
	
//		Validate_Navigation_to_l8("Validate_Navigation_to_l8", Text_input,  input_data,  pos_txt, jobs_title_ip,  clb_pos_content, job_short_des, url, Emp_app_ip_txt, How_hear_abt_us,  Radiobtn18YearsOld, F_name, L_name, email, Phone, Address, Zipcode, L2_txt, Edu_level_ip,  Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip, Worktime_ip,  Considerchkbox_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip , Gender_ip, RaceEthnicity_ip);
		
		By EOE=By.xpath("//span[contains(text(),'Equal Opportunity Employment')]");
		  
		Element_isdisplayed(btn_prev);
		MoveToElement(btn_prev);
		click(btn_prev);
		Log.info("Successfully clicked on Previous step button in Employment Submit Application Applicant Statement level 8 page");
		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Previous step button in Employment Submit Application Applicant Statement level 8 page");


		 Element_isdisplayed(EOE);
		  String EoE_txt=driver.findElement(EOE).getText().replace("\n", " ");
		  Assert.assertEquals(EoE_txt.toUpperCase().trim(), "Equal Opportunity Employment".toUpperCase().trim(), "Equal Opportunity Employment text in Submit Application Equal Opportunity Employment level 7 page not validated");
		  Log.info(EoE_txt+" text successfully displayed and navigated to Submit Application Equal Opportunity Employment level 7 page");
		  ExtentTestManager.getTest().log(Status.PASS, EoE_txt+" text successfully displayed and navigated to Submit Application Equal Opportunity Employment level 7 page");
				 
	}
	}

public void Validate_Next_btn_in_l8_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Next_btn_in_l8_AH")) 
	{
	
		Validate_ip_in_Signedbyname_in_l8_AH( "Validate_ip_in_Signedbyname_in_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);

		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
	
	
		By signedby=By.id("ctl00_MainContent_ApplicantAgreement_wwWebTextBoxSignedBy");
		 By ADRA=By.xpath("//span[contains(text(),'Arbitration and Dispute Resolution Agreement')]");
//		 By paragraphs=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[12]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]/div[1]/p");
		
		 	Element_isdisplayed(btn_next);
			MoveToElement(btn_next);
			click(btn_next);
			Log.info("Successfully clicked on Next step button in Employment Submit Application Applicant Statement level 8 page");
			ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Next step button in Employment Submit Application Applicant Statement level 8 page");


			Thread.sleep(200);
			 Element_isdisplayed(ADRA);
			 String ADRA_txt=driver.findElement(ADRA).getText().replace("\n", " ");
			 Assert.assertEquals(ADRA_txt.toUpperCase().trim(), "Arbitration and Dispute Resolution Agreement".toUpperCase().trim(), "Arbitration and Dispute Resolution Agreement text in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page not validated");
			 Log.info(ADRA_txt+" text successfully displayed and navigated to Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, ADRA_txt+" text successfully displayed and navigated to Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			  
		  
	}
	}

public void Validate_heading_in_l9_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip, String heading_l9) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_heading_in_l9_AH")) 
	{
	
		Validate_Next_btn_in_l8_AH( "Validate_Next_btn_in_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);

		By signedby=By.id("ctl00_MainContent_ApplicantAgreement_wwWebTextBoxSignedBy");
		 By heading=By.xpath("//body/form[@id='aspnetForm']/div[3]/div[2]/div[1]/div[1]/div[13]/div[1]/div[1]");
//		 By paragraphs=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[12]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]/div[1]/p");
		

			 Thread.sleep(200);
			 Element_isdisplayed(heading);
			 String ADRA_txt=driver.findElement(heading).getText().replace("\n", " ");
			 Assert.assertEquals(ADRA_txt.toUpperCase().trim(), heading_l9.toUpperCase().trim(), heading_l9+" heading in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page not validated");
			 Log.info(ADRA_txt+" heading successfully displayed and navigated to Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, ADRA_txt+" heading successfully displayed and navigated to Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			  
		  
	}
	}



public void Validate_Rules_procedures_in_l9_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip, String R_a_P_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Rules_procedures_in_l9_AH")) 
	{
	
		Validate_Next_btn_in_l8_AH( "Validate_Next_btn_in_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);

		
		By signedby=By.id("ctl00_MainContent_ApplicantAgreement_wwWebTextBoxSignedBy");
		 By Rules_and_procedures_x=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[13]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]");
//		 By paragraphs=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[12]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]/div[1]/p");
		

			 Thread.sleep(200);
			 Element_isdisplayed(Rules_and_procedures_x);
			 String RAP_txt=driver.findElement(Rules_and_procedures_x).getText().replace("\n", " ");
			 Assert.assertEquals(RAP_txt.toUpperCase().trim(), R_a_P_ip.toUpperCase().trim(), R_a_P_ip+" details in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page not validated");
			 Log.info(" All RULES AND PROCEDURES "+RAP_txt+" details successfully displayed and navigated to Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, " All RULES AND PROCEDURES "+RAP_txt+" details successfully displayed and navigated to Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			  
		  
	}
	}

public void Validate_ip_in_prtname_dateandipadd_in_l9_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip, String Ipaddress_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_ip_in_prtname_dateandipadd_in_l9_AH")) 
	{
	
		Validate_Next_btn_in_l8_AH( "Validate_Next_btn_in_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);


//		Validate_Next_button_in_l8("Validate_Next_button_in_l8", Text_input,  input_data,  pos_txt, jobs_title_ip,  clb_pos_content, job_short_des, url, Emp_app_ip_txt, How_hear_abt_us,  Radiobtn18YearsOld, F_name, L_name, email, Phone, Address, Zipcode, L2_txt, Edu_level_ip,  Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip, Worktime_ip,  Considerchkbox_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip , Gender_ip, RaceEthnicity_ip);
//		 By signedby=By.id("ctl00_MainContent_ApplicantAgreement_wwWebTextBoxSignedBy");
//		 By Rules_and_procedures_x=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[13]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]");
//		 By paragraphs=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[12]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]/div[1]/p");
		 By printname=By.id("ctl00_MainContent_ApplicantArbitration_wwWebTextBoxSignedBy");
		 By date=By.id("ctl00_MainContent_ApplicantArbitration_LabelSignatureDate");
		 By IPaddress=By.id("ctl00_MainContent_ApplicantArbitration_LabelIPAddress");
		 String fullname=F_name.trim()+" "+L_name.trim();
		 
		 	Thread.sleep(200);
		 	Element_isdisplayed(printname);
		 	MoveToElement(printname);
		 	input(printname, fullname);
		 	Log.info("Print Name: "+fullname+" successfully entered/inputted in Print name field in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Print Name: "+fullname+" successfully entered/inputted in Print name field in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			  
		 
			 Element_isdisplayed(date);
			 String date_txt=driver.findElement(date).getText().replace("\n", " ");
			 Assert.assertEquals(date_txt.toUpperCase().trim(), Get_todays_date().replace(".", "").toUpperCase().trim(), "Date: "+Get_todays_date()+"  in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page not validated");
			 Log.info("Date: "+date_txt+" successfully displayed and validated in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Date:"+date_txt+" successfully displayed and validated in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			  
			 Element_isdisplayed(IPaddress);
			 String IPaddress_txt=driver.findElement(IPaddress).getText().replace("\n", " ");
			 Assert.assertEquals(IPaddress_txt.toUpperCase().trim(), Ipaddress_ip.toUpperCase().trim(), "IP Address: "+Ipaddress_ip+"  in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page not validated");
			 Log.info(" IP Address: "+IPaddress_txt+" details successfully displayed and validated in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, " IP Address: "+IPaddress_txt+" details successfully displayed and validated in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			  
		  
	}
	}

public void Validate_Robert_Bryant_Sign_in_l9_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip, String para_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Robert_Bryant_Sign_in_l9_AH")) 
	{
	
		Validate_Next_btn_in_l8_AH( "Validate_Next_btn_in_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);


		By para=By.xpath("//td[contains(text(),'Fitness International, LLC, agrees to follow this ')]");
		 By Sign_img=By.id("ctl00_MainContent_ApplicantArbitration_ImageLAFitnessSignature");
		 By Signature=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[13]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/div[1]/table[1]/tbody[1]/tr[3]/td[1]");
		
		 	String[] texts=para_ip.split("--");
			 Thread.sleep(200);
			 Element_isdisplayed(para);
			 
			 MoveToElement(para);
//			 MoveToElement(para);
			 String txt=driver.findElement(para).getText().replace("\n", " ");
			 Assert.assertEquals(txt.toUpperCase().trim(), texts[0].toUpperCase().trim(), texts[0]+" Procedures text in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page not validated");
			 Log.info("Procedures text "+txt+" details successfully displayed and validated in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Procedures text "+txt+" details successfully displayed and validated in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			  
			 Assert.assertTrue(driver.findElement(Sign_img).isDisplayed(), "Robert Bryant Signature image is not displayed in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 Log.info("Robert Bryant Signature image is successfully displayed in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Robert Bryant Signature image is successfully displayed in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			  
			 Element_isdisplayed(Signature);
			 String Signature_txt=driver.findElement(Signature).getText().replace("\n", " ");
			 Assert.assertEquals(Signature_txt.toUpperCase().trim(), texts[1].toUpperCase().trim(), texts[1]+" Robert Bryant Signature text in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page not validated");
			 Log.info("Robert Bryant Signature text "+Signature_txt+" details successfully displayed and validated in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Robert Bryant Signature text "+Signature_txt+" details successfully displayed and validated in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			  
	}
	}

public void Validate_Iagree_textandbtn_in_l9_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip, String Iagree_text_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Iagree_textandbtn_in_l9_AH")) 
	{
	
		Validate_Next_btn_in_l8_AH( "Validate_Next_btn_in_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);


		//		 By para=By.xpath("//td[contains(text(),'Fitness International, LLC, agrees to follow this ')]");
		 By Iagree_text=By.id("ctl00_MainContent_LabelSubmitPrompt");
		 By Iagree_btn=By.id("ctl00_MainContent_ButtonValidateAll");
//		 By Signature=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[13]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[2]/div[1]/table[1]/tbody[1]/tr[3]/td[1]");
		
//		 	String[] texts=para_ip.split("--");
			 Thread.sleep(200);
			 Element_isdisplayed(Iagree_text);
			 
//			 MoveToElement(para);
			 MoveToElement(Iagree_text);
			 String txt=driver.findElement(Iagree_text).getText().replace("\n", " ");
			 Assert.assertEquals(txt.toUpperCase().trim(), Iagree_text_ip.toUpperCase().trim(), Iagree_text_ip+" text in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page not validated");
			 Log.info(txt+" text successfully displayed and validated in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, " text successfully displayed and validated in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
//			  
//			 Assert.assertTrue(driver.findElement(Sign_img).isDisplayed(), "Robert Bryant Signature image is not displayed in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
//			 Log.info("Robert Bryant Signature image is successfully displayed in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
//			 ExtentTestManager.getTest().log(Status.PASS, "Robert Bryant Signature image is successfully displayed in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			  
			 Element_isdisplayed(Iagree_btn);
			 MoveToElement(Iagree_btn);
//			 String Signature_txt=driver.findElement(Signature).getText().replace("\n", " ");
//			 Assert.assertEquals(Signature_txt.toUpperCase().trim(), texts[1].toUpperCase().trim(), texts[1]+" Robert Bryant Signature text in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page not validated");
			 Log.info("I Agree button successfully displayed in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, "I Agree button successfully displayed in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			  
	}
	}

public void Validate_Prev_step_btn_in_l9_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Prev_step_btn_in_l9_AH")) 
	{
	
		Validate_Next_btn_in_l8_AH( "Validate_Next_btn_in_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);


		By btn_next = By.id("btn_next");
		By btn_prev = By.id("btn_prev");
	
	
//			 By ADRA=By.xpath("//span[contains(text(),'Arbitration and Dispute Resolution Agreement')]");
//			 By paragraphs=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[12]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]/div[1]/p");
			 By app_stmt=By.xpath("//span[contains(text(),'Applicant Statement')]");
			 
			 	Element_isdisplayed(btn_prev);
				MoveToElement(btn_prev);
				click(btn_prev);
				Log.info("Successfully clicked on Previous step button in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
				ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Previous step button in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");


				Thread.sleep(300);
				Thread.sleep(200);
				 Element_isdisplayed(app_stmt);
				 String app_stmt_txt=driver.findElement(app_stmt).getText().replace("\n", " ");
				 Assert.assertEquals(app_stmt_txt.toUpperCase().trim(), "Applicant Statement".toUpperCase().trim(), "Applicant Statement text in Employment Submit Application Applicant Statement level 8 page not validated");
				 Log.info(app_stmt_txt+" text successfully displayed and navigated to Employment Submit Application Applicant Statement level 8 page");
				 ExtentTestManager.getTest().log(Status.PASS, app_stmt_txt+" text successfully displayed and navigated to Employment Submit Application Applicant Statement level 8 page");
				  
			 
	}
	}

public void Validate_Iagreebtn_and_succ_submsn_in_l9_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Iagreebtn_and_succ_submsn_in_l9_AH")) 
	{
	
		Validate_Next_btn_in_l8_AH( "Validate_Next_btn_in_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);

		//		 By signedby=By.id("ctl00_MainContent_ApplicantAgreement_wwWebTextBoxSignedBy");
//		 By Rules_and_procedures_x=By.xpath("//body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[13]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]");
//		 By paragraphs=By.xpath("/html[1]/body[1]/form[1]/div[3]/div[2]/div[1]/div[1]/div[12]/div[1]/div[2]/div[1]/table[1]/tbody[1]/tr[1]/td[1]/div[1]/div[1]/div[1]/p");
		 By printname=By.id("ctl00_MainContent_ApplicantArbitration_wwWebTextBoxSignedBy");
//		 By date=By.id("ctl00_MainContent_ApplicantArbitration_LabelSignatureDate");
		 By Success_heading=By.xpath("//h1[contains(text(),'Your Submission was Successful')]");
		 By Iagree_btn=By.id("ctl00_MainContent_ButtonValidateAll");
		 String fullname=F_name.trim()+" "+L_name.trim();
		 
		 	Thread.sleep(200);
		 	Element_isdisplayed(printname);
		 	MoveToElement(printname);
		 	input(printname, fullname);
		 	Log.info("Print Name: "+fullname+" successfully entered/inputted in Print name field in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Print Name: "+fullname+" successfully entered/inputted in Print name field in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			  
			 Element_isdisplayed(Iagree_btn);
			 MoveToElement(Iagree_btn);
			 click(Iagree_btn);
			 Log.info("I Agree button successfully clicked in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, "I Agree button successfully clicked in Employment Submit Application Arbitration and Dispute Resolution Agreement level 9 page");
			 
			 Thread.sleep(2500);
//			 Thread.sleep(200);
			
			 Element_isdisplayed(Success_heading);
			 String Success_heading_txt=driver.findElement(Success_heading).getText().replace("\n", " ");
			 Assert.assertEquals(Success_heading_txt.toUpperCase().trim(), "Your Submission was Successful".toUpperCase().trim(), "Your Submission was Successful text not validated in Application Submission Successful final level page");
			 Log.info(Success_heading_txt+" text successfully displayed and navigated to Application Submission Successful final level page");
			 ExtentTestManager.getTest().log(Status.PASS, Success_heading_txt+" text successfully displayed and navigated to Application Submission Successful final level page");	
		  
	}

	}

public void Validate_Success_msg_in_final_page_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip, String msg_Txt_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Success_msg_in_final_page_AH")) 
	{
	
		Validate_Iagreebtn_and_succ_submsn_in_l9_AH( "Validate_Iagreebtn_and_succ_submsn_in_l9_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);

		 By printyourapp_btn=By.id("ctl00_MainContent_ApplicantSubmissionSuccess_LinkButtonApplicationPrint");
		 By print_link=By.xpath("//a[contains(text(),'Print')]");
		 By emp_app=By.xpath("//h1[contains(text(),'Employment Application')]");
		
		 By msg_table=By.id("ctl00_MainContent_ApplicantSubmissionSuccess_tableSubmissionSuccessful");
		 
		 Element_isdisplayed(msg_table);
		 String Success_txt=driver.findElement(msg_table).getText().replace("\n", " ");
		 Assert.assertEquals(Success_txt.replace("Print Your Application", "").toUpperCase().trim(), msg_Txt_ip.toUpperCase().trim(), "Your Submission Successful details: "+msg_Txt_ip+" not validated in Application Submission Successful final level page");
		 Log.info(Success_txt+" text successfully displayed and validated in Application Submission Successful final level page");
		 ExtentTestManager.getTest().log(Status.PASS, Success_txt+" text successfully displayed and validated in Application Submission Successful final level page");	
	  
		 Element_isdisplayed(printyourapp_btn);
		 Log.info("Print Your Application button successfully displayed in Application Submission Successful final level page");
		 ExtentTestManager.getTest().log(Status.PASS, "Print Your Application button successfully displayed in Application Submission Successful final level page");	
	  
//		 click(printyourapp_btn);
//		 Thread.sleep(1000);
		
//		 String parentWindow= driver.getWindowHandle();
//		 Set<String> allWindows = driver.getWindowHandles();
//		 for(String curWindow : allWindows){
//		     driver.switchTo().window(curWindow);
//		     if(driver.getTitle().equalsIgnoreCase("LA Fitness | Print Employment Application"))
//		     {
//		    	 Assert.assertTrue(driver.findElement(print_link).isDisplayed());
//		    	 Log.info("Print link displayed successfully");
//				 ExtentTestManager.getTest().log(Status.PASS, "Print link displayed successfully");
//		    	 Assert.assertTrue(driver.findElement(emp_app).isDisplayed());
//		    	 Log.info("Employment Application heading displayed successfully");
//				 ExtentTestManager.getTest().log(Status.PASS, "Employment Application heading displayed successfully");
//		    	 driver.close();
//		    	 	
//			  
//		    	 break;
//		     }
//		     else {
//		    	 driver.close();
//			}
//		 }
//		
//		 Thread.sleep(200);
		 
//		 driver.switchTo().window(parentWindow);		  
	}

	}

public void Validate_prtbtn_in_print_emp_app_page_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip, String msg_Txt_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_prtbtn_in_print_emp_app_page_AH")) 
	{
	
		Validate_Success_msg_in_final_page_AH( "Validate_Success_msg_in_final_page_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip,msg_Txt_ip);

					
		 By printyourapp_btn=By.id("ctl00_MainContent_ApplicantSubmissionSuccess_LinkButtonApplicationPrint");
		 By print_link=By.xpath("//a[contains(text(),'Print')]");
		 By emp_app=By.xpath("//h1[contains(text(),'Employment Application')]");
		
		 By msg_table=By.id("ctl00_MainContent_ApplicantSubmissionSuccess_tableSubmissionSuccessful");
		 
		 Element_isdisplayed(msg_table);
		 String Success_txt=driver.findElement(msg_table).getText().replace("\n", " ");
		 Assert.assertEquals(Success_txt.replace("Print Your Application", "").toUpperCase().trim(), msg_Txt_ip.toUpperCase().trim(), "Your Submission Successful details: "+msg_Txt_ip+" not validated in Application Submission Successful final level page");
		 Log.info(Success_txt+" text successfully displayed and validated in Application Submission Successful final level page");
		 ExtentTestManager.getTest().log(Status.PASS, Success_txt+" text successfully displayed and validated in Application Submission Successful final level page");	
	  
		 Element_isdisplayed(printyourapp_btn);
		 Log.info("Print Your Application button successfully displayed in Application Submission Successful final level page");
		 ExtentTestManager.getTest().log(Status.PASS, "Print Your Application button successfully displayed in Application Submission Successful final level page");	
	  
		 click(printyourapp_btn);
		 Thread.sleep(2000);
		 Log.info("Successfully clicked on Print Your Application button in Application Submission Successful final level page");
		 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Print Your Application button in Application Submission Successful final level page");	
	  
//		 String parentWindow= driver.getWindowHandle();
//		 Set<String> allWindows = driver.getWindowHandles();
		 try {
			 Set<String> allWindows = driver.getWindowHandles();
			 for(String curWindow : allWindows){
			     driver.switchTo().window(curWindow);
			     Thread.sleep(300);
			     if(driver.getTitle().equalsIgnoreCase("Esporta Fitness | Print Employment Application"))
			     {
			    	 Log.info("Successfully 'Esporta Fitness | Print Employment Application' page window opened");
					 ExtentTestManager.getTest().log(Status.PASS, "Successfully 'Esporta  Fitness | Print Employment Application' page window opened");	
				  
			    	 Assert.assertTrue(driver.findElement(print_link).isDisplayed());
			    	 Log.info("Print link displayed successfully in 'Esporta Fitness | Print Employment Application' page");
					 ExtentTestManager.getTest().log(Status.PASS, "Print link displayed successfully in 'Esporta Fitness | Print Employment Application' page");
			    	 Assert.assertTrue(driver.findElement(emp_app).isDisplayed());
			    	 Log.info("Employment Application heading displayed successfully in 'Esporta Fitness | Print Employment Application' page");
					 ExtentTestManager.getTest().log(Status.PASS, "Employment Application heading displayed successfully in 'Esporta Fitness | Print Employment Application' page");
			    	 driver.close();
			    	 	
				  
			    	 break;
			     }
			     else {
//			    	 driver.close();
				}
			 }
			 }
			 catch (Exception e) {
				
				 throw new Exception(e);
			}
//			 Thread.sleep(200);
			 
//			 driver.switchTo().window(parentWindow);		  
		}

	}

public void Validate_Rules_link_in_l9_AH(String Value, String How_hear_abt_us, String Radiobtn18YearsOld, String F_name, String L_name, String email, String Phone, String Address, String Zipcode, String L2_txt, String Edu_level_ip, String Exp_ip, String checkboxes_ip, String checkboxes_ip_1,  String Gap_ip,String emplr_name,String supr_name,String emp_from_date,String emp_to_date,String title,String leaving_reason, String emp_details_ip, String can_contact_ip, String doc_name, String Emp_checkbox_ip, String CB_ip, String Worktime_ip, String consider_chkbx_ip, String Date_ip, String radiobtn_ip, String EmpHowResigned_ip, String PriorEmploymentWhyResigned_ip, String EmploymentWhyLeaveCurrent_ip, String EmploymentWhyReapply_ip, String EmploymentWhatLike_ip, String EmploymentWhatDislike_ip, String  EmploymentSuccess_ip, String EmploymentWhyResignInFuture_ip, String Gender_ip, String RaceEthnicity_ip) throws Exception {
	
	if(Value.equalsIgnoreCase("Validate_Rules_link_in_l9_AH")) 
	{
	
		Validate_Next_btn_in_l8_AH( "Validate_Next_btn_in_l8_AH" ,  How_hear_abt_us,  Radiobtn18YearsOld,  F_name,  L_name,  email,  Phone,  Address,  Zipcode,  L2_txt,  Edu_level_ip,  Exp_ip,  checkboxes_ip,  checkboxes_ip_1,   Gap_ip, emplr_name, supr_name, emp_from_date, emp_to_date, title, leaving_reason,  emp_details_ip,  can_contact_ip,  doc_name,  Emp_checkbox_ip,  CB_ip,  Worktime_ip,  consider_chkbx_ip,  Date_ip,  radiobtn_ip,  EmpHowResigned_ip,  PriorEmploymentWhyResigned_ip,  EmploymentWhyLeaveCurrent_ip,  EmploymentWhyReapply_ip,  EmploymentWhatLike_ip,  EmploymentWhatDislike_ip,   EmploymentSuccess_ip,  EmploymentWhyResignInFuture_ip,Gender_ip, RaceEthnicity_ip);

	
		 By Rules_link=By.id("ctl00_MainContent_ApplicantArbitration_LinkButtonDisputeResolutionRules");
		  Thread.sleep(200);
		  Element_isdisplayed(Rules_link);
			 Log.info("Dispute Resolution Rules and Procedures link is successfully displayed in Application Submission level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Dispute Resolution Rules and Procedures link is successfully displayed in Application Submission level 9 page");	
		  
			 click(Rules_link);
			 Thread.sleep(1000);
			 Log.info("Successfully clicked on Dispute Resolution Rules and Procedures link in Application Submission level 9 page");
			 ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Dispute Resolution Rules and Procedures link in Application Submission level 9 page");	
		  
//			 String parentWindow= driver.getWindowHandle();
			 Boolean found=false;
			 Set<String> allWindows = driver.getWindowHandles();
			 for(String curWindow : allWindows){
			     driver.switchTo().window(curWindow);
//			     Thread.sleep(500);
//			     System.out.println("titles "+driver.getTitle());
			     if(allWindows.size()==2)
			     {
			    	 Log.info("Successfully 'iCreate Agreement DisputeResolutionRules.pdf' page window opened");
					 ExtentTestManager.getTest().log(Status.PASS, "Successfully 'iCreate Agreement DisputeResolutionRules.pdf' page window opened");	
				  Thread.sleep(500);
			    	driver.close();
			    	 	found=true;
				  
			    	 break;
			     }
			     else {
			    	 driver.close();
				}
			 }
			 
			 if (!found) {
					throw new Exception("DisputeResolutionRules new window not opened on click of Dispute Resolution Rules and Procedures link in Application Submission level 9 page");
					
				} 


		  
	}
	}




	
}
