package com.pages;

import java.awt.AWTException;
import java.sql.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.Utility.Log;

import org.apache.poi.hssf.record.PageBreakRecord.Break;
//import org.apache.logging.log4j.core.util.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.BasePackage.Base_Class;
import com.aventstack.extentreports.Status;
import com.extentReports.ExtentTestManager;
import com.google.common.collect.Multiset.Entry;

import org.testng.Assert;

public class Locations extends Base_Class {

	private static By findclub_heading = By.xpath("//h1[contains(text(),'Find a Club')]");

	private static By Locations = By.xpath("//div[@class='d-flex align-items-center nav-menu-list']//a[contains(text(),'Locations')]");
	
	private static By country_state_subheading=By.xpath("//legend[contains(text(),'Find by Country & State')]");
	private static By Map_locationspage = By.id("divMap");
	private static By IconDes_map = By.id("divIconDescription");
	private static By map_move_btns = By.xpath("//button[@class='btn btn-default btn-xs ae-button']");
	private static By map_move = By.xpath("//div[@class='btn-group btn-group-sm']");
	private static By move_top = By.xpath("//button[@title='Move Up']/span");
	private static By move_down = By.xpath("//button[@title='Move Down']/span");
	private static By move_left = By.xpath("//button[@title='Move Left']/span");
	private static By move_right = By.xpath("//button[@title='Move Right']/span");
	private static By Map_resultpage = By.id("mapDiv");
	
	private static By Map_typeswitch_btn = By.id("MapTypeSwitcherButton");
	private static By ZoomOutBtn = By.id("ZoomOutButton");
	private static By ZoomInBtn = By.id("ZoomInButton");
	private static By country_dd = By.id("ctl00_MainContent_FindAClub1_cboSelCountry");
	private static By state_dd = By.id("ctl00_MainContent_FindAClub1_cboSelState");
	private static By zipcode_subheading = By.xpath("//legend[contains(text(),'Find by Zip Code')]");
	private static By zipcode_ip = By.id("ctl00_MainContent_FindAClub1_txtZipCode");
	private static By find_btn_zipcode = By.id("ctl00_MainContent_FindAClub1_lnkBtnGo");
	private static By city_subheading = By.xpath("//legend[contains(text(),'Find by City')]");
	private static By city_ip = By.id("ctl00_MainContent_FindAClub1_txtCity");
	private static By find_btn_city = By.id("ctl00_MainContent_FindAClub1_lnkBtnGoByCity");
	
	private static By Start_new_search = By.id("ctl00_MainContent_LinkButton1");
	private static By Sortby_dd = By.id("ctl00_MainContent_ddlSortBy");
	private static By show_dd = By.id("ctl00_MainContent_ddlPageSize");
	private static By Login = By.xpath("//a[@id='ctl00_GlobalHeader_lnkLogin']/img");
	private static By ASC_btn = By.id("ctl00_MainContent_btnASC");
	private static By DESC_btn = By.id("ctl00_MainContent_btnDESC");
	private static By search_title = By.xpath("//div[@class='lah4']");
	private static By VirtualTour = By.xpath("//input[@value='Virtual Tour']");
	private static By VirtualTour_window = By.xpath("//div[@id='club-tour-video-modal' and @style='padding-right: 17px; display: block;']//div[@class='modal-dialog']");
	private static By play_popup_video = By.xpath("//body/form[@id='aspnetForm']/div[3]/div[2]/div[3]/div[1]/div[1]/div[1]/a[1]/img[1]");
	private static By play_Pause=By.xpath("//button[@class='tour-controls mp-nova-btn mp-nova-btn-tertiary mp-nova-btn-overlay mp-nova-btn-icon' and @aria-label='Play']/span[@class='nova-icon icon-play']");
	private static By VirtualTour_heading = By.id("modal_hdr_txt");
	private static By video_popup = By.id("loading-gui");
	private static By showcase_play = By.id("showcase-play");
	private static By close_img = By.xpath("//img[@class='ae-img' and @alt='Close Window']");
	
	private static By popup_close_btn = By.xpath("//div[@id='club-tour-video-modal' and @style='padding-right: 17px; display: block;']//div[@class='modal-dialog']//button[contains(text(),'Close')]");
	private static By page_nos = By.xpath("//div[@class='col-xs-7 nopadding text-center']//div[@class='col-xs-5 xsNopadding']");
	private static By Next = By.id("ctl00_MainContent_lnkNextTop");
	private static By Previous = By.id("ctl00_MainContent_lnkPreviousTop");
//	private static By Next = By.id("ctl00_MainContent_lnkNextTop");
	private static By parentrows = By.xpath("//tr[@class='ParentRow' and @style='display: none;']");
	private static By rows_data = By.xpath("//tbody//tr//td[2]//fieldset");
	private static By S_Nos = By.xpath("//td[@class='verticalCol text-center vertical-m hidden-xs']");
	private static By clubname = By.xpath("//span[@class= 'ClubTitle']");
	private static By clubphone = By.xpath("//div[@class= 'colclass-sm-7 col-xs-6']/a[2]");
	private static By clubaddress = By.xpath("//fieldset/div[1]/div[@class='colclass-sm-7 col-xs-6']/span[1]");
	private static By classtimes = By.xpath("//input[@value='Class Times']");
	//div[@class='row PaddingLeft10 PaddingTopBottom5']//input[@value='Class Times']
	private static By freepass = By.xpath("//input[@value='Free Pass']");
	private static By clubinfo = By.xpath("//input[@value='Club Info']");
	private static By clubinfo_section = By.xpath("//tr[@class='ParentRow']//div[@id='divClubInfo']");
	private static By view_full_clb_detail = By.xpath("//a[contains(text(),'View Full Club Detail')]");
	private static By club_data = By.xpath("//fieldset/div[1]/div[@class='colclass-sm-7 col-xs-6']");
	
	
	
	Home home=new Home();
	
	public void Validate_Findclub_heading(String Value, String page_title ) throws Exception {
		
				if (Value.equalsIgnoreCase("Validate_Findclub_heading")) {
		
					home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
					
					Element_isdisplayed(findclub_heading);
				
					ExtentTestManager.getTest().log(Status.PASS, "Find a Club heading is successfully displayed on 'Find a club' page");
					Log.info("Find a Club heading is successfully displayed on 'Find a club' page");
			
				}

			}
	
	
	public void Validate_country_state_searchsec(String Value, String page_title) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_country_state_searchsec")) {

			home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
			
		Element_isdisplayed(country_state_subheading);
		ExtentTestManager.getTest().log(Status.PASS, "Find by Country & State legend/subheading is Successfully displayed on 'Find a club' page");
		Log.info("Find by Country & State legend/subheading is Successfully displayed on 'Find a club' page");
		
		Element_isdisplayed(country_dd);
		ExtentTestManager.getTest().log(Status.PASS, "Select a Country dropdown is Successfully displayed on 'Find a club' page");
		Log.info("Select a Country dropdown is Successfully displayed on 'Find a club' page");
		
		Element_isdisplayed(state_dd);
		ExtentTestManager.getTest().log(Status.PASS, "Select a State OR Province dropdown is Successfully displayed on 'Find a club' page");
		Log.info("Select a State OR Province dropdown is Successfully displayed on 'Find a club' page");
		
//		Assert.assertEquals(driver.getTitle().toUpperCase().trim(), "LA Fitness | Find a Club".toUpperCase(),"Not navigated to LA Fitness | Find a Club / Locations page");
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Locations page");
//		Log.info("Successfully navigated to Locations page");
		
//		Element_isdisplayed(About);
//		ExtentTestManager.getTest().log(Status.PASS, "About dropdown displayed successful");
//		Log.info("About dropdown displayed successful");
//		Mouse_hover(About);
//		Element_isdisplayed(Carer_Opp);
//		ExtentTestManager.getTest().log(Status.PASS, "Career opportunities option is displayed successfully under About dropdown in homepage");
//		Log.info("Career opportunities option is displayed successfully under About dropdown in homepage");
//		
//		click(Carer_Opp);
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Career opportunities option under About dropdown in homepage");
//		Log.info("Successfully clicked on Career opportunities option under About dropdown in homepage");
//		Thread.sleep(200);
//		String t=driver.getTitle();
//		Assert.assertEquals(t.toUpperCase().trim(), "LA Fitness | Gym Jobs | Fitness Employment Opportunities".toUpperCase().trim(), "Emplyoment_page title not validated and not navigatd to Emplyoment_page");
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Fitness Career Opportunities/Employment page: "+t);
//		Log.info("Successfully navigated to Fitness Career Opportunities/Employment page: "+t);
		
//		Employment e= new Employment();
//		e.play_video();
		
		
		}
	

	
	}
	
	
	public void Validate_zipcode_searchsec(String Value, String page_title) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_zipcode_searchsec")) {

			home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
			
		Element_isdisplayed(zipcode_subheading);
		ExtentTestManager.getTest().log(Status.PASS, "Find by Zip Code legend/subheading is Successfully displayed on 'Find a club' page");
		Log.info("Find by Zip Code legend/subheading is Successfully displayed on 'Find a club' page");
		
		Element_isdisplayed(zipcode_ip);
		ExtentTestManager.getTest().log(Status.PASS, "Enter a Zip Code Or Postal Code input textbox is Successfully displayed on 'Find a club' page");
		Log.info("Enter a Zip Code Or Postal Code input textbox is Successfully displayed on 'Find a club' page");
		
		Element_isdisplayed(find_btn_zipcode);
		ExtentTestManager.getTest().log(Status.PASS, "Find button below the Zipcode textbox is Successfully displayed on 'Find a club' page");
		Log.info("Find button below the Zipcode textbox is Successfully displayed on 'Find a club' page");
		
//		Assert.assertEquals(driver.getTitle().toUpperCase().trim(), "LA Fitness | Find a Club".toUpperCase(),"Not navigated to LA Fitness | Find a Club / Locations page");
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Locations page");
//		Log.info("Successfully navigated to Locations page");
		
//		Element_isdisplayed(About);
//		ExtentTestManager.getTest().log(Status.PASS, "About dropdown displayed successful");
//		Log.info("About dropdown displayed successful");
//		Mouse_hover(About);
//		Element_isdisplayed(Carer_Opp);
//		ExtentTestManager.getTest().log(Status.PASS, "Career opportunities option is displayed successfully under About dropdown in homepage");
//		Log.info("Career opportunities option is displayed successfully under About dropdown in homepage");
//		
//		click(Carer_Opp);
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Career opportunities option under About dropdown in homepage");
//		Log.info("Successfully clicked on Career opportunities option under About dropdown in homepage");
//		Thread.sleep(200);
//		String t=driver.getTitle();
//		Assert.assertEquals(t.toUpperCase().trim(), "LA Fitness | Gym Jobs | Fitness Employment Opportunities".toUpperCase().trim(), "Emplyoment_page title not validated and not navigatd to Emplyoment_page");
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Fitness Career Opportunities/Employment page: "+t);
//		Log.info("Successfully navigated to Fitness Career Opportunities/Employment page: "+t);
		
//		Employment e= new Employment();
//		e.play_video();
		
		
		}
	

	
	}
	
	
	public void Validate_city_searchsec(String Value,String page_title) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_city_searchsec")) {

			home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
				
		Element_isdisplayed(city_subheading);
		ExtentTestManager.getTest().log(Status.PASS, "Find by City legend/subheading is Successfully displayed on 'Find a club' page");
		Log.info("Find by City legend/subheading is Successfully displayed on 'Find a club' page");
		
		Element_isdisplayed(city_ip);
		ExtentTestManager.getTest().log(Status.PASS, "Enter a City Name input textbox is Successfully displayed on 'Find a club' page");
		Log.info("Enter a City Name input textbox is Successfully displayed on 'Find a club' page");
		
		Element_isdisplayed(find_btn_city);
		ExtentTestManager.getTest().log(Status.PASS, "Find button below the City textbox is Successfully displayed on 'Find a club' page");
		Log.info("Find button below the City textbox is Successfully displayed on 'Find a club' page");
		
//		Assert.assertEquals(driver.getTitle().toUpperCase().trim(), "LA Fitness | Find a Club".toUpperCase(),"Not navigated to LA Fitness | Find a Club / Locations page");
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Locations page");
//		Log.info("Successfully navigated to Locations page");
		
//		Element_isdisplayed(About);
//		ExtentTestManager.getTest().log(Status.PASS, "About dropdown displayed successful");
//		Log.info("About dropdown displayed successful");
//		Mouse_hover(About);
//		Element_isdisplayed(Carer_Opp);
//		ExtentTestManager.getTest().log(Status.PASS, "Career opportunities option is displayed successfully under About dropdown in homepage");
//		Log.info("Career opportunities option is displayed successfully under About dropdown in homepage");
//		
//		click(Carer_Opp);
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Career opportunities option under About dropdown in homepage");
//		Log.info("Successfully clicked on Career opportunities option under About dropdown in homepage");
//		Thread.sleep(200);
//		String t=driver.getTitle();
//		Assert.assertEquals(t.toUpperCase().trim(), "LA Fitness | Gym Jobs | Fitness Employment Opportunities".toUpperCase().trim(), "Emplyoment_page title not validated and not navigatd to Emplyoment_page");
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Fitness Career Opportunities/Employment page: "+t);
//		Log.info("Successfully navigated to Fitness Career Opportunities/Employment page: "+t);
		
//		Employment e= new Employment();
//		e.play_video();
		
		
		}
	

	
	}
	

	public void Validate_select_desired_country(String Value, String page_title,String country_value) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_select_desired_country")) {

		home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
		
		Element_isdisplayed(country_dd);
		ExtentTestManager.getTest().log(Status.PASS, "Select a Country dropdown is Successfully displayed on 'Find a club' page");
		Log.info("Select a Country dropdown is Successfully displayed on 'Find a club' page");
		
		
		 Select select = new Select(driver.findElement(country_dd));  
		
		 if(!select.getFirstSelectedOption().getText().trim().equalsIgnoreCase(country_value)) {
		 select.selectByVisibleText(country_value);
		 Log.info("Country : '"+country_value.trim()+"' value is selected successfully");
		 ExtentTestManager.getTest().log(Status.PASS, "Country : '"+country_value.trim()+"' value is selected successfully");
		  
		 }
		 else {
		 Log.info("Country : '"+country_value.trim()+"' value is by default selected");
		 ExtentTestManager.getTest().log(Status.PASS, "Country : '"+country_value.trim()+"' value is by default selected");
		 }
		
		}
	

	
	}
	

	public void Validate_select_desired_state(String Value, String page_title, String country_value, String state_value) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_select_desired_state")) {

//		home.Navigate_to_Locations_page("Navigate_to_Locations_page");
		
		Validate_select_desired_country("Validate_select_desired_country",page_title,country_value);
		
		Element_isdisplayed(state_dd);
		ExtentTestManager.getTest().log(Status.PASS, "Select a State OR Province dropdown is Successfully displayed on 'Find a club' page");
		Log.info("Select a State OR Province dropdown is Successfully displayed on 'Find a club' page");
		
		
		 Select select = new Select(driver.findElement(state_dd));  
		 select.selectByVisibleText(state_value);
		 Log.info("State : '"+state_value.trim()+"' value is selected successfully");
		 ExtentTestManager.getTest().log(Status.PASS, "State : '"+state_value.trim()+"' value is selected successfully");
		  
		
		}
	

	
	}
	

	public void Validate_country_dd_all_options(String Value,String page_title ,String values) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_country_dd_all_options")) {

		home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
		
		Element_isdisplayed(country_dd);
		ExtentTestManager.getTest().log(Status.PASS, "Select a Country dropdown is Successfully displayed on 'Find a club' page");
		Log.info("Select a Country dropdown is Successfully displayed on 'Find a club' page");
		
		
		String[] country_values=values.split(",");

		
		 Select select = new Select(driver.findElement(country_dd));  
		 int count=0;
		 List<WebElement> options = select.getOptions();  
		 
		 ArrayList<String> mylist = new ArrayList<String>();
		 
		 for(WebElement we:options)  
		 	{  
			 
			 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
		 	}
		 	String delim = ",";
	        String res = String.join(delim, mylist);
			 
		  for (int i=0; i<country_values.length; i++)
		  	{
			  
			  if(res.trim().toUpperCase().contains(country_values[i].trim().toUpperCase()))
			  	{
				  count++;
				  Log.info(country_values[i].trim()+" value matched");
				  ExtentTestManager.getTest().log(Status.PASS, country_values[i].trim()+" value matched");
				  
			  	}
			  else
			  {
				  
				  Log.error(country_values[i].trim()+" value not matched with the values in country dropdown list"); 
				  ExtentTestManager.getTest().log(Status.FAIL, country_values[i].trim()+" value not matched with the values in country dropdown list");
				  
				 
				  }
			  
		  		}	 
		
		   if (country_values.length == count &&  mylist.size()==country_values.length) 
		    {	
			  
			   	Log.info("All values matched successfully in the country dropdown Expected");
		        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the country dropdown Expected");

		    } else 
		    {	
		    	Log.error("All values not matched successfully in the country dropdown. Expected dropdown list [ "+values +" ] Actual dropdown list [ "+res+" ]");
	        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the country dropdown. Expected dropdown list [ "+values +" ] Actual dropdown list [ "+res+" ]");
	        	throw new Exception("All values not matched successfully in the country dropdown");
		    }

		
		
		
		}
	

	
	}
	

	public void Validate_state_dd_all_options(String Value, String page_title, String  country , String dropdown_values) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_state_dd_all_options")) {


			Validate_select_desired_country("Validate_select_desired_country",page_title,country);
			
			
//		home.Navigate_to_Locations_page("Navigate_to_Locations_page");
//		
//		Element_isdisplayed(country_dd);
//		ExtentTestManager.getTest().log(Status.PASS, "Select a Country dropdown is Successfully displayed on 'Find a club' page");
//		Log.info("Select a Country dropdown is Successfully displayed on 'Find a club' page");
//		
//		 Select select = new Select(driver.findElement(country_dd));
//		 if(!select.getFirstSelectedOption().getText().equalsIgnoreCase(country.trim()))
//			 select.selectByValue(country.trim());
//
//		Log.info("Country dropdown value: "+country.trim()+" is selected successfully");
//		ExtentTestManager.getTest().log(Status.PASS, "Country dropdown value: "+country.trim()+"is selected successfully");
	
//		 if(!select.getFirstSelectedOption().getText().trim().equalsIgnoreCase(country)) {
//			 select.selectByVisibleText(country);
//			 Log.info("Country : '"+country.trim()+"' value is selected successfully");
//			 ExtentTestManager.getTest().log(Status.PASS, "Country : '"+country.trim()+"' value is selected successfully");
//			  
//			 }
//			 else {
//			 Log.info("Country : '"+country.trim()+"' value is by default selected");
//			 ExtentTestManager.getTest().log(Status.PASS, "Country : '"+country.trim()+"' value is by default selected");
//			 }
//		 
		 
		 Thread.sleep(200);

		Element_isdisplayed(state_dd);
		ExtentTestManager.getTest().log(Status.PASS, "Select a State OR Province dropdown is Successfully displayed on 'Find a club' page");
		Log.info("Select a State OR Province dropdown is Successfully displayed on 'Find a club' page");
		
		
//		String[] State_values = {"","AB","AZ","CA","CT","DE","FL","GA","IL","IN","MA","MD","MI","MN","NC","NJ","NY","ON","OR","PA","RI","TX","VA","WA"};
		String[] State_values=dropdown_values.split(",");
		Thread.sleep(200);
		 Select select1 = new Select(driver.findElement(state_dd));  
		 int count=0;
		 List<WebElement> options = select1.getOptions(); 

		 
		  
		  ArrayList<String> mylist = new ArrayList<String>();

			 for(WebElement we:options)  
			 	{  
				 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
			 	}
			 	String delim = ",";
		        String res = String.join(delim, mylist);
				 
			  for (int i=0; i<State_values.length; i++)
			  	{
				  
				  if(res.trim().toUpperCase().contains(State_values[i].trim().toUpperCase()))
				  	{
					  count++;
					  Log.info(State_values[i].trim()+" value matched");
					  ExtentTestManager.getTest().log(Status.PASS, State_values[i].trim()+" value matched");
				  	}
				  else {
						  Log.error(State_values[i].trim()+" value not matched with the values in state dropdown list");
						  ExtentTestManager.getTest().log(Status.FAIL, State_values[i].trim()+" value not matched with the values in state dropdown list");
				  }
				  
			    }	 
		  
//		 	} 
		   if (count == State_values.length && mylist.size()==State_values.length) 
		    {	
		        Log.info("All values matched successfully in the state dropdown");
		        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the country dropdown");

		     } else 
		    {	
		        Log.error("All values not matched successfully in the state dropdown. Expected dropdown list [ "+dropdown_values +" ] Actual dropdown list [ "+res+" ]");
		        ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the state dropdown. Expected dropdown list [ "+dropdown_values +" ] Actual dropdown list [ "+res+" ]");
//		        Assert.assertTrue(false, "All values not matched successfully in the ByState province dropdown");
		        
		        throw new Exception("All values not matched successfully in the state dropdown");
		    }

		
		
		
		}
	

	
	}
	

	public void Validate_ip_in_zipcode(String Value, String page_title, String zipcode) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_ip_in_zipcode")) {

//		home.Navigate_to_Locations_page("Navigate_to_Locations_page");
		Validate_zipcode_searchsec("Validate_zipcode_searchsec", page_title);	
		
//		Element_isdisplayed(zipcode_subheading);
//		ExtentTestManager.getTest().log(Status.PASS, "Find by Zip Code legend/subheading is Successfully displayed on 'Find a club' page");
//		Log.info("Find by Zip Code legend/subheading is Successfully displayed on 'Find a club' page");
		
//		Element_isdisplayed(zipcode_ip);
		input(zipcode_ip, zipcode);
		ExtentTestManager.getTest().log(Status.PASS, "Entered Zip Code Or Postal Code : "+zipcode+"  Successfully on 'Find a club' page");
		Log.info("Entered Zip Code Or Postal Code : "+zipcode+"  Successfully on 'Find a club' page");
		
		Assert.assertEquals(driver.findElement(zipcode_ip).getAttribute("value").trim().toUpperCase(),zipcode.toUpperCase().trim(), "Zipcode not fetched or entered properly");
		
//		Element_isdisplayed(find_btn_zipcode);
//		ExtentTestManager.getTest().log(Status.PASS, "Find button below the Zipcode textbox is Successfully displayed on 'Find a club' page");
//		Log.info("Find button below the Zipcode textbox is Successfully displayed on 'Find a club' page");
		
//		Assert.assertEquals(driver.getTitle().toUpperCase().trim(), "LA Fitness | Find a Club".toUpperCase(),"Not navigated to LA Fitness | Find a Club / Locations page");
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Locations page");
//		Log.info("Successfully navigated to Locations page");
		
//		Element_isdisplayed(About);
//		ExtentTestManager.getTest().log(Status.PASS, "About dropdown displayed successful");
//		Log.info("About dropdown displayed successful");
//		Mouse_hover(About);
//		Element_isdisplayed(Carer_Opp);
//		ExtentTestManager.getTest().log(Status.PASS, "Career opportunities option is displayed successfully under About dropdown in homepage");
//		Log.info("Career opportunities option is displayed successfully under About dropdown in homepage");
//		
//		click(Carer_Opp);
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Career opportunities option under About dropdown in homepage");
//		Log.info("Successfully clicked on Career opportunities option under About dropdown in homepage");
//		Thread.sleep(200);
//		String t=driver.getTitle();
//		Assert.assertEquals(t.toUpperCase().trim(), "LA Fitness | Gym Jobs | Fitness Employment Opportunities".toUpperCase().trim(), "Emplyoment_page title not validated and not navigatd to Emplyoment_page");
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Fitness Career Opportunities/Employment page: "+t);
//		Log.info("Successfully navigated to Fitness Career Opportunities/Employment page: "+t);
		
//		Employment e= new Employment();
//		e.play_video();
		
		
		}
	

	
	}
	

	public void Validate_ip_in_city(String Value,String page_title, String city) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_ip_in_city")) {

//			home.Navigate_to_Locations_page("Navigate_to_Locations_page");
		Validate_city_searchsec("Validate_city_searchsec", page_title);
		
		Element_isdisplayed(city_ip);
		ExtentTestManager.getTest().log(Status.PASS, "Enter a City Name input textbox is Successfully displayed on 'Find a club' page");
		Log.info("Enter a City Name input textbox is Successfully displayed on 'Find a club' page");
		
		input(city_ip, city);
		ExtentTestManager.getTest().log(Status.PASS, "Entered City Name : "+city+"  Successfully on 'Find a club' page");
		Log.info("Entered City Name : "+city+"  Successfully on 'Find a club' page");
		
		Assert.assertEquals(driver.findElement(city_ip).getAttribute("value").trim().toUpperCase(),city.toUpperCase().trim(), "City Name not fetched or entered properly");
		
		
//		Element_isdisplayed(find_btn_city);
//		ExtentTestManager.getTest().log(Status.PASS, "Find button below the City textbox is Successfully displayed on 'Find a club' page");
//		Log.info("Find button below the City textbox is Successfully displayed on 'Find a club' page");
//		
//		Assert.assertEquals(driver.getTitle().toUpperCase().trim(), "LA Fitness | Find a Club".toUpperCase(),"Not navigated to LA Fitness | Find a Club / Locations page");
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Locations page");
//		Log.info("Successfully navigated to Locations page");
		
//		Element_isdisplayed(About);
//		ExtentTestManager.getTest().log(Status.PASS, "About dropdown displayed successful");
//		Log.info("About dropdown displayed successful");
//		Mouse_hover(About);
//		Element_isdisplayed(Carer_Opp);
//		ExtentTestManager.getTest().log(Status.PASS, "Career opportunities option is displayed successfully under About dropdown in homepage");
//		Log.info("Career opportunities option is displayed successfully under About dropdown in homepage");
//		
//		click(Carer_Opp);
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Career opportunities option under About dropdown in homepage");
//		Log.info("Successfully clicked on Career opportunities option under About dropdown in homepage");
//		Thread.sleep(200);
//		String t=driver.getTitle();
//		Assert.assertEquals(t.toUpperCase().trim(), "LA Fitness | Gym Jobs | Fitness Employment Opportunities".toUpperCase().trim(), "Emplyoment_page title not validated and not navigatd to Emplyoment_page");
//		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Fitness Career Opportunities/Employment page: "+t);
//		Log.info("Successfully navigated to Fitness Career Opportunities/Employment page: "+t);
		
//		Employment e= new Employment();
//		e.play_video();
		
		
		}
	

	
	}
	

	public void Validate_country_state_search(String Value,String page_title, String country_value, String state_value, String result_url) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_country_state_search")) {

//		home.Navigate_to_Locations_page("Navigate_to_Locations_page");
		
		Validate_select_desired_state("Validate_select_desired_state",page_title,country_value, state_value);
		
		Thread.sleep(500);
		
		String url= driver.getCurrentUrl();
		String resultpage_title;
		if(url.toUpperCase().trim().contains(result_url.toUpperCase().trim())) 
		{
			 resultpage_title=driver.getTitle();
			Log.info("Successfully landed into '"+resultpage_title+"' find club results page");
			ExtentTestManager.getTest().log(Status.PASS, "Successfully landed into '"+resultpage_title+"' find club results page");
			 	
		}
		else 
		{
		
			throw new Exception("Not landed into find club results page");
			
		}
		 
		
		}
	

	
	}
	

	public void Validate_zipcode_search(String Value, String page_title, String zipcode, String result_url) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_zipcode_search")) {

//		home.Navigate_to_Locations_page("Navigate_to_Locations_page");
		Validate_ip_in_zipcode("Validate_ip_in_zipcode",page_title, zipcode);	
		
//		Element_isdisplayed(find_btn_zipcode);
		click(find_btn_zipcode);
		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Find button below the Zipcode textbox in 'Find a club' page");
		Log.info("Successfully clicked on Find button below the Zipcode textbox in 'Find a club' page");
		
		
		Thread.sleep(500);
		
		String url= driver.getCurrentUrl();
		String resultpage_title;
		if(url.toUpperCase().trim().contains(result_url.toUpperCase().trim())) 
		{
			 resultpage_title=driver.getTitle();
			Log.info("Successfully landed into '"+resultpage_title+"' find club results page");
			ExtentTestManager.getTest().log(Status.PASS, "Successfully landed into '"+resultpage_title+"' find club results page");
			 	
		}
		else 
		{
		
			throw new Exception("Not landed into find club results page");
			
		}
		
		}
	

	
	}
	

	public void Validate_city_search(String Value, String page_title, String city, String result_url) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_city_search")) {

//			home.Navigate_to_Locations_page("Navigate_to_Locations_page");
		Validate_ip_in_city("Validate_ip_in_city", page_title,city);
		
		click(find_btn_city);
		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Find button below the City Name textbox in 'Find a club' page");
		Log.info("Successfully clicked on Find button below the City Name textbox in 'Find a club' page");
		
		Thread.sleep(500);
		
		String url= driver.getCurrentUrl();
		String resultpage_title;
		if(url.toUpperCase().trim().contains(result_url.toUpperCase().trim())) 
		{
			 resultpage_title=driver.getTitle();
			Log.info("Successfully landed into '"+resultpage_title+"' find club results page");
			ExtentTestManager.getTest().log(Status.PASS, "Successfully landed into '"+resultpage_title+"' find club results page");
			 	
		}
		else 
		{
		
			throw new Exception("Not landed into find club results page");
			
		}
		
	
		
		}
	

	
	}
	

	public void Validate_sort_show_newsearch(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
		
		if (Value.equalsIgnoreCase("Validate_sort_show_newsearch")) {
		
		if(!(country_value.isEmpty()&& country_value.isBlank() && state_value.isEmpty()&& state_value.isBlank()) ) {
		Validate_country_state_search("Validate_country_state_search",page_title,country_value,state_value,result_url );
		sort_show_newsearch_fields();
		
		}
		else if (!(zipcode.isEmpty()&& zipcode.isBlank()) ) {
			
			Validate_zipcode_search("Validate_zipcode_search",page_title,zipcode, result_url);
			sort_show_newsearch_fields();
		}
		
		else if (!(city_name.isEmpty()&& city_name.isBlank())) {
			
			Validate_city_search("Validate_city_search",page_title, city_name, result_url);
			sort_show_newsearch_fields();
		}
		
		
		
		
		
//		home.Navigate_to_Locations_page("Navigate_to_Locations_page");
		
//		Validate_select_desired_state("Validate_select_desired_state",country_value, state_value);
//		
//		Thread.sleep(500);
//		
//		String url= driver.getCurrentUrl();
//		String resultpage_title;
//		if(url.toUpperCase().trim().contains(result_url.toUpperCase().trim())) 
//		{
//			 resultpage_title=driver.getTitle();
//			Log.info("Successfully landed into '"+resultpage_title+"' find club results page");
//			ExtentTestManager.getTest().log(Status.PASS, "Successfully landed into '"+resultpage_title+"' find club results page");
//			 	
//		}
//		else 
//		{
//		
//			throw new Exception("Not landed into find club results page");
//			
//		}
		 
		
		}
	

	
	}
	
	
public void sort_show_newsearch_fields() throws Exception {
	
	String title = driver.getTitle();
	
	Element_isdisplayed(Start_new_search);	
	ExtentTestManager.getTest().log(Status.PASS, "Start New Search button is Successfully displayed on '"+title+"' page");
	Log.info("Start New Search button is Successfully displayed on '"+title+"' page");
	
	Element_isdisplayed(Sortby_dd);	
	ExtentTestManager.getTest().log(Status.PASS, "Sort by dropdown is Successfully displayed on '"+title+"' page");
	Log.info("Sort by dropdown is Successfully displayed on '"+title+"' page");
	
	Element_isdisplayed(show_dd);	
	ExtentTestManager.getTest().log(Status.PASS, "Show dropdown is Successfully displayed on '"+title+"' page");
	Log.info("Show dropdown is Successfully displayed on '"+title+"' page");
	
	
}	
	
	

public void Validate_sortby_dd_all_options(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name, String sortby_dd_values) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_sortby_dd_all_options")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
	
	String[] sortby_values=sortby_dd_values.split(",");

	
	 Select select = new Select(driver.findElement(Sortby_dd));  
	 int count=0;
	 List<WebElement> options = select.getOptions();  
	 
	 ArrayList<String> mylist = new ArrayList<String>();
	 
	 for(WebElement we:options)  
	 	{  
		 
		 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
	 	}
	 	String delim = ",";
        String res = String.join(delim, mylist);
		 
	  for (int i=0; i<sortby_values.length; i++)
	  	{
		  
		  if(res.trim().toUpperCase().contains(sortby_values[i].trim().toUpperCase()))
		  	{
			  count++;
			  Log.info(sortby_values[i].trim()+" value matched");
			  ExtentTestManager.getTest().log(Status.PASS, sortby_values[i].trim()+" value matched");
			  
		  	}
		  else
		  {
			  
			  Log.error(sortby_values[i].trim()+" value not matched with the values in Sort by dropdown list"); 
			  ExtentTestManager.getTest().log(Status.FAIL, sortby_values[i].trim()+" value not matched with the values in Sort by dropdown list");
			  
			 
			  }
		  
	  		}	 
	
	   if (sortby_values.length == count &&  mylist.size()==sortby_values.length) 
	    {	
		  
		   	Log.info("All values matched successfully in the Sort by dropdown Expected");
	        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the Sort by dropdown Expected");

	    } else 
	    {	
	    	Log.error("All values not matched successfully in the Sort by dropdown. Expected dropdown list [ "+sortby_dd_values +" ] Actual dropdown list [ "+res+" ]");
        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the Sort by dropdown. Expected dropdown list [ "+sortby_dd_values +" ] Actual dropdown list [ "+res+" ]");
        	throw new Exception("All values not matched successfully in the Sort by dropdown");
	    }

	
	
	
	}



}



public void Validate_show_dd_all_options(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name, String show_dd_values) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_show_dd_all_options")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title,  country_value,state_value,result_url,zipcode,city_name);
	
	String[] show_values=show_dd_values.split(",");

	
	 Select select = new Select(driver.findElement(show_dd));  
	 int count=0;
	 List<WebElement> options = select.getOptions();  
	 
	 ArrayList<String> mylist = new ArrayList<String>();
	 
	 for(WebElement we:options)  
	 	{  
		 
		 if (!we.getText().isEmpty()) mylist.add(we.getText().trim());
	 	}
	 	String delim = ",";
        String res = String.join(delim, mylist);
		 
	  for (int i=0; i<show_values.length; i++)
	  	{
		  
		  if(res.trim().toUpperCase().contains(show_values[i].trim().toUpperCase()))
		  	{
			  count++;
			  Log.info(show_values[i].trim()+" value matched");
			  ExtentTestManager.getTest().log(Status.PASS, show_values[i].trim()+" value matched");
			  
		  	}
		  else
		  {
			  
			  Log.error(show_values[i].trim()+" value not matched with the values in show dropdown list"); 
			  ExtentTestManager.getTest().log(Status.FAIL, show_values[i].trim()+" value not matched with the values in show dropdown list");
			  
			 
			  }
		  
	  		}	 
	
	   if (show_values.length == count &&  mylist.size()==show_values.length) 
	    {	
		  
		   	Log.info("All values matched successfully in the show dropdown Expected");
	        ExtentTestManager.getTest().log(Status.PASS, "All values matched successfully in the show dropdown Expected");

	    } else 
	    {	
	    	Log.error("All values not matched successfully in the show dropdown. Expected dropdown list [ "+show_dd_values +" ] Actual dropdown list [ "+res+" ]");
        	ExtentTestManager.getTest().log(Status.FAIL, "All values not matched successfully in the show dropdown. Expected dropdown list [ "+show_dd_values +" ] Actual dropdown list [ "+res+" ]");
        	throw new Exception("All values not matched successfully in the show dropdown");
	    }

	
	
	
	}



}


public void Validate_sortby_default_option(String Value, String page_title,String country_value, String state_value, String result_url, String zipcode, String city_name, String sortby_dd_value) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_sortby_default_option")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title,  country_value,state_value,result_url,zipcode,city_name);
	
	
	 Select select = new Select(driver.findElement(Sortby_dd));  
	 String default_option= select.getFirstSelectedOption().getText().trim();

	 Assert.assertEquals(default_option.toUpperCase(), sortby_dd_value.trim().toUpperCase(), "Sort by dropdown default option not validated in Locations search result page");
	 Log.info("Sort by dropdown default option: "+ sortby_dd_value+ " is successfully validated in Locations search result page");
     ExtentTestManager.getTest().log(Status.PASS, "Sort by dropdown default option: "+ sortby_dd_value+ " is successfully validated in Locations search result page");

	
	}



}



public void Validate_show_default_option(String Value, String page_title,String country_value, String state_value, String result_url, String zipcode, String city_name, String show_dd_value) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_show_default_option")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title,  country_value,state_value,result_url,zipcode,city_name);
	
	
	 Select select = new Select(driver.findElement(show_dd));  
	 String default_option= select.getFirstSelectedOption().getText().trim();

	 Assert.assertEquals(default_option.toUpperCase(), show_dd_value.trim().toUpperCase(), "Show dropdown default option not validated in Locations search result page");
	 Log.info("Show dropdown default option: "+ show_dd_value+ " is successfully validated in Locations search result page");
     ExtentTestManager.getTest().log(Status.PASS, "Show dropdown default option: "+ show_dd_value+ " is successfully validated in Locations search result page");

	
	}



}

	

public void Validate_sortby_select_desired_option(String Value, String page_title,  String country_value, String state_value, String result_url, String zipcode, String city_name, String sortby_dd_value) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_sortby_select_desired_option")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title,  country_value,state_value,result_url,zipcode,city_name);
	
	
	 Select select = new Select(driver.findElement(Sortby_dd));  
//	 String default_option= select.getFirstSelectedOption().getText().trim();
	 select.selectByVisibleText(sortby_dd_value.trim());
	 
//	 Assert.assertEquals(default_option.toUpperCase(), sortby_dd_value.trim().toUpperCase(), "Sort by dropdown default option not validated in Locations search result page");
	 Log.info("Sort by dropdown option: "+ sortby_dd_value+ " is successfully selected in Locations search result page");
     ExtentTestManager.getTest().log(Status.PASS, "Sort by dropdown option: "+ sortby_dd_value+ " is successfully selected in Locations search result page");

	
	}



}



public void Validate_show_select_desired_option(String Value, String page_title,  String country_value, String state_value, String result_url, String zipcode, String city_name, String show_dd_value) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_show_select_desired_option")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title,  country_value,state_value,result_url,zipcode,city_name);
	
	
	 Select select = new Select(driver.findElement(show_dd));  
//	 String default_option= select.getFirstSelectedOption().getText().trim();
	 select.selectByVisibleText(show_dd_value.trim());

//	 Assert.assertEquals(default_option.toUpperCase(), show_dd_value.trim().toUpperCase(), "Show dropdown default option not validated in Locations search result page");
	 Log.info("Show dropdown option: "+ show_dd_value+ " is successfully selected in Locations search result page");
     ExtentTestManager.getTest().log(Status.PASS, "Show dropdown option: "+ show_dd_value+ " is successfully selected in Locations search result page");

	
	}



}

	

public void Validate_start_new_search_btn(String Value,String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name, String show_dd_value) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_start_new_search_btn")) {

//	String[] titles= page_title.split(",");	
		
	Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title,  country_value,state_value,result_url,zipcode,city_name);
	
	
//	 Select select = new Select(driver.findElement(show_dd));  
//	 String default_option= select.getFirstSelectedOption().getText().trim();
//	 select.selectByVisibleText(show_dd_value.trim());

	click(Start_new_search);
	Log.info("successfully clicked on 'Start new search' button in 'Locations results' page");
    ExtentTestManager.getTest().log(Status.PASS, "successfully clicked on 'Start new search' button in 'Locations results' page");

	Thread.sleep(500);
	String title = driver.getTitle();
	 Assert.assertEquals(title.trim().toUpperCase().trim(), page_title.toUpperCase().trim(), "On click of 'Start new search' button not navigated to '"+page_title+"' page");
	 Log.info("successfully navigated to '"+title+"' page");
     ExtentTestManager.getTest().log(Status.PASS, "successfully navigated to '"+title+"' page");

	
	}



}

		

public void Validate_results_sec_fields(String Value, String page_title,  String country_value, String state_value, String result_url, String zipcode, String city_name, String show_dd_value) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_results_sec_fields")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title,  country_value,state_value,result_url,zipcode,city_name);
	
	
	Element_isdisplayed(ASC_btn);
	ExtentTestManager.getTest().log(Status.PASS, "ASC order button is Successfully displayed on 'Locations search results page' page");
	Log.info("ASC order button is Successfully displayed on 'Locations search results page' page");
	
	
	Element_isdisplayed(search_title);
	String search_Title = driver.findElement(search_title).getText();
	ExtentTestManager.getTest().log(Status.PASS, "Search title: '"+search_Title+"' is Successfully displayed on 'Locations search results page' page");
	Log.info("Search title: '"+search_Title+"' is Successfully displayed on 'Locations search results page' page");
	
	
	Element_isdisplayed(page_nos);
	String Page_numbers = driver.findElement(page_nos).getText();
	ExtentTestManager.getTest().log(Status.PASS, "Page numbers: '"+Page_numbers+"' is Successfully displayed on 'Locations search results page' page");
	Log.info("Page numbers : '"+Page_numbers+"' is Successfully displayed on 'Locations search results page' page");
	
	Element_isdisplayed(Next);
	ExtentTestManager.getTest().log(Status.PASS, "Next page Link is Successfully displayed on 'Locations search results page' page");
	Log.info("Next page Link is Successfully displayed on 'Locations search results page' page");
	
	
//	 Select select = new Select(driver.findElement(show_dd));  
//	 String default_option= select.getFirstSelectedOption().getText().trim();
//	 select.selectByVisibleText(show_dd_value.trim());

//	 Assert.assertEquals(default_option.toUpperCase(), show_dd_value.trim().toUpperCase(), "Show dropdown default option not validated in Locations search result page");
//	 Log.info("Show dropdown option: "+ show_dd_value+ " is successfully selected in Locations search result page");
//     ExtentTestManager.getTest().log(Status.PASS, "Show dropdown option: "+ show_dd_value+ " is successfully selected in Locations search result page");

	
	}



}

		

public void Validate_no_next_link(String Value,  String page_title,  String country_value, String state_value, String result_url, String zipcode, String city_name, String show_dd_value) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_no_next_link")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title,  country_value,state_value,result_url,zipcode,city_name);
	
	
	
//	Element_isdisplayed(ASC_btn);
//	ExtentTestManager.getTest().log(Status.PASS, "ASC order button is Successfully displayed on 'Locations search results page' page");
//	Log.info("ASC order button is Successfully displayed on 'Locations search results page' page");
//	
//	
//	Element_isdisplayed(search_title);
//	String search_Title = driver.findElement(search_title).getText();
//	ExtentTestManager.getTest().log(Status.PASS, "Search title: '"+search_Title+"' is Successfully displayed on 'Locations search results page' page");
//	Log.info("Search title: '"+search_Title+"' is Successfully displayed on 'Locations search results page' page");
	Select select = new Select(driver.findElement(show_dd));
	select.selectByVisibleText("50");
	
	Element_isdisplayed(page_nos);
	String Page_numbers = driver.findElement(page_nos).getText();
	Assert.assertEquals(Page_numbers.trim().toUpperCase(), "Page: 1 of 1".toUpperCase(), "Page no's did not matched");
	ExtentTestManager.getTest().log(Status.PASS, "Page number: '"+Page_numbers+"' is Successfully displayed on 'Locations search results page' page");
	Log.info("Page number : '"+Page_numbers+"' is Successfully displayed on 'Locations search results page' page");
	
	int next_size=driver.findElements(Next).size();
	if(next_size >=1) {
		
		ExtentTestManager.getTest().log(Status.FAIL, "Next page link is displayed when there's only 1 page available");
		Log.error("Next page link is displayed when there's only 1 page available");
		throw new Exception("Next page link is displayed when there's only 1 page available");
	}
	else {
		
		ExtentTestManager.getTest().log(Status.PASS, "Next page link is not displayed on 'Locations search results' page when there's only 1 page available");
		Log.info( "Next page link is not displayed on 'Locations search results' page when there's only 1 page available");
		
	}
	
	
	
//	Element_isdisplayed(Next);
//	ExtentTestManager.getTest().log(Status.PASS, "Next page Link is Successfully displayed on 'Locations search results page' page");
//	Log.info("Next page Link is Successfully displayed on 'Locations search results page' page");
	
	
//	 Select select = new Select(driver.findElement(show_dd));  
//	 String default_option= select.getFirstSelectedOption().getText().trim();
//	 select.selectByVisibleText(show_dd_value.trim());

//	 Assert.assertEquals(default_option.toUpperCase(), show_dd_value.trim().toUpperCase(), "Show dropdown default option not validated in Locations search result page");
//	 Log.info("Show dropdown option: "+ show_dd_value+ " is successfully selected in Locations search result page");
//     ExtentTestManager.getTest().log(Status.PASS, "Show dropdown option: "+ show_dd_value+ " is successfully selected in Locations search result page");

	
	}



}

	

public void Validate_MAP_in_Locationspage(String Value,  String page_title ) throws Exception {
	
			if (Value.equalsIgnoreCase("Validate_MAP_in_Locationspage")) {
	
				home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
				
				Element_isdisplayed(Map_locationspage);
			
				ExtentTestManager.getTest().log(Status.PASS, "Map is successfully displayed on 'Find a club / Locations' page");
				Log.info("Map is successfully displayed on 'Find a club / Locations' page");
		
			}

		}


public void Validate_IconDes_map_in_Loc_page(String Value, String page_title,  String Icon_des_ip) throws Exception {
	
			if (Value.equalsIgnoreCase("Validate_IconDes_map_in_Loc_page")) {
	
				home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
				
				Element_isdisplayed(IconDes_map);
				String des=driver.findElement(IconDes_map).getText().trim();
				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
				
				ExtentTestManager.getTest().log(Status.PASS, "Map Icon Description's ("+Icon_des_ip+") successfully displayed and validated on 'Find a club / Locations' page");
				Log.info("Map Icon Description's ("+Icon_des_ip+")is successfully displayed and validated on 'Find a club / Locations' page");
		
				
				
			}

		}


public void Validate_Movebtns_map_in_Loc_page(String Value,  String page_title ) throws Exception {
	
			if (Value.equalsIgnoreCase("Validate_Movebtns_map_in_Loc_page")) {
	
				home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
				
//				Element_isdisplayed(map_move_btns);
				Element_isdisplayed(map_move);
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
				List<WebElement> move_btns=driver.findElements(map_move_btns);
				for(WebElement btn:move_btns)
					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
//				ExtentTestManager.getTest().log(Status.PASS, "All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
//				Log.info("All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
		
				Element_isdisplayed(move_top);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move Up Button is successfully displayed in 'Find a club / Locations' page");
				Log.info("Map Move Up Button is successfully displayed in 'Find a club / Locations' page");
		
				Element_isdisplayed(move_down);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move down Button is successfully displayed in 'Find a club / Locations' page");
				Log.info("Map Move down Button is successfully displayed in 'Find a club / Locations' page");
		
				Element_isdisplayed(move_left);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move Left Button is successfully displayed in 'Find a club / Locations' page");
				Log.info("Map Move Left Button is successfully displayed in 'Find a club / Locations' page");
		
				Element_isdisplayed(move_right);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move Right Button is successfully displayed in 'Find a club / Locations' page");
				Log.info("Map Move Right Button is successfully displayed in 'Find a club / Locations' page");
		
				
			}

		}


public void Validate_zoom_out_in_maptype_btns(String Value,  String page_title ) throws Exception {
	
			if (Value.equalsIgnoreCase("Validate_zoom_out_in_maptype_btns")) {
	
				home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
				
				Element_isdisplayed(Map_typeswitch_btn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully displayed in 'Find a club / Locations' page");
				Log.info("Map Type Switcher Button is successfully displayed in 'Find a club / Locations' page");
		
				Element_isdisplayed(ZoomInBtn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully displayed in 'Find a club / Locations' page");
				Log.info("Map Zoom In Button is successfully displayed in 'Find a club / Locations' page");
		
				Element_isdisplayed(ZoomOutBtn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully displayed and by default disabled in 'Find a club / Locations' page");
				Log.info("Map Zoom Out Button is successfully displayed and by default disabled in 'Find a club / Locations' page");
		
				
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
				
				
				
			}

		}


public void Validate_Move_up_in_Loc_page(String Value,  String page_title ) throws Exception {
	
			if (Value.equalsIgnoreCase("Validate_Move_up_in_Loc_page")) {
	
				home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
				
//				Element_isdisplayed(map_move_btns);
				Element_isdisplayed(map_move);
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
//				ExtentTestManager.getTest().log(Status.PASS, "All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
//				Log.info("All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
		
				click(move_top);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move Up Button is successfully clicked in 'Find a club / Locations' page");
				Log.info("Map Move Up Button is successfully clicked in 'Find a club / Locations' page");
				Thread.sleep(200);
//				Element_isdisplayed(move_down);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Move down Button is successfully displayed in 'Find a club / Locations' page");
//				Log.info("Map Move down Button is successfully displayed in 'Find a club / Locations' page");
//		
//				Element_isdisplayed(move_left);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Move Left Button is successfully displayed in 'Find a club / Locations' page");
//				Log.info("Map Move Left Button is successfully displayed in 'Find a club / Locations' page");
//		
//				Element_isdisplayed(move_right);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Move Right Button is successfully displayed in 'Find a club / Locations' page");
//				Log.info("Map Move Right Button is successfully displayed in 'Find a club / Locations' page");
//		
				
			}

		}


public void Validate_Move_down_in_Loc_page(String Value,  String page_title ) throws Exception {
	
			if (Value.equalsIgnoreCase("Validate_Move_down_in_Loc_page")) {
	
				home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
				
//				Element_isdisplayed(map_move_btns);
				Element_isdisplayed(map_move);
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
//				ExtentTestManager.getTest().log(Status.PASS, "All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
//				Log.info("All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
		
				click(move_down);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move down Button is successfully clicked in 'Find a club / Locations' page");
				Log.info("Map Move down Button is successfully clicked in 'Find a club / Locations' page");
				Thread.sleep(200);
				
			}

		}

	

public void Validate_Move_left_in_Loc_page(String Value,  String page_title ) throws Exception {
	
			if (Value.equalsIgnoreCase("Validate_Move_left_in_Loc_page")) {
	
				home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
				
//				Element_isdisplayed(map_move_btns);
				Element_isdisplayed(map_move);
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
//				ExtentTestManager.getTest().log(Status.PASS, "All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
//				Log.info("All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
		
				click(move_left);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move left Button is successfully clicked in 'Find a club / Locations' page");
				Log.info("Map Move left Button is successfully clicked in 'Find a club / Locations' page");
				Thread.sleep(200);
				
			}

		}

	

public void Validate_Move_right_in_Loc_page(String Value,  String page_title ) throws Exception {
	
			if (Value.equalsIgnoreCase("Validate_Move_right_in_Loc_page")) {
	
				home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
				
//				Element_isdisplayed(map_move_btns);
				Element_isdisplayed(map_move);
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
//				ExtentTestManager.getTest().log(Status.PASS, "All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
//				Log.info("All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
		
				click(move_right);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move right Button is successfully clicked in 'Find a club / Locations' page");
				Log.info("Map Move right Button is successfully clicked in 'Find a club / Locations' page");
				Thread.sleep(200);
				
			}

		}

	

public void Validate_Maptypeswitcher_btn(String Value,  String page_title ) throws Exception {
	
			if (Value.equalsIgnoreCase("Validate_Maptypeswitcher_btn")) {
	
				home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
				
				click(Map_typeswitch_btn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
				Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
				Thread.sleep(200);
//				Element_isdisplayed(ZoomInBtn);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully displayed in 'Find a club / Locations' page");
//				Log.info("Map Zoom In Button is successfully displayed in 'Find a club / Locations' page");
//		
//				Element_isdisplayed(ZoomOutBtn);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully displayed and by default disabled in 'Find a club / Locations' page");
//				Log.info("Map Zoom Out Button is successfully displayed and by default disabled in 'Find a club / Locations' page");
		
				
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
				
				
				
			}

		}


public void Validate_ZoomIn_btn(String Value,  String page_title ) throws Exception {
	
			if (Value.equalsIgnoreCase("Validate_ZoomIn_btn")) {
	
				home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
				
//				click(Map_typeswitch_btn);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
//				Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
		
				click(ZoomInBtn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully clicked in 'Find a club / Locations' page");
				Log.info("Map Zoom In Button is successfully clicked in 'Find a club / Locations' page");
				Thread.sleep(200);
//				Element_isdisplayed(ZoomOutBtn);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully displayed and by default disabled in 'Find a club / Locations' page");
//				Log.info("Map Zoom Out Button is successfully displayed and by default disabled in 'Find a club / Locations' page");
		
				
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
				
				
				
			}

		}

	

public void Validate_ZoomOut_btn(String Value,  String page_title ) throws Exception {
	
			if (Value.equalsIgnoreCase("Validate_ZoomOut_btn")) {
	
				home.Navigate_to_Locations_page("Navigate_to_Locations_page", page_title);
				
//				click(Map_typeswitch_btn);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
//				Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
		
				click(ZoomInBtn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully clicked in 'Find a club / Locations' page");
				Log.info("Map Zoom In Button is successfully clicked in 'Find a club / Locations' page");
				Thread.sleep(200);
				click(ZoomOutBtn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully clicked in 'Find a club / Locations' page");
				Log.info("Map Zoom Out Button is successfully clicked in 'Find a club / Locations' page");
				Thread.sleep(200);
				
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
				
				
				
			}

		}

	

public void Validate_MAP_in_resultspage(String Value, String page_title,  String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_MAP_in_resultspage")) {

			Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title,  country_value,state_value,result_url,zipcode,city_name);
	
			Element_isdisplayed(Map_resultpage);
			
			ExtentTestManager.getTest().log(Status.PASS, "Map is successfully displayed on 'Find Club results' page");
			Log.info("Map is successfully displayed on 'Find Club results' page");
		
			}

		}


public void Validate_IconDes_map_in_Res_page(String Value, String page_title,  String country_value, String state_value, String result_url, String zipcode, String city_name, String Icon_des_ip) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_IconDes_map_in_Res_page")) {

			Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title,  country_value,state_value,result_url,zipcode,city_name);
	
				Element_isdisplayed(IconDes_map);
				String des=driver.findElement(IconDes_map).getText().trim();
				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find club Results' page" );
				
				ExtentTestManager.getTest().log(Status.PASS, "Map Icon Description's ("+Icon_des_ip+") successfully displayed and validated on 'Find club Results' page");
				Log.info("Map Icon Description's ("+Icon_des_ip+")is successfully displayed and validated on 'Find club Results' page");
		
				
				
			}

		}


public void Validate_Movebtns_map_in_Res_page(String Value, String page_title,  String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_Movebtns_map_in_Res_page")) {

			Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
	
//				Element_isdisplayed(map_move_btns);
				Element_isdisplayed(map_move);
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
				List<WebElement> move_btns=driver.findElements(map_move_btns);
				for(WebElement btn:move_btns)
					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find club Results' page");
			
//				ExtentTestManager.getTest().log(Status.PASS, "All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
//				Log.info("All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
		
				Element_isdisplayed(move_top);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move Up Button is successfully displayed in 'Find club Results' page");
				Log.info("Map Move Up Button is successfully displayed in 'Find club Results' page");
		
				Element_isdisplayed(move_down);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move down Button is successfully displayed in 'Find club Results' page");
				Log.info("Map Move down Button is successfully displayed in 'Find club Results' page");
		
				Element_isdisplayed(move_left);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move Left Button is successfully displayed in 'Find club Results' page");
				Log.info("Map Move Left Button is successfully displayed in 'Find club Results' page");
		
				Element_isdisplayed(move_right);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move Right Button is successfully displayed in 'Find club Results' page");
				Log.info("Map Move Right Button is successfully displayed in 'Find club Results' page");
		
				
			}

		}


public void Validate_zoom_out_in_maptype_btns_Res(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_zoom_out_in_maptype_btns_Res")) {

				Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title,  country_value,state_value,result_url,zipcode,city_name);
				
				Element_isdisplayed(Map_typeswitch_btn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully displayed in 'Find club Results' page");
				Log.info("Map Type Switcher Button is successfully displayed in 'Find club Results' page");
		
				Element_isdisplayed(ZoomInBtn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully displayed in 'Find club Results' page");
				Log.info("Map Zoom In Button is successfully displayed in 'Find club Results' page");
		
				Element_isdisplayed(ZoomOutBtn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully displayed and by default disabled in 'Find club Results' page");
				Log.info("Map Zoom Out Button is successfully displayed and by default disabled in 'Find club Results' page");
		
				
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
				
				
				
			}

		}


public void Validate_Move_up_in_Res_page(String Value, String page_title,  String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_Move_up_in_Res_page")) {

				Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title,  country_value,state_value,result_url,zipcode,city_name);

//				Element_isdisplayed(map_move_btns);
				Element_isdisplayed(map_move);
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
//				ExtentTestManager.getTest().log(Status.PASS, "All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
//				Log.info("All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
		
				click(move_top);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move Up Button is successfully clicked in 'Find club Results' page");
				Log.info("Map Move Up Button is successfully clicked in 'Find club Results' page");
				Thread.sleep(200);
//				Element_isdisplayed(move_down);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Move down Button is successfully displayed in 'Find a club / Locations' page");
//				Log.info("Map Move down Button is successfully displayed in 'Find a club / Locations' page");
//		
//				Element_isdisplayed(move_left);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Move Left Button is successfully displayed in 'Find a club / Locations' page");
//				Log.info("Map Move Left Button is successfully displayed in 'Find a club / Locations' page");
//		
//				Element_isdisplayed(move_right);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Move Right Button is successfully displayed in 'Find a club / Locations' page");
//				Log.info("Map Move Right Button is successfully displayed in 'Find a club / Locations' page");
//		
				
			}

		}


public void Validate_Move_down_in_Res_page(String Value, String page_title,  String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_Move_down_in_Res_page")) {

				Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title,  country_value,state_value,result_url,zipcode,city_name);
				
//				Element_isdisplayed(map_move_btns);
				Element_isdisplayed(map_move);
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
//				ExtentTestManager.getTest().log(Status.PASS, "All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
//				Log.info("All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
		
				click(move_down);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move down Button is successfully clicked in 'Find club Results' page");
				Log.info("Map Move down Button is successfully clicked in 'Find club Results' page");
				Thread.sleep(200);
				
			}

		}

	

public void Validate_Move_left_in_Res_page(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_Move_left_in_Res_page")) {

				Validate_sort_show_newsearch("Validate_sort_show_newsearch",  page_title, country_value,state_value,result_url,zipcode,city_name);
				
//				Element_isdisplayed(map_move_btns);
				Element_isdisplayed(map_move);
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
//				ExtentTestManager.getTest().log(Status.PASS, "All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
//				Log.info("All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
		
				click(move_left);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move left Button is successfully clicked in 'Find club Results' page");
				Log.info("Map Move left Button is successfully clicked in 'Find club Results' page");
				Thread.sleep(200);
				
			}

		}

	

public void Validate_Move_right_in_Res_page(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_Move_right_in_Res_page")) {

				Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
				
//				Element_isdisplayed(map_move_btns);
				Element_isdisplayed(map_move);
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
//				ExtentTestManager.getTest().log(Status.PASS, "All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
//				Log.info("All move buttons (up, down, right, left) of Map are successfully displayed in 'Find a club / Locations' page");
		
				click(move_right);
				ExtentTestManager.getTest().log(Status.PASS, "Map Move right Button is successfully clicked in 'Find club Results' page");
				Log.info("Map Move right Button is successfully clicked in 'Find club Results' page");
				Thread.sleep(200);
				
			}

		}

	

public void Validate_Maptypeswitcher_btn_Res(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_Maptypeswitcher_btn_Res")) {

				Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title,  country_value,state_value,result_url,zipcode,city_name);
				
				click(Map_typeswitch_btn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find club Results' page");
				Log.info("Map Type Switcher Button is successfully clicked in 'Find club Results' page");
				Thread.sleep(200);
//				Element_isdisplayed(ZoomInBtn);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully displayed in 'Find a club / Locations' page");
//				Log.info("Map Zoom In Button is successfully displayed in 'Find a club / Locations' page");
//		
//				Element_isdisplayed(ZoomOutBtn);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully displayed and by default disabled in 'Find a club / Locations' page");
//				Log.info("Map Zoom Out Button is successfully displayed and by default disabled in 'Find a club / Locations' page");
		
				
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
				
				
				
			}

		}


public void Validate_ZoomIn_btn_Res(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_ZoomIn_btn_Res")) {

				Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
				
//				click(Map_typeswitch_btn);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
//				Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
		
				click(ZoomInBtn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully clicked in 'Find club Results' page");
				Log.info("Map Zoom In Button is successfully clicked in 'Find club Results' page");
				Thread.sleep(200);
//				Element_isdisplayed(ZoomOutBtn);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully displayed and by default disabled in 'Find a club / Locations' page");
//				Log.info("Map Zoom Out Button is successfully displayed and by default disabled in 'Find a club / Locations' page");
		
				
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
				
				
				
			}

		}

	

public void Validate_ZoomOut_btn_Res(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_ZoomOut_btn_Res")) {

				Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
				
//				click(Map_typeswitch_btn);
//				ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
//				Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
		
				click(ZoomInBtn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully clicked in 'Find club Results' page");
				Log.info("Map Zoom In Button is successfully clicked in 'Find club Results' page");
				Thread.sleep(200);
				click(ZoomOutBtn);
				ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully clicked in 'Find club Results' page");
				Log.info("Map Zoom Out Button is successfully clicked in 'Find club Results' page");
				Thread.sleep(200);
				
//				String des=driver.findElement(IconDes_map).getText().trim();
//				Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//				List<WebElement> move_btns=driver.findElements(map_move_btns);
//				for(WebElement btn:move_btns)
//					
//					Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
			
				
				
				
			}

		}

	


public void Validate_clubs(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {

if (Value.equalsIgnoreCase("Validate_clubs")) {

			Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
			
			Select select = new Select(driver.findElement(show_dd));  
			 select.selectByVisibleText("50");
		     Thread.sleep(200);
			
//			click(Map_typeswitch_btn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
//			Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
	
//			click(ZoomInBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
//			click(ZoomOutBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
			
//			String des=driver.findElement(IconDes_map).getText().trim();
//			Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//			List<WebElement> move_btns=driver.findElements(map_move_btns);
//			for(WebElement btn:move_btns)
//				
//				Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
		
			Element_isdisplayed(search_title);
			String search_Title = driver.findElement(search_title).getText();
			ExtentTestManager.getTest().log(Status.PASS, search_Title);
			Log.info(search_Title);
			
			boolean next_click=false;
			boolean clubnamefound=false;
			
			do {
			
			int rows_count=driver.findElements(parentrows).size();
			
			List<WebElement> S_nos=driver.findElements(S_Nos);
			List<WebElement> Rows_data=driver.findElements(rows_data);	
			//div[@class='colclass-sm-7 col-xs-6']
			
			
			
			for(int i=0; i<rows_count; i++) {
				
				WebElement data=Rows_data.get(i);
				WebElement no=S_nos.get(i);
//				String clubinfo=data.findElement(By.xpath("//div[@class='colclass-sm-7 col-xs-6']")).getText();
//				String[] clubdata= clubinfo.split("\n");
//				String clubname=clubdata[0];
//				String clubaddress=clubdata[1]+", "+clubdata[2];
//				String clubmobile=clubdata[3];
//				System.out.println(no.getText()+". Club name: "+clubname +"\nClub address: "+clubaddress+"\nclub mobile: "+clubmobile);
				
				if(data.isDisplayed()) {
				ExtentTestManager.getTest().log(Status.PASS,  "\n"+no.getText().trim()+". "+data.getText());
				Log.info("\n"+no.getText().trim()+". "+data.getText());

				}
				
			}
		
			int next_count=driver.findElements(Next).size();
			if(next_count==1)
			{
//				MoveToElement(Next);
				click(Next);
				next_click =true;
				
			}	
			
			else	next_click=false;
			
		}
		while(next_click);
			
		}

	}



public void Validate_all_clubfields(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {

if (Value.equalsIgnoreCase("Validate_all_clubfields")) {

			Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
			
			Select select = new Select(driver.findElement(show_dd));  
			 select.selectByVisibleText("50");
		     Thread.sleep(200);
			
			
//			click(Map_typeswitch_btn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
//			Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
	
//			click(ZoomInBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
//			click(ZoomOutBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
			
//			String des=driver.findElement(IconDes_map).getText().trim();
//			Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//			List<WebElement> move_btns=driver.findElements(map_move_btns);
//			for(WebElement btn:move_btns)
//				
//				Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
		
			Element_isdisplayed(search_title);
			String search_Title = driver.findElement(search_title).getText();
			ExtentTestManager.getTest().log(Status.PASS, search_Title);
			Log.info(search_Title);
			
			boolean next_click=false;
//			boolean clubnamefound=false;
			
			do {
			
			int rows_count=driver.findElements(clubname).size();
			
			List<WebElement> S_nos=driver.findElements(S_Nos);
			List<WebElement> Rows_data=driver.findElements(rows_data);	
			List<WebElement> Clubnames=driver.findElements(clubname);	
			List<WebElement> Clubaddress=driver.findElements(clubaddress);	
			List<WebElement> Clubnumbers=driver.findElements(clubphone);	
			List<WebElement> CT=driver.findElements(classtimes);	
			List<WebElement> FA=driver.findElements(freepass);	
			List<WebElement> CI=driver.findElements(clubinfo);	
			
//			System.out.println("C T: "+CT.size()); 
			List<WebElement> sub_Rows_data=driver.findElements(By.xpath("//div[@class='row PaddingLeft10 PaddingTopBottom5']"));
			
			int row_Value=0;
			for(int i=0; i<rows_count; i++) {
				
				WebElement data=Rows_data.get(i);
				WebElement no=S_nos.get(i);
				WebElement clubName=Clubnames.get(i);
				WebElement clubAddress=Clubaddress.get(i);
				WebElement clubMobile=Clubnumbers.get(i);
				WebElement sbd=sub_Rows_data.get(i);
				if(i==0)  row_Value=1;
				else row_Value=row_Value+2;
				
				By classTimes= By.xpath("//tbody/tr["+row_Value+"]//div[@class='row PaddingLeft10 PaddingTopBottom5']//input[@value='Class Times']");
				By freePass= By.xpath("//tbody/tr["+row_Value+"]//div[@class='row PaddingLeft10 PaddingTopBottom5']//input[@value='Free Pass']");
				By clubInfo= By.xpath("//tbody/tr["+row_Value+"]//div[@class='row PaddingLeft10 PaddingTopBottom5']//input[@value='Club Info']");
				
//				WebElement classTimes=CT.get(i);
//				WebElement freePass=FA.get(i);
//				WebElement clubInfo=CI.get(i);
				
//						driver.findElement(By.xpath("//tbody//tr[7]//td[2]//fieldset"));
				
//				String clubinfo=data.findElement(By.xpath("//div[@class='colclass-sm-7 col-xs-6']")).getText();
//				String[] clubdata= clubinfo.split("\n");
//				String clubname=clubdata[0];
//				String clubaddress=clubdata[1]+", "+clubdata[2];
//				String clubmobile=clubdata[3];
//				System.out.println(no.getText()+". Club name: "+clubname +"\nClub address: "+clubaddress+"\nclub mobile: "+clubmobile);
				
				
				MoveTo_webelement(sbd);
				Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
//				MoveTo_webelement(clubName);
				Assert.assertTrue(no.isDisplayed(), "S No is not displayed");
				MoveTo_webelement(no);
				String name=clubName.getText();
				ExtentTestManager.getTest().log(Status.PASS,  no.getText().trim()+". Club name: "+name);
				Log.info(no.getText().trim()+". Club name: "+name);

				Assert.assertTrue(clubAddress.isDisplayed(), "Club Address is not displayed");
//				MoveTo_webelement(clubAddress);
				String address=clubAddress.getText().replaceAll("\n", ", ");
				ExtentTestManager.getTest().log(Status.PASS,  "Club address: "+address);
				Log.info( "Club address: "+address);

				Assert.assertTrue(clubMobile.isDisplayed(), "Club Mobile is not displayed");
//				MoveTo_webelement(clubMobile);
				String mobile=clubMobile.getText();
				ExtentTestManager.getTest().log(Status.PASS,  "Club Mobile: "+mobile);
				Log.info("Club Mobile: "+mobile);
				
//				MoveTo_webelement(clubMobile);
				Assert.assertTrue(driver.findElement(classTimes).isDisplayed(), "class times button is not displayed");
				ExtentTestManager.getTest().log(Status.PASS,  "class times button is successfully displayed");
				Log.info("class times button is successfully displayed");
//				MoveToElement(classTimes);
				Assert.assertTrue(driver.findElement(freePass).isDisplayed(), "free pass button is not displayed");
				ExtentTestManager.getTest().log(Status.PASS,  "free pass button is successfully displayed");
				Log.info("free pass button is successfully displayed");
				
				Assert.assertTrue(driver.findElement(clubInfo).isDisplayed(), "club info button is not displayed");
				ExtentTestManager.getTest().log(Status.PASS,  "club info button is successfully displayed");
				Log.info("club info button is successfully displayed");
				

			}
			

			int next_count=driver.findElements(Next).size();
			if(next_count==1)
			{
				MoveToElement(Next);
				click(Next);
				next_click =true;
				
			}	
			
			else	next_click=false;
			
		}
		while(next_click);
			
		}

	}

	

public void Validate_select_club(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name, String clubname_ip) throws Exception {

	if (Value.equalsIgnoreCase("Validate_select_club")) {

			Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
		
			Select select = new Select(driver.findElement(show_dd));  
			 select.selectByVisibleText("50");
		     Thread.sleep(200);
		     
//			click(Map_typeswitch_btn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
//			Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
	
//			click(ZoomInBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
//			click(ZoomOutBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
			
//			String des=driver.findElement(IconDes_map).getText().trim();
//			Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//			List<WebElement> move_btns=driver.findElements(map_move_btns);
//			for(WebElement btn:move_btns)
//				
//				Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
		
			Element_isdisplayed(search_title);
			String search_Title = driver.findElement(search_title).getText();
			ExtentTestManager.getTest().log(Status.PASS, search_Title);
			Log.info(search_Title);
			
			boolean next_click=false;
			boolean clubnamefound=false;
			
			do {
				
				int rows_count=driver.findElements(clubname).size();
				
				List<WebElement> S_nos=driver.findElements(S_Nos);
				List<WebElement> Rows_data=driver.findElements(rows_data);	
				List<WebElement> Clubnames=driver.findElements(clubname);	
				List<WebElement> Clubaddress=driver.findElements(clubaddress);	
				List<WebElement> Clubnumbers=driver.findElements(clubphone);	
				List<WebElement> CT=driver.findElements(classtimes);	
				List<WebElement> FA=driver.findElements(freepass);	
				List<WebElement> CI=driver.findElements(clubinfo);	
				
				
				
				for(int i=0; i<rows_count; i++) {
					
					WebElement data=Rows_data.get(i);
					WebElement no=S_nos.get(i);
					WebElement clubName=Clubnames.get(i);
					WebElement clubAddress=Clubaddress.get(i);
					WebElement clubMobile=Clubnumbers.get(i);
					
					WebElement classTimes=CT.get(i);
					WebElement freePass=FA.get(i);
					WebElement clubInfo=CI.get(i);
					
					
					Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
					Assert.assertTrue(no.isDisplayed(), "S No is not displayed");
//					Assert.assertEquals(clubName.getText().trim().toUpperCase(), clubname_ip.trim().toUpperCase(), "Club name is not validated");
					
					String clubname_op =clubName.getText().trim();
					
					
					if(clubname_op.equalsIgnoreCase(clubname_ip.trim())) {
						
						MoveTo_webelement(clubName);
						clubName.click();
						ExtentTestManager.getTest().log(Status.PASS,  "Successfully clicked on the club: "+clubname_ip+" in Locations result page");
						Log.info( "Successfully clicked on the club: "+clubname_ip+" in Locations result page");
						Thread.sleep(200);
						ArrayList<String>	tab= new ArrayList<String>(driver.getWindowHandles());
						if(tab.size()>=2) driver.switchTo().window(tab.get(1));
						
						String title=driver.getTitle();
						Assert.assertTrue(title.toUpperCase().trim().contains(clubname_ip.toUpperCase().trim()), "Navigated to url: '"+driver.getCurrentUrl()+"' title : '"+title+"' page instead of navigating to club: "+clubname_ip+" details page up on clicking  club: "+clubname_ip + "link");
						ExtentTestManager.getTest().log(Status.PASS,  "Successfully navigated to "+driver.getTitle()+" page");
						Log.info( "Successfully navigated to "+driver.getTitle()+" page");
						
						
						Thread.sleep(200);
						clubnamefound=true;
						break;
					}
					
					}
				
				if(clubnamefound)break;
				
				int next_count=driver.findElements(Next).size();
				if(next_count==1)
				{
//					MoveToElement(Next);
					click(Next);
					next_click =true;
					
				}	
				
				else	next_click=false;
				
			}
			while(next_click);
			
							
				if(!clubnamefound) 
					throw new Exception("Club name: "+clubname_ip+" is not matched with any of the clubs in Locations results page");
				
				
				

			
			
		}

	}

	

public void Validate_desired_clubinfo(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name, String clubname_ip, String clubaddress_ip, String clubmobile_ip  ) throws Exception {

	if (Value.equalsIgnoreCase("Validate_desired_clubinfo")) {

			Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
			
			Select select = new Select(driver.findElement(show_dd));  
			 select.selectByVisibleText("50");
		     Thread.sleep(200);
			
//			click(Map_typeswitch_btn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
//			Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
	
//			click(ZoomInBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
//			click(ZoomOutBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
			
//			String des=driver.findElement(IconDes_map).getText().trim();
//			Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//			List<WebElement> move_btns=driver.findElements(map_move_btns);
//			for(WebElement btn:move_btns)
//				
//				Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
		
			Element_isdisplayed(search_title);
			String search_Title = driver.findElement(search_title).getText();
			ExtentTestManager.getTest().log(Status.PASS, search_Title);
			Log.info(search_Title);
			
			boolean next_click=false;
			boolean clubnamefound=false;
			
			do {
				
				int rows_count=driver.findElements(parentrows).size();
				
				List<WebElement> S_nos=driver.findElements(S_Nos);
				List<WebElement> Rows_data=driver.findElements(rows_data);	
				List<WebElement> Clubnames=driver.findElements(clubname);	
				List<WebElement> Clubaddress=driver.findElements(clubaddress);	
				List<WebElement> Clubnumbers=driver.findElements(clubphone);	
				List<WebElement> CT=driver.findElements(classtimes);	
				List<WebElement> FA=driver.findElements(freepass);	
				List<WebElement> CI=driver.findElements(clubinfo);	
				
				
				
				
				for(int i=0; i<rows_count; i++) {
					
					WebElement data=Rows_data.get(i);
					WebElement no=S_nos.get(i);
					WebElement clubName=Clubnames.get(i);
					WebElement clubAddress=Clubaddress.get(i);
					WebElement clubMobile=Clubnumbers.get(i);
					
					WebElement classTimes=CT.get(i);
					WebElement freePass=FA.get(i);
					WebElement clubInfo=CI.get(i);
					
					
					Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
					Assert.assertTrue(no.isDisplayed(), "S No is not displayed");
//					Assert.assertEquals(clubName.getText().trim().toUpperCase(), clubname_ip.trim().toUpperCase(), "Club name is not validated");
					
					String clubname_op =clubName.getText().trim();
					
					
					if(clubname_op.equalsIgnoreCase(clubname_ip.trim())) {
						
						MoveTo_webelement(clubName);
//						clubName.click();
						ExtentTestManager.getTest().log(Status.PASS,  "Successfully validated the club: "+clubname_ip+" in Locations search result page");
						Log.info( "Successfully validated the club: "+clubname_ip+" in Locations search result page");

						
//						ArrayList<String>	tab= new ArrayList<String>(driver.getWindowHandles());
//						if(tab.size()>=2) driver.switchTo().window(tab.get(1));
						
						String clb_address= clubAddress.getText().replaceAll("\n", ", ").trim();
						String clb_mobile= clubMobile.getText().replaceAll("[^0-9]", "").trim();
//						Assert.assertTrue(title.toUpperCase().trim().contains(clubname_ip.toUpperCase().trim()), "Navigated to url: '"+driver.getCurrentUrl()+"' title : '"+title+"' page instead of navigating to club: "+clubname_ip+" details page up on clicking  club: "+clubname_ip + "link");
//						ExtentTestManager.getTest().log(Status.PASS,  "Successfully navigated to "+driver.getTitle()+" page");
//						Log.info( "Successfully navigated to "+driver.getTitle()+" page");
						
						Assert.assertEquals(clb_address.toUpperCase(), clubaddress_ip.toUpperCase().trim(), "'"+clubname_ip+"' club Address: '"+clubaddress_ip+"' is not validated in Locations search results page");
						ExtentTestManager.getTest().log(Status.PASS,  "Successfully validated the Address: '"+clubaddress_ip+"' of club: '"+clubname_ip+"' in Locations search result page");
						Log.info( "Successfully validated the Address: '"+clubaddress_ip+"' of club: '"+clubname_ip+"' in Locations search result page");
						
						Assert.assertEquals(clb_mobile.toUpperCase(), clubmobile_ip.toUpperCase().trim(), "'"+clubname_ip+"' club mobile: '"+clubmobile_ip+"' is not validated in Locations search results page");
						ExtentTestManager.getTest().log(Status.PASS,  "Successfully validated the mobile number: '"+clubmobile_ip+"' of club: '"+clubname_ip+"' in Locations search result page");
						Log.info( "Successfully validated the the mobile number: '"+clubmobile_ip+"' of club: '"+clubname_ip+"' in Locations search result page");
						
						
						Thread.sleep(200);
						clubnamefound=true;
						break;
						
					}
					
					}
					
				if(clubnamefound)break;
				
				int next_count=driver.findElements(Next).size();
				
				if(next_count==1)
				{
					MoveToElement(Next);
					click(Next);
					next_click =true;
					
				}	
				
				else	next_click=false;
				
			}
			while(next_click);
			
							
				if(!clubnamefound) 
					throw new Exception("Club name: "+clubname_ip+" is not matched with any of the clubs in Locations results page");
				
			
		}

	}

		

public void Validate_club_classtimes_btn(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name, String clubname_ip) throws Exception {

	if (Value.equalsIgnoreCase("Validate_club_classtimes_btn")) {

			Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
			
			Select select = new Select(driver.findElement(show_dd));  
			 select.selectByVisibleText("50");
		     Thread.sleep(200);
			
//			click(Map_typeswitch_btn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
//			Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
	
//			click(ZoomInBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
//			click(ZoomOutBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
			
//			String des=driver.findElement(IconDes_map).getText().trim();
//			Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//			List<WebElement> move_btns=driver.findElements(map_move_btns);
//			for(WebElement btn:move_btns)
//				
//				Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
		
			Element_isdisplayed(search_title);
			String search_Title = driver.findElement(search_title).getText();
			ExtentTestManager.getTest().log(Status.PASS, search_Title);
			Log.info(search_Title);
			
			boolean next_click=false;
			boolean clubnamefound=false;
			
			do {
				
				int rows_count=driver.findElements(parentrows).size();
				
				List<WebElement> S_nos=driver.findElements(S_Nos);
				List<WebElement> Rows_data=driver.findElements(rows_data);	
				List<WebElement> Clubnames=driver.findElements(clubname);	
				List<WebElement> Clubaddress=driver.findElements(clubaddress);	
				List<WebElement> Clubnumbers=driver.findElements(clubphone);	
				List<WebElement> CT=driver.findElements(classtimes);	
				List<WebElement> FA=driver.findElements(freepass);	
				List<WebElement> CI=driver.findElements(clubinfo);	
				
				
				
				
				for(int i=0; i<rows_count; i++) {
					
					WebElement data=Rows_data.get(i);
					WebElement no=S_nos.get(i);
					WebElement clubName=Clubnames.get(i);
					WebElement clubAddress=Clubaddress.get(i);
					WebElement clubMobile=Clubnumbers.get(i);
					
					WebElement classTimes=CT.get(i);
					WebElement freePass=FA.get(i);
					WebElement clubInfo=CI.get(i);
					
					
					Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
					Assert.assertTrue(no.isDisplayed(), "S No is not displayed");
//					Assert.assertEquals(clubName.getText().trim().toUpperCase(), clubname_ip.trim().toUpperCase(), "Club name is not validated");
					
					String clubname_op =clubName.getText().trim();
					
					
					if(clubname_op.equalsIgnoreCase(clubname_ip.trim())) {
						
						MoveTo_webelement(clubName);
//						clubName.click();
						
						ExtentTestManager.getTest().log(Status.PASS,  "Successfully validated the club: "+clubname_ip+" in Locations search result page");
						Log.info( "Successfully validated the club: "+clubname_ip+" in Locations search result page");

						
						Assert.assertTrue(classTimes.isDisplayed(), "class times button is not displayed");
						ExtentTestManager.getTest().log(Status.PASS,  "class times button is successfully displayed");
						Log.info("class times button is successfully displayed");
						
//						Assert.assertTrue(freePass.isDisplayed(), "free pass button is not displayed");
//						ExtentTestManager.getTest().log(Status.PASS,  "free pass button is successfully displayed");
//						Log.info("free pass button is successfully displayed");
//						
//						Assert.assertTrue(clubInfo.isDisplayed(), "club info button is not displayed");
//						ExtentTestManager.getTest().log(Status.PASS,  "club info button is successfully displayed");
//						Log.info("club info button is successfully displayed");
//						if(data.findElement(By.xpath("//input[@value='Class Times']")).isDisplayed()) {
							MoveTo_webelement(classTimes);
							classTimes.click();
							ExtentTestManager.getTest().log(Status.PASS,  "Successfully clicked on the class times button of club: "+clubname_ip+" in Locations result page");
							Log.info( "Successfully clicked on the class times button of club: "+clubname_ip+" in Locations result page");
							
							Thread.sleep(200);
							
							ArrayList<String>	tab= new ArrayList<String>(driver.getWindowHandles());
							if(tab.size()>=2) driver.switchTo().window(tab.get(1));
							
							String title=driver.getTitle();
							Assert.assertTrue(title.toUpperCase().trim().contains(clubname_ip.toUpperCase().trim()), "Navigated to url: '"+driver.getCurrentUrl()+"' title : '"+title+"' page instead of navigating to club: "+clubname_ip+"'s Class Schedule page up on clicking  club: "+clubname_ip + "link");
							ExtentTestManager.getTest().log(Status.PASS,  "Successfully navigated to "+driver.getTitle()+" page");
							Log.info( "Successfully navigated to "+driver.getTitle()+" page");
					
						
						
						Thread.sleep(200);
						clubnamefound=true;
						break;
					}
					
					}
				
				if(clubnamefound)break;
				
				int next_count=driver.findElements(Next).size();
				if(next_count==1)
				{
//					MoveToElement(Next);
					click(Next);
					next_click =true;
					
				}	
				
				else	next_click=false;
				
			}
			while(next_click);
			
							
				if(!clubnamefound) 
					throw new Exception("Club name: "+clubname_ip+" is not matched with any of the clubs in Locations results page");
				
				
				

			
			
		}

	}


public void Validate_club_freepass_btn(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name, String clubname_ip) throws Exception {

	if (Value.equalsIgnoreCase("Validate_club_freepass_btn")) {

			Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
			
			Select select = new Select(driver.findElement(show_dd));  
			 select.selectByVisibleText("50");
		     Thread.sleep(200);
			
//			click(Map_typeswitch_btn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
//			Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
	
//			click(ZoomInBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
//			click(ZoomOutBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
			
//			String des=driver.findElement(IconDes_map).getText().trim();
//			Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//			List<WebElement> move_btns=driver.findElements(map_move_btns);
//			for(WebElement btn:move_btns)
//				
//				Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
		
			Element_isdisplayed(search_title);
			String search_Title = driver.findElement(search_title).getText();
			ExtentTestManager.getTest().log(Status.PASS, search_Title);
			Log.info(search_Title);
			
			boolean next_click=false;
			boolean clubnamefound=false;
			
			do {
				
				int rows_count=driver.findElements(parentrows).size();
				
				List<WebElement> S_nos=driver.findElements(S_Nos);
				List<WebElement> Rows_data=driver.findElements(rows_data);	
				List<WebElement> Clubnames=driver.findElements(clubname);	
				List<WebElement> Clubaddress=driver.findElements(clubaddress);	
				List<WebElement> Clubnumbers=driver.findElements(clubphone);	
				List<WebElement> CT=driver.findElements(classtimes);	
				List<WebElement> FA=driver.findElements(freepass);	
				List<WebElement> CI=driver.findElements(clubinfo);	
				
				
				
				
				for(int i=0; i<rows_count; i++) {
					
					WebElement data=Rows_data.get(i);
					WebElement no=S_nos.get(i);
					WebElement clubName=Clubnames.get(i);
					WebElement clubAddress=Clubaddress.get(i);
					WebElement clubMobile=Clubnumbers.get(i);
					
					WebElement classTimes=CT.get(i);
					WebElement freePass=FA.get(i);
					WebElement clubInfo=CI.get(i);
					
					
					Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
					Assert.assertTrue(no.isDisplayed(), "S No is not displayed");
//					Assert.assertEquals(clubName.getText().trim().toUpperCase(), clubname_ip.trim().toUpperCase(), "Club name is not validated");
					
					String clubname_op =clubName.getText().trim();
					
					
					if(clubname_op.equalsIgnoreCase(clubname_ip.trim())) {
						
						MoveTo_webelement(clubName);
//						clubName.click();
						
						ExtentTestManager.getTest().log(Status.PASS,  "Successfully validated the club: "+clubname_ip+" in Locations search result page");
						Log.info( "Successfully validated the club: "+clubname_ip+" in Locations search result page");

						
//						Assert.assertTrue(classTimes.isDisplayed(), "class times button is not displayed");
//						ExtentTestManager.getTest().log(Status.PASS,  "class times button is successfully displayed");
//						Log.info("class times button is successfully displayed");
//						
						Assert.assertTrue(freePass.isDisplayed(), "free pass button is not displayed");
						ExtentTestManager.getTest().log(Status.PASS,  "free pass button is successfully displayed");
						Log.info("free pass button is successfully displayed");
						
//						Assert.assertTrue(clubInfo.isDisplayed(), "club info button is not displayed");
//						ExtentTestManager.getTest().log(Status.PASS,  "club info button is successfully displayed");
//						Log.info("club info button is successfully displayed");
						
						MoveTo_webelement(freePass);
						freePass.click();
						ExtentTestManager.getTest().log(Status.PASS,  "Successfully clicked on the free pass button of club: "+clubname_ip+" in Locations result page");
						Log.info( "Successfully clicked on the free pass button of club: "+clubname_ip+" in Locations result page");
						
						Thread.sleep(200);
						
						ArrayList<String>	tab= new ArrayList<String>(driver.getWindowHandles());
						if(tab.size()>=2) driver.switchTo().window(tab.get(1));
						
						String title=driver.getTitle();
						String url=driver.getCurrentUrl();
						Assert.assertTrue(url.toUpperCase().trim().contains("freepass".toUpperCase().trim()), "Navigated to url: '"+driver.getCurrentUrl()+"' title : '"+title+"' page instead of navigating to free pass page up on clicking  club: "+clubname_ip + "link");
						ExtentTestManager.getTest().log(Status.PASS,  "Successfully navigated to "+driver.getTitle()+" page");
						Log.info( "Successfully navigated to "+driver.getTitle()+" page");
						
						
						Thread.sleep(200);
						clubnamefound=true;
						break;
					}
					
					}
				
				if(clubnamefound)break;
				
				int next_count=driver.findElements(Next).size();
				if(next_count==1)
				{
//					MoveToElement(Next);
					click(Next);
					next_click =true;
					
				}	
				
				else	next_click=false;
				
			}
			while(next_click);
			
							
				if(!clubnamefound) 
					throw new Exception("Club name: "+clubname_ip+" is not matched with any of the clubs in Locations results page");
				
				
				

			
			
		}

	}


public void Validate_club_info_btn(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name, String clubname_ip) throws Exception {

	if (Value.equalsIgnoreCase("Validate_club_info_btn")) {

			Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
			
			Select select = new Select(driver.findElement(show_dd));  
			 select.selectByVisibleText("50");
		     Thread.sleep(200);
			
//			click(Map_typeswitch_btn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
//			Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
	
//			click(ZoomInBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
//			click(ZoomOutBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
			
//			String des=driver.findElement(IconDes_map).getText().trim();
//			Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//			List<WebElement> move_btns=driver.findElements(map_move_btns);
//			for(WebElement btn:move_btns)
//				
//				Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
		
			Element_isdisplayed(search_title);
			String search_Title = driver.findElement(search_title).getText();
			ExtentTestManager.getTest().log(Status.PASS, search_Title);
			Log.info(search_Title);
			
			boolean next_click=false;
			boolean clubnamefound=false;
			
			do {
				
				int rows_count=driver.findElements(parentrows).size();
				
				List<WebElement> S_nos=driver.findElements(S_Nos);
				List<WebElement> Rows_data=driver.findElements(rows_data);	
				List<WebElement> Clubnames=driver.findElements(clubname);	
				List<WebElement> Clubaddress=driver.findElements(clubaddress);	
				List<WebElement> Clubnumbers=driver.findElements(clubphone);	
				List<WebElement> CT=driver.findElements(classtimes);	
				List<WebElement> FA=driver.findElements(freepass);	
				List<WebElement> CI=driver.findElements(clubinfo);	
				
				
				
				
				for(int i=0; i<rows_count; i++) {
					
					WebElement data=Rows_data.get(i);
					WebElement no=S_nos.get(i);
					WebElement clubName=Clubnames.get(i);
					WebElement clubAddress=Clubaddress.get(i);
					WebElement clubMobile=Clubnumbers.get(i);
					
					WebElement classTimes=CT.get(i);
					WebElement freePass=FA.get(i);
					WebElement clubInfo=CI.get(i);
					
					
					Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
					Assert.assertTrue(no.isDisplayed(), "S No is not displayed");
//					Assert.assertEquals(clubName.getText().trim().toUpperCase(), clubname_ip.trim().toUpperCase(), "Club name is not validated");
					
					String clubname_op =clubName.getText().trim();
					
					
					if(clubname_op.equalsIgnoreCase(clubname_ip.trim())) {
						
						MoveTo_webelement(clubName);
//						clubName.click();
						
						ExtentTestManager.getTest().log(Status.PASS,  "Successfully validated the club: "+clubname_ip+" in Locations search result page");
						Log.info( "Successfully validated the club: "+clubname_ip+" in Locations search result page");

						
//						Assert.assertTrue(classTimes.isDisplayed(), "class times button is not displayed");
//						ExtentTestManager.getTest().log(Status.PASS,  "class times button is successfully displayed");
//						Log.info("class times button is successfully displayed");
						
//						Assert.assertTrue(freePass.isDisplayed(), "free pass button is not displayed");
//						ExtentTestManager.getTest().log(Status.PASS,  "free pass button is successfully displayed");
//						Log.info("free pass button is successfully displayed");
//						
						Assert.assertTrue(clubInfo.isDisplayed(), "club info button is not displayed");
						ExtentTestManager.getTest().log(Status.PASS,  "club info button is successfully displayed");
						Log.info("club info button is successfully displayed");
						
						MoveTo_webelement(clubInfo);
						clubInfo.click();
						ExtentTestManager.getTest().log(Status.PASS,  "Successfully clicked on the club info button of club: "+clubname_ip+" in Locations result page");
						Log.info( "Successfully clicked on the club info button of club: "+clubname_ip+" in Locations result page");
						
						Thread.sleep(200);
						
//						ArrayList<String>	tab= new ArrayList<String>(driver.getWindowHandles());
//						if(tab.size()>=2) driver.switchTo().window(tab.get(1));
//						
//						String title=driver.getTitle();
						Element_isdisplayed(clubinfo_section);
						MoveToElement(view_full_clb_detail);
//						Assert.assertTrue(title.toUpperCase().trim().contains(clubname_ip.toUpperCase().trim()), "Navigated to url: '"+driver.getCurrentUrl()+"' title : '"+title+"' page instead of navigating to club: "+clubname_ip+"'s Class Schedule page up on clicking  club: "+clubname_ip + "link");
						ExtentTestManager.getTest().log(Status.PASS,  "Club Info section is Successfully displayed in Locations search results page");
						Log.info( "Club Info section is Successfully displayed in Locations search results page");
						
						
						Thread.sleep(1000);
						clubnamefound=true;
						break;
					}
					
					}
				
				if(clubnamefound)break;
				
				int next_count=driver.findElements(Next).size();
				if(next_count==1)
				{
//					MoveToElement(Next);
					click(Next);
					next_click =true;
					
				}	
				
				else	next_click=false;
				
			}
			while(next_click);
			
							
				if(!clubnamefound) 
					throw new Exception("Club name: "+clubname_ip+" is not matched with any of the clubs in Locations results page");
				
				
				

			
			
		}

	}

			

public void Validate_show_filter(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name, String show_dd_value) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_show_filter")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
	
	
	 Select select = new Select(driver.findElement(show_dd));  
	 String default_option= select.getFirstSelectedOption().getText().trim();
	 
	 if(show_dd_value.trim().equalsIgnoreCase(default_option.trim())) {
		 
		 Log.info("Show dropdown option: "+ show_dd_value+ " is by default selected in Locations search result page");
	     ExtentTestManager.getTest().log(Status.PASS, "Show dropdown option: "+ show_dd_value+ " is by default selected in Locations search result page");
	     
	 }
	 else {
		 
	 select.selectByVisibleText(show_dd_value.trim());
	 
	 Log.info("Show dropdown option: "+ show_dd_value+ " is successfully selected in Locations search result page");
     ExtentTestManager.getTest().log(Status.PASS, "Show dropdown option: "+ show_dd_value+ " is successfully selected in Locations search result page");
     
	 }
//	 Assert.assertEquals(default_option.toUpperCase(), show_dd_value.trim().toUpperCase(), "Show dropdown default option not validated in Locations search result page");
	 
     Thread.sleep(200);
     
     int rows_count=driver.findElements(parentrows).size();
     Assert.assertTrue(rows_count<= Integer.parseInt(show_dd_value.trim()), "show filter assertion failed actual rows count ("+ rows_count+") >= expected rows count input ("+show_dd_value+")" );
     Log.info("show filter applied successfully for the show dropdown option:"+ show_dd_value+ " in Locations search result page");
     ExtentTestManager.getTest().log(Status.PASS, "show filter applied successfully for the show dropdown option:"+ show_dd_value+ " in Locations search result page");
     
	
	}



}


public void Validate_sortby_filter_city(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name, String sortby_dd_value) throws Exception {

	if (Value.equalsIgnoreCase("Validate_sortby_filter_city")) {
//			Validate_sortby_select_desired_option
			
		Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
			
		Select select = new Select(driver.findElement(show_dd));  
		 select.selectByVisibleText("50");
	     Thread.sleep(200);

		
			boolean next_click=false;
			
			List<String> clubs_sorted = new ArrayList<String>();
//			List<String> clubs_1 = new ArrayList<String>();
			List<String> clubs = new ArrayList<String>();
			
			do {
				
				int rows_count=driver.findElements(parentrows).size();
				
				List<WebElement> Clubnames=driver.findElements(clubname);	
				List<WebElement> Clubaddress=driver.findElements(clubaddress);	
					
				for(int i=0; i<rows_count; i++) {
					
					WebElement clubName=Clubnames.get(i);
					WebElement clubAddress=Clubaddress.get(i);
					
					Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
					Assert.assertTrue(clubAddress.isDisplayed(), "Club Address is not displayed");
					String[] club_cities = clubAddress.getText().split("\n");
					String clubname_op =clubName.getText().trim();
			
					String[] club_cities_1=club_cities[1].split(",");
					String clubcity_op =club_cities_1[0].trim();
					if(!(clubcity_op.isBlank() && clubname_op.isBlank() && clubcity_op.isEmpty() && clubname_op.isEmpty()))
					{
						clubs.add(clubcity_op+clubname_op);
					}
					}
				
				int next_count=driver.findElements(Next).size();
				if(next_count==1)
				{
//					MoveToElement(Next);
					click(Next);
					next_click =true;
					next_count=0;
				}	
				
				else	next_click=false;
				
			}
			while(next_click);
			
							
			 Select select_1 = new Select(driver.findElement(Sortby_dd));  
			 select_1.selectByVisibleText(sortby_dd_value.trim());
			 Log.info("Sort by dropdown option: "+ sortby_dd_value+ " is successfully selected in Locations search result page");
		     ExtentTestManager.getTest().log(Status.PASS, "Sort by dropdown option: "+ sortby_dd_value+ " is successfully selected in Locations search result page");

		     int previous_count=driver.findElements(Previous).size();
		     
		     while (previous_count==1) {
				click(Previous);
				previous_count=driver.findElements(Previous).size();
			}
			
		     do {
					
					int rows_count=driver.findElements(parentrows).size();
					
					List<WebElement> Clubnames=driver.findElements(clubname);	
					List<WebElement> Clubaddress=driver.findElements(clubaddress);	
					
					
					for(int i=0; i<rows_count; i++) {
						
						WebElement clubName=Clubnames.get(i);
						WebElement clubAddress=Clubaddress.get(i);
						Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
						Assert.assertTrue(clubAddress.isDisplayed(), "Club Address is not displayed");
						String[] club_cities = clubAddress.getText().split("\n");
						String clubname_op =clubName.getText();
						String[] club_cities_1=club_cities[1].split(",");
						String clubcity_op =club_cities_1[0].trim();
						if(!(clubcity_op.isBlank() && clubname_op.isBlank() && clubcity_op.isEmpty() && clubname_op.isEmpty())) {
							clubs_sorted.add(clubcity_op+clubname_op);
						}
						}
					int next_count=driver.findElements(Next).size();
					if(next_count==1)
					{
//						MoveToElement(Next);
						click(Next);
						next_click =true;
						next_count=0;
					}	
					
					else	next_click=false;
					
				}
				while(next_click);
				
		    Collections.sort(clubs);
		    int lastindex_clubs =clubs.size()-1;
		    int lastindex_clubs_sorted =clubs_sorted.size()-1;
		    
		if( clubs.get(0).equalsIgnoreCase(clubs_sorted.get(0)) && clubs.get(lastindex_clubs).equalsIgnoreCase(clubs_sorted.get(lastindex_clubs_sorted))) {
		
			  Log.info("Sort by filter applied successfully for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page");
			  ExtentTestManager.getTest().log(Status.PASS, "Sort by filter applied successfully for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page");
			     
		}
		else {
			
			throw new Exception("Sort by filter not applied for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page Expected clubs list "+clubs+" after applying sort by Actual clubs list  "+clubs_sorted);
		}
			
		}

	}


			

public void Validate_sortby_filter_club(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name, String sortby_dd_value) throws Exception {

	if (Value.equalsIgnoreCase("Validate_sortby_filter_club")) {
//			Validate_sortby_select_desired_option
			
		Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
			
		Select select = new Select(driver.findElement(show_dd));  
		 select.selectByVisibleText("50");
	     Thread.sleep(200);

		
			boolean next_click=false;
			
			List<String> clubs_sorted = new ArrayList<String>();
//			List<String> clubs_1 = new ArrayList<String>();
			List<String> clubs = new ArrayList<String>();
			
			do {
				
				int rows_count=driver.findElements(parentrows).size();
				
				List<WebElement> Clubnames=driver.findElements(clubname);	
				List<WebElement> Clubaddress=driver.findElements(clubaddress);	
					
				for(int i=0; i<rows_count; i++) {
					
					WebElement clubName=Clubnames.get(i);
					WebElement clubAddress=Clubaddress.get(i);
					
					Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
					Assert.assertTrue(clubAddress.isDisplayed(), "Club Address is not displayed");
					String[] club_cities = clubAddress.getText().split("\n");
					String clubname_op =clubName.getText().trim();
			
					String[] club_cities_1=club_cities[1].split(",");
					String clubcity_op =club_cities_1[0].trim();
					
					
//					if(!(clubcity_op.isBlank() && clubname_op.isBlank() && clubcity_op.isEmpty() && clubname_op.isEmpty()))
//					{
//						clubs.add(clubcity_op+clubname_op);
//					}
					

					if(!( clubname_op.isBlank() && clubname_op.isEmpty())) {
						clubs.add(clubname_op);
					}
					
					}
				
				int next_count=driver.findElements(Next).size();
				if(next_count==1)
				{
//					MoveToElement(Next);
					click(Next);
					next_click =true;
					next_count=0;
				}	
				
				else	next_click=false;
				
			}
			while(next_click);
			
							
			 Select select_1 = new Select(driver.findElement(Sortby_dd));  
			 select_1.selectByVisibleText(sortby_dd_value.trim());
			 Log.info("Sort by dropdown option: "+ sortby_dd_value+ " is successfully selected in Locations search result page");
		     ExtentTestManager.getTest().log(Status.PASS, "Sort by dropdown option: "+ sortby_dd_value+ " is successfully selected in Locations search result page");

		     int previous_count=driver.findElements(Previous).size();
		     
		     while (previous_count==1) {
				click(Previous);
				previous_count=driver.findElements(Previous).size();
			}
			
		     do {
					
					int rows_count=driver.findElements(parentrows).size();
					
					List<WebElement> Clubnames=driver.findElements(clubname);	
					List<WebElement> Clubaddress=driver.findElements(clubaddress);	
					
					
					for(int i=0; i<rows_count; i++) {
						
						WebElement clubName=Clubnames.get(i);
						WebElement clubAddress=Clubaddress.get(i);
						Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
						Assert.assertTrue(clubAddress.isDisplayed(), "Club Address is not displayed");
						String[] club_cities = clubAddress.getText().split("\n");
						String clubname_op =clubName.getText();
						String[] club_cities_1=club_cities[1].split(",");
						String clubcity_op =club_cities_1[0].trim();
						
//						if(!(clubcity_op.isBlank() && clubname_op.isBlank() && clubcity_op.isEmpty() && clubname_op.isEmpty())) {
//							clubs_sorted.add(clubcity_op+clubname_op);
//						}
						
						if(!( clubname_op.isBlank() && clubname_op.isEmpty())) {
							clubs_sorted.add(clubname_op);
						}
						
						
						}
					int next_count=driver.findElements(Next).size();
					if(next_count==1)
					{
//						MoveToElement(Next);
						click(Next);
						next_click =true;
						next_count=0;
					}	
					
					else	next_click=false;
					
				}
				while(next_click);
				
		    Collections.sort(clubs);
//		    Arrays.sort(clubs.toArray());
		    int lastindex_clubs =clubs.size()-1;
		    int lastindex_clubs_sorted =clubs_sorted.size()-1;
		    
//		     if(clubs.equals(clubs_sorted)) {
//		    	
//		    	 Log.info("Sort by filter applied successfully for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page");
//				  ExtentTestManager.getTest().log(Status.PASS, "Sort by filter applied successfully for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page");
//				   
//		     }
		     
		if( clubs.get(0).equalsIgnoreCase(clubs_sorted.get(0)) && clubs.get(lastindex_clubs).equalsIgnoreCase(clubs_sorted.get(lastindex_clubs_sorted))) {
		
			  Log.info("Sort by filter applied successfully for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page");
			  ExtentTestManager.getTest().log(Status.PASS, "Sort by filter applied successfully for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page");
			     
		}
		
		else {
			
			throw new Exception("Sort by filter not applied for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page Expected clubs list "+clubs+" after applying sort by Actual clubs list  "+clubs_sorted);
		}
			
		}

	}

	


public void Validate_sortby_filter_Distance(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name, String sortby_dd_value) throws Exception {

	if (Value.equalsIgnoreCase("Validate_sortby_filter_Distance")) {
//			Validate_sortby_select_desired_option
			
		Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
			
		Select select = new Select(driver.findElement(show_dd));  
		 select.selectByVisibleText("50");
	     Thread.sleep(200);

		
	     Select select_1 = new Select(driver.findElement(Sortby_dd));  
		 select_1.selectByVisibleText("Club");
		 Log.info("Sort by dropdown option: Club is successfully selected in Locations search result page");
	     ExtentTestManager.getTest().log(Status.PASS, "Sort by dropdown option: Club is successfully selected in Locations search result page");
	     Thread.sleep(200);
	     
	     
			boolean next_click=false;
			
			List<String> clubs_sorted = new ArrayList<String>();
			List<String> clubs_1 = new ArrayList<String>();
			TreeMap<Double,String> clubs = new TreeMap<Double,String>();
			
			do {
				
				int rows_count=driver.findElements(parentrows).size();
				
				List<WebElement> Clubnames=driver.findElements(clubname);	
				List<WebElement> Clubdata=driver.findElements(club_data);	
					
				for(int i=0; i<rows_count; i++) {
					
					WebElement clubName=Clubnames.get(i);
					WebElement clubAddress=Clubdata.get(i);
					
					Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
					Assert.assertTrue(clubAddress.isDisplayed(), "Club Address is not displayed");
					String[] club_distance = clubAddress.getText().split("\n");
					String clubname_op =clubName.getText().trim();
			
//					String[] club_distance_1=club_distance[4].split("\n");
					String[] Clb_dis =club_distance[4].split(":");
					
					Double Club_dis =Double.parseDouble(Clb_dis[1].replaceAll("mi", "").trim());
					if(!( clubname_op.isBlank()  && clubname_op.isEmpty()))
					{
						clubs.put(Club_dis,clubname_op);
					}
					}
				
				int next_count=driver.findElements(Next).size();
				if(next_count==1)
				{
//					MoveToElement(Next);
					click(Next);
					next_click =true;
					next_count=0;
				}	
				
				else	next_click=false;
				
			}
			while(next_click);
			
							
			 Select select_2 = new Select(driver.findElement(Sortby_dd));  
			 select_2.selectByVisibleText(sortby_dd_value.trim());
			 Log.info("Sort by dropdown option: "+ sortby_dd_value+ " is successfully selected in Locations search result page");
		     ExtentTestManager.getTest().log(Status.PASS, "Sort by dropdown option: "+ sortby_dd_value+ " is successfully selected in Locations search result page");

		     int previous_count=driver.findElements(Previous).size();
		     
		     while (previous_count==1) {
				click(Previous);
				previous_count=driver.findElements(Previous).size();
			}
			
		     do {
					
					int rows_count=driver.findElements(parentrows).size();
					
					List<WebElement> Clubnames=driver.findElements(clubname);	
					List<WebElement> Clubdata=driver.findElements(club_data);	
					
					
					for(int i=0; i<rows_count; i++) {
						
						WebElement clubName=Clubnames.get(i);
						WebElement clubAddress=Clubdata.get(i);
						
						Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
						Assert.assertTrue(clubAddress.isDisplayed(), "Club Address is not displayed");
						String[] club_distance = clubAddress.getText().split("\n");
						String clubname_op =clubName.getText().trim();
				
//						String[] club_distance_1=club_distance[4].split("\n");
						String[] Clb_dis =club_distance[4].split(":");
						String Club_dis =Clb_dis[1].trim();
						if(!(Club_dis.isBlank() && clubname_op.isBlank() && Club_dis.isEmpty() && clubname_op.isEmpty()))
						{
							clubs_sorted.add(clubname_op);
						}
						}
					int next_count=driver.findElements(Next).size();
					if(next_count==1)
					{
//						MoveToElement(Next);
						click(Next);
						next_click =true;
						next_count=0;
					}	
					
					else	next_click=false;
					
				}
				while(next_click);
				
		     
		     for (String s:clubs.values()) {
				
			clubs_1.add(s.trim());
				
			}
		     
		     
//		     System.out.println(clubs_1);
//		     System.out.println(clubs_sorted);
//		     if(clubs_1.equals(clubs_sorted))
//		     boolean Notmatch= false;
//		     for(int i=0;i<clubs_1.size()-1;i++) {
		    	 
//		    	if( ! clubs_1.get(i).equalsIgnoreCase(clubs_sorted.get(i))) {
//		    		
//		    		Log.error("Clubs not matched. Expected Club name : '"+clubs_1.get(i)+"' Actual Clib name: '"+clubs_sorted+"' ");
//					ExtentTestManager.getTest().log(Status.FAIL, "Clubs not matched. Expected Club name : '"+clubs_1.get(i)+"' Actual Clib name: '"+clubs_sorted+"' ");
//					Notmatch=true;
//		    	}
//		    
//		     }
//		     
//		     if(Notmatch)throw new Exception("Sort by filter not applied for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page Expected clubs list "+clubs_1+" after applying sort by Actual clubs list  "+clubs_sorted);
//			else {
//				 Log.info("Sort by filter applied successfully for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page");
//				  ExtentTestManager.getTest().log(Status.PASS, "Sort by filter applied successfully for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page");
//				   
//			}	
		     
		     
		     
//		     for(Map.Entry<Double, String > s: clubs.entrySet()) {}
		     
//		    clubs_1=(List<String>) clubs.values();
		     
		     
//		     if(clubs_1.equals(clubs_sorted)) {
//		    	
//		    	 Log.info("Sort by filter applied successfully for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page");
//				  ExtentTestManager.getTest().log(Status.PASS, "Sort by filter applied successfully for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page");
//				   
//		     }
//		    Collections.sort(clubs);
		     
		     
		    
		    int lastindex_clubs =clubs_1.size()-1;
		    int lastindex_clubs_sorted =clubs_sorted.size()-1;
		    
		if( clubs_1.get(0).equalsIgnoreCase(clubs_sorted.get(0)) && clubs_1.get(lastindex_clubs).equalsIgnoreCase(clubs_sorted.get(lastindex_clubs_sorted))) {
		
			  Log.info("Sort by filter applied successfully for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page");
			  ExtentTestManager.getTest().log(Status.PASS, "Sort by filter applied successfully for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page");
			     
		}
		
		else 
		{
			
			throw new Exception("Sort by filter not applied for the sort by dropdown option:"+ sortby_dd_value+ " in Locations search result page Expected clubs list "+clubs_1+" after applying sort by Actual clubs list  "+clubs_sorted);
		}
			
		}

	}



public void Validate_all_clubfields_zipcode(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {

if (Value.equalsIgnoreCase("Validate_all_clubfields_zipcode")) {

			Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
			
			Select select = new Select(driver.findElement(show_dd));  
			 select.selectByVisibleText("50");
		     Thread.sleep(200);
			
			
//			click(Map_typeswitch_btn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
//			Log.info("Map Type Switcher Button is successfully clicked in 'Find a club / Locations' page");
	
//			click(ZoomInBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom In Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
//			click(ZoomOutBtn);
//			ExtentTestManager.getTest().log(Status.PASS, "Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Log.info("Map Zoom Out Button is successfully clicked in 'Find club Results' page");
//			Thread.sleep(200);
			
//			String des=driver.findElement(IconDes_map).getText().trim();
//			Assert.assertEquals(des.toUpperCase(), Icon_des_ip.trim().toUpperCase(), "Map Icon Description's not validated on 'Find a club / Locations' page" );
//			List<WebElement> move_btns=driver.findElements(map_move_btns);
//			for(WebElement btn:move_btns)
//				
//				Assert.assertTrue(btn.isDisplayed(), "All move buttons of Map are not displayed in 'Find a club / Locations' page");
		
			Element_isdisplayed(search_title);
			String search_Title = driver.findElement(search_title).getText();
			ExtentTestManager.getTest().log(Status.PASS, search_Title);
			Log.info(search_Title);
			
			boolean next_click=false;
//			boolean clubnamefound=false;
			
			do {
			
			int rows_count=driver.findElements(parentrows).size();
			
			List<WebElement> S_nos=driver.findElements(S_Nos);
			List<WebElement> Rows_data=driver.findElements(rows_data);	
			List<WebElement> Clubnames=driver.findElements(clubname);	
			List<WebElement> Clubaddress=driver.findElements(clubaddress);	
			List<WebElement> Clubnumbers=driver.findElements(clubphone);	
			List<WebElement> CT=driver.findElements(classtimes);	
			List<WebElement> FA=driver.findElements(freepass);	
			List<WebElement> CI=driver.findElements(clubinfo);	
			List<WebElement> Club_distance=driver.findElements(club_data);
			
			
			
			for(int i=0; i<rows_count; i++) {
				
				WebElement data=Rows_data.get(i);
				WebElement no=S_nos.get(i);
				WebElement clubName=Clubnames.get(i);
				WebElement clubAddress=Clubaddress.get(i);
				WebElement clubMobile=Clubnumbers.get(i);
				WebElement Clubdistance=Club_distance.get(i);
				WebElement classTimes=CT.get(i);
				WebElement freePass=FA.get(i);
				WebElement clubInfo=CI.get(i);
				
				
//						driver.findElement(By.xpath("//tbody//tr[7]//td[2]//fieldset"));
				
//				String clubinfo=data.findElement(By.xpath("//div[@class='colclass-sm-7 col-xs-6']")).getText();
//				String[] clubdata= clubinfo.split("\n");
//				String clubname=clubdata[0];
//				String clubaddress=clubdata[1]+", "+clubdata[2];
//				String clubmobile=clubdata[3];
//				System.out.println(no.getText()+". Club name: "+clubname +"\nClub address: "+clubaddress+"\nclub mobile: "+clubmobile);
				
				
				
				
				Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
				Assert.assertTrue(no.isDisplayed(), "S No is not displayed");
				String name=clubName.getText();
				ExtentTestManager.getTest().log(Status.PASS,  no.getText().trim()+". Club name: "+name);
				Log.info(no.getText().trim()+". Club name: "+name);

				Assert.assertTrue(clubAddress.isDisplayed(), "Club Address is not displayed");
				String address=clubAddress.getText().replaceAll("\n", ", ");
				ExtentTestManager.getTest().log(Status.PASS,  "Club address: "+address);
				Log.info( "Club address: "+address);

				Assert.assertTrue(clubMobile.isDisplayed(), "Club Mobile is not displayed");
				String mobile=clubMobile.getText();
				ExtentTestManager.getTest().log(Status.PASS,  "Club Mobile: "+mobile);
				Log.info("Club Mobile: "+mobile);
				
				
				Assert.assertTrue(Clubdistance.isDisplayed(), "Club Data and Distance is not displayed");
				String[] Distance_a=Clubdistance.getText().split("\n");
				String Distance=Distance_a[4];
				ExtentTestManager.getTest().log(Status.PASS,  Distance);
				Log.info( Distance);
				
				
				Assert.assertTrue(classTimes.isDisplayed(), "class times button is not displayed");
				ExtentTestManager.getTest().log(Status.PASS,  "class times button is successfully displayed");
				Log.info("class times button is successfully displayed");
				
				Assert.assertTrue(freePass.isDisplayed(), "free pass button is not displayed");
				ExtentTestManager.getTest().log(Status.PASS,  "free pass button is successfully displayed");
				Log.info("free pass button is successfully displayed");
				
				Assert.assertTrue(clubInfo.isDisplayed(), "club info button is not displayed");
				ExtentTestManager.getTest().log(Status.PASS,  "club info button is successfully displayed");
				Log.info("club info button is successfully displayed");
				

			}
			

			int next_count=driver.findElements(Next).size();
			if(next_count==1)
			{
//				MoveToElement(Next);
				click(Next);
				next_click =true;
				
			}	
			
			else	next_click=false;
			
		}
		while(next_click);
			
		}

	}



public void Validate_DES_order(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {

	if (Value.equalsIgnoreCase("Validate_DES_order")) {
//			Validate_sortby_select_desired_option
			
		Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
			

		Select select = new Select(driver.findElement(show_dd));  
		 select.selectByVisibleText("50");
		 Log.info("Show dropdown option: 50 is successfully selected in Locations search result page");
	     ExtentTestManager.getTest().log(Status.PASS, "Show dropdown option: 50 is successfully selected in Locations search result page");
	     
	     Thread.sleep(200);
		
		
		Element_isdisplayed(ASC_btn);
		ExtentTestManager.getTest().log(Status.PASS, "ASC order button is Successfully displayed on 'Locations search results page' page");
		Log.info("ASC order button is Successfully displayed on 'Locations search results page' page");
		
		
			boolean next_click=false;
			
			List<String> clubs_sorted = new ArrayList<String>();
//			List<String> clubs_1 = new ArrayList<String>();
			List<String> clubs = new ArrayList<String>();
			
			do {
				
				int rows_count=driver.findElements(parentrows).size();
				
				List<WebElement> Clubnames=driver.findElements(clubname);	
				List<WebElement> Clubaddress=driver.findElements(clubaddress);	
					
				for(int i=0; i<rows_count; i++) {
					
					WebElement clubName=Clubnames.get(i);
					WebElement clubAddress=Clubaddress.get(i);
					
					Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
					Assert.assertTrue(clubAddress.isDisplayed(), "Club Address is not displayed");
					String[] club_cities = clubAddress.getText().split("\n");
					String clubname_op =clubName.getText().trim();
			
//					String[] club_cities_1=club_cities[1].split(",");
//					String clubcity_op =club_cities_1[0].trim();
					if(!( clubname_op.isBlank() && clubname_op.isEmpty()))
					{
						clubs.add(clubname_op);
					}
					}
				
				int next_count=driver.findElements(Next).size();
				if(next_count==1)
				{
//					MoveToElement(Next);
					click(Next);
					next_click =true;
					next_count=0;
				}	
				
				else	next_click=false;
				
			}
			while(next_click);
			
							
//			 Select select_1 = new Select(driver.findElement(Sortby_dd));  
//			 select_1.selectByVisibleText(sortby_dd_value.trim());
//			 Log.info("Sort by dropdown option: "+ sortby_dd_value+ " is successfully selected in Locations search result page");
//		     ExtentTestManager.getTest().log(Status.PASS, "Sort by dropdown option: "+ sortby_dd_value+ " is successfully selected in Locations search result page");

			
//			Element_isdisplayed(ASC_btn);
			click(ASC_btn);
			ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on ASC order button in 'Locations search results page' page");
			Log.info("Successfully clicked on ASC order button in 'Locations search results page' page");
			
			Element_isdisplayed(DESC_btn);
			ExtentTestManager.getTest().log(Status.PASS, "DES order button is Successfully displayed on 'Locations search results page' page");
			Log.info("DES order button is Successfully displayed on 'Locations search results page' page");
			
			
			
		     int previous_count=driver.findElements(Previous).size();
		     
		     while (previous_count==1) {
				click(Previous);
				previous_count=driver.findElements(Previous).size();
			}
			
		     do {
					
					int rows_count=driver.findElements(parentrows).size();
					
					List<WebElement> Clubnames=driver.findElements(clubname);	
					List<WebElement> Clubaddress=driver.findElements(clubaddress);	
					
					
					for(int i=0; i<rows_count; i++) {
						
						WebElement clubName=Clubnames.get(i);
						WebElement clubAddress=Clubaddress.get(i);
						Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
						Assert.assertTrue(clubAddress.isDisplayed(), "Club Address is not displayed");
						String[] club_cities = clubAddress.getText().split("\n");
						String clubname_op =clubName.getText();
//						String[] club_cities_1=club_cities[1].split(",");
//						String clubcity_op =club_cities_1[0].trim();
						if(!( clubname_op.isBlank() && clubname_op.isEmpty())) {
							clubs_sorted.add(clubname_op);
						}
						}
					int next_count=driver.findElements(Next).size();
					if(next_count==1)
					{
//						MoveToElement(Next);
						click(Next);
						next_click =true;
						next_count=0;
					}	
					
					else	next_click=false;
					
				}
				while(next_click);
				
		    Collections.sort(clubs, Collections.reverseOrder());
		    int lastindex_clubs =clubs.size()-1;
		    int lastindex_clubs_sorted =clubs_sorted.size()-1;
		    
		if( clubs.get(0).equalsIgnoreCase(clubs_sorted.get(0)) && clubs.get(lastindex_clubs).equalsIgnoreCase(clubs_sorted.get(lastindex_clubs_sorted))) {
		
			  Log.info("Successfully validated the DES order in Locations search result page");
			  ExtentTestManager.getTest().log(Status.PASS, "Successfully validated the DES order in Locations search result page");
			     
		}
		else {
			
			throw new Exception("Not validated the DES order in Locations search result page. Expected clubs list "+clubs+" Actual clubs list  "+clubs_sorted);
		}
			
		}

	}



public void Validate_ASC_order(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {

	if (Value.equalsIgnoreCase("Validate_ASC_order")) {
//			Validate_sortby_select_desired_option
			
		Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
			

		Select select = new Select(driver.findElement(show_dd));  
		 select.selectByVisibleText("50");
		 Log.info("Show dropdown option: 50 is successfully selected in Locations search result page");
	     ExtentTestManager.getTest().log(Status.PASS, "Show dropdown option: 50 is successfully selected in Locations search result page");
	     
	     Thread.sleep(200);
		
		
		Element_isdisplayed(ASC_btn);
		ExtentTestManager.getTest().log(Status.PASS, "ASC order button is Successfully displayed on 'Locations search results page' page");
		Log.info("ASC order button is Successfully displayed on 'Locations search results page' page");
		click(ASC_btn);
		ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on ASC order button in 'Locations search results page' page");
		Log.info("Successfully clicked on ASC order button in 'Locations search results page' page");
		
		Element_isdisplayed(DESC_btn);
		ExtentTestManager.getTest().log(Status.PASS, "DES order button is Successfully displayed on 'Locations search results page' page");
		Log.info("DES order button is Successfully displayed on 'Locations search results page' page");
		
		
			boolean next_click=false;
			
			List<String> clubs_sorted = new ArrayList<String>();
//			List<String> clubs_1 = new ArrayList<String>();
			List<String> clubs = new ArrayList<String>();
			
			do {
				
				int rows_count=driver.findElements(parentrows).size();
				
				List<WebElement> Clubnames=driver.findElements(clubname);	
				List<WebElement> Clubaddress=driver.findElements(clubaddress);	
					
				for(int i=0; i<rows_count; i++) {
					
					WebElement clubName=Clubnames.get(i);
					WebElement clubAddress=Clubaddress.get(i);
					
					Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
					Assert.assertTrue(clubAddress.isDisplayed(), "Club Address is not displayed");
					String[] club_cities = clubAddress.getText().split("\n");
					String clubname_op =clubName.getText().trim();
			
//					String[] club_cities_1=club_cities[1].split(",");
//					String clubcity_op =club_cities_1[0].trim();
					if(!( clubname_op.isBlank() && clubname_op.isEmpty()))
					{
						clubs.add(clubname_op);
					}
					}
				
				int next_count=driver.findElements(Next).size();
				if(next_count==1)
				{
//					MoveToElement(Next);
					click(Next);
					next_click =true;
					next_count=0;
				}	
				
				else	next_click=false;
				
			}
			while(next_click);
			
							
//			 Select select_1 = new Select(driver.findElement(Sortby_dd));  
//			 select_1.selectByVisibleText(sortby_dd_value.trim());
//			 Log.info("Sort by dropdown option: "+ sortby_dd_value+ " is successfully selected in Locations search result page");
//		     ExtentTestManager.getTest().log(Status.PASS, "Sort by dropdown option: "+ sortby_dd_value+ " is successfully selected in Locations search result page");

			
//			Element_isdisplayed(ASC_btn);
			click(DESC_btn);
			ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on DES order button in 'Locations search results page' page");
			Log.info("Successfully clicked on DES order button in 'Locations search results page' page");
			
			Element_isdisplayed(ASC_btn);
			ExtentTestManager.getTest().log(Status.PASS, "ASC order button is Successfully displayed on 'Locations search results page' page");
			Log.info("ASC order button is Successfully displayed on 'Locations search results page' page");
			
			
			
		     int previous_count=driver.findElements(Previous).size();
		     
		     while (previous_count==1) {
				click(Previous);
				previous_count=driver.findElements(Previous).size();
			}
			
		     do {
					
					int rows_count=driver.findElements(parentrows).size();
					
					List<WebElement> Clubnames=driver.findElements(clubname);	
					List<WebElement> Clubaddress=driver.findElements(clubaddress);	
					
					
					for(int i=0; i<rows_count; i++) {
						
						WebElement clubName=Clubnames.get(i);
						WebElement clubAddress=Clubaddress.get(i);
						Assert.assertTrue(clubName.isDisplayed(), "Club Name is not displayed");
						Assert.assertTrue(clubAddress.isDisplayed(), "Club Address is not displayed");
						String[] club_cities = clubAddress.getText().split("\n");
						String clubname_op =clubName.getText();
//						String[] club_cities_1=club_cities[1].split(",");
//						String clubcity_op =club_cities_1[0].trim();
						if(!( clubname_op.isBlank() && clubname_op.isEmpty())) {
							clubs_sorted.add(clubname_op);
						}
						}
					int next_count=driver.findElements(Next).size();
					if(next_count==1)
					{
//						MoveToElement(Next);
						click(Next);
						next_click =true;
						next_count=0;
					}	
					
					else	next_click=false;
					
				}
				while(next_click);
				
		    Collections.sort(clubs);
		    int lastindex_clubs =clubs.size()-1;
		    int lastindex_clubs_sorted =clubs_sorted.size()-1;
		    
		if( clubs.get(0).equalsIgnoreCase(clubs_sorted.get(0)) && clubs.get(lastindex_clubs).equalsIgnoreCase(clubs_sorted.get(lastindex_clubs_sorted))) {
		
			  Log.info("Successfully validated the ASC order in Locations search result page");
			  ExtentTestManager.getTest().log(Status.PASS, "Successfully validated the ASC order in Locations search result page");
			     
		}
		else {
			
			throw new Exception("Not validated the ASC order in Locations search result page. Expected clubs list "+clubs+" Actual clubs list  "+clubs_sorted);
		}
			
		}

	}



public void Validate_previous_page_Link(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_previous_page_Link")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
	
	
//	Element_isdisplayed(ASC_btn);
//	ExtentTestManager.getTest().log(Status.PASS, "ASC order button is Successfully displayed on 'Locations search results page' page");
//	Log.info("ASC order button is Successfully displayed on 'Locations search results page' page");
//	
//	
//	Element_isdisplayed(search_title);
//	String search_Title = driver.findElement(search_title).getText();
//	ExtentTestManager.getTest().log(Status.PASS, "Search title: '"+search_Title+"' is Successfully displayed on 'Locations search results page' page");
//	Log.info("Search title: '"+search_Title+"' is Successfully displayed on 'Locations search results page' page");
//	
	
//	Element_isdisplayed(page_nos);
//	String Page_numbers = driver.findElement(page_nos).getText();
//	ExtentTestManager.getTest().log(Status.PASS, "Page numbers: '"+Page_numbers+"' is Successfully displayed on 'Locations search results page' page");
//	Log.info("Page numbers : '"+Page_numbers+"' is Successfully displayed on 'Locations search results page' page");
//	
	Element_isdisplayed(Next);
	ExtentTestManager.getTest().log(Status.PASS, "Next page Link is Successfully displayed on 'Locations search results page' page");
	Log.info("Next page Link is Successfully displayed on 'Locations search results page' page");
	
	click(Next);
	ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Next page Link in 'Locations search results page' page");
	Log.info("Successfully clicked on Next page Link in 'Locations search results page' page");
	
	Element_isdisplayed(Previous);
	ExtentTestManager.getTest().log(Status.PASS, "Previous page Link is Successfully displayed on 'Locations search results page' page");
	Log.info("Previous page Link is Successfully displayed on 'Locations search results page' page");
	click(Previous);
	ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Previous page Link in 'Locations search results page' page");
	Log.info("Successfully clicked on Previous page Link in 'Locations search results page' page");
	
	int previous_count= driver.findElements(Previous).size();
	
	if(previous_count==0) {
		
		ExtentTestManager.getTest().log(Status.PASS, "Successfully navigated to Previous page in 'Locations search results page' page");
		Log.info("Successfully navigated to Previous page  in 'Locations search results page' page");
		
	}
	
	else {
		throw new Exception(" Not navigated to Previous page on click of previous link in 'Locations search results page");
	}
	
//	 Select select = new Select(driver.findElement(show_dd));  
//	 String default_option= select.getFirstSelectedOption().getText().trim();
//	 select.selectByVisibleText(show_dd_value.trim());

//	 Assert.assertEquals(default_option.toUpperCase(), show_dd_value.trim().toUpperCase(), "Show dropdown default option not validated in Locations search result page");
//	 Log.info("Show dropdown option: "+ show_dd_value+ " is successfully selected in Locations search result page");
//     ExtentTestManager.getTest().log(Status.PASS, "Show dropdown option: "+ show_dd_value+ " is successfully selected in Locations search result page");

	
	}



}

	


public void Validate_DES_button(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_DES_button")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
	
	
	Element_isdisplayed(ASC_btn);
	ExtentTestManager.getTest().log(Status.PASS, "ASC order button is Successfully displayed on 'Locations search results page' page");
	Log.info("ASC order button is Successfully displayed on 'Locations search results page' page");
	click(ASC_btn);
	ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on ASC order button in 'Locations search results page' page");
	Log.info("Successfully clicked on ASC order button in 'Locations search results page' page");
	
	Element_isdisplayed(DESC_btn);
	ExtentTestManager.getTest().log(Status.PASS, "DES order button is Successfully displayed on 'Locations search results page' page");
	Log.info("DES order button is Successfully displayed on 'Locations search results page' page");
	
	
	
	}



}


public void Validate_VirtualTour_button(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_VirtualTour_button")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
	
	
	Element_isdisplayed(VirtualTour);
	ExtentTestManager.getTest().log(Status.PASS, "Virtual Tour button is Successfully displayed on 'Locations search results page' page");
	Log.info("Virtual Tour button is Successfully displayed on 'Locations search results page' page");
//	click(VirtualTour);
//	ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Virtual Tour button in 'Locations search results page' page");
//	Log.info("Successfully clicked on Virtual Tour button in 'Locations search results page' page");
	
//	Element_isdisplayed(DESC_btn);
//	ExtentTestManager.getTest().log(Status.PASS, "DES order button is Successfully displayed on 'Locations search results page' page");
//	Log.info("DES order button is Successfully displayed on 'Locations search results page' page");
//	
	
	
	}



}


public void Validate_VirtualTour_window(String Value, String page_title, String country_value, String state_value, String result_url, String zipcode, String city_name) throws Exception {
	
	if (Value.equalsIgnoreCase("Validate_VirtualTour_window")) {

	Validate_sort_show_newsearch("Validate_sort_show_newsearch", page_title, country_value,state_value,result_url,zipcode,city_name);
	
	
	Element_isdisplayed(VirtualTour);
	ExtentTestManager.getTest().log(Status.PASS, "Virtual Tour button is Successfully displayed on 'Locations search results page' page");
	Log.info("Virtual Tour button is Successfully displayed on 'Locations search results page' page");
	click(VirtualTour);
	ExtentTestManager.getTest().log(Status.PASS, "Successfully clicked on Virtual Tour button in 'Locations search results page' page");
	Log.info("Successfully clicked on Virtual Tour button in 'Locations search results page' page");
	
	Thread.sleep(200);
	Element_isdisplayed(VirtualTour_window);
	ExtentTestManager.getTest().log(Status.PASS, "Virtual Tour popup window is Successfully displayed on 'Locations search results page' page");
	Log.info("Virtual Tour popup window is Successfully displayed on 'Locations search results page' page");
	
	Thread.sleep(500);
	
//	Element_isdisplayed(VirtualTour_heading);
//	Element_isdisplayed(popup_close_btn);	
//	Element_isdisplayed(close_img);
//	driver.switchTo().frame(0);
//	Element_isdisplayed(video_popup);

//	System.out.println("done");
//	Element_isdisplayed(play_popup_video);
//	click(play_popup_video);
//	Thread.sleep(1000);
//	System.out.println(" Iframes count: "+driver.findElements(By. tagName("iframe")). size());
	
//	List<WebElement> frames = driver.findElements(By. tagName("iframe"));
//	for (int i=0;i< frames.size(); i++) {
//		
//		if(frames.get(i).isDisplayed()) {
//			System.out.println(frames.get(i).getText()+" count : "+i );
//			
//		}
//		
//	}
	
	
	
	
//	driver.switchTo().frame(0);
//	click(showcase_play);
//	Thread.sleep(9000);
//
//	Element_isdisplayed(play_Pause);
//	click(play_Pause);
//	Thread.sleep(8000);

	
	}



}

					
	
//	public void Main_login(String Value,String Email, String Password) throws InterruptedException, AWTException {
//
//		if (Value.equalsIgnoreCase("Login")) {
//
//			login_popup(Email,Password);
//
//		}
//
//	}
//
//	public void login_popup(String Emails, String Passwords) throws AWTException, InterruptedException {
//
//		click(ProfileButton);
//		Thread.sleep(100);
//		click(LoginOption);
//		Thread.sleep(1000);
//		input(Email, Emails);
//		input(Password, Passwords);
//		ExtentTestManager.getTest().log(Status.PASS, "User Login Credentials entered Successfully");
//		click(LoginButton);
//		Thread.sleep(1000);
//		ExtentTestManager.getTest().log(Status.PASS, "Login Successful");
//
//	}

}
