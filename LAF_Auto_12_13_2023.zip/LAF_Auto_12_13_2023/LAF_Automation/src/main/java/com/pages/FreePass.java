package com.pages;

import org.openqa.selenium.By;

import com.BasePackage.Base_Class;
 

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.Utility.Log;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
//import org.apache.logging.log4j.core.util.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.BasePackage.Base_Class;
import com.aventstack.extentreports.Status;
import com.extentReports.ExtentTestManager;

import net.bytebuddy.description.annotation.AnnotationList.Empty;

import org.testng.Assert;

public class FreePass extends Base_Class
{
	
	private static By FreePass_top_button = By.xpath("//div[@class='d-flex align-items-center nav-menu-list']/div/a[@title='FREE PASS']");
	
	private static By Text_tryus = By.xpath("//h1[text()='TRY US ']");
	private static By Text_tryusforfree = By.xpath("//h1[text()='TRY US ']/span[text()='FOR FREE']");
	
	private static By Text_Tryusforfree = By.xpath("//body/form[@id='aspnetForm']/div[3]/div[2]/div[1]/div[1]/div[1]");
	
	private static By Text_3= By.xpath("//span[@id='ctl00_MainContent_FreePass_lblPassTypeDaysCount']");
	private static By Text_day = By.xpath("//h1[text()=' DAY ']");
	private static By Text_guestpass= By.xpath("//h1[text()=' DAY ']/span");
	
	private static By Text_free3daystrial= By.xpath("//h1[@id='ctl00_MainContent_FreePass_trialHeader']");
	private static By Text_Enterurziporpostalcode= By.xpath("//div[@id='ctl00_MainContent_FreePass_divZipCodeLbl']");
	private static By Text_Enterzip = By.xpath("//div[@id='ctl00_MainContent_FreePass_divZipCodeLbl']");
	
	private static By Zipcode_input = By.xpath("//input[@id='ctl00_MainContent_FreePass_txtSelectClubZip']");
	
	private static By Firstname_input = By.xpath("//input[@id='ctl00_MainContent_FreePass_txtFirstName']");
	
	private static By Lastname_input = By.xpath("//input[@id='ctl00_MainContent_FreePass_txtLastName']");
	
	private static By Cellphone_input = By.xpath("//input[@id='ctl00_MainContent_FreePass_txtPhone']");
	
	private static By Email_input = By.xpath("//input[@id='ctl00_MainContent_FreePass_txtEmail']");
	
	private static By Findclub_button = By.xpath("//input[@id='ctl00_MainContent_FreePass_bntChangeClub']");
	
	private static By Condition_text= By.xpath("//label[@for='terms']");
	
	private static By checckbox = By.xpath("//input[@id='terms']");
	
	private static By Tc_link = By.xpath("//u/strong[text()='Terms and Conditions']");
	
	private static By PrivacyPolicy_link = By.xpath("//strong[contains(text(),'Privacy Policy')]");

	private static By Next_button = By.xpath("//input[@id='ctl00_MainContent_FreePass_btnSubmit']");
	
	private static By Clublist_count = By.xpath("//div[@class='col-xs-9 text-left']");
	
	private static By results_count= By.xpath("//div[@class='row mobClubRow']");
	private static By results_firstrow = By.xpath("//div[@class='row mobClubRow'][1]");
	private static By no_results_found = By.id("lblNoClubs");
	private static By zipcode_field = By.id("ctl00_MainContent_FreePass_txtSelectClubZip");
	private static By find_button = By.id("ctl00_MainContent_FreePass_bntChangeClub");
	private static By firstimg_onpopup = By.xpath("(//img[@class='img-responsive'])[1]");	
	private static By firstclub_name = By.xpath("(//div[@class ='clubname'])[1]");
	//private static By firstclub_distance = By.xpath("//div[text() ='(Distance: 2 miles)']");
	private static By firstclub_distance = By.xpath("(//div[@class='clubname'])[2]");
	private static By first_address = By.xpath("(//div[@class='clublabel'])[1]");
	private static By first_phone = By.xpath("(//div[@class='clublabel'])[2]");
	private static By Selectclub_name = By.id("ctl00_MainContent_FreePass_lblClubName");
	private static By Selectclub_Address = By.id("ctl00_MainContent_FreePass_lblClubAdress");
	private static By changelocation = By.xpath("//span/a[text()='CHANGE LOCATION']");
	private static By checkbox = By.id("terms");
	private static By nextbutton = By.id("ctl00_MainContent_FreePass_btnSubmit");
	private static By Text_justonemorething = By.xpath("//div[@class='text-container']");
	
	private static By Text_waiver = By.xpath("//h1[contains(text(),'WAIVER')]");
	private static By Text_waiver_below = By.xpath("//h2[contains(text(),'Assumption of Risk, Waiver')]");
	private static By Text_acknowledgement = By.xpath("//div[@class='mt-4 waiver-box']");
	private static By Text_firstlastname = By.id("ctl00_MainContent_AckName");
	
	private static By checkbox_imnotrobort = By.xpath("//div[@class='recaptcha-checkbox-border']");
	private static By Text_agreeme = By.xpath("//div[@class='mt-4 waiver-box']");
	private static By FL_Names = By.id("ctl00_MainContent_AckName");
	private static By acknowledge = By.xpath("(//div[@class='text-center pt-4 waiver-agree'])[1]");
	private static By Text_Agree_andEmail = By.id("ctl00_MainContent_cmdPrintPass");
	
	private static By Freepass_confirmation = By.xpath("//div[@class='col-sm-12']/h1");
	private static By Thankyou_confirmation = By.xpath("//div[@class='col-sm-12 PaddingTopBottom']");
	// private static By Text_Agree_andEmail = By.xpath("//body/form[@id='aspnetForm']/div[3]/div[3]/div[1]/div[1]/div[1]/div[2]/div[1]");
	//Scanner sc= new Scanner(System.in);  
	
	public void TC_02_Validate_Tryusforfree_text(String Value,String Tryusforfree_input) throws Exception {
		
				if (Value.equalsIgnoreCase("Tryusforfree")) {
					
					click(FreePass_top_button);

					Log.info("Freepass_button clicked successfully");
					ExtentTestManager.getTest().log(Status.PASS, "FreePass_button clicked successfully");
					Element_isdisplayed(Text_Tryusforfree);
					String[] inputdata = Tryusforfree_input.split(",");
					
					String text = driver.findElement(Text_Tryusforfree).getText().replace("\n", " ").trim();
					
					Assert.assertEquals(text.toUpperCase(),inputdata[0].trim().toUpperCase(),"Try Us for Free input text doesnot matched");
					
					Log.info("Try us for free text displayed and validated successfully");
					ExtentTestManager.getTest().log(Status.PASS, "Try us for free text displayed and validated successfully");
					
					
					Element_isdisplayed(Text_free3daystrial);
					String Gymtrial_Text = driver.findElement(Text_free3daystrial).getText();
					
					Assert.assertEquals(Gymtrial_Text.toUpperCase(),inputdata[1].trim().toUpperCase(),"FREE 3 DAY GYM TRIAL input text doesnot matched");
					
					Log.info("FREE 3 DAY GYM TRIAL text displayed and validated successfully");
					ExtentTestManager.getTest().log(Status.PASS, "FREE 3 DAY GYM TRIAL text displayed and validated successfully");
					
					
					/*Element_isdisplayed(Searchclub_text);
				
					Log.info(driver.findElement(Searchclub_text).getText()+" text is displayed successfully");
					ExtentTestManager.getTest().log(Status.PASS, driver.findElement(Searchclub_text).getText()+" text is displayed successfully");
					
					Element_isdisplayed(Joinnow_steps);
					ExtentTestManager.getTest().log(Status.PASS, "4 Join_now steps are displayed successfully");
					Log.info("4 Join_now steps are displayed successfully");*/
					
				}
		
	}	

	public void TC_03_Validate_Enterurziporpostalcode_text(String Value,String EnterZiporPostal) throws Exception {
		
		if (Value.equalsIgnoreCase("Enterurziporpostalcode_text")) {
			
			click(FreePass_top_button);

			Log.info("Freepass_button clicked successfully");
			ExtentTestManager.getTest().log(Status.PASS, "FreePass_button clicked successfully");
			Element_isdisplayed(Text_Enterurziporpostalcode);
			
			String ziporpostalcode_Text = driver.findElement(Text_Enterurziporpostalcode).getText();
			MoveToElement(Text_Enterurziporpostalcode);
			Assert.assertEquals(ziporpostalcode_Text.toUpperCase(),EnterZiporPostal.toUpperCase(), "Freepass EnterZiporPostal text validated Failed");
		
			Log.info("Freepass condition text validated successfully");
			ExtentTestManager.getTest().log(Status.PASS, "Freepass EnterZiporPostal text validated successfully");
			

			Thread.sleep(500);
		}

	}	

	
	
public void TC_04_Validate_Freepass_Fields(String Value) throws Exception {
	
	if (Value.equalsIgnoreCase("Freepass_fields")) {
		
		click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass_button clicked successfully");
		Log.info("Freepass_button clicked successfully");
		
		Element_isdisplayed(Firstname_input);
		ExtentTestManager.getTest().log(Status.PASS, "Firstname_input field is displayed successfully");
		Log.info("Firstname_input field is displayed successfully");
		
		Element_isdisplayed(Lastname_input);
		ExtentTestManager.getTest().log(Status.PASS, "Lastname_input field is displayed successfully");
		Log.info("Lastname_input field is displayed successfully");
		
		Element_isdisplayed(Zipcode_input);
		ExtentTestManager.getTest().log(Status.PASS, "Zipcode_input field is displayed successfully");
		Log.info("Zipcode_input field is displayed successfully");
		
		Element_isdisplayed(Cellphone_input);
		ExtentTestManager.getTest().log(Status.PASS, "Cellphone_input field is displayed successfully");
		Log.info("Cellphone_input field is displayed successfully");
		
		Element_isdisplayed(Email_input);
		ExtentTestManager.getTest().log(Status.PASS, "Email_input field is displayed successfully");
		Log.info("Email_input field is displayed successfully");
		
		Element_isdisplayed(Findclub_button);
		ExtentTestManager.getTest().log(Status.PASS, "Findclub_button field is displayed successfully");
		Log.info("Findclub_button field is displayed successfully");
		
	}
}

public void TC_05_Validate_Freepass_Condition_Text(String Value,String Freepass_Condition) throws Exception {
	
	if (Value.equalsIgnoreCase("Freepass_Condtion_Text")) {
		
		click(FreePass_top_button);

		Log.info("Freepass_button clicked successfully");
		ExtentTestManager.getTest().log(Status.PASS, "FreePass_button clicked successfully");
		Element_isdisplayed(Condition_text);
		
		String Condi_Text = driver.findElement(Condition_text).getText();
		MoveToElement(Condition_text);
		Assert.assertEquals(Condi_Text.toUpperCase(),Freepass_Condition.toUpperCase(), "Freepass condition text validated Failed");
		
		Log.info("Freepass condition text validated successfully");
		ExtentTestManager.getTest().log(Status.PASS, "Freepass condition text validated successfully");
	
	}
}


public void TC_06_Validate_Freepass_Next_button(String Value,String Freepass_Condition) throws Exception {
	
	if (Value.equalsIgnoreCase("Next_button")) {

click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass_button clicked successfully");
		Log.info("Freepass_button clicked successfully");

		Element_isdisplayed(Next_button);
		ExtentTestManager.getTest().log(Status.PASS, "Next_button field is displayed successfully");
		Log.info("Next_button field is displayed successfully");

}
}

public void TC_07_Validate_Tncandpp_Hyperlinks(String Value,String Freepass_Condition) throws Exception {
	
	if (Value.equalsIgnoreCase("Link_isdisplayed")) {

click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass_button clicked successfully");
		Log.info("Freepass_button clicked successfully");

		Element_isdisplayed(Tc_link);
		ExtentTestManager.getTest().log(Status.PASS, "Tc_link link is displayed successfully");
		Log.info("Tc_link link is displayed successfully");
		
		Element_isdisplayed(PrivacyPolicy_link);
		ExtentTestManager.getTest().log(Status.PASS, "PrivacyPolicy_link link is displayed successfully");
		Log.info("PrivacyPolicy_link link is displayed successfully");
		
		
		
}
}

public void TC_08_Validate_Listofclubsdisplayed(String Value,String Freepass_Condition,String zipcodef) throws Exception {
	
	if (Value.equalsIgnoreCase("Listofclubs_isdisplayed")) {

click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass_button clicked successfully");
		Log.info("Freepass_button clicked successfully");
		
		
		//System.out.println("Provide ZIP/Postal code");
	//	
		//String zipcodef=sc.next();
		
		driver.findElement(zipcode_field).sendKeys(zipcodef.trim());
		click(find_button);
		
		Thread.sleep(300);
//		boolean b = driver.findElement(results_firstrow).isDisplayed();
		List<WebElement> count = driver.findElements(results_count);
		if(count.size()>=1) {

			ExtentTestManager.getTest().log(Status.PASS, "List of results found");
			Log.info("List of results found");
			
		
			List<WebElement> results = driver.findElements(results_count);

			for (WebElement Wb : results) {
				 String resultrow = Wb.getText();
				 
				 ExtentTestManager.getTest().log(Status.PASS, resultrow);
					Log.info(resultrow);
				
			}

			
		}
		
		else if(driver.findElement(no_results_found).isDisplayed() ) {	
			
			ExtentTestManager.getTest().log(Status.FAIL, driver.findElement(no_results_found).getText());
			Log.error( driver.findElement(no_results_found).getText());
			throw new Exception("Invalid zipcode, No results found");
		}
		else {
			
			throw new Exception("unexpected error");
		}
		
		
	}
}

	public void TC_09_Validate_select_record_closepopup(String Value,String Freepass_Condition,String zip) throws Exception {
		
		if (Value.equalsIgnoreCase("Select_recordonpopup")) {

	click(FreePass_top_button);
			 
			ExtentTestManager.getTest().log(Status.PASS, "Freepass_button clicked successfully");
			Log.info("Freepass_button clicked successfully");	
			
			driver.findElement(zipcode_field).sendKeys(zip.trim());	
			click(find_button);
			Thread.sleep(100);
			
			MoveToElement(results_firstrow);
			 click(results_firstrow);
			 ExtentTestManager.getTest().log(Status.PASS, "First record clicked successfully and popup is closed");
				Log.info("First record clicked successfully and popup is closed");				
				
}
	}

	public void TC_10_Validate_sections_on_listpopups(String Value,String Freepass_Condition,String zip) throws Exception {
		
		if (Value.equalsIgnoreCase("Sections_onlistofclubs")) {

	click(FreePass_top_button);
			
			ExtentTestManager.getTest().log(Status.PASS, "Freepass_button clicked successfully");
			Log.info("Freepass_button clicked successfully");	
			
			driver.findElement(zipcode_field).sendKeys(zip.trim());	
			click(find_button);
	
			Element_isdisplayed(firstimg_onpopup);
			ExtentTestManager.getTest().log(Status.PASS, "image of club is displayed successfully");
			Log.info("image of club is displayed successfully");
			
			Element_isdisplayed(firstclub_name);
			ExtentTestManager.getTest().log(Status.PASS, "club name is displayed successfully");
			Log.info("club name is displayed successfully");
			
			Element_isdisplayed(firstclub_distance);
			ExtentTestManager.getTest().log(Status.PASS, "club distance is displayed successfully");
			Log.info("image of club is displayed successfully");
			
			Element_isdisplayed(first_address);
			ExtentTestManager.getTest().log(Status.PASS, "Address of club is displayed successfully");
			Log.info("Address of club is displayed successfully");
			
			Element_isdisplayed(first_phone);
			ExtentTestManager.getTest().log(Status.PASS, "phone number of club is displayed successfully");
			Log.info("phone number of club is displayed successfully");
			
		
			
		}
	}
	
	
public void TC_11_Validate_selected_clubname(String Value,String Freepass_Condition,String zip,String text) throws Exception {
		
		if (Value.equalsIgnoreCase("clubname_displayed")) {

	click(FreePass_top_button);
			
			ExtentTestManager.getTest().log(Status.PASS, "Freepass_button clicked successfully");
			Log.info("Freepass_button clicked successfully");	
			
			driver.findElement(zipcode_field).sendKeys(zip.trim());	
			click(find_button);
			Thread.sleep(100);
			
			MoveToElement(firstclub_name);
			
			String popup_clubname = driver.findElement(firstclub_name).getText();
			System.out.println(popup_clubname);
			 click(results_firstrow);
			 ExtentTestManager.getTest().log(Status.PASS, "First record clicked successfully and popup is closed");
			Log.info("First record clicked successfully and popup is closed");	
	
			String clubname_displayed = driver.findElement(Selectclub_name).getText();
			
		
			Assert.assertEquals(popup_clubname.toUpperCase(),clubname_displayed.toUpperCase(), "club name validation Failed");
			
			Log.info("club name validated successfully");
			ExtentTestManager.getTest().log(Status.PASS, "club name validated successfully");
				
			String Changelocation_expected = driver.findElement(changelocation).getText();
			
			Assert.assertEquals(Changelocation_expected.toUpperCase(),text.toUpperCase(), "Change location validation Failed");
			
			Log.info("Change location validated successfully");
			ExtentTestManager.getTest().log(Status.PASS, "Change location validated successfully");
			
			
	
	}
}


public void TC_12_Validate_Field_inputs(String Value,String Freepass_Condition,String zip,String text, String first_Name, String last_Name, String phone_Num, String email_Input2) throws Exception {
	
	if (Value.equalsIgnoreCase("Field_inputs")) {

		Element_isdisplayed(FreePass_top_button);
		click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass button clicked successfully");
		Log.info("Freepass button clicked successfully");	
		
		Element_isdisplayed(zipcode_field);
		input(zipcode_field, zip.trim());
		ExtentTestManager.getTest().log(Status.PASS, "zipcode_field input: '"+zip+"' entered successfully");
		Log.info("zipcode_field input: '"+zip+"' entered successfully");
		
//		driver.findElement(zipcode_field).sendKeys(zip.trim());	
		
		click(find_button);
		 click(results_firstrow);
		Thread.sleep(100);
		
		Element_isdisplayed(Firstname_input);
		input(Firstname_input, first_Name.trim());
		
		
//		driver.findElement(Firstname_input).sendKeys(first_Name);
		ExtentTestManager.getTest().log(Status.PASS, "Firstname input: '"+first_Name+"' entered successfully");
		Log.info("Firstname input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Lastname_input);
		input(Lastname_input, last_Name.trim());
		
		
//		driver.findElement(Lastname_input).sendKeys(last_Name);
		ExtentTestManager.getTest().log(Status.PASS, "last_Name input: '"+last_Name+"' entered successfully");
		Log.info("last_Name input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Cellphone_input);
		input(Cellphone_input, phone_Num.trim());
		
		
//		driver.findElement(Cellphone_input).sendKeys(phone_Num);
		ExtentTestManager.getTest().log(Status.PASS, "Cellphone input: '"+phone_Num+"' entered successfully");
		Log.info("Cellphone input: '"+phone_Num+"' entered successfully");
		Thread.sleep(100);
//		driver.findElement(Email_input).sendKeys(email_Input2);
		Element_isdisplayed(Email_input);
		input(Email_input, email_Input2);
		ExtentTestManager.getTest().log(Status.PASS, "Email input: '"+email_Input2+"'  entered successfully");
		Log.info("Email input: '"+email_Input2+"'  entered successfully");
	
		
	}
	
}


public void TC_13_Validate_checkbox_nextbutton(String Value,String Freepass_Condition,String zip,String text, String first_Name, String last_Name, String phone_Num, String email_Input2) throws Exception {
	
	if (Value.equalsIgnoreCase("Checkbox_nextbutton")) {
		
//		TC_12_Validate_Field_inputs( "Field_inputs", Freepass_Condition, zip, text,  first_Name,  last_Name,  phone_Num,  email_Input2);
			
		
		
//		Element_isdisplayed(FreePass_top_button);
//		click(FreePass_top_button);
//		
//		ExtentTestManager.getTest().log(Status.PASS, "Freepass_button clicked successfully");
//		Log.info("Freepass_button clicked successfully");	
//		Element_isdisplayed(zipcode_field);
//		driver.findElement(zipcode_field).sendKeys(zip.trim());	
//		Thread.sleep(100);
//		Element_isdisplayed(find_button);
//		click(find_button);
//		Thread.sleep(300);
//		click(results_firstrow);
//		Thread.sleep(300);
//		
//		
//		driver.findElement(Firstname_input).sendKeys(first_Name);
//		ExtentTestManager.getTest().log(Status.PASS, "Firstname_input field is displayed successfully");
//		Log.info("Firstname_input field is displayed successfully");
//		
//		driver.findElement(Lastname_input).sendKeys(last_Name);
//		ExtentTestManager.getTest().log(Status.PASS, "Lastname_input field is displayed successfully");
//		Log.info("Lastname_input field is displayed successfully");
//		
//		driver.findElement(Cellphone_input).sendKeys(phone_Num);
//		ExtentTestManager.getTest().log(Status.PASS, "Cellphone_input field is displayed successfully");
//		Log.info("Cellphone_input field is displayed successfully");
//		Thread.sleep(100);
//		driver.findElement(Email_input).sendKeys(email_Input2);
//		ExtentTestManager.getTest().log(Status.PASS, "Email_input field is displayed successfully");
//		Log.info("Email_input field is displayed successfully");

		Element_isdisplayed(FreePass_top_button);
		click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass button clicked successfully");
		Log.info("Freepass button clicked successfully");	
		
		Element_isdisplayed(zipcode_field);
		input(zipcode_field, zip.trim());
		ExtentTestManager.getTest().log(Status.PASS, "zipcode_field input: '"+zip+"' entered successfully");
		Log.info("zipcode_field input: '"+zip+"' entered successfully");
		
//		driver.findElement(zipcode_field).sendKeys(zip.trim());	
		
		click(find_button);
		 click(results_firstrow);
		Thread.sleep(100);
		
		Element_isdisplayed(Firstname_input);
		input(Firstname_input, first_Name.trim());
		
		
//		driver.findElement(Firstname_input).sendKeys(first_Name);
		ExtentTestManager.getTest().log(Status.PASS, "Firstname input: '"+first_Name+"' entered successfully");
		Log.info("Firstname input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Lastname_input);
		input(Lastname_input, last_Name.trim());
		
		
//		driver.findElement(Lastname_input).sendKeys(last_Name);
		ExtentTestManager.getTest().log(Status.PASS, "last_Name input: '"+last_Name+"' entered successfully");
		Log.info("last_Name input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Cellphone_input);
		input(Cellphone_input, phone_Num.trim());
		
		
//		driver.findElement(Cellphone_input).sendKeys(phone_Num);
		ExtentTestManager.getTest().log(Status.PASS, "Cellphone input: '"+phone_Num+"' entered successfully");
		Log.info("Cellphone input: '"+phone_Num+"' entered successfully");
		Thread.sleep(100);
//		driver.findElement(Email_input).sendKeys(email_Input2);
		Element_isdisplayed(Email_input);
		input(Email_input, email_Input2);
		ExtentTestManager.getTest().log(Status.PASS, "Email input: '"+email_Input2+"'  entered successfully");
		Log.info("Email input: '"+email_Input2+"'  entered successfully");
	
	
		
		
		Thread.sleep(200);
		boolean b = driver.findElement(checkbox).isSelected();
		ExtentTestManager.getTest().log(Status.PASS, "Checkbox is clicked successfully");
		Log.info("Checkbox is clicked successfully");


		driver.findElement(Next_button).click();
		ExtentTestManager.getTest().log(Status.PASS, "Next button clicked successfully");
		Log.info("Next button clicked successfully");
	}
	
}


public void TC_14_Validate_text_Justonemorething(String Value,String Freepass_Condition,String zip,String justonemore,String first_Name, String last_Name, String phone_Num, String email_Input2) throws Exception {
	
	if (Value.equalsIgnoreCase("text_Justonemorething")) {

		
		Element_isdisplayed(FreePass_top_button);
		click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass button clicked successfully");
		Log.info("Freepass button clicked successfully");	
		
		Element_isdisplayed(zipcode_field);
		input(zipcode_field, zip.trim());
		ExtentTestManager.getTest().log(Status.PASS, "zipcode_field input: '"+zip+"' entered successfully");
		Log.info("zipcode_field input: '"+zip+"' entered successfully");
		
//		driver.findElement(zipcode_field).sendKeys(zip.trim());	
		
		click(find_button);
		 click(results_firstrow);
		Thread.sleep(100);
		
		Element_isdisplayed(Firstname_input);
		input(Firstname_input, first_Name.trim());
		
		
//		driver.findElement(Firstname_input).sendKeys(first_Name);
		ExtentTestManager.getTest().log(Status.PASS, "Firstname input: '"+first_Name+"' entered successfully");
		Log.info("Firstname input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Lastname_input);
		input(Lastname_input, last_Name.trim());
		
		
//		driver.findElement(Lastname_input).sendKeys(last_Name);
		ExtentTestManager.getTest().log(Status.PASS, "last_Name input: '"+last_Name+"' entered successfully");
		Log.info("last_Name input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Cellphone_input);
		input(Cellphone_input, phone_Num.trim());
		
		
//		driver.findElement(Cellphone_input).sendKeys(phone_Num);
		ExtentTestManager.getTest().log(Status.PASS, "Cellphone input: '"+phone_Num+"' entered successfully");
		Log.info("Cellphone input: '"+phone_Num+"' entered successfully");
		Thread.sleep(100);
//		driver.findElement(Email_input).sendKeys(email_Input2);
		Element_isdisplayed(Email_input);
		input(Email_input, email_Input2);
		ExtentTestManager.getTest().log(Status.PASS, "Email input: '"+email_Input2+"'  entered successfully");
		Log.info("Email input: '"+email_Input2+"'  entered successfully");
	
	Thread.sleep(200);
//	  driver.findElement(checkbox).click();
	  click(checkbox);
		ExtentTestManager.getTest().log(Status.PASS, "Checkbox is clicked successfully");
		Log.info("Checkbox is clicked successfully");


//		driver.findElement(Next_button).click();
		click(Next_button);
		ExtentTestManager.getTest().log(Status.PASS, "Next button clicked successfully");
		Log.info("Next button clicked successfully");
		Thread.sleep(200);
		//Element_isdisplayed(Text_justonemorething);
		//String[] Inputjust = justonemore.split(",");
		//
		String text = driver.findElement(Text_justonemorething).getText().replace("\n", " ").trim();
		System.out.println(text.toUpperCase());
//		System.out.println(Inputjust[0].trim().toUpperCase());
		Assert.assertEquals(text.toUpperCase(),justonemore.trim().toUpperCase(),"Just one more text text doesnot matched");
		
	//	Assert.assertEquals(Gymtrial_Text.toUpperCase(),Inputjust[1].trim().toUpperCase(),"Just one more text text doesnot matched");
		
		Log.info("Just one more text displayed and validated successfully");
		ExtentTestManager.getTest().log(Status.PASS, "Just one more text validated successfully");
		
	
		
	}
	
}


public void TC_15_Validate_text_WAIVER(String Value,String Freepass_Condition,String zip,String justonemore,String first_Name, String last_Name, String phone_Num, String email_Input2) throws Exception {
	
	if (Value.equalsIgnoreCase("Text_waiver")) {

		
		Element_isdisplayed(FreePass_top_button);
		click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass button clicked successfully");
		Log.info("Freepass button clicked successfully");	
		
		Element_isdisplayed(zipcode_field);
		input(zipcode_field, zip.trim());
		ExtentTestManager.getTest().log(Status.PASS, "zipcode_field input: '"+zip+"' entered successfully");
		Log.info("zipcode_field input: '"+zip+"' entered successfully");
		
//		driver.findElement(zipcode_field).sendKeys(zip.trim());	
		
		click(find_button);
		 click(results_firstrow);
		Thread.sleep(100);
		
		Element_isdisplayed(Firstname_input);
		input(Firstname_input, first_Name.trim());
		
		
//		driver.findElement(Firstname_input).sendKeys(first_Name);
		ExtentTestManager.getTest().log(Status.PASS, "Firstname input: '"+first_Name+"' entered successfully");
		Log.info("Firstname input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Lastname_input);
		input(Lastname_input, last_Name.trim());
		
		
//		driver.findElement(Lastname_input).sendKeys(last_Name);
		ExtentTestManager.getTest().log(Status.PASS, "last_Name input: '"+last_Name+"' entered successfully");
		Log.info("last_Name input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Cellphone_input);
		input(Cellphone_input, phone_Num.trim());
		
		
//		driver.findElement(Cellphone_input).sendKeys(phone_Num);
		ExtentTestManager.getTest().log(Status.PASS, "Cellphone input: '"+phone_Num+"' entered successfully");
		Log.info("Cellphone input: '"+phone_Num+"' entered successfully");
		Thread.sleep(100);
//		driver.findElement(Email_input).sendKeys(email_Input2);
		Element_isdisplayed(Email_input);
		input(Email_input, email_Input2);
		ExtentTestManager.getTest().log(Status.PASS, "Email input: '"+email_Input2+"'  entered successfully");
		Log.info("Email input: '"+email_Input2+"'  entered successfully");
	Thread.sleep(200);
	  driver.findElement(checkbox).click();
		ExtentTestManager.getTest().log(Status.PASS, "Checkbox is clicked successfully");
		Log.info("Checkbox is clicked successfully");


		driver.findElement(Next_button).click();
		ExtentTestManager.getTest().log(Status.PASS, "Next button clicked successfully");
		Log.info("Next button clicked successfully");

		String Act_Waiver = driver.findElement(Text_waiver).getText();
		String Act_Waiverbelow = driver.findElement(Text_waiver_below).getText();
	
		String Waivertext = Act_Waiver +" "+Act_Waiverbelow.replaceAll("\n+", " ").trim();
		
		Assert.assertEquals(Waivertext.toUpperCase(),justonemore.trim().toUpperCase(),"waiver text doesnot matched");
		
		//	Assert.assertEquals(Gymtrial_Text.toUpperCase(),Inputjust[1].trim().toUpperCase(),"Just one more text text doesnot matched");
			
			Log.info("waiver text displayed and validated successfully: "+ Waivertext);
			ExtentTestManager.getTest().log(Status.PASS, "waiver text displayed and validated successfully:"+ Waivertext);
			
			

	}
}
public void TC_16_Validate_text_agreement(String Value,String Freepass_Condition,String zip,String justonemore,String first_Name, String last_Name, String phone_Num, String email_Input2) throws Exception {
	
	if (Value.equalsIgnoreCase("Text_agreement")) {
		
		Element_isdisplayed(FreePass_top_button);
		click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass button clicked successfully");
		Log.info("Freepass button clicked successfully");	
		
		Element_isdisplayed(zipcode_field);
		input(zipcode_field, zip.trim());
		ExtentTestManager.getTest().log(Status.PASS, "zipcode_field input: '"+zip+"' entered successfully");
		Log.info("zipcode_field input: '"+zip+"' entered successfully");
		
//		driver.findElement(zipcode_field).sendKeys(zip.trim());	
		
		click(find_button);
		 click(results_firstrow);
		Thread.sleep(100);
		
		Element_isdisplayed(Firstname_input);
		input(Firstname_input, first_Name.trim());
		
		
//		driver.findElement(Firstname_input).sendKeys(first_Name);
		ExtentTestManager.getTest().log(Status.PASS, "Firstname input: '"+first_Name+"' entered successfully");
		Log.info("Firstname input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Lastname_input);
		input(Lastname_input, last_Name.trim());
		
		
//		driver.findElement(Lastname_input).sendKeys(last_Name);
		ExtentTestManager.getTest().log(Status.PASS, "last_Name input: '"+last_Name+"' entered successfully");
		Log.info("last_Name input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Cellphone_input);
		input(Cellphone_input, phone_Num.trim());
		
		
//		driver.findElement(Cellphone_input).sendKeys(phone_Num);
		ExtentTestManager.getTest().log(Status.PASS, "Cellphone input: '"+phone_Num+"' entered successfully");
		Log.info("Cellphone input: '"+phone_Num+"' entered successfully");
		Thread.sleep(100);
//		driver.findElement(Email_input).sendKeys(email_Input2);
		Element_isdisplayed(Email_input);
		input(Email_input, email_Input2);
		ExtentTestManager.getTest().log(Status.PASS, "Email input: '"+email_Input2+"'  entered successfully");
		Log.info("Email input: '"+email_Input2+"'  entered successfully");
			Thread.sleep(200);
	  driver.findElement(checkbox).click();
		ExtentTestManager.getTest().log(Status.PASS, "Checkbox is clicked successfully");
		Log.info("Checkbox is clicked successfully");


		driver.findElement(Next_button).click();
		ExtentTestManager.getTest().log(Status.PASS, "Next button clicked successfully");
		Log.info("Next button clicked successfully");

		String Text_Agreement = driver.findElement(Text_agreeme).getText().replaceAll("\n+", " ").trim();
		
Assert.assertEquals(Text_Agreement.toUpperCase(),justonemore.trim().toUpperCase(),"waiver text doesnot matched");
		
	
			Log.info("waiver text displayed and validated successfully: "+ Text_Agreement);
			ExtentTestManager.getTest().log(Status.PASS, "waiver text displayed and validated successfully:"+ Text_Agreement);
	
	}
	}




public void TC_17_Validate_text_Firstlast_Names(String Value,String Freepass_Condition,String zip,String Firstlast_Names,String first_Name, String last_Name, String phone_Num, String email_Input2) throws Exception {
	
	if (Value.equalsIgnoreCase("First_last")) {
		
		Element_isdisplayed(FreePass_top_button);
		click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass button clicked successfully");
		Log.info("Freepass button clicked successfully");	
		
		Element_isdisplayed(zipcode_field);
		input(zipcode_field, zip.trim());
		ExtentTestManager.getTest().log(Status.PASS, "zipcode_field input: '"+zip+"' entered successfully");
		Log.info("zipcode_field input: '"+zip+"' entered successfully");
		
//		driver.findElement(zipcode_field).sendKeys(zip.trim());	
		
		click(find_button);
		 click(results_firstrow);
		Thread.sleep(100);
		
		Element_isdisplayed(Firstname_input);
		input(Firstname_input, first_Name.trim());
		
		
//		driver.findElement(Firstname_input).sendKeys(first_Name);
		ExtentTestManager.getTest().log(Status.PASS, "Firstname input: '"+first_Name+"' entered successfully");
		Log.info("Firstname input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Lastname_input);
		input(Lastname_input, last_Name.trim());
		
		
//		driver.findElement(Lastname_input).sendKeys(last_Name);
		ExtentTestManager.getTest().log(Status.PASS, "last_Name input: '"+last_Name+"' entered successfully");
		Log.info("last_Name input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Cellphone_input);
		input(Cellphone_input, phone_Num.trim());
		
		
//		driver.findElement(Cellphone_input).sendKeys(phone_Num);
		ExtentTestManager.getTest().log(Status.PASS, "Cellphone input: '"+phone_Num+"' entered successfully");
		Log.info("Cellphone input: '"+phone_Num+"' entered successfully");
		Thread.sleep(100);
//		driver.findElement(Email_input).sendKeys(email_Input2);
		Element_isdisplayed(Email_input);
		input(Email_input, email_Input2);
		ExtentTestManager.getTest().log(Status.PASS, "Email input: '"+email_Input2+"'  entered successfully");
		Log.info("Email input: '"+email_Input2+"'  entered successfully");
			
		driver.findElement(checkbox).click();
		ExtentTestManager.getTest().log(Status.PASS, "Checkbox is clicked successfully");
		Log.info("Checkbox is clicked successfully");

		driver.findElement(Next_button).click();
		ExtentTestManager.getTest().log(Status.PASS, "Next button clicked successfully");
		Log.info("Next button clicked successfully");
		
		MoveToElement(FL_Names);
		driver.findElement(FL_Names).sendKeys(Firstlast_Names.trim());	
	
		ExtentTestManager.getTest().log(Status.PASS, "Enter First and Last name successfully");
		Log.info("Enter First and Last name successfully");
	
	}
}


public void TC_18_Validate_Text_Acknowledgement(String Value,String Freepass_Condition,String zip,String First_last_names,String Text_input,String first_Name, String last_Name, String phone_Num, String email_Input2) throws Exception {
	
	if (Value.equalsIgnoreCase("Text_Acknowledgement")) {
		
		Element_isdisplayed(FreePass_top_button);
		click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass button clicked successfully");
		Log.info("Freepass button clicked successfully");	
		
		Element_isdisplayed(zipcode_field);
		input(zipcode_field, zip.trim());
		ExtentTestManager.getTest().log(Status.PASS, "zipcode_field input: '"+zip+"' entered successfully");
		Log.info("zipcode_field input: '"+zip+"' entered successfully");
		
//		driver.findElement(zipcode_field).sendKeys(zip.trim());	
		
		click(find_button);
		 click(results_firstrow);
		Thread.sleep(100);
		
		Element_isdisplayed(Firstname_input);
		input(Firstname_input, first_Name.trim());
		
		
//		driver.findElement(Firstname_input).sendKeys(first_Name);
		ExtentTestManager.getTest().log(Status.PASS, "Firstname input: '"+first_Name+"' entered successfully");
		Log.info("Firstname input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Lastname_input);
		input(Lastname_input, last_Name.trim());
		
		
//		driver.findElement(Lastname_input).sendKeys(last_Name);
		ExtentTestManager.getTest().log(Status.PASS, "last_Name input: '"+last_Name+"' entered successfully");
		Log.info("last_Name input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Cellphone_input);
		input(Cellphone_input, phone_Num.trim());
		
		
//		driver.findElement(Cellphone_input).sendKeys(phone_Num);
		ExtentTestManager.getTest().log(Status.PASS, "Cellphone input: '"+phone_Num+"' entered successfully");
		Log.info("Cellphone input: '"+phone_Num+"' entered successfully");
		Thread.sleep(100);
//		driver.findElement(Email_input).sendKeys(email_Input2);
		Element_isdisplayed(Email_input);
		input(Email_input, email_Input2);
		ExtentTestManager.getTest().log(Status.PASS, "Email input: '"+email_Input2+"'  entered successfully");
		Log.info("Email input: '"+email_Input2+"'  entered successfully");
		
		
		driver.findElement(checkbox).click();
		ExtentTestManager.getTest().log(Status.PASS, "Checkbox is clicked successfully");
		Log.info("Checkbox is clicked successfully");


		driver.findElement(Next_button).click();
		ExtentTestManager.getTest().log(Status.PASS, "Next button clicked successfully");
		Log.info("Next button clicked successfully");
		
	//	MoveToElement(FL_Names);
		//driver.findElement(FL_Names).sendKeys(First_last_names);	
	
		//ExtentTestManager.getTest().log(Status.PASS, "Enter First and Last name successfully");
		//Log.info("Enter First and Last name successfully"); 
		
		Date date = new Date();  
//      System.out.println(formatter.format(date));
      System.out.println(date);
      String[] d=date.toString().split(" ");
      String day=d[0];
      String month=d[1];
      String day_number=d[2];
      String year=d[5];
      
      String day1= convert_day_to_fulldayname(day);
//      System.out.println(day1);
      
      String month1= convert_month_to_monthname(month);
//      System.out.println(month1);
      
      String full_date =day1+", "+month1+" "+day_number+" "+year;
    //  System.out.println(full_date);
	MoveToElement(acknowledge);
	Thread.sleep(200);
	
		String Textinput1 = Text_input.replace("DD/MM/YYYY", full_date);


		String Text_acknowledge = driver.findElement(acknowledge).getText().replaceAll("\n+", " ").trim();
	
Assert.assertEquals(Text_acknowledge.toUpperCase(),Textinput1.trim().toUpperCase(),"waiver text doesnot matched");
		
	
			Log.info("acknowledge text displayed and validated successfully: "+ Text_acknowledge);
			ExtentTestManager.getTest().log(Status.PASS, "acknowledge text displayed and validated successfully:"+ Text_acknowledge);
	
	}
}

public void TC_19_Validate_Text_AgreeEmailGuest(String Value,String Freepass_Condition,String zip,String First_last_names,String Text_input,String first_Name, String last_Name, String phone_Num, String email_Input2) throws Exception {
	
	if (Value.equalsIgnoreCase("Text_AgreeEmailGuest")) {
		
		Element_isdisplayed(FreePass_top_button);
		click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass button clicked successfully");
		Log.info("Freepass button clicked successfully");	
		
		Element_isdisplayed(zipcode_field);
		input(zipcode_field, zip.trim());
		ExtentTestManager.getTest().log(Status.PASS, "zipcode_field input: '"+zip+"' entered successfully");
		Log.info("zipcode_field input: '"+zip+"' entered successfully");
		
//		driver.findElement(zipcode_field).sendKeys(zip.trim());	
		
		click(find_button);
		 click(results_firstrow);
		Thread.sleep(100);
		
		Element_isdisplayed(Firstname_input);
		input(Firstname_input, first_Name.trim());
		
		
//		driver.findElement(Firstname_input).sendKeys(first_Name);
		ExtentTestManager.getTest().log(Status.PASS, "Firstname input: '"+first_Name+"' entered successfully");
		Log.info("Firstname input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Lastname_input);
		input(Lastname_input, last_Name.trim());
		
		
//		driver.findElement(Lastname_input).sendKeys(last_Name);
		ExtentTestManager.getTest().log(Status.PASS, "last_Name input: '"+last_Name+"' entered successfully");
		Log.info("last_Name input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Cellphone_input);
		input(Cellphone_input, phone_Num.trim());
		
		
//		driver.findElement(Cellphone_input).sendKeys(phone_Num);
		ExtentTestManager.getTest().log(Status.PASS, "Cellphone input: '"+phone_Num+"' entered successfully");
		Log.info("Cellphone input: '"+phone_Num+"' entered successfully");
		Thread.sleep(100);
//		driver.findElement(Email_input).sendKeys(email_Input2);
		Element_isdisplayed(Email_input);
		input(Email_input, email_Input2);
		ExtentTestManager.getTest().log(Status.PASS, "Email input: '"+email_Input2+"'  entered successfully");
		Log.info("Email input: '"+email_Input2+"'  entered successfully");
			
		driver.findElement(checkbox).click();
		ExtentTestManager.getTest().log(Status.PASS, "Checkbox is clicked successfully");
		Log.info("Checkbox is clicked successfully");


		driver.findElement(Next_button).click();
		ExtentTestManager.getTest().log(Status.PASS, "Next button clicked successfully");
		Log.info("Next button clicked successfully");
		
		MoveToElement(FL_Names);
		driver.findElement(FL_Names).sendKeys(First_last_names);	

		ExtentTestManager.getTest().log(Status.PASS, "Enter First and Last name successfully");
		Log.info("Enter First and Last name successfully"); 
		MoveToElement(Text_Agree_andEmail);
		
	
	MoveToElement(Text_Agree_andEmail);
	Thread.sleep(200);
		String Text_AgreeEmail = driver.findElement(Text_Agree_andEmail).getAttribute("value");

		Assert.assertEquals(Text_AgreeEmail.toUpperCase(),Text_input.trim().toUpperCase(),"AGREE AND EMAIL GUEST PASS not validated");
						
					Log.info("AGREE AND EMAIL GUEST PASS"+ Text_AgreeEmail);
					ExtentTestManager.getTest().log(Status.PASS, "AGREE AND EMAIL GUEST PASS:"+ Text_AgreeEmail);
				
	}
	}


public void TC_20_Validate_Button_AgreeEmailGuest(String Value,String Freepass_Condition,String zip,String First_last_names,String Text_input,String first_Name, String last_Name, String phone_Num, String email_Input2) throws Exception {
	
	if (Value.equalsIgnoreCase("Button_AgreeEmailGuest")) {
		
		Element_isdisplayed(FreePass_top_button);
		click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass button clicked successfully");
		Log.info("Freepass button clicked successfully");	
		
		Element_isdisplayed(zipcode_field);
		input(zipcode_field, zip.trim());
		ExtentTestManager.getTest().log(Status.PASS, "zipcode_field input: '"+zip+"' entered successfully");
		Log.info("zipcode_field input: '"+zip+"' entered successfully");
		
//		driver.findElement(zipcode_field).sendKeys(zip.trim());	
		
		click(find_button);
		 click(results_firstrow);
		Thread.sleep(100);
		
		Element_isdisplayed(Firstname_input);
		input(Firstname_input, first_Name.trim());
		
		
//		driver.findElement(Firstname_input).sendKeys(first_Name);
		ExtentTestManager.getTest().log(Status.PASS, "Firstname input: '"+first_Name+"' entered successfully");
		Log.info("Firstname input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Lastname_input);
		input(Lastname_input, last_Name.trim());
		
		
//		driver.findElement(Lastname_input).sendKeys(last_Name);
		ExtentTestManager.getTest().log(Status.PASS, "last_Name input: '"+last_Name+"' entered successfully");
		Log.info("last_Name input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Cellphone_input);
		input(Cellphone_input, phone_Num.trim());
		
		
//		driver.findElement(Cellphone_input).sendKeys(phone_Num);
		ExtentTestManager.getTest().log(Status.PASS, "Cellphone input: '"+phone_Num+"' entered successfully");
		Log.info("Cellphone input: '"+phone_Num+"' entered successfully");
		Thread.sleep(100);
//		driver.findElement(Email_input).sendKeys(email_Input2);
		Element_isdisplayed(Email_input);
		input(Email_input, email_Input2);
		ExtentTestManager.getTest().log(Status.PASS, "Email input: '"+email_Input2+"'  entered successfully");
		Log.info("Email input: '"+email_Input2+"'  entered successfully");
			
		driver.findElement(checkbox).click();
		ExtentTestManager.getTest().log(Status.PASS, "Checkbox is clicked successfully");
		Log.info("Checkbox is clicked successfully");


		driver.findElement(Next_button).click();
		ExtentTestManager.getTest().log(Status.PASS, "Next button clicked successfully");
		Log.info("Next button clicked successfully");
	
		MoveToElement(FL_Names);
		driver.findElement(FL_Names).sendKeys(First_last_names);	

		ExtentTestManager.getTest().log(Status.PASS, "Enter First and Last name successfully");
		Log.info("Enter First and Last name successfully"); 
		
		MoveToElement(Text_Agree_andEmail);	
		Thread.sleep(200);
		//String Text_AgreeEmail = driver.findElement(Text_Agree_andEmail).getAttribute("value");
		boolean status = driver.findElement(Text_Agree_andEmail).isEnabled();
		
		if(status){
			System.out.println("AGREE AND EMAIL GUEST PASS button is enabled");
		} else {
			System.out.println("AGREE AND EMAIL GUEST PASS button is disabled");
		}
				
	}
	}
public void TC_21_Validate_Text_FreePassConfm(String Value,String Freepass_Condition,String zip,String First_last_names,String Text_input,String first_Name, String last_Name, String phone_Num, String email_Input2) throws Exception {
	
	if (Value.equalsIgnoreCase("Text_FreePassConfm")) {

		
		Element_isdisplayed(FreePass_top_button);
		click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass button clicked successfully");
		Log.info("Freepass button clicked successfully");	
		
		Element_isdisplayed(zipcode_field);
		input(zipcode_field, zip.trim());
		ExtentTestManager.getTest().log(Status.PASS, "zipcode_field input: '"+zip+"' entered successfully");
		Log.info("zipcode_field input: '"+zip+"' entered successfully");
		
//		driver.findElement(zipcode_field).sendKeys(zip.trim());	
		
		click(find_button);
		 click(results_firstrow);
		Thread.sleep(100);
		
		Element_isdisplayed(Firstname_input);
		input(Firstname_input, first_Name.trim());
		
		
//		driver.findElement(Firstname_input).sendKeys(first_Name);
		ExtentTestManager.getTest().log(Status.PASS, "Firstname input: '"+first_Name+"' entered successfully");
		Log.info("Firstname input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Lastname_input);
		input(Lastname_input, last_Name.trim());
		
		
//		driver.findElement(Lastname_input).sendKeys(last_Name);
		ExtentTestManager.getTest().log(Status.PASS, "last_Name input: '"+last_Name+"' entered successfully");
		Log.info("last_Name input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Cellphone_input);
		input(Cellphone_input, phone_Num.trim());
		
		
//		driver.findElement(Cellphone_input).sendKeys(phone_Num);
		ExtentTestManager.getTest().log(Status.PASS, "Cellphone input: '"+phone_Num+"' entered successfully");
		Log.info("Cellphone input: '"+phone_Num+"' entered successfully");
		Thread.sleep(100);
//		driver.findElement(Email_input).sendKeys(email_Input2);
		Element_isdisplayed(Email_input);
		input(Email_input, email_Input2);
		ExtentTestManager.getTest().log(Status.PASS, "Email input: '"+email_Input2+"'  entered successfully");
		Log.info("Email input: '"+email_Input2+"'  entered successfully");
	
		
		driver.findElement(checkbox).click();
		ExtentTestManager.getTest().log(Status.PASS, "Checkbox is clicked successfully");
		Log.info("Checkbox is clicked successfully");


		driver.findElement(Next_button).click();
		ExtentTestManager.getTest().log(Status.PASS, "Next button clicked successfully");
		Log.info("Next button clicked successfully");
	
		MoveToElement(FL_Names);
		driver.findElement(FL_Names).sendKeys(First_last_names);	

		ExtentTestManager.getTest().log(Status.PASS, "Enter First and Last name successfully");
		Log.info("Enter First and Last name successfully"); 
		Thread.sleep(200);
		MoveToElement(Text_Agree_andEmail);	
		driver.findElement(Text_Agree_andEmail).click();
		String Free_cofm = driver.findElement(Freepass_confirmation).getText();
		
		Assert.assertEquals(Free_cofm.toUpperCase(),Text_input.trim().toUpperCase(),"Free pass confirmation text not validated");
						
					Log.info("Free Pass confirmation text validated"+ Free_cofm);
					ExtentTestManager.getTest().log(Status.PASS, "Free Pass confirmation text not validated:"+ Free_cofm);		
	}
	}


public void TC_22_Validate_Text_ThankyouConfm(String Value,String Freepass_Condition,String zip,String First_last_names,String Text_input,String first_Name, String last_Name, String phone_Num, String email_Input2) throws Exception {
	
	if (Value.equalsIgnoreCase("Text_ThankyouConfm")) {
		
		Element_isdisplayed(FreePass_top_button);
		click(FreePass_top_button);
		
		ExtentTestManager.getTest().log(Status.PASS, "Freepass button clicked successfully");
		Log.info("Freepass button clicked successfully");	
		
		Element_isdisplayed(zipcode_field);
		input(zipcode_field, zip.trim());
		ExtentTestManager.getTest().log(Status.PASS, "zipcode_field input: '"+zip+"' entered successfully");
		Log.info("zipcode_field input: '"+zip+"' entered successfully");
		
//		driver.findElement(zipcode_field).sendKeys(zip.trim());	
		
		click(find_button);
		 click(results_firstrow);
		Thread.sleep(100);
		
		Element_isdisplayed(Firstname_input);
		input(Firstname_input, first_Name.trim());
		
		
//		driver.findElement(Firstname_input).sendKeys(first_Name);
		ExtentTestManager.getTest().log(Status.PASS, "Firstname input: '"+first_Name+"' entered successfully");
		Log.info("Firstname input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Lastname_input);
		input(Lastname_input, last_Name.trim());
		
		
//		driver.findElement(Lastname_input).sendKeys(last_Name);
		ExtentTestManager.getTest().log(Status.PASS, "last_Name input: '"+last_Name+"' entered successfully");
		Log.info("last_Name input: '"+first_Name+"' entered successfully");
		
		Element_isdisplayed(Cellphone_input);
		input(Cellphone_input, phone_Num.trim());
		
		
//		driver.findElement(Cellphone_input).sendKeys(phone_Num);
		ExtentTestManager.getTest().log(Status.PASS, "Cellphone input: '"+phone_Num+"' entered successfully");
		Log.info("Cellphone input: '"+phone_Num+"' entered successfully");
		Thread.sleep(100);
//		driver.findElement(Email_input).sendKeys(email_Input2);
		Element_isdisplayed(Email_input);
		input(Email_input, email_Input2);
		ExtentTestManager.getTest().log(Status.PASS, "Email input: '"+email_Input2+"'  entered successfully");
		Log.info("Email input: '"+email_Input2+"'  entered successfully");
			
		driver.findElement(checkbox).click();
		ExtentTestManager.getTest().log(Status.PASS, "Checkbox is clicked successfully");
		Log.info("Checkbox is clicked successfully");


		driver.findElement(Next_button).click();
		ExtentTestManager.getTest().log(Status.PASS, "Next button clicked successfully");
		Log.info("Next button clicked successfully");
	
		MoveToElement(FL_Names);
		driver.findElement(FL_Names).sendKeys(First_last_names);	

		ExtentTestManager.getTest().log(Status.PASS, "Enter First and Last name successfully");
		Log.info("Enter First and Last name successfully"); 
		Thread.sleep(200);
		MoveToElement(Text_Agree_andEmail);	
		driver.findElement(Text_Agree_andEmail).click();
		String Thanku_cofm = driver.findElement(Thankyou_confirmation).getText();
		
		Assert.assertEquals(Thanku_cofm.toUpperCase(),Text_input.trim().toUpperCase(),"Thankyou confirmation text not validated");
						
					Log.info("Thankyou confirmation text validated"+ Thanku_cofm);
					ExtentTestManager.getTest().log(Status.PASS, "Thankyou confirmation text not validated:"+ Thanku_cofm);	
					
	}
	}

}