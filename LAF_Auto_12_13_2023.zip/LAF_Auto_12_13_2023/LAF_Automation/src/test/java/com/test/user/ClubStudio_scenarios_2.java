
	package com.test.user;
	
	import java.io.File;
	import java.io.IOException;
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.List;
	import java.util.Map;
	import org.testng.ITestContext;
	import org.testng.annotations.AfterTest;
	import org.testng.annotations.BeforeSuite;
	import org.apache.commons.lang3.ObjectUtils.Null;
	import org.apache.poi.hssf.record.PageBreakRecord.Break;
	import org.testng.*;
	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Test;
	import com.BasePackage.Base_Class;
	import com.Utility.Log;
	import com.aventstack.extentreports.MediaEntityBuilder;
	import com.aventstack.extentreports.Status;
	import com.extentReports.ExtentManager;
	import com.extentReports.ExtentTestManager;
	import com.google.common.base.Throwables;
	import com.listeners.TestListener;
	
	public class ClubStudio_scenarios_2 extends Base_Class  {
	
		Base_Class Base_Class;
		com.pages.Home Home;
		com.pages.Joinnow joinnow;
		Log log;
		TestListener TestListener;
		com.Utility.ScreenShot screenShot;
		com.pages.Employment Employment;
		com.pages.FreePass FreePass;
		com.pages.CareerOpportunity CareerOpportunity;
		com.pages.ClubStudio ClubStudio;
		
		
		@BeforeSuite
		public void reference() {
			Base_Class = new Base_Class();
			log = new Log();
			TestListener = new TestListener();
			screenShot = new com.Utility.ScreenShot(null);
			Home = new com.pages.Home();
			joinnow = new com.pages.Joinnow();
			Employment = new com.pages.Employment();
			FreePass = new com.pages.FreePass();
			ClubStudio = new com.pages.ClubStudio();
			CareerOpportunity = new com.pages.CareerOpportunity();
		}
		
		@Test(dataProvider = "TestData")
		public void RUNALL(Map<Object, Object> testdata, ITestContext context) throws Throwable {
	
			try {
	
				if (testdata.get("Run").toString().equalsIgnoreCase("Yes")) {
					String fileName;
					ExtentTestManager.startTest(testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " running Starting ***");
					Log.info("*** Running test method " + testdata.get("TestScenario").toString() + "...");
					ExtentTestManager.getTest().log(Status.PASS, "*** Running test method " + testdata.get("TestScenario").toString() + "...");
				
					String Change_brand_name=testdata.get("Change_brand_name").toString();
					if(testdata.get("TextMessage").toString().trim().equalsIgnoreCase("Change_Brand".trim())) {
						
						Base_Class.setup_Change_brand();
						if(!Change_brand_name.isBlank() && !Change_brand_name.isEmpty()) Base_Class.Change_Brand(Change_brand_name);
						
					else {
						
						throw new Exception("please provide brand name to change the brand");
					
						}
						
					driver.quit();
						
					}
					
					else {
						Base_Class.setup();
					}
	
					
//					Base_Class.setup();
					ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered into Application URL ");
	
	
					String Dropdown_values=testdata.get("Dropdown_values").toString();
	
					String Country =testdata.get("Country").toString();
					String Ratesoramenities =testdata.get("Rates/amenities").toString();
					String Club_name =testdata.get("Club_name").toString();
					
					String Add_amenities =testdata.get("Add_amenities").toString();
					String Included_amenities =testdata.get("Included_amenities").toString();
				
					String Amount_details =testdata.get("Amount_details").toString();
					String rates_details =testdata.get("Rates_details").toString();
					String plan_rates =testdata.get("Plan_rates").toString();
					
					
					
					
					String Text_input =testdata.get("Text_input").toString();
		
					
					String Number_of_Persons1 =testdata.get("Number_of_Persons1").toString();
					String Initiation_Fee =testdata.get("Initiation_Fee").toString();
					String Billing_Frequency =testdata.get("Billing_Frequency").toString();				
					String Initial_Term =testdata.get("Initial_Term").toString();
					String Prepayment =testdata.get("Prepayment").toString();
					String First_Month_Dues =testdata.get("First_Month_Dues").toString();
					String Last_Month_Dues =testdata.get("Last_Month_Dues").toString();
					String Total_initial_Payment =testdata.get("Total_initial_Payment").toString();	
					String Annual_Fee_Per_Person =testdata.get("Annual_Fee_Per_Person").toString();
					
					String Everemployed_rdobtn =testdata.get("Everemployed_rdobtn").toString();
					String Date_to_begin =testdata.get("Date_to_begin").toString();
					String Languages =testdata.get("Languages").toString();
					String Work_time =testdata.get("Work_time").toString();
					String Url =testdata.get("Url").toString();
					String additional_input =testdata.get("additional_input").toString();
					String input_data =testdata.get("input_data").toString();
					String input_data1 =testdata.get("input_data1").toString();
					String input_data2 =testdata.get("input_data2").toString();
					String input_data3 =testdata.get("input_data3").toString();
					String input_data4 =testdata.get("input_data4").toString();
					String input_data5 =testdata.get("input_data5").toString();
					String input_data6 =testdata.get("input_data6").toString();
					String IP_Address =testdata.get("IP_Address").toString();
					
					String File_name =testdata.get("File_name").toString();
					
					String Job_short_des =testdata.get("Job_short_des").toString();
					String Job_long_des =testdata.get("Job_long_des").toString();
					String F_Name =testdata.get("F_Name").toString();
					String L_Name =testdata.get("L_Name").toString();
					String Full_name =testdata.get("Full_name").toString();
					String Phone =testdata.get("Member_Phone").toString();
					String Email =testdata.get("Email").toString();
					String Address =testdata.get("Member_address").toString();
	//				job_short_des
					String City =testdata.get("Member_City").toString();
					
					String E_EducationLeve_Dropdown = testdata.get("E_EducationLeve_Dropdown").toString();
	
					String Aerobics_Instructor_Exp_DD = testdata.get("Aerobics_Instructor_Exp_DD").toString();
					String Time_period_DD = testdata.get("Time_period_DD").toString();
					String Club_Employer_DD = testdata.get("Club_Employer_DD").toString();
					String Class_per_week = testdata.get("Class_per_week").toString();
					
					String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
					String PriorEmploymentWhyResigned_ip = testdata.get("PriorEmploymentWhyResigned_ip").toString();
					String EmploymentWhyLeaveCurrent_ip = testdata.get("EmploymentWhyLeaveCurrent_ip").toString();
					String EmploymentWhyReapply_ip = testdata.get("EmploymentWhyReapply_ip").toString();
					String EmploymentWhatLike_ip = testdata.get("EmploymentWhatLike_ip").toString();
					String EmploymentWhatDislike_ip = testdata.get("EmploymentWhatDislike_ip").toString();
					
					String EmploymentSuccess_ip = testdata.get("EmploymentSuccess_ip").toString();
					String EmploymentWhyResignInFuture_ip = testdata.get("EmploymentWhyResignInFuture_ip").toString();
					String Gender_dd = testdata.get("Gender_dd").toString();
					String RaceEthnicity_dd = testdata.get("RaceEthnicity_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				
					String Personal_Training_ExperienceDPValues = testdata.get("Personal_Training_ExperienceDPValues").toString();
					String Certification_IssuedByDPValues = testdata.get("Certification_IssuedByDPValues").toString();
					String Hold_cert_GT_AC_ratio_button = testdata.get("Hold_cert_GT_AC_ratio_button").toString();
					String Certified_In_DD = testdata.get("Certified_In_DD").toString();
					String Certificate_No = testdata.get("Certificate_No").toString();
					String Emp_gap = testdata.get("Emp_gap").toString();
					String Employer_name = testdata.get("Employer_name").toString();
					String Supervisor_name = testdata.get("Supervisor_name").toString();
					String From_date = testdata.get("From_date").toString();
					String To_date = testdata.get("To_date").toString();
					String Job_title = testdata.get("Job_title").toString();
					String Leaving_Reason = testdata.get("Leaving_Reason").toString();
					String Emp_details = testdata.get("Emp_details").toString();
					String Can_contact_radio_button = testdata.get("Can_contact_radio_button").toString();
					
					
					String Club_phone =testdata.get("Club_phone").toString();
					String Club_zip =testdata.get("Club_zip").toString();
					String Club_Address =testdata.get("Club_Address").toString();
					String Club_city =testdata.get("Club_city").toString();
	//				
					String State =testdata.get("State").toString();
					String Zipcode =testdata.get("Member_Zipcode").toString();
					String Radius_travel_to_work =testdata.get("Radius_travel_to_work").toString();
					String How_hear_abt_us =testdata.get("How_hear_abt_us").toString();
					String Radiobtn18YearsOld =testdata.get("Radiobtn18YearsOld").toString();
					String Payment_type =testdata.get("Payment_type").toString();
					String Card_number  =testdata.get("Card_number").toString();
					
					String Ex_month =testdata.get("Ex_month").toString();
					String Ex_year  =testdata.get("Ex_year").toString();
					
					String Routing_number  =testdata.get("Routing_number").toString();
					String Account_number =testdata.get("Account_number").toString();
					String Card_name =testdata.get("Card_name").toString();
					String Checkbox_class_formats =testdata.get("Checkbox_class_formats").toString();

					String No_Prev_emp_chk_box =testdata.get("No_Prev_emp_chk_box").toString();
				
					String Considered_for_chkbx =testdata.get("Considered_for_chkbx").toString();
						
					
					
							
					switch (testdata.get("TextMessage").toString()) {
					
					
					
				case "Validate_emp_para_CSCC":
					
					context.setAttribute("fileName", "Validate_emp_para_CSCC");
					ClubStudio.Validate_emp_para_CSCC(testdata.get("TextMessage").toString(), Text_input, additional_input);
					context.setAttribute("fileName", "Validate_emp_para_CSCC");
					driver.quit();
					break;
					
					
				case "Validate_App_info_text_CSCC":
					
					context.setAttribute("fileName", "Validate_App_info_text_CSCC");
					ClubStudio.Validate_App_info_text_CSCC(testdata.get("TextMessage").toString(), Text_input, additional_input);
					context.setAttribute("fileName", "Validate_App_info_text_CSCC");
					driver.quit();
					break;
					
					
				case "Validate_all_ip_fields_in_emp_page_CSCC":
					
					context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_CSCC");
					ClubStudio.Validate_all_ip_fields_in_emp_page_CSCC(testdata.get("TextMessage").toString(), Text_input);
					context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_CSCC");
					driver.quit();
					break;
					
					
				case "Validate_Howdidyouhearaboutus_dd_CSCC":
					
					context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_CSCC");
					ClubStudio.Validate_Howdidyouhearaboutus_dd_CSCC(testdata.get("TextMessage").toString(), Text_input, Dropdown_values);
					context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_CSCC");
					driver.quit();
					break;
					
				case "Validate_Radiobtn18YearsOld_options_CSCC":
					
					context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_CSCC");
					ClubStudio.Validate_Radiobtn18YearsOld_options_CSCC(testdata.get("TextMessage").toString(), Text_input);
					context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_CSCC");
					driver.quit();
					break;
					
					
				case "Validate_US_format_text_CSCC":
					
					context.setAttribute("fileName", "Validate_US_format_text_CSCC");
					ClubStudio.Validate_US_format_text_CSCC(testdata.get("TextMessage").toString(), Text_input, additional_input);
					context.setAttribute("fileName", "Validate_US_format_text_CSCC");
					driver.quit();
					break;
					
					
				case "Validate_Miles_text_CSCC":
					
					context.setAttribute("fileName", "Validate_Miles_text_CSCC");
					ClubStudio.Validate_Miles_text_CSCC(testdata.get("TextMessage").toString(), Text_input, additional_input);
					context.setAttribute("fileName", "Validate_Miles_text_CSCC");
					driver.quit();
					break;
					
				case "Validate_phone_errorlabel_CSCC":
					
					context.setAttribute("fileName", "Validate_phone_errorlabel_CSCC");
					ClubStudio.Validate_phone_errorlabel_CSCC(testdata.get("TextMessage").toString(), Text_input, additional_input);
					context.setAttribute("fileName", "Validate_phone_errorlabel_CSCC");
					driver.quit();
					break;
					
					
				case "Validate_Next_step_button_in_l1_CSCC":
					
					context.setAttribute("fileName", "Validate_Next_step_button_in_l1_CSCC");
					ClubStudio.Validate_Next_step_button_in_l1_CSCC(testdata.get("TextMessage").toString(), Text_input);
					context.setAttribute("fileName", "Validate_Next_step_button_in_l1_CSCC");
					driver.quit();
					break;
					
					
				case "Validate_input_in_all_fields_CSCC":
					
				context.setAttribute("fileName", "Validate_input_in_all_fields_CSCC");
				ClubStudio.Validate_input_in_all_fields_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode  );
				context.setAttribute("fileName", "Validate_input_in_all_fields_CSCC");
				driver.quit();break;
					
				
				case "Validate_List18YrsOld_No_popupalrt_CSCC":
					
					context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_CSCC");
					ClubStudio.Validate_List18YrsOld_No_popupalrt_CSCC(testdata.get("TextMessage").toString(), Text_input, Radiobtn18YearsOld);
					context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_CSCC");
					driver.quit();
					break;
					
					
					
				case "Validate_Next_step_l1_CSCC":
					
				context.setAttribute("fileName", "Validate_Next_step_l1_CSCC");
				ClubStudio.Validate_Next_step_l1_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
				context.setAttribute("fileName", "Validate_Next_step_l1_CSCC");
				driver.quit();break;
					
					
				
				case "Validate_education_level_dd_CSCC":
					
				context.setAttribute("fileName", "Validate_education_level_dd_CSCC");
				ClubStudio.Validate_education_level_dd_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
				context.setAttribute("fileName", "Validate_education_level_dd_CSCC");
				driver.quit();break;
				
					
				
				case "Validate_edu_level_dd_allvalues_CSCC":
					
				context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_CSCC");
				ClubStudio.Validate_edu_level_dd_allvalues_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input , E_EducationLeve_Dropdown );
				context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_previous_next_step_buttons_l2_CSCC":
					
				context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_CSCC");
				ClubStudio.Validate_previous_next_step_buttons_l2_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
				context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_CSCC");
				driver.quit();break;
				
				
				case "Validate_previous_step_button_l2_CSCC":
					
				context.setAttribute("fileName", "Validate_previous_step_button_l2_CSCC");
				ClubStudio.Validate_previous_step_button_l2_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
				context.setAttribute("fileName", "Validate_previous_step_button_l2_CSCC");
				driver.quit();break;
				
				
				case "Validate_Next_step_button_l2_CSCC":
					
				context.setAttribute("fileName", "Validate_Next_step_button_l2_CSCC");
				ClubStudio.Validate_Next_step_button_l2_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
				context.setAttribute("fileName", "Validate_Next_step_button_l2_CSCC");
				driver.quit();break;
				

				case "Validate_Exp_info_text_in_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_CSCC");
				ClubStudio.Validate_Exp_info_text_in_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
				context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_CSCC");
				driver.quit();break;
				
				
				case "Validate_sales_mngnt_exp_text_in_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_sales_mngnt_exp_text_in_l3_CSCC");
				ClubStudio.Validate_sales_mngnt_exp_text_in_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
				context.setAttribute("fileName", "Validate_sales_mngnt_exp_text_in_l3_CSCC");
				driver.quit();break;
				
				case "Validate_Equipment_Techn_exp_heading_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_Equipment_Techn_exp_heading_l3_CSCC");
				ClubStudio.Validate_Equipment_Techn_exp_heading_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
				context.setAttribute("fileName", "Validate_Equipment_Techn_exp_heading_l3_CSCC");
				driver.quit();break;
				
				case "Validate_all_dropdowns_in_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_all_dropdowns_in_l3_CSCC");
				ClubStudio.Validate_all_dropdowns_in_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
				context.setAttribute("fileName", "Validate_all_dropdowns_in_l3_CSCC");
				driver.quit();break;
				
				case "Validate_all_options_FSE_dd_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_all_options_FSE_dd_l3_CSCC");
				ClubStudio.Validate_all_options_FSE_dd_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
				context.setAttribute("fileName", "Validate_all_options_FSE_dd_l3_CSCC");
				driver.quit();break;
				
				
				case "Validate_all_options_PTSE_dd_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_all_options_PTSE_dd_l3_CSCC");
				ClubStudio.Validate_all_options_PTSE_dd_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
				context.setAttribute("fileName", "Validate_all_options_PTSE_dd_l3_CSCC");
				driver.quit();break;
				
				case "Validate_all_options_ME_dd_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_all_options_ME_dd_l3_CSCC");
				ClubStudio.Validate_all_options_ME_dd_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
				context.setAttribute("fileName", "Validate_all_options_ME_dd_l3_CSCC");
				driver.quit();break;
				
				case "Validate_all_options_BE_dd_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_all_options_BE_dd_l3_CSCC");
				ClubStudio.Validate_all_options_BE_dd_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
				context.setAttribute("fileName", "Validate_all_options_BE_dd_l3_CSCC");
				driver.quit();break;
				
				case "Validate_all_options_YE_dd_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_all_options_YE_dd_l3_CSCC");
				ClubStudio.Validate_all_options_YE_dd_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
				context.setAttribute("fileName", "Validate_all_options_YE_dd_l3_CSCC");
				driver.quit();break;
				
				case "Validate_selecting_all_dds_in_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_selecting_all_dds_in_l3_CSCC");
				ClubStudio.Validate_selecting_all_dds_in_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
				context.setAttribute("fileName", "Validate_selecting_all_dds_in_l3_CSCC");
				driver.quit();break;
				
				
				case "Validate_Skills_section_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_Skills_section_l3_CSCC");
				ClubStudio.Validate_Skills_section_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data, input_data1 );
				context.setAttribute("fileName", "Validate_Skills_section_l3_CSCC");
				driver.quit();break;
				
				case "Validate_select_Skills_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_select_Skills_l3_CSCC");
				ClubStudio.Validate_select_Skills_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data );
				context.setAttribute("fileName", "Validate_select_Skills_l3_CSCC");
				driver.quit();break;
				

				case "Validate_Skills_2_section_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_Skills_2_section_l3_CSCC");
				ClubStudio.Validate_Skills_2_section_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data, input_data1 );
				context.setAttribute("fileName", "Validate_Skills_2_section_l3_CSCC");
				driver.quit();break;
				
				case "Validate_select_Skills_2_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_select_Skills_2_l3_CSCC");
				ClubStudio.Validate_select_Skills_2_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data );
				context.setAttribute("fileName", "Validate_select_Skills_2_l3_CSCC");
				driver.quit();break;

				
				case "Validate_Next_step_in_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_Next_step_in_l3_CSCC");
				ClubStudio.Validate_Next_step_in_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
				context.setAttribute("fileName", "Validate_Next_step_in_l3_CSCC");
				driver.quit();break;
				
				
				case "Validate_Prev_next_btns_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_Prev_next_btns_l3_CSCC");
				ClubStudio.Validate_Prev_next_btns_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
				context.setAttribute("fileName", "Validate_Prev_next_btns_l3_CSCC");
				driver.quit();break;
				
				
				case "Validate_Prev_step_in_l3_CSCC":
					
				context.setAttribute("fileName", "Validate_Prev_step_in_l3_CSCC");
				ClubStudio.Validate_Prev_step_in_l3_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
				context.setAttribute("fileName", "Validate_Prev_step_in_l3_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_EmpHis_PreEmp_texts_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_EmpHis_PreEmp_texts_in_l4_CSCC");
				ClubStudio.Validate_EmpHis_PreEmp_texts_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
				context.setAttribute("fileName", "Validate_EmpHis_PreEmp_texts_in_l4_CSCC");
				driver.quit();break;
				
				
				case "Validate_rdobtns_of_EmpHis_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_rdobtns_of_EmpHis_in_l4_CSCC");
				ClubStudio.Validate_rdobtns_of_EmpHis_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
				context.setAttribute("fileName", "Validate_rdobtns_of_EmpHis_in_l4_CSCC");
				driver.quit();break;
				
				case "Validate_upload_res_chkbx_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_upload_res_chkbx_in_l4_CSCC");
				ClubStudio.Validate_upload_res_chkbx_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
				context.setAttribute("fileName", "Validate_upload_res_chkbx_in_l4_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_upload_res_section_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_upload_res_section_in_l4_CSCC");
				ClubStudio.Validate_upload_res_section_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, input_data2);
				context.setAttribute("fileName", "Validate_upload_res_section_in_l4_CSCC");
				driver.quit();break;
				
				
				case "Validate_upload_res_file_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_upload_res_section_in_l4_CSCC");
				ClubStudio.Validate_upload_res_file_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, input_data2, File_name);
				context.setAttribute("fileName", "Validate_upload_res_file_l4_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_cur_prev_emp_texts_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_cur_prev_emp_texts_in_l4_CSCC");
				ClubStudio.Validate_cur_prev_emp_texts_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1,input_data2 );
				context.setAttribute("fileName", "Validate_cur_prev_emp_texts_in_l4_CSCC");
				driver.quit();break;
				
				
				case "Validate_all_ip_fields_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_all_ip_fields_in_l4_CSCC");
				ClubStudio.Validate_all_ip_fields_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
				context.setAttribute("fileName", "Validate_all_ip_fields_in_l4_CSCC");
				driver.quit();break;
				
				
				case "Validate_input_inallfields_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_input_inallfields_in_l4_CSCC");
				ClubStudio.Validate_input_inallfields_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button );
				context.setAttribute("fileName", "Validate_input_inallfields_in_l4_CSCC");
				driver.quit();break;
				
				
				case "Validate_prev_next_step_btns_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_CSCC");
				ClubStudio.Validate_prev_next_step_btns_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
				context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_CSCC");
				driver.quit();break;
				
				
				case "Validate_AddEmployer_2_btn_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_AddEmployer_2_btn_in_l4_CSCC");
				ClubStudio.Validate_AddEmployer_2_btn_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
				context.setAttribute("fileName", "Validate_AddEmployer_2_btn_in_l4_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_Next_btn_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_Next_btn_in_l4_CSCC");
				ClubStudio.Validate_Next_btn_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name);
				context.setAttribute("fileName", "Validate_Next_btn_in_l4_CSCC");
				driver.quit();break;
			
				
				case "Validate_No_Prev_Emp_RdoBtn_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_in_l4_CSCC");
				ClubStudio.Validate_No_Prev_Emp_RdoBtn_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
				context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_in_l4_CSCC");
				driver.quit();break;
				
				case "Validate_prev_step_btn_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_CSCC");
				ClubStudio.Validate_prev_step_btn_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
				context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_CSCC");
				driver.quit();break;
			
				
				case "Validate_all_ip_fieldsofAddemplr2_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr2_in_l4_CSCC");
				ClubStudio.Validate_all_ip_fieldsofAddemplr2_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
				context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr2_in_l4_CSCC");
				driver.quit();break;
				
				
				case "Validate_all_ip_fieldsofAddemplr3_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr3_in_l4_CSCC");
				ClubStudio.Validate_all_ip_fieldsofAddemplr3_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
				context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr3_in_l4_CSCC");
				driver.quit();break;
				
				case "Validate_removebtn2_by_ipingempr2_in_l4_CSCC":
					
				context.setAttribute("fileName", "Validate_removebtn2_by_ipingempr2_in_l4_CSCC");
				ClubStudio.Validate_removebtn2_by_ipingempr2_in_l4_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button );
				context.setAttribute("fileName", "Validate_removebtn2_by_ipingempr2_in_l4_CSCC");
				driver.quit();break;
				
				

				case "Validate_Ind_langs_text_l5_CSCC":
					
				context.setAttribute("fileName", "Validate_Ind_langs_text_l5_CSCC");
				ClubStudio.Validate_Ind_langs_text_l5_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, input_data2);
				context.setAttribute("fileName", "Validate_Ind_langs_text_l5_CSCC");
				driver.quit();break;
				
				
				case "Validate_all_langs_in_l5_CSCC":
					
				context.setAttribute("fileName", "Validate_all_langs_in_l5_CSCC");
				ClubStudio.Validate_all_langs_in_l5_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
				context.setAttribute("fileName", "Validate_all_langs_in_l5_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_bydefault_Eng_lang_sltd_in_l5_CSCC":
					
				context.setAttribute("fileName", "Validate_bydefault_Eng_lang_sltd_in_l5_CSCC");
				ClubStudio.Validate_bydefault_Eng_lang_sltd_in_l5_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
				context.setAttribute("fileName", "Validate_bydefault_Eng_lang_sltd_in_l5_CSCC");
				driver.quit();break;
				
				
				case "Validate_slt_desired_langs_in_l5_CSCC":
					
				context.setAttribute("fileName", "Validate_slt_desired_langs_in_l5_CSCC");
				ClubStudio.Validate_slt_desired_langs_in_l5_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
				context.setAttribute("fileName", "Validate_slt_desired_langs_in_l5_CSCC");
				driver.quit();break;
				

				case "Validate_prev_next_step_btns_in_l5_CSCC":
					
				context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_CSCC");
				ClubStudio.Validate_prev_next_step_btns_in_l5_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name);
				context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_CSCC");
				driver.quit();break;
				
				
				case "Validate_prev_step_btn_in_l5_CSCC":
					
				context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_CSCC");
				ClubStudio.Validate_prev_step_btn_in_l5_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name);
				context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_CSCC");
				driver.quit();break;
				
				
				case "Validate_Next_step_btn_in_l5_CSCC":
					
				context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_CSCC");
				ClubStudio.Validate_Next_step_btn_in_l5_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
				context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_CSCC");
				driver.quit();break;
				
				
				case "Validate_text_COqualify_in_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_text_COqualify_in_l6_CSCC");
				ClubStudio.Validate_text_COqualify_in_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data3);
				context.setAttribute("fileName", "Validate_text_COqualify_in_l6_CSCC");
				driver.quit();break;	
				
				
				case "Validate_all_fields_in_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_all_fields_in_l6_CSCC");
				ClubStudio.Validate_all_fields_in_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Considered_for_chkbx);
				context.setAttribute("fileName", "Validate_all_fields_in_l6_CSCC");
				driver.quit();break;
				
				
				case "Validate_slt_Worktime_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_slt_Worktime_l6_CSCC");
				ClubStudio.Validate_slt_Worktime_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time);
				context.setAttribute("fileName", "Validate_slt_Worktime_l6_CSCC");
				driver.quit();break;
				
				
				case "Validate_slt_considerfor_chkbxs_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_CSCC");
				ClubStudio.Validate_slt_considerfor_chkbxs_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx);
				context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_CSCC");
				driver.quit();break;
				
				
				case "Validate_deslt_considerfor_chkbxs_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_CSCC");
				ClubStudio.Validate_deslt_considerfor_chkbxs_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx);
				context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_COs_asperCFchkbxsltn_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_CSCC");
				ClubStudio.Validate_COs_asperCFchkbxsltn_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx);
				context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_CSCC");
				driver.quit();break;
				
				
				case "Validate_COs_asperCFchkbxdesltn_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_CSCC");
				ClubStudio.Validate_COs_asperCFchkbxdesltn_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx , input_data4);
				context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_defaultvalueofCO_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_CSCC");
				ClubStudio.Validate_defaultvalueofCO_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Considered_for_chkbx);
				context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_CSCC");
				driver.quit();break;
				
				
				case "Validate_ip_date_to_begin_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_CSCC");
				ClubStudio.Validate_ip_date_to_begin_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Date_to_begin );
				context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_CSCC");
				driver.quit();break;
				
				
				case "Validate_empdwithus_no_rdobtn_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_CSCC");
				ClubStudio.Validate_empdwithus_no_rdobtn_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
				context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_CSCC");
				driver.quit();break;
				
				case "Validate_basedonsltns_text_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_basedonsltns_text_l6_CSCC");
				ClubStudio.Validate_basedonsltns_text_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
				context.setAttribute("fileName", "Validate_basedonsltns_text_l6_CSCC");
				driver.quit();break;
				
				
				case "Validate_Club_locations_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_Club_locations_l6_CSCC");
				ClubStudio.Validate_Club_locations_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
				context.setAttribute("fileName", "Validate_Club_locations_l6_CSCC");
				driver.quit();break;
				
				
				case "Validate_Rehire_Questionnaire_sec_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6_CSCC");
				ClubStudio.Validate_Rehire_Questionnaire_sec_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
				context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_Resigned_dd_allvalues_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_CSCC");
				ClubStudio.Validate_Resigned_dd_allvalues_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, EmploymentHowResigned_dd );
				context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_ip_in_RQ_sec_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_CSCC");
				ClubStudio.Validate_ip_in_RQ_sec_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
				context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_CSCC");
				driver.quit();break;
				
				case "Validate_prev_next_step_btns_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_CSCC");
				ClubStudio.Validate_prev_next_step_btns_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages );
				context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_CSCC");
				driver.quit();break;
				
				
				case "Validate_prev_step_btn_in_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_CSCC");
				ClubStudio.Validate_prev_step_btn_in_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages );
				context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_CSCC");
				driver.quit();break;
				
				case "Validate_next_btn_byipallfields_l6_CSCC":
					
				context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_CSCC");
				ClubStudio.Validate_next_btn_byipallfields_l6_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
				context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_paras_in_l7_CSCC":
					
				context.setAttribute("fileName", "Validate_paras_in_l7_CSCC");
				ClubStudio.Validate_paras_in_l7_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data2 );
				context.setAttribute("fileName", "Validate_paras_in_l7_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_rdobtns_in_l7_CSCC":
					
				context.setAttribute("fileName", "Validate_rdobtns_in_l7_CSCC");
				ClubStudio.Validate_rdobtns_in_l7_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
				context.setAttribute("fileName", "Validate_rdobtns_in_l7_CSCC");
				driver.quit();break;
				
				
				case "Validate_all_form_sec_in_l7_CSCC":
					
				context.setAttribute("fileName", "Validate_all_form_sec_in_l7_CSCC");
				ClubStudio.Validate_all_form_sec_in_l7_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
				context.setAttribute("fileName", "Validate_all_form_sec_in_l7_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_all_options_of_Gender_dd_in_l7_CSCC":
					
				context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_CSCC");
				ClubStudio.Validate_all_options_of_Gender_dd_in_l7_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd );
				context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_CSCC");
				driver.quit();break;
				
				
				case "Validate_all_options_of_RaceEthnicity_dd_in_l7_CSCC":
					
				context.setAttribute("fileName", "Validate_all_options_of_RaceEthnicity_dd_in_l7_CSCC");
				ClubStudio.Validate_all_options_of_RaceEthnicity_dd_in_l7_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, RaceEthnicity_dd );
				context.setAttribute("fileName", "Validate_all_options_of_RaceEthnicity_dd_in_l7_CSCC");
				driver.quit();break;
				
				
				case "Validate_EOE_details_paras_in_l7_CSCC":
					
				context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_CSCC");
				ClubStudio.Validate_EOE_details_paras_in_l7_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data2 );
				context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_No_rdobtnof_form_sec_in_l7_CSCC":
					
				context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_CSCC");
				ClubStudio.Validate_No_rdobtnof_form_sec_in_l7_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
				context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_CSCC");
				driver.quit();break;
				
				
				case "Validate_prev_next_step_btns_in_l7_CSCC":
					
				context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_CSCC");
				ClubStudio.Validate_prev_next_step_btns_in_l7_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
				context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_CSCC");
				driver.quit();break;
				
				case "Validate_prev_step_btn_in_l7_CSCC":
					
				context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_CSCC");
				ClubStudio.Validate_prev_step_btn_in_l7_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
				context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_CSCC");
				driver.quit();break;
				
				
				case "Validate_Next_step_btn_in_l7_CSCC":
					
				context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_CSCC");
				ClubStudio.Validate_Next_step_btn_in_l7_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
				context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_CSCC");
				driver.quit();break;
				
				
				case "Validate_Nav_to_l8_CSCC":
					
				context.setAttribute("fileName", "Validate_Nav_to_l8_CSCC");
				ClubStudio.Validate_Nav_to_l8_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
				context.setAttribute("fileName", "Validate_Nav_to_l8_CSCC");
				driver.quit();break;
				
				
				case "Validate_AS_paras_in_l8_CSCC":
					
				context.setAttribute("fileName", "Validate_AS_paras_in_l8_CSCC");
				ClubStudio.Validate_AS_paras_in_l8_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
				context.setAttribute("fileName", "Validate_AS_paras_in_l8_CSCC");
				driver.quit();break;
				
				
				case "Validate_ackmnt_in_l8_CSCC":
					
				context.setAttribute("fileName", "Validate_ackmnt_in_l8_CSCC");
				ClubStudio.Validate_ackmnt_in_l8_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
				context.setAttribute("fileName", "Validate_ackmnt_in_l8_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_ip_in_Signedbyname_in_l8_CSCC":
					
				context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_CSCC");
				ClubStudio.Validate_ip_in_Signedbyname_in_l8_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
				context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_CSCC");
				driver.quit();break;
				
				
				case "Validate_prev_next_step_btns_in_l8_CSCC":
					
				context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_CSCC");
				ClubStudio.Validate_prev_next_step_btns_in_l8_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
				context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_CSCC");
				driver.quit();break;
			
				
				
				case "Validate_prev_step_btn_in_l8_CSCC":
					
				context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_CSCC");
				ClubStudio.Validate_prev_step_btn_in_l8_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
				context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_Next_btn_in_l8_CSCC":
					
				context.setAttribute("fileName", "Validate_Next_btn_in_l8_CSCC");
				ClubStudio.Validate_Next_btn_in_l8_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
				context.setAttribute("fileName", "Validate_Next_btn_in_l8_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_heading_in_l9_CSCC":
					
				context.setAttribute("fileName", "Validate_heading_in_l9_CSCC");
				ClubStudio.Validate_heading_in_l9_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
				context.setAttribute("fileName", "Validate_heading_in_l9_CSCC");
				driver.quit();break;
				
				
				case "Validate_Rules_procedures_in_l9_CSCC":
					
				context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_CSCC");
				ClubStudio.Validate_Rules_procedures_in_l9_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
				context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_ip_in_prtname_dateandipadd_in_l9_CSCC":
					
				context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_CSCC");
				ClubStudio.Validate_ip_in_prtname_dateandipadd_in_l9_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, IP_Address );
				context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_Robert_Bryant_Sign_in_l9_CSCC":
					
				context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_CSCC");
				ClubStudio.Validate_Robert_Bryant_Sign_in_l9_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
				context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_Iagree_textandbtn_in_l9_CSCC":
					
				context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_CSCC");
				ClubStudio.Validate_Iagree_textandbtn_in_l9_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
				context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_CSCC");
				driver.quit();break;
				
				case "Validate_Prev_step_btn_in_l9_CSCC":
					
				context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_CSCC");
				ClubStudio.Validate_Prev_step_btn_in_l9_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
				context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_CSCC");
				driver.quit();break;
				
				
				case "Validate_Iagreebtn_and_succ_submsn_in_l9_CSCC":
					
				context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_CSCC");
				ClubStudio.Validate_Iagreebtn_and_succ_submsn_in_l9_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
				context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_CSCC");
				driver.quit();break;
				
				case "Validate_Success_msg_in_final_page_CSCC":
					
				context.setAttribute("fileName", "Validate_Success_msg_in_final_page_CSCC");
				ClubStudio.Validate_Success_msg_in_final_page_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
				context.setAttribute("fileName", "Validate_Success_msg_in_final_page_CSCC");
				driver.quit();break;
				
				
				case "Validate_prtbtn_in_print_emp_app_page_CSCC":
					
				context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_CSCC");
				ClubStudio.Validate_prtbtn_in_print_emp_app_page_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
				context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_CSCC");
				driver.quit();break;
				
				
				
				case "Validate_Rules_link_in_l9_CSCC":
					
				context.setAttribute("fileName", "Validate_Rules_link_in_l9_CSCC");
				ClubStudio.Validate_Rules_link_in_l9_CSCC(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
				context.setAttribute("fileName", "Validate_Rules_link_in_l9_CSCC");
				driver.quit();break;
				
				
				
				// Club Studio Coordinator
				
				
			case "Validate_emp_para_CSCO":
				
				context.setAttribute("fileName", "Validate_emp_para_CSCO");
				ClubStudio.Validate_emp_para_CSCO(testdata.get("TextMessage").toString(), Text_input, additional_input);
				context.setAttribute("fileName", "Validate_emp_para_CSCO");
				driver.quit();
				break;
				
				
			case "Validate_App_info_text_CSCO":
				
				context.setAttribute("fileName", "Validate_App_info_text_CSCO");
				ClubStudio.Validate_App_info_text_CSCO(testdata.get("TextMessage").toString(), Text_input, additional_input);
				context.setAttribute("fileName", "Validate_App_info_text_CSCO");
				driver.quit();
				break;
				
				
			case "Validate_all_ip_fields_in_emp_page_CSCO":
				
				context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_CSCO");
				ClubStudio.Validate_all_ip_fields_in_emp_page_CSCO(testdata.get("TextMessage").toString(), Text_input);
				context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_CSCO");
				driver.quit();
				break;
				
				
			case "Validate_Howdidyouhearaboutus_dd_CSCO":
				
				context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_CSCO");
				ClubStudio.Validate_Howdidyouhearaboutus_dd_CSCO(testdata.get("TextMessage").toString(), Text_input, Dropdown_values);
				context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_CSCO");
				driver.quit();
				break;
				
			case "Validate_Radiobtn18YearsOld_options_CSCO":
				
				context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_CSCO");
				ClubStudio.Validate_Radiobtn18YearsOld_options_CSCO(testdata.get("TextMessage").toString(), Text_input);
				context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_CSCO");
				driver.quit();
				break;
				
				
			case "Validate_US_format_text_CSCO":
				
				context.setAttribute("fileName", "Validate_US_format_text_CSCO");
				ClubStudio.Validate_US_format_text_CSCO(testdata.get("TextMessage").toString(), Text_input, additional_input);
				context.setAttribute("fileName", "Validate_US_format_text_CSCO");
				driver.quit();
				break;
				
				
			case "Validate_Miles_text_CSCO":
				
				context.setAttribute("fileName", "Validate_Miles_text_CSCO");
				ClubStudio.Validate_Miles_text_CSCO(testdata.get("TextMessage").toString(), Text_input, additional_input);
				context.setAttribute("fileName", "Validate_Miles_text_CSCO");
				driver.quit();
				break;
				
			case "Validate_phone_errorlabel_CSCO":
				
				context.setAttribute("fileName", "Validate_phone_errorlabel_CSCO");
				ClubStudio.Validate_phone_errorlabel_CSCO(testdata.get("TextMessage").toString(), Text_input, additional_input);
				context.setAttribute("fileName", "Validate_phone_errorlabel_CSCO");
				driver.quit();
				break;
				
				
			case "Validate_Next_step_button_in_l1_CSCO":
				
				context.setAttribute("fileName", "Validate_Next_step_button_in_l1_CSCO");
				ClubStudio.Validate_Next_step_button_in_l1_CSCO(testdata.get("TextMessage").toString(), Text_input);
				context.setAttribute("fileName", "Validate_Next_step_button_in_l1_CSCO");
				driver.quit();
				break;
				
				
			case "Validate_input_in_all_fields_CSCO":
				
			context.setAttribute("fileName", "Validate_input_in_all_fields_CSCO");
			ClubStudio.Validate_input_in_all_fields_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode  );
			context.setAttribute("fileName", "Validate_input_in_all_fields_CSCO");
			driver.quit();break;
				
			
			case "Validate_List18YrsOld_No_popupalrt_CSCO":
				
				context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_CSCO");
				ClubStudio.Validate_List18YrsOld_No_popupalrt_CSCO(testdata.get("TextMessage").toString(), Text_input, Radiobtn18YearsOld);
				context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_CSCO");
				driver.quit();
				break;
				
				
				
			case "Validate_Next_step_l1_CSCO":
				
			context.setAttribute("fileName", "Validate_Next_step_l1_CSCO");
			ClubStudio.Validate_Next_step_l1_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
			context.setAttribute("fileName", "Validate_Next_step_l1_CSCO");
			driver.quit();break;
				
				
			
			case "Validate_education_level_dd_CSCO":
				
			context.setAttribute("fileName", "Validate_education_level_dd_CSCO");
			ClubStudio.Validate_education_level_dd_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
			context.setAttribute("fileName", "Validate_education_level_dd_CSCO");
			driver.quit();break;
			
				
			
			case "Validate_edu_level_dd_allvalues_CSCO":
				
			context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_CSCO");
			ClubStudio.Validate_edu_level_dd_allvalues_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input , E_EducationLeve_Dropdown );
			context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_previous_next_step_buttons_l2_CSCO":
				
			context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_CSCO");
			ClubStudio.Validate_previous_next_step_buttons_l2_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
			context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_CSCO");
			driver.quit();break;
			
			
			case "Validate_previous_step_button_l2_CSCO":
				
			context.setAttribute("fileName", "Validate_previous_step_button_l2_CSCO");
			ClubStudio.Validate_previous_step_button_l2_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
			context.setAttribute("fileName", "Validate_previous_step_button_l2_CSCO");
			driver.quit();break;
			
			
			case "Validate_Next_step_button_l2_CSCO":
				
			context.setAttribute("fileName", "Validate_Next_step_button_l2_CSCO");
			ClubStudio.Validate_Next_step_button_l2_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
			context.setAttribute("fileName", "Validate_Next_step_button_l2_CSCO");
			driver.quit();break;
			

			case "Validate_Exp_info_text_in_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_CSCO");
			ClubStudio.Validate_Exp_info_text_in_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
			context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_CSCO");
			driver.quit();break;
			
			
			case "Validate_sales_mngnt_exp_text_in_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_sales_mngnt_exp_text_in_l3_CSCO");
			ClubStudio.Validate_sales_mngnt_exp_text_in_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
			context.setAttribute("fileName", "Validate_sales_mngnt_exp_text_in_l3_CSCO");
			driver.quit();break;
			
			case "Validate_Equipment_Techn_exp_heading_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_Equipment_Techn_exp_heading_l3_CSCO");
			ClubStudio.Validate_Equipment_Techn_exp_heading_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
			context.setAttribute("fileName", "Validate_Equipment_Techn_exp_heading_l3_CSCO");
			driver.quit();break;
			


			case "Validate_all_dropdowns_in_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_all_dropdowns_in_l3_CSCO");
			ClubStudio.Validate_all_dropdowns_in_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
			context.setAttribute("fileName", "Validate_all_dropdowns_in_l3_CSCO");
			driver.quit();break;
			
			case "Validate_all_options_FSE_dd_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_all_options_FSE_dd_l3_CSCO");
			ClubStudio.Validate_all_options_FSE_dd_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
			context.setAttribute("fileName", "Validate_all_options_FSE_dd_l3_CSCO");
			driver.quit();break;
			
			
			case "Validate_all_options_PTSE_dd_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_all_options_PTSE_dd_l3_CSCO");
			ClubStudio.Validate_all_options_PTSE_dd_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
			context.setAttribute("fileName", "Validate_all_options_PTSE_dd_l3_CSCO");
			driver.quit();break;
			
			case "Validate_all_options_ME_dd_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_all_options_ME_dd_l3_CSCO");
			ClubStudio.Validate_all_options_ME_dd_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
			context.setAttribute("fileName", "Validate_all_options_ME_dd_l3_CSCO");
			driver.quit();break;
			
			case "Validate_all_options_BE_dd_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_all_options_BE_dd_l3_CSCO");
			ClubStudio.Validate_all_options_BE_dd_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
			context.setAttribute("fileName", "Validate_all_options_BE_dd_l3_CSCO");
			driver.quit();break;
			
			case "Validate_all_options_YE_dd_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_all_options_YE_dd_l3_CSCO");
			ClubStudio.Validate_all_options_YE_dd_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
			context.setAttribute("fileName", "Validate_all_options_YE_dd_l3_CSCO");
			driver.quit();break;
			
			case "Validate_selecting_all_dds_in_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_selecting_all_dds_in_l3_CSCO");
			ClubStudio.Validate_selecting_all_dds_in_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
			context.setAttribute("fileName", "Validate_selecting_all_dds_in_l3_CSCO");
			driver.quit();break;
			
			
			case "Validate_Skills_section_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_Skills_section_l3_CSCO");
			ClubStudio.Validate_Skills_section_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data, input_data1 );
			context.setAttribute("fileName", "Validate_Skills_section_l3_CSCO");
			driver.quit();break;
			
			case "Validate_select_Skills_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_select_Skills_l3_CSCO");
			ClubStudio.Validate_select_Skills_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data );
			context.setAttribute("fileName", "Validate_select_Skills_l3_CSCO");
			driver.quit();break;
			

			case "Validate_Skills_2_section_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_Skills_2_section_l3_CSCO");
			ClubStudio.Validate_Skills_2_section_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data, input_data1 );
			context.setAttribute("fileName", "Validate_Skills_2_section_l3_CSCO");
			driver.quit();break;
			
			case "Validate_select_Skills_2_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_select_Skills_2_l3_CSCO");
			ClubStudio.Validate_select_Skills_2_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data );
			context.setAttribute("fileName", "Validate_select_Skills_2_l3_CSCO");
			driver.quit();break;

			
			case "Validate_Next_step_in_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_Next_step_in_l3_CSCO");
			ClubStudio.Validate_Next_step_in_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
			context.setAttribute("fileName", "Validate_Next_step_in_l3_CSCO");
			driver.quit();break;
			
			
			case "Validate_Prev_next_btns_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_Prev_next_btns_l3_CSCO");
			ClubStudio.Validate_Prev_next_btns_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
			context.setAttribute("fileName", "Validate_Prev_next_btns_l3_CSCO");
			driver.quit();break;
			
			
			case "Validate_Prev_step_in_l3_CSCO":
				
			context.setAttribute("fileName", "Validate_Prev_step_in_l3_CSCO");
			ClubStudio.Validate_Prev_step_in_l3_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
			context.setAttribute("fileName", "Validate_Prev_step_in_l3_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_EmpHis_PreEmp_texts_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_EmpHis_PreEmp_texts_in_l4_CSCO");
			ClubStudio.Validate_EmpHis_PreEmp_texts_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
			context.setAttribute("fileName", "Validate_EmpHis_PreEmp_texts_in_l4_CSCO");
			driver.quit();break;
			
			
			case "Validate_rdobtns_of_EmpHis_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_rdobtns_of_EmpHis_in_l4_CSCO");
			ClubStudio.Validate_rdobtns_of_EmpHis_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
			context.setAttribute("fileName", "Validate_rdobtns_of_EmpHis_in_l4_CSCO");
			driver.quit();break;
			
			case "Validate_upload_res_chkbx_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_upload_res_chkbx_in_l4_CSCO");
			ClubStudio.Validate_upload_res_chkbx_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
			context.setAttribute("fileName", "Validate_upload_res_chkbx_in_l4_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_upload_res_section_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_upload_res_section_in_l4_CSCO");
			ClubStudio.Validate_upload_res_section_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, input_data2);
			context.setAttribute("fileName", "Validate_upload_res_section_in_l4_CSCO");
			driver.quit();break;
			
			
			case "Validate_upload_res_file_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_upload_res_section_in_l4_CSCO");
			ClubStudio.Validate_upload_res_file_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, input_data2, File_name);
			context.setAttribute("fileName", "Validate_upload_res_file_l4_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_cur_prev_emp_texts_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_cur_prev_emp_texts_in_l4_CSCO");
			ClubStudio.Validate_cur_prev_emp_texts_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1,input_data2 );
			context.setAttribute("fileName", "Validate_cur_prev_emp_texts_in_l4_CSCO");
			driver.quit();break;
			

			
			case "Validate_all_ip_fields_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_all_ip_fields_in_l4_CSCO");
			ClubStudio.Validate_all_ip_fields_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_all_ip_fields_in_l4_CSCO");
			driver.quit();break;
			
			
			case "Validate_input_inallfields_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_input_inallfields_in_l4_CSCO");
			ClubStudio.Validate_input_inallfields_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button );
			context.setAttribute("fileName", "Validate_input_inallfields_in_l4_CSCO");
			driver.quit();break;
			
			
			case "Validate_prev_next_step_btns_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_CSCO");
			ClubStudio.Validate_prev_next_step_btns_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_CSCO");
			driver.quit();break;
			
			
			case "Validate_AddEmployer_2_btn_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_AddEmployer_2_btn_in_l4_CSCO");
			ClubStudio.Validate_AddEmployer_2_btn_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_AddEmployer_2_btn_in_l4_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_Next_btn_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_Next_btn_in_l4_CSCO");
			ClubStudio.Validate_Next_btn_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name);
			context.setAttribute("fileName", "Validate_Next_btn_in_l4_CSCO");
			driver.quit();break;
		
			
			case "Validate_No_Prev_Emp_RdoBtn_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_in_l4_CSCO");
			ClubStudio.Validate_No_Prev_Emp_RdoBtn_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_in_l4_CSCO");
			driver.quit();break;
			
			case "Validate_prev_step_btn_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_CSCO");
			ClubStudio.Validate_prev_step_btn_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_CSCO");
			driver.quit();break;
		
			
			case "Validate_all_ip_fieldsofAddemplr2_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr2_in_l4_CSCO");
			ClubStudio.Validate_all_ip_fieldsofAddemplr2_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr2_in_l4_CSCO");
			driver.quit();break;
			
			
			case "Validate_all_ip_fieldsofAddemplr3_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr3_in_l4_CSCO");
			ClubStudio.Validate_all_ip_fieldsofAddemplr3_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr3_in_l4_CSCO");
			driver.quit();break;
			
			case "Validate_removebtn2_by_ipingempr2_in_l4_CSCO":
				
			context.setAttribute("fileName", "Validate_removebtn2_by_ipingempr2_in_l4_CSCO");
			ClubStudio.Validate_removebtn2_by_ipingempr2_in_l4_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button );
			context.setAttribute("fileName", "Validate_removebtn2_by_ipingempr2_in_l4_CSCO");
			driver.quit();break;
			
			

			case "Validate_Ind_langs_text_l5_CSCO":
				
			context.setAttribute("fileName", "Validate_Ind_langs_text_l5_CSCO");
			ClubStudio.Validate_Ind_langs_text_l5_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, input_data2);
			context.setAttribute("fileName", "Validate_Ind_langs_text_l5_CSCO");
			driver.quit();break;
			
			
			case "Validate_all_langs_in_l5_CSCO":
				
			context.setAttribute("fileName", "Validate_all_langs_in_l5_CSCO");
			ClubStudio.Validate_all_langs_in_l5_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
			context.setAttribute("fileName", "Validate_all_langs_in_l5_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_bydefault_Eng_lang_sltd_in_l5_CSCO":
				
			context.setAttribute("fileName", "Validate_bydefault_Eng_lang_sltd_in_l5_CSCO");
			ClubStudio.Validate_bydefault_Eng_lang_sltd_in_l5_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
			context.setAttribute("fileName", "Validate_bydefault_Eng_lang_sltd_in_l5_CSCO");
			driver.quit();break;
			
			
			case "Validate_slt_desired_langs_in_l5_CSCO":
				
			context.setAttribute("fileName", "Validate_slt_desired_langs_in_l5_CSCO");
			ClubStudio.Validate_slt_desired_langs_in_l5_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
			context.setAttribute("fileName", "Validate_slt_desired_langs_in_l5_CSCO");
			driver.quit();break;
			

			case "Validate_prev_next_step_btns_in_l5_CSCO":
				
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_CSCO");
			ClubStudio.Validate_prev_next_step_btns_in_l5_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name);
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_CSCO");
			driver.quit();break;
			
			
			case "Validate_prev_step_btn_in_l5_CSCO":
				
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_CSCO");
			ClubStudio.Validate_prev_step_btn_in_l5_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name);
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_CSCO");
			driver.quit();break;
			
			
			case "Validate_Next_step_btn_in_l5_CSCO":
				
			context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_CSCO");
			ClubStudio.Validate_Next_step_btn_in_l5_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
			context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_CSCO");
			driver.quit();break;
			
			
			case "Validate_text_COqualify_in_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_text_COqualify_in_l6_CSCO");
			ClubStudio.Validate_text_COqualify_in_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data3);
			context.setAttribute("fileName", "Validate_text_COqualify_in_l6_CSCO");
			driver.quit();break;	
			
			
			case "Validate_all_fields_in_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_all_fields_in_l6_CSCO");
			ClubStudio.Validate_all_fields_in_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Considered_for_chkbx);
			context.setAttribute("fileName", "Validate_all_fields_in_l6_CSCO");
			driver.quit();break;
			
			
			case "Validate_slt_Worktime_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_slt_Worktime_l6_CSCO");
			ClubStudio.Validate_slt_Worktime_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time);
			context.setAttribute("fileName", "Validate_slt_Worktime_l6_CSCO");
			driver.quit();break;
			
			
			case "Validate_slt_considerfor_chkbxs_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_CSCO");
			ClubStudio.Validate_slt_considerfor_chkbxs_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx);
			context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_CSCO");
			driver.quit();break;
			
			
			case "Validate_deslt_considerfor_chkbxs_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_CSCO");
			ClubStudio.Validate_deslt_considerfor_chkbxs_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx);
			context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_COs_asperCFchkbxsltn_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_CSCO");
			ClubStudio.Validate_COs_asperCFchkbxsltn_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx);
			context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_CSCO");
			driver.quit();break;
			
			
			case "Validate_COs_asperCFchkbxdesltn_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_CSCO");
			ClubStudio.Validate_COs_asperCFchkbxdesltn_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx , input_data4);
			context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_defaultvalueofCO_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_CSCO");
			ClubStudio.Validate_defaultvalueofCO_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Considered_for_chkbx);
			context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_CSCO");
			driver.quit();break;
			
			
			case "Validate_ip_date_to_begin_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_CSCO");
			ClubStudio.Validate_ip_date_to_begin_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Date_to_begin );
			context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_CSCO");
			driver.quit();break;
			
			
			case "Validate_empdwithus_no_rdobtn_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_CSCO");
			ClubStudio.Validate_empdwithus_no_rdobtn_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
			context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_CSCO");
			driver.quit();break;
			
			case "Validate_basedonsltns_text_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_basedonsltns_text_l6_CSCO");
			ClubStudio.Validate_basedonsltns_text_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
			context.setAttribute("fileName", "Validate_basedonsltns_text_l6_CSCO");
			driver.quit();break;
			
			
			case "Validate_Club_locations_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_Club_locations_l6_CSCO");
			ClubStudio.Validate_Club_locations_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
			context.setAttribute("fileName", "Validate_Club_locations_l6_CSCO");
			driver.quit();break;
			
			
			case "Validate_Rehire_Questionnaire_sec_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6_CSCO");
			ClubStudio.Validate_Rehire_Questionnaire_sec_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
			context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6_CSCO");
			driver.quit();break;
			
			
			
			
			case "Validate_Resigned_dd_allvalues_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_CSCO");
			ClubStudio.Validate_Resigned_dd_allvalues_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, EmploymentHowResigned_dd );
			context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_ip_in_RQ_sec_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_CSCO");
			ClubStudio.Validate_ip_in_RQ_sec_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_CSCO");
			driver.quit();break;
			
			case "Validate_prev_next_step_btns_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_CSCO");
			ClubStudio.Validate_prev_next_step_btns_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages );
			context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_CSCO");
			driver.quit();break;
			
			
			case "Validate_prev_step_btn_in_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_CSCO");
			ClubStudio.Validate_prev_step_btn_in_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages );
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_CSCO");
			driver.quit();break;
			
			case "Validate_next_btn_byipallfields_l6_CSCO":
				
			context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_CSCO");
			ClubStudio.Validate_next_btn_byipallfields_l6_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_paras_in_l7_CSCO":
				
			context.setAttribute("fileName", "Validate_paras_in_l7_CSCO");
			ClubStudio.Validate_paras_in_l7_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data2 );
			context.setAttribute("fileName", "Validate_paras_in_l7_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_rdobtns_in_l7_CSCO":
				
			context.setAttribute("fileName", "Validate_rdobtns_in_l7_CSCO");
			ClubStudio.Validate_rdobtns_in_l7_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_rdobtns_in_l7_CSCO");
			driver.quit();break;
			
			
			case "Validate_all_form_sec_in_l7_CSCO":
				
			context.setAttribute("fileName", "Validate_all_form_sec_in_l7_CSCO");
			ClubStudio.Validate_all_form_sec_in_l7_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_all_form_sec_in_l7_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_all_options_of_Gender_dd_in_l7_CSCO":
				
			context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_CSCO");
			ClubStudio.Validate_all_options_of_Gender_dd_in_l7_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd );
			context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_CSCO");
			driver.quit();break;
			
			
			case "Validate_all_options_of_RaceEthnicity_dd_in_l7_CSCO":
				
			context.setAttribute("fileName", "Validate_all_options_of_RaceEthnicity_dd_in_l7_CSCO");
			ClubStudio.Validate_all_options_of_RaceEthnicity_dd_in_l7_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_all_options_of_RaceEthnicity_dd_in_l7_CSCO");
			driver.quit();break;
			
			
			case "Validate_EOE_details_paras_in_l7_CSCO":
				
			context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_CSCO");
			ClubStudio.Validate_EOE_details_paras_in_l7_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data2 );
			context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_No_rdobtnof_form_sec_in_l7_CSCO":
				
			context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_CSCO");
			ClubStudio.Validate_No_rdobtnof_form_sec_in_l7_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_CSCO");
			driver.quit();break;
			
			
			case "Validate_prev_next_step_btns_in_l7_CSCO":
				
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_CSCO");
			ClubStudio.Validate_prev_next_step_btns_in_l7_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_CSCO");
			driver.quit();break;
			
			case "Validate_prev_step_btn_in_l7_CSCO":
				
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_CSCO");
			ClubStudio.Validate_prev_step_btn_in_l7_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_CSCO");
			driver.quit();break;
			
			
			case "Validate_Next_step_btn_in_l7_CSCO":
				
			context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_CSCO");
			ClubStudio.Validate_Next_step_btn_in_l7_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_CSCO");
			driver.quit();break;
			
			
			case "Validate_Nav_to_l8_CSCO":
				
			context.setAttribute("fileName", "Validate_Nav_to_l8_CSCO");
			ClubStudio.Validate_Nav_to_l8_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_Nav_to_l8_CSCO");
			driver.quit();break;
			
			
			case "Validate_AS_paras_in_l8_CSCO":
				
			context.setAttribute("fileName", "Validate_AS_paras_in_l8_CSCO");
			ClubStudio.Validate_AS_paras_in_l8_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
			context.setAttribute("fileName", "Validate_AS_paras_in_l8_CSCO");
			driver.quit();break;
			
			
			case "Validate_ackmnt_in_l8_CSCO":
				
			context.setAttribute("fileName", "Validate_ackmnt_in_l8_CSCO");
			ClubStudio.Validate_ackmnt_in_l8_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
			context.setAttribute("fileName", "Validate_ackmnt_in_l8_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_ip_in_Signedbyname_in_l8_CSCO":
				
			context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_CSCO");
			ClubStudio.Validate_ip_in_Signedbyname_in_l8_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_CSCO");
			driver.quit();break;
			
			
			case "Validate_prev_next_step_btns_in_l8_CSCO":
				
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_CSCO");
			ClubStudio.Validate_prev_next_step_btns_in_l8_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_CSCO");
			driver.quit();break;
		
			
			
			case "Validate_prev_step_btn_in_l8_CSCO":
				
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_CSCO");
			ClubStudio.Validate_prev_step_btn_in_l8_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_Next_btn_in_l8_CSCO":
				
			context.setAttribute("fileName", "Validate_Next_btn_in_l8_CSCO");
			ClubStudio.Validate_Next_btn_in_l8_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_Next_btn_in_l8_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_heading_in_l9_CSCO":
				
			context.setAttribute("fileName", "Validate_heading_in_l9_CSCO");
			ClubStudio.Validate_heading_in_l9_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
			context.setAttribute("fileName", "Validate_heading_in_l9_CSCO");
			driver.quit();break;
			
			
			case "Validate_Rules_procedures_in_l9_CSCO":
				
			context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_CSCO");
			ClubStudio.Validate_Rules_procedures_in_l9_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
			context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_ip_in_prtname_dateandipadd_in_l9_CSCO":
				
			context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_CSCO");
			ClubStudio.Validate_ip_in_prtname_dateandipadd_in_l9_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, IP_Address );
			context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_Robert_Bryant_Sign_in_l9_CSCO":
				
			context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_CSCO");
			ClubStudio.Validate_Robert_Bryant_Sign_in_l9_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
			context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_Iagree_textandbtn_in_l9_CSCO":
				
			context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_CSCO");
			ClubStudio.Validate_Iagree_textandbtn_in_l9_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
			context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_CSCO");
			driver.quit();break;
			
			case "Validate_Prev_step_btn_in_l9_CSCO":
				
			context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_CSCO");
			ClubStudio.Validate_Prev_step_btn_in_l9_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_CSCO");
			driver.quit();break;
			
			
			case "Validate_Iagreebtn_and_succ_submsn_in_l9_CSCO":
				
			context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_CSCO");
			ClubStudio.Validate_Iagreebtn_and_succ_submsn_in_l9_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_CSCO");
			driver.quit();break;
			
			case "Validate_Success_msg_in_final_page_CSCO":
				
			context.setAttribute("fileName", "Validate_Success_msg_in_final_page_CSCO");
			ClubStudio.Validate_Success_msg_in_final_page_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
			context.setAttribute("fileName", "Validate_Success_msg_in_final_page_CSCO");
			driver.quit();break;
			
			
			case "Validate_prtbtn_in_print_emp_app_page_CSCO":
				
			context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_CSCO");
			ClubStudio.Validate_prtbtn_in_print_emp_app_page_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
			context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_CSCO");
			driver.quit();break;
			
			
			
			case "Validate_Rules_link_in_l9_CSCO":
				
			context.setAttribute("fileName", "Validate_Rules_link_in_l9_CSCO");
			ClubStudio.Validate_Rules_link_in_l9_CSCO(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_Rules_link_in_l9_CSCO");
			driver.quit();break;
			
			
			// Membership Director
			
			
			
			case "Validate_emp_para_MD":
				
				context.setAttribute("fileName", "Validate_emp_para_MD");
				ClubStudio.Validate_emp_para_MD(testdata.get("TextMessage").toString(), Text_input, additional_input);
				context.setAttribute("fileName", "Validate_emp_para_MD");
				driver.quit();
				break;
				
				
			case "Validate_App_info_text_MD":
				
				context.setAttribute("fileName", "Validate_App_info_text_MD");
				ClubStudio.Validate_App_info_text_MD(testdata.get("TextMessage").toString(), Text_input, additional_input);
				context.setAttribute("fileName", "Validate_App_info_text_MD");
				driver.quit();
				break;
				
				
			case "Validate_all_ip_fields_in_emp_page_MD":
				
				context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_MD");
				ClubStudio.Validate_all_ip_fields_in_emp_page_MD(testdata.get("TextMessage").toString(), Text_input);
				context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_MD");
				driver.quit();
				break;
				
				
			case "Validate_Howdidyouhearaboutus_dd_MD":
				
				context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_MD");
				ClubStudio.Validate_Howdidyouhearaboutus_dd_MD(testdata.get("TextMessage").toString(), Text_input, Dropdown_values);
				context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_MD");
				driver.quit();
				break;
				
			case "Validate_Radiobtn18YearsOld_options_MD":
				
				context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_MD");
				ClubStudio.Validate_Radiobtn18YearsOld_options_MD(testdata.get("TextMessage").toString(), Text_input);
				context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_MD");
				driver.quit();
				break;
				
				
			case "Validate_US_format_text_MD":
				
				context.setAttribute("fileName", "Validate_US_format_text_MD");
				ClubStudio.Validate_US_format_text_MD(testdata.get("TextMessage").toString(), Text_input, additional_input);
				context.setAttribute("fileName", "Validate_US_format_text_MD");
				driver.quit();
				break;
				
				
			case "Validate_Miles_text_MD":
				
				context.setAttribute("fileName", "Validate_Miles_text_MD");
				ClubStudio.Validate_Miles_text_MD(testdata.get("TextMessage").toString(), Text_input, additional_input);
				context.setAttribute("fileName", "Validate_Miles_text_MD");
				driver.quit();
				break;
				
			case "Validate_phone_errorlabel_MD":
				
				context.setAttribute("fileName", "Validate_phone_errorlabel_MD");
				ClubStudio.Validate_phone_errorlabel_MD(testdata.get("TextMessage").toString(), Text_input, additional_input);
				context.setAttribute("fileName", "Validate_phone_errorlabel_MD");
				driver.quit();
				break;
				
				
			case "Validate_Next_step_button_in_l1_MD":
				
				context.setAttribute("fileName", "Validate_Next_step_button_in_l1_MD");
				ClubStudio.Validate_Next_step_button_in_l1_MD(testdata.get("TextMessage").toString(), Text_input);
				context.setAttribute("fileName", "Validate_Next_step_button_in_l1_MD");
				driver.quit();
				break;
				
				
			case "Validate_input_in_all_fields_MD":
				
			context.setAttribute("fileName", "Validate_input_in_all_fields_MD");
			ClubStudio.Validate_input_in_all_fields_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode  );
			context.setAttribute("fileName", "Validate_input_in_all_fields_MD");
			driver.quit();break;
				
			
			case "Validate_List18YrsOld_No_popupalrt_MD":
				
				context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_MD");
				ClubStudio.Validate_List18YrsOld_No_popupalrt_MD(testdata.get("TextMessage").toString(), Text_input, Radiobtn18YearsOld);
				context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_MD");
				driver.quit();
				break;
				
				
				
			case "Validate_Next_step_l1_MD":
				
			context.setAttribute("fileName", "Validate_Next_step_l1_MD");
			ClubStudio.Validate_Next_step_l1_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
			context.setAttribute("fileName", "Validate_Next_step_l1_MD");
			driver.quit();break;
				
				
			
			case "Validate_education_level_dd_MD":
				
			context.setAttribute("fileName", "Validate_education_level_dd_MD");
			ClubStudio.Validate_education_level_dd_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
			context.setAttribute("fileName", "Validate_education_level_dd_MD");
			driver.quit();break;
			
				
			
			case "Validate_edu_level_dd_allvalues_MD":
				
			context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_MD");
			ClubStudio.Validate_edu_level_dd_allvalues_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input , E_EducationLeve_Dropdown );
			context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_MD");
			driver.quit();break;
			
			
			
			case "Validate_previous_next_step_buttons_l2_MD":
				
			context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_MD");
			ClubStudio.Validate_previous_next_step_buttons_l2_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
			context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_MD");
			driver.quit();break;
			
			
			case "Validate_previous_step_button_l2_MD":
				
			context.setAttribute("fileName", "Validate_previous_step_button_l2_MD");
			ClubStudio.Validate_previous_step_button_l2_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input  );
			context.setAttribute("fileName", "Validate_previous_step_button_l2_MD");
			driver.quit();break;
			
			
			case "Validate_Next_step_button_l2_MD":
				
			context.setAttribute("fileName", "Validate_Next_step_button_l2_MD");
			ClubStudio.Validate_Next_step_button_l2_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
			context.setAttribute("fileName", "Validate_Next_step_button_l2_MD");
			driver.quit();break;
			

			case "Validate_Exp_info_text_in_l3_MD":
				
			context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_MD");
			ClubStudio.Validate_Exp_info_text_in_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
			context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_MD");
			driver.quit();break;
			
			
			case "Validate_sales_mngnt_exp_text_in_l3_MD":
				
			context.setAttribute("fileName", "Validate_sales_mngnt_exp_text_in_l3_MD");
			ClubStudio.Validate_sales_mngnt_exp_text_in_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
			context.setAttribute("fileName", "Validate_sales_mngnt_exp_text_in_l3_MD");
			driver.quit();break;
			
			case "Validate_Equipment_Techn_exp_heading_l3_MD":
				
			context.setAttribute("fileName", "Validate_Equipment_Techn_exp_heading_l3_MD");
			ClubStudio.Validate_Equipment_Techn_exp_heading_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , input_data );
			context.setAttribute("fileName", "Validate_Equipment_Techn_exp_heading_l3_MD");
			driver.quit();break;
			


			case "Validate_all_dropdowns_in_l3_MD":
				
			context.setAttribute("fileName", "Validate_all_dropdowns_in_l3_MD");
			ClubStudio.Validate_all_dropdowns_in_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown  );
			context.setAttribute("fileName", "Validate_all_dropdowns_in_l3_MD");
			driver.quit();break;
			
			case "Validate_all_options_FSE_dd_l3_MD":
				
			context.setAttribute("fileName", "Validate_all_options_FSE_dd_l3_MD");
			ClubStudio.Validate_all_options_FSE_dd_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
			context.setAttribute("fileName", "Validate_all_options_FSE_dd_l3_MD");
			driver.quit();break;
			
			
			case "Validate_all_options_PTSE_dd_l3_MD":
				
			context.setAttribute("fileName", "Validate_all_options_PTSE_dd_l3_MD");
			ClubStudio.Validate_all_options_PTSE_dd_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
			context.setAttribute("fileName", "Validate_all_options_PTSE_dd_l3_MD");
			driver.quit();break;
			
			case "Validate_all_options_ME_dd_l3_MD":
				
			context.setAttribute("fileName", "Validate_all_options_ME_dd_l3_MD");
			ClubStudio.Validate_all_options_ME_dd_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
			context.setAttribute("fileName", "Validate_all_options_ME_dd_l3_MD");
			driver.quit();break;
			
			case "Validate_all_options_BE_dd_l3_MD":
				
			context.setAttribute("fileName", "Validate_all_options_BE_dd_l3_MD");
			ClubStudio.Validate_all_options_BE_dd_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
			context.setAttribute("fileName", "Validate_all_options_BE_dd_l3_MD");
			driver.quit();break;
			
			case "Validate_all_options_YE_dd_l3_MD":
				
			context.setAttribute("fileName", "Validate_all_options_YE_dd_l3_MD");
			ClubStudio.Validate_all_options_YE_dd_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
			context.setAttribute("fileName", "Validate_all_options_YE_dd_l3_MD");
			driver.quit();break;
			
			case "Validate_selecting_all_dds_in_l3_MD":
				
			context.setAttribute("fileName", "Validate_selecting_all_dds_in_l3_MD");
			ClubStudio.Validate_selecting_all_dds_in_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values );
			context.setAttribute("fileName", "Validate_selecting_all_dds_in_l3_MD");
			driver.quit();break;
			
			
			case "Validate_Skills_section_l3_MD":
				
			context.setAttribute("fileName", "Validate_Skills_section_l3_MD");
			ClubStudio.Validate_Skills_section_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data, input_data1 );
			context.setAttribute("fileName", "Validate_Skills_section_l3_MD");
			driver.quit();break;
			
			case "Validate_select_Skills_l3_MD":
				
			context.setAttribute("fileName", "Validate_select_Skills_l3_MD");
			ClubStudio.Validate_select_Skills_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data );
			context.setAttribute("fileName", "Validate_select_Skills_l3_MD");
			driver.quit();break;
			

			case "Validate_Skills_2_section_l3_MD":
				
			context.setAttribute("fileName", "Validate_Skills_2_section_l3_MD");
			ClubStudio.Validate_Skills_2_section_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data, input_data1 );
			context.setAttribute("fileName", "Validate_Skills_2_section_l3_MD");
			driver.quit();break;
			
			case "Validate_select_Skills_2_l3_MD":
				
			context.setAttribute("fileName", "Validate_select_Skills_2_l3_MD");
			ClubStudio.Validate_select_Skills_2_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values, input_data );
			context.setAttribute("fileName", "Validate_select_Skills_2_l3_MD");
			driver.quit();break;

			
			case "Validate_Next_step_in_l3_MD":
				
			context.setAttribute("fileName", "Validate_Next_step_in_l3_MD");
			ClubStudio.Validate_Next_step_in_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
			context.setAttribute("fileName", "Validate_Next_step_in_l3_MD");
			driver.quit();break;
			
			
			case "Validate_Prev_next_btns_l3_MD":
				
			context.setAttribute("fileName", "Validate_Prev_next_btns_l3_MD");
			ClubStudio.Validate_Prev_next_btns_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
			context.setAttribute("fileName", "Validate_Prev_next_btns_l3_MD");
			driver.quit();break;
			
			
			case "Validate_Prev_step_in_l3_MD":
				
			context.setAttribute("fileName", "Validate_Prev_step_in_l3_MD");
			ClubStudio.Validate_Prev_step_in_l3_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown );
			context.setAttribute("fileName", "Validate_Prev_step_in_l3_MD");
			driver.quit();break;
			
			
			
			case "Validate_EmpHis_PreEmp_texts_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_EmpHis_PreEmp_texts_in_l4_MD");
			ClubStudio.Validate_EmpHis_PreEmp_texts_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
			context.setAttribute("fileName", "Validate_EmpHis_PreEmp_texts_in_l4_MD");
			driver.quit();break;
			
			
			case "Validate_rdobtns_of_EmpHis_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_rdobtns_of_EmpHis_in_l4_MD");
			ClubStudio.Validate_rdobtns_of_EmpHis_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
			context.setAttribute("fileName", "Validate_rdobtns_of_EmpHis_in_l4_MD");
			driver.quit();break;
			
			case "Validate_upload_res_chkbx_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_upload_res_chkbx_in_l4_MD");
			ClubStudio.Validate_upload_res_chkbx_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1);
			context.setAttribute("fileName", "Validate_upload_res_chkbx_in_l4_MD");
			driver.quit();break;
			
			
			
			case "Validate_upload_res_section_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_upload_res_section_in_l4_MD");
			ClubStudio.Validate_upload_res_section_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, input_data2);
			context.setAttribute("fileName", "Validate_upload_res_section_in_l4_MD");
			driver.quit();break;
			
			
			case "Validate_upload_res_file_l4_MD":
				
			context.setAttribute("fileName", "Validate_upload_res_section_in_l4_MD");
			ClubStudio.Validate_upload_res_file_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, input_data2, File_name);
			context.setAttribute("fileName", "Validate_upload_res_file_l4_MD");
			driver.quit();break;
			
			
			
			case "Validate_cur_prev_emp_texts_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_cur_prev_emp_texts_in_l4_MD");
			ClubStudio.Validate_cur_prev_emp_texts_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1,input_data2 );
			context.setAttribute("fileName", "Validate_cur_prev_emp_texts_in_l4_MD");
			driver.quit();break;
			

			
			case "Validate_all_ip_fields_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_all_ip_fields_in_l4_MD");
			ClubStudio.Validate_all_ip_fields_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_all_ip_fields_in_l4_MD");
			driver.quit();break;
			
			
			case "Validate_input_inallfields_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_input_inallfields_in_l4_MD");
			ClubStudio.Validate_input_inallfields_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button );
			context.setAttribute("fileName", "Validate_input_inallfields_in_l4_MD");
			driver.quit();break;
			
			
			case "Validate_prev_next_step_btns_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_MD");
			ClubStudio.Validate_prev_next_step_btns_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_MD");
			driver.quit();break;
			
			
			case "Validate_AddEmployer_2_btn_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_AddEmployer_2_btn_in_l4_MD");
			ClubStudio.Validate_AddEmployer_2_btn_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_AddEmployer_2_btn_in_l4_MD");
			driver.quit();break;
			
			
			
			case "Validate_Next_btn_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_Next_btn_in_l4_MD");
			ClubStudio.Validate_Next_btn_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name);
			context.setAttribute("fileName", "Validate_Next_btn_in_l4_MD");
			driver.quit();break;
		
			
			case "Validate_No_Prev_Emp_RdoBtn_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_in_l4_MD");
			ClubStudio.Validate_No_Prev_Emp_RdoBtn_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_in_l4_MD");
			driver.quit();break;
			
			case "Validate_prev_step_btn_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_MD");
			ClubStudio.Validate_prev_step_btn_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_MD");
			driver.quit();break;
		
			
			case "Validate_all_ip_fieldsofAddemplr2_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr2_in_l4_MD");
			ClubStudio.Validate_all_ip_fieldsofAddemplr2_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr2_in_l4_MD");
			driver.quit();break;
			
			
			case "Validate_all_ip_fieldsofAddemplr3_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr3_in_l4_MD");
			ClubStudio.Validate_all_ip_fieldsofAddemplr3_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1 );
			context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr3_in_l4_MD");
			driver.quit();break;
			
			case "Validate_removebtn2_by_ipingempr2_in_l4_MD":
				
			context.setAttribute("fileName", "Validate_removebtn2_by_ipingempr2_in_l4_MD");
			ClubStudio.Validate_removebtn2_by_ipingempr2_in_l4_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button );
			context.setAttribute("fileName", "Validate_removebtn2_by_ipingempr2_in_l4_MD");
			driver.quit();break;
			
			

			case "Validate_Ind_langs_text_l5_MD":
				
			context.setAttribute("fileName", "Validate_Ind_langs_text_l5_MD");
			ClubStudio.Validate_Ind_langs_text_l5_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, input_data2);
			context.setAttribute("fileName", "Validate_Ind_langs_text_l5_MD");
			driver.quit();break;
			
			
			case "Validate_all_langs_in_l5_MD":
				
			context.setAttribute("fileName", "Validate_all_langs_in_l5_MD");
			ClubStudio.Validate_all_langs_in_l5_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
			context.setAttribute("fileName", "Validate_all_langs_in_l5_MD");
			driver.quit();break;
			
			
			
			case "Validate_bydefault_Eng_lang_sltd_in_l5_MD":
				
			context.setAttribute("fileName", "Validate_bydefault_Eng_lang_sltd_in_l5_MD");
			ClubStudio.Validate_bydefault_Eng_lang_sltd_in_l5_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
			context.setAttribute("fileName", "Validate_bydefault_Eng_lang_sltd_in_l5_MD");
			driver.quit();break;
			
			
			case "Validate_slt_desired_langs_in_l5_MD":
				
			context.setAttribute("fileName", "Validate_slt_desired_langs_in_l5_MD");
			ClubStudio.Validate_slt_desired_langs_in_l5_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
			context.setAttribute("fileName", "Validate_slt_desired_langs_in_l5_MD");
			driver.quit();break;
			

			case "Validate_prev_next_step_btns_in_l5_MD":
				
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_MD");
			ClubStudio.Validate_prev_next_step_btns_in_l5_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name);
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_MD");
			driver.quit();break;
			
			
			case "Validate_prev_step_btn_in_l5_MD":
				
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_MD");
			ClubStudio.Validate_prev_step_btn_in_l5_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name);
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_MD");
			driver.quit();break;
			
			
			case "Validate_Next_step_btn_in_l5_MD":
				
			context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_MD");
			ClubStudio.Validate_Next_step_btn_in_l5_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages);
			context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_MD");
			driver.quit();break;
			
			
			case "Validate_text_COqualify_in_l6_MD":
				
			context.setAttribute("fileName", "Validate_text_COqualify_in_l6_MD");
			ClubStudio.Validate_text_COqualify_in_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data3);
			context.setAttribute("fileName", "Validate_text_COqualify_in_l6_MD");
			driver.quit();break;	
			
			
			case "Validate_all_fields_in_l6_MD":
				
			context.setAttribute("fileName", "Validate_all_fields_in_l6_MD");
			ClubStudio.Validate_all_fields_in_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Considered_for_chkbx);
			context.setAttribute("fileName", "Validate_all_fields_in_l6_MD");
			driver.quit();break;
			
			
			case "Validate_slt_Worktime_l6_MD":
				
			context.setAttribute("fileName", "Validate_slt_Worktime_l6_MD");
			ClubStudio.Validate_slt_Worktime_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time);
			context.setAttribute("fileName", "Validate_slt_Worktime_l6_MD");
			driver.quit();break;
			
			
			case "Validate_slt_considerfor_chkbxs_l6_MD":
				
			context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_MD");
			ClubStudio.Validate_slt_considerfor_chkbxs_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx);
			context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_MD");
			driver.quit();break;
			
			
			case "Validate_deslt_considerfor_chkbxs_l6_MD":
				
			context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_MD");
			ClubStudio.Validate_deslt_considerfor_chkbxs_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx);
			context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_MD");
			driver.quit();break;
			
			
			
			case "Validate_COs_asperCFchkbxsltn_l6_MD":
				
			context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_MD");
			ClubStudio.Validate_COs_asperCFchkbxsltn_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx);
			context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_MD");
			driver.quit();break;
			
			
			case "Validate_COs_asperCFchkbxdesltn_l6_MD":
				
			context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_MD");
			ClubStudio.Validate_COs_asperCFchkbxdesltn_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Work_time, Considered_for_chkbx , input_data4);
			context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_MD");
			driver.quit();break;
			
			
			
			case "Validate_defaultvalueofCO_l6_MD":
				
			context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_MD");
			ClubStudio.Validate_defaultvalueofCO_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Considered_for_chkbx);
			context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_MD");
			driver.quit();break;
			
			
			case "Validate_ip_date_to_begin_l6_MD":
				
			context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_MD");
			ClubStudio.Validate_ip_date_to_begin_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, Date_to_begin );
			context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_MD");
			driver.quit();break;
			
			
			case "Validate_empdwithus_no_rdobtn_l6_MD":
				
			context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_MD");
			ClubStudio.Validate_empdwithus_no_rdobtn_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
			context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_MD");
			driver.quit();break;
			
			case "Validate_basedonsltns_text_l6_MD":
				
			context.setAttribute("fileName", "Validate_basedonsltns_text_l6_MD");
			ClubStudio.Validate_basedonsltns_text_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
			context.setAttribute("fileName", "Validate_basedonsltns_text_l6_MD");
			driver.quit();break;
			
			
			case "Validate_Club_locations_l6_MD":
				
			context.setAttribute("fileName", "Validate_Club_locations_l6_MD");
			ClubStudio.Validate_Club_locations_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
			context.setAttribute("fileName", "Validate_Club_locations_l6_MD");
			driver.quit();break;
			
			
			case "Validate_Rehire_Questionnaire_sec_l6_MD":
				
			context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6_MD");
			ClubStudio.Validate_Rehire_Questionnaire_sec_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, input_data2 );
			context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l6_MD");
			driver.quit();break;
			
			
			
			
			case "Validate_Resigned_dd_allvalues_l6_MD":
				
			context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_MD");
			ClubStudio.Validate_Resigned_dd_allvalues_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages, EmploymentHowResigned_dd );
			context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_MD");
			driver.quit();break;
			
			
			
			case "Validate_ip_in_RQ_sec_l6_MD":
				
			context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_MD");
			ClubStudio.Validate_ip_in_RQ_sec_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_MD");
			driver.quit();break;
			
			case "Validate_prev_next_step_btns_l6_MD":
				
			context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_MD");
			ClubStudio.Validate_prev_next_step_btns_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages );
			context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_MD");
			driver.quit();break;
			
			
			case "Validate_prev_step_btn_in_l6_MD":
				
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_MD");
			ClubStudio.Validate_prev_step_btn_in_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages );
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_MD");
			driver.quit();break;
			
			case "Validate_next_btn_byipallfields_l6_MD":
				
			context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_MD");
			ClubStudio.Validate_next_btn_byipallfields_l6_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_MD");
			driver.quit();break;
			
			
			
			case "Validate_paras_in_l7_MD":
				
			context.setAttribute("fileName", "Validate_paras_in_l7_MD");
			ClubStudio.Validate_paras_in_l7_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data2 );
			context.setAttribute("fileName", "Validate_paras_in_l7_MD");
			driver.quit();break;
			
			
			
			case "Validate_rdobtns_in_l7_MD":
				
			context.setAttribute("fileName", "Validate_rdobtns_in_l7_MD");
			ClubStudio.Validate_rdobtns_in_l7_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_rdobtns_in_l7_MD");
			driver.quit();break;
			
			
			case "Validate_all_form_sec_in_l7_MD":
				
			context.setAttribute("fileName", "Validate_all_form_sec_in_l7_MD");
			ClubStudio.Validate_all_form_sec_in_l7_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_all_form_sec_in_l7_MD");
			driver.quit();break;
			
			
			
			case "Validate_all_options_of_Gender_dd_in_l7_MD":
				
			context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_MD");
			ClubStudio.Validate_all_options_of_Gender_dd_in_l7_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd );
			context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_MD");
			driver.quit();break;
			
			
			case "Validate_all_options_of_RaceEthnicity_dd_in_l7_MD":
				
			context.setAttribute("fileName", "Validate_all_options_of_RaceEthnicity_dd_in_l7_MD");
			ClubStudio.Validate_all_options_of_RaceEthnicity_dd_in_l7_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_all_options_of_RaceEthnicity_dd_in_l7_MD");
			driver.quit();break;
			
			
			case "Validate_EOE_details_paras_in_l7_MD":
				
			context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_MD");
			ClubStudio.Validate_EOE_details_paras_in_l7_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data2 );
			context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_MD");
			driver.quit();break;
			
			
			
			case "Validate_No_rdobtnof_form_sec_in_l7_MD":
				
			context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_MD");
			ClubStudio.Validate_No_rdobtnof_form_sec_in_l7_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_MD");
			driver.quit();break;
			
			
			case "Validate_prev_next_step_btns_in_l7_MD":
				
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_MD");
			ClubStudio.Validate_prev_next_step_btns_in_l7_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_MD");
			driver.quit();break;
			
			case "Validate_prev_step_btn_in_l7_MD":
				
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_MD");
			ClubStudio.Validate_prev_step_btn_in_l7_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_MD");
			driver.quit();break;
			
			
			case "Validate_Next_step_btn_in_l7_MD":
				
			context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_MD");
			ClubStudio.Validate_Next_step_btn_in_l7_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
			context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_MD");
			driver.quit();break;
			
			
			case "Validate_Nav_to_l8_MD":
				
			context.setAttribute("fileName", "Validate_Nav_to_l8_MD");
			ClubStudio.Validate_Nav_to_l8_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_Nav_to_l8_MD");
			driver.quit();break;
			
			
			case "Validate_AS_paras_in_l8_MD":
				
			context.setAttribute("fileName", "Validate_AS_paras_in_l8_MD");
			ClubStudio.Validate_AS_paras_in_l8_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
			context.setAttribute("fileName", "Validate_AS_paras_in_l8_MD");
			driver.quit();break;
			
			
			case "Validate_ackmnt_in_l8_MD":
				
			context.setAttribute("fileName", "Validate_ackmnt_in_l8_MD");
			ClubStudio.Validate_ackmnt_in_l8_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
			context.setAttribute("fileName", "Validate_ackmnt_in_l8_MD");
			driver.quit();break;
			
			
			
			case "Validate_ip_in_Signedbyname_in_l8_MD":
				
			context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_MD");
			ClubStudio.Validate_ip_in_Signedbyname_in_l8_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_MD");
			driver.quit();break;
			
			
			case "Validate_prev_next_step_btns_in_l8_MD":
				
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_MD");
			ClubStudio.Validate_prev_next_step_btns_in_l8_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_MD");
			driver.quit();break;
		
			
			
			case "Validate_prev_step_btn_in_l8_MD":
				
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_MD");
			ClubStudio.Validate_prev_step_btn_in_l8_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_MD");
			driver.quit();break;
			
			
			
			case "Validate_Next_btn_in_l8_MD":
				
			context.setAttribute("fileName", "Validate_Next_btn_in_l8_MD");
			ClubStudio.Validate_Next_btn_in_l8_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_Next_btn_in_l8_MD");
			driver.quit();break;
			
			
			
			case "Validate_heading_in_l9_MD":
				
			context.setAttribute("fileName", "Validate_heading_in_l9_MD");
			ClubStudio.Validate_heading_in_l9_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
			context.setAttribute("fileName", "Validate_heading_in_l9_MD");
			driver.quit();break;
			
			
			case "Validate_Rules_procedures_in_l9_MD":
				
			context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_MD");
			ClubStudio.Validate_Rules_procedures_in_l9_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
			context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_MD");
			driver.quit();break;
			
			
			
			case "Validate_ip_in_prtname_dateandipadd_in_l9_MD":
				
			context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_MD");
			ClubStudio.Validate_ip_in_prtname_dateandipadd_in_l9_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, IP_Address );
			context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_MD");
			driver.quit();break;
			
			
			
			case "Validate_Robert_Bryant_Sign_in_l9_MD":
				
			context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_MD");
			ClubStudio.Validate_Robert_Bryant_Sign_in_l9_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
			context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_MD");
			driver.quit();break;
			
			
			
			case "Validate_Iagree_textandbtn_in_l9_MD":
				
			context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_MD");
			ClubStudio.Validate_Iagree_textandbtn_in_l9_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data2 );
			context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_MD");
			driver.quit();break;
			
			case "Validate_Prev_step_btn_in_l9_MD":
				
			context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_MD");
			ClubStudio.Validate_Prev_step_btn_in_l9_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_MD");
			driver.quit();break;
			
			
			case "Validate_Iagreebtn_and_succ_submsn_in_l9_MD":
				
			context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_MD");
			ClubStudio.Validate_Iagreebtn_and_succ_submsn_in_l9_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_MD");
			driver.quit();break;
			
			case "Validate_Success_msg_in_final_page_MD":
				
			context.setAttribute("fileName", "Validate_Success_msg_in_final_page_MD");
			ClubStudio.Validate_Success_msg_in_final_page_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
			context.setAttribute("fileName", "Validate_Success_msg_in_final_page_MD");
			driver.quit();break;
			
			
			case "Validate_prtbtn_in_print_emp_app_page_MD":
				
			context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_MD");
			ClubStudio.Validate_prtbtn_in_print_emp_app_page_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd , input_data2);
			context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_MD");
			driver.quit();break;
			
			
			
			case "Validate_Rules_link_in_l9_MD":
				
			context.setAttribute("fileName", "Validate_Rules_link_in_l9_MD");
			ClubStudio.Validate_Rules_link_in_l9_MD(testdata.get("TextMessage").toString(),Text_input,  How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, additional_input,E_EducationLeve_Dropdown , Dropdown_values , input_data, input_data1, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box , File_name, Languages , Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd );
			context.setAttribute("fileName", "Validate_Rules_link_in_l9_MD");
			driver.quit();break;
			


			

			
			
					
					default:
						driver.quit();
						break;
	
					}
	
					// EndTest
	//				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
					ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
					ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
					ExtentTestManager.endTest();
					ExtentManager.getInstance().flush();
					Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
					Log.info("Browser is closed");
	
	
				}
	
			} 
			catch (Exception e)
			{
				Thread.sleep(1000);
				ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				String stackTrace = Throwables.getStackTraceAsString(e);
				Log.error( stackTrace);
			
				
				String fileName = (String) context.getAttribute("fileName");
	
				try {
					File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
							testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().fail(e.getMessage(),
							MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
					ExtentTestManager.getTest().log(Status.FAIL, e);
					} 
				catch (Exception e1) {
					System.out.println("File not found " + e1);
									}
				ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");
	
	//			 Logout
				context.setAttribute("fileName", "Logout");
				if (com.test.user.All_scenarios.driver!=null)driver.quit();
				ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
				Log.info("Browser is closed");
	
				// EndTest
				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
				ExtentTestManager.endTest();
				ExtentManager.getInstance().flush();
				Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				throw new Exception(stackTrace);
			} 
			catch (AssertionError e) 
			{
				Thread.sleep(1000);
	//			System.out.println("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				String stackTrace = Throwables.getStackTraceAsString(e);
				Log.error( stackTrace);
				
				String fileName = (String) context.getAttribute("fileName");
	
				try {
					File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
							testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().fail(e.getMessage(),
							MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
					ExtentTestManager.getTest().log(Status.FAIL, e);
					} 
				catch (Exception e1)
				{
					System.out.println("File not found " + e1);
				}
				ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");
	
				// Logout
				context.setAttribute("fileName", "Logout");
				driver.quit();
				ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
				Log.info("Browser is closed");
	
				// EndTest
				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
				ExtentTestManager.endTest();
				ExtentManager.getInstance().flush();
				Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				
				throw new Exception(stackTrace);
				

					}
					}
	
		
		@DataProvider(name = "TestData")
		public static Object[][] gettestdate() throws IOException {
	
			Object[][] objectarry = null;
			java.util.List<Map<String, String>> completedata = com.Utility.ExcelReader.getdata("ClubStudio_2");
	
			java.util.List<Map<String, String>> completedata1 = new ArrayList<Map<String,String>>();
			int j=0;
	
			for (int i = 0; i < completedata.size(); i++) {
				if(completedata.get(i).get("Run").toString().equalsIgnoreCase("Yes")) 
				{
				completedata1.add(j, completedata.get(i));
				j++;
				}
			}
			
			objectarry = new Object[completedata1.size()][1];
			
			for (int i = 0; i < completedata1.size(); i++) {
				objectarry[i][0] = completedata1.get(i);
			}
			return objectarry;
	
		}
	
		public void Takescreenshot(String fileName, String scenario) {
			try {
				File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
						scenario);
				ExtentTestManager.getTest().pass("File upload screenshot",
						MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
				
				} 
			catch (Exception e1) {
				System.out.println("File not found " + e1);
								}
		}
		
		
	}



