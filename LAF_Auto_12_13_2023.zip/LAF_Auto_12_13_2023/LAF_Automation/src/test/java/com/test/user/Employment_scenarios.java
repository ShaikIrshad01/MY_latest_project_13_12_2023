	package com.test.user;
	
	import java.io.File;
	import java.io.IOException;
	import java.util.ArrayList;
	import java.util.Collections;
	import java.util.List;
	import java.util.Map;
	import org.testng.ITestContext;
	import org.testng.annotations.AfterTest;
	import org.testng.annotations.BeforeSuite;
	import org.apache.commons.lang3.ObjectUtils.Null;
	import org.apache.poi.hssf.record.PageBreakRecord.Break;
	import org.testng.*;
	import org.testng.annotations.DataProvider;
	import org.testng.annotations.Test;
	import com.BasePackage.Base_Class;
	import com.Utility.Log;
	import com.aventstack.extentreports.MediaEntityBuilder;
	import com.aventstack.extentreports.Status;
	import com.extentReports.ExtentManager;
	import com.extentReports.ExtentTestManager;
	import com.google.common.base.Throwables;
	import com.listeners.TestListener;
	
	public class Employment_scenarios extends Base_Class  {
	
		Base_Class Base_Class;
		com.pages.Home Home;
		com.pages.Joinnow joinnow;
		Log log;
		TestListener TestListener;
		com.Utility.ScreenShot screenShot;
		com.pages.Employment Employment;
		com.pages.FreePass FreePass;
		com.pages.CareerOpportunity CareerOpportunity;
		
		@BeforeSuite
		public void reference() {
			Base_Class = new Base_Class();
			log = new Log();
			TestListener = new TestListener();
			screenShot = new com.Utility.ScreenShot(null);
			Home = new com.pages.Home();
			joinnow = new com.pages.Joinnow();
			Employment = new com.pages.Employment();
			FreePass = new com.pages.FreePass();
			
			CareerOpportunity = new com.pages.CareerOpportunity();
		}
		
		@Test(dataProvider = "TestData")
		public void RUNALL(Map<Object, Object> testdata, ITestContext context) throws Throwable {
	
			try {
	
				if (testdata.get("Run").toString().equalsIgnoreCase("Yes")) {
					String fileName;
					ExtentTestManager.startTest(testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " running Starting ***");
					Log.info("*** Running test method " + testdata.get("TestScenario").toString() + "...");
					ExtentTestManager.getTest().log(Status.PASS, "*** Running test method " + testdata.get("TestScenario").toString() + "...");
				
					String Change_brand_name=testdata.get("Change_brand_name").toString();
					if(testdata.get("TextMessage").toString().trim().equalsIgnoreCase("Change_Brand".trim())) {
						
						Base_Class.setup_Change_brand();
						if(!Change_brand_name.isBlank() && !Change_brand_name.isEmpty()) Base_Class.Change_Brand(Change_brand_name);
						
					else {
						
						throw new Exception("please provide brand name to change the brand");
					
						}
						
						driver.quit();
						
					}
					
					else {
						Base_Class.setup();
					}
	
					ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered into Application URL ");
	
	
					String Dropdown_values=testdata.get("Dropdown_values").toString();
	
					String Country =testdata.get("Country").toString();
					String Ratesoramenities =testdata.get("Rates/amenities").toString();
					String Club_name =testdata.get("Club_name").toString();
					
					String Add_amenities =testdata.get("Add_amenities").toString();
					String Included_amenities =testdata.get("Included_amenities").toString();
				
					String Amount_details =testdata.get("Amount_details").toString();
					String rates_details =testdata.get("Rates_details").toString();
					String plan_rates =testdata.get("Plan_rates").toString();
					
					
					
					
					String Text_input =testdata.get("Text_input").toString();
		
					
					String Number_of_Persons1 =testdata.get("Number_of_Persons1").toString();
					String Initiation_Fee =testdata.get("Initiation_Fee").toString();
					String Billing_Frequency =testdata.get("Billing_Frequency").toString();				
					String Initial_Term =testdata.get("Initial_Term").toString();
					String Prepayment =testdata.get("Prepayment").toString();
					String First_Month_Dues =testdata.get("First_Month_Dues").toString();
					String Last_Month_Dues =testdata.get("Last_Month_Dues").toString();
					String Total_initial_Payment =testdata.get("Total_initial_Payment").toString();	
					String Annual_Fee_Per_Person =testdata.get("Annual_Fee_Per_Person").toString();
					
					String Everemployed_rdobtn =testdata.get("Everemployed_rdobtn").toString();
					String Date_to_begin =testdata.get("Date_to_begin").toString();
					String Languages =testdata.get("Languages").toString();
					String Work_time =testdata.get("Work_time").toString();
					String Url =testdata.get("Url").toString();
					String additional_input =testdata.get("additional_input").toString();
					String input_data =testdata.get("input_data").toString();
					String input_data1 =testdata.get("input_data1").toString();
					String input_data2 =testdata.get("input_data2").toString();
					String input_data3 =testdata.get("input_data3").toString();
					String input_data4 =testdata.get("input_data4").toString();
					String input_data5 =testdata.get("input_data5").toString();
					String input_data6 =testdata.get("input_data6").toString();
					String IP_Address =testdata.get("IP_Address").toString();
					
					String File_name =testdata.get("File_name").toString();
					
					String Job_short_des =testdata.get("Job_short_des").toString();
					String Job_long_des =testdata.get("Job_long_des").toString();
					String F_Name =testdata.get("F_Name").toString();
					String L_Name =testdata.get("L_Name").toString();
					String Full_name =testdata.get("Full_name").toString();
					String Phone =testdata.get("Member_Phone").toString();
					String Email =testdata.get("Email").toString();
					String Address =testdata.get("Member_address").toString();
	//				job_short_des
					String City =testdata.get("Member_City").toString();
					
					String E_EducationLeve_Dropdown = testdata.get("E_EducationLeve_Dropdown").toString();
	
					String Aerobics_Instructor_Exp_DD = testdata.get("Aerobics_Instructor_Exp_DD").toString();
					String Time_period_DD = testdata.get("Time_period_DD").toString();
					String Club_Employer_DD = testdata.get("Club_Employer_DD").toString();
					String Class_per_week = testdata.get("Class_per_week").toString();
					
					String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
					String PriorEmploymentWhyResigned_ip = testdata.get("PriorEmploymentWhyResigned_ip").toString();
					String EmploymentWhyLeaveCurrent_ip = testdata.get("EmploymentWhyLeaveCurrent_ip").toString();
					String EmploymentWhyReapply_ip = testdata.get("EmploymentWhyReapply_ip").toString();
					String EmploymentWhatLike_ip = testdata.get("EmploymentWhatLike_ip").toString();
					String EmploymentWhatDislike_ip = testdata.get("EmploymentWhatDislike_ip").toString();
					
					String EmploymentSuccess_ip = testdata.get("EmploymentSuccess_ip").toString();
					String EmploymentWhyResignInFuture_ip = testdata.get("EmploymentWhyResignInFuture_ip").toString();
					String Gender_dd = testdata.get("Gender_dd").toString();
					String RaceEthnicity_dd = testdata.get("RaceEthnicity_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
	//				
					String Personal_Training_ExperienceDPValues = testdata.get("Personal_Training_ExperienceDPValues").toString();
					String Certification_IssuedByDPValues = testdata.get("Certification_IssuedByDPValues").toString();
					String Hold_cert_GT_AC_ratio_button = testdata.get("Hold_cert_GT_AC_ratio_button").toString();
					String Certified_In_DD = testdata.get("Certified_In_DD").toString();
					String Certificate_No = testdata.get("Certificate_No").toString();
					String Emp_gap = testdata.get("Emp_gap").toString();
					String Employer_name = testdata.get("Employer_name").toString();
					String Supervisor_name = testdata.get("Supervisor_name").toString();
					String From_date = testdata.get("From_date").toString();
					String To_date = testdata.get("To_date").toString();
					String Job_title = testdata.get("Job_title").toString();
					String Leaving_Reason = testdata.get("Leaving_Reason").toString();
					String Emp_details = testdata.get("Emp_details").toString();
					String Can_contact_radio_button = testdata.get("Can_contact_radio_button").toString();
					
					
					String Club_phone =testdata.get("Club_phone").toString();
					String Club_zip =testdata.get("Club_zip").toString();
					String Club_Address =testdata.get("Club_Address").toString();
					String Club_city =testdata.get("Club_city").toString();
	//				
					String State =testdata.get("State").toString();
					String Zipcode =testdata.get("Member_Zipcode").toString();
					String Radius_travel_to_work =testdata.get("Radius_travel_to_work").toString();
					String How_hear_abt_us =testdata.get("How_hear_abt_us").toString();
					String Radiobtn18YearsOld =testdata.get("Radiobtn18YearsOld").toString();
					String Payment_type =testdata.get("Payment_type").toString();
					String Card_number  =testdata.get("Card_number").toString();
					
					String Ex_month =testdata.get("Ex_month").toString();
					String Ex_year  =testdata.get("Ex_year").toString();
					
					String Routing_number  =testdata.get("Routing_number").toString();
					String Account_number =testdata.get("Account_number").toString();
					String Card_name =testdata.get("Card_name").toString();
					String Checkbox_class_formats =testdata.get("Checkbox_class_formats").toString();

					String No_Prev_emp_chk_box =testdata.get("No_Prev_emp_chk_box").toString();
				
					String Considered_for_chkbx= testdata.get("Considered_for_chkbx").toString();
					
					
					
							
					switch (testdata.get("TextMessage").toString()) {
					
					
					// Career Opportunities / Employment  Group Fitness, HIIT Coach and Corporate Apply here Test cases
					
					
					
					case "About_dropdown":
						
						context.setAttribute("fileName", "About_dropdown");
						Home.Validate_About_dropdown(testdata.get("TextMessage").toString());
						context.setAttribute("fileName", "About_dropdown");
						driver.quit();
						break;
						
					case "Nav_to_Employment_page":
						
						context.setAttribute("fileName", "Nav_to_Employment_page");
						Home.Navigate_to_Emplyoment_page(testdata.get("TextMessage").toString());
						context.setAttribute("fileName", "Nav_to_Employment_page");
						driver.quit();		
						break;
						
					case "Validate_play_pause_video":
						
						context.setAttribute("fileName", "Validate_play_pause_video");
						Employment.Validate_play_pause_video(testdata.get("TextMessage").toString(),Text_input, input_data);
						context.setAttribute("fileName", "Validate_play_pause_video");
						driver.quit();
						break;
						
					case "Validate_Club_and_corporate_positions":
						
						context.setAttribute("fileName", "Validate_Club_and_corporate_positions");
						Employment.Validate_Club_and_corporate_positions(testdata.get("TextMessage").toString(), Text_input, input_data, additional_input);
						context.setAttribute("fileName", "Validate_Club_and_corporate_positions");
						driver.quit();
						break;
						
					case "Career_opportunity_section":
						
						context.setAttribute("fileName", "Career_opportunity_section");
						Employment.Career_opportunity_section(testdata.get("TextMessage").toString(), Text_input, input_data);
						context.setAttribute("fileName", "Career_opportunity_section");
						driver.quit();break;
						
					case "Validate_Club_positions_section":
						
						context.setAttribute("fileName", "Validate_Club_positions_section");
						Employment.Validate_Club_positions_section(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2);
						context.setAttribute("fileName", "Validate_Club_positions_section");
						driver.quit();break;
						
					case "Validate_corporate_positions_section":
						
						context.setAttribute("fileName", "Validate_corporate_positions_section");
						Employment.Validate_Corporate_positions_section(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1 );
						context.setAttribute("fileName", "Validate_corporate_positions_section");
						driver.quit();break;
						
						
						
					case "Validate_details_of_Group_Fitness_position":
						
						context.setAttribute("fileName", "Validate_details_of_Group_Fitness_position");
						Employment.Validate_details_of_Group_Fitness_position(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_Group_Fitness_position");
						driver.quit();break;
						
					case "Validate_details_of_Personal_Trainer_position":
						
						context.setAttribute("fileName", "Validate_details_of_Personal_Trainer_position");
						Employment.Validate_details_of_Personal_Trainer_position(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_Personal_Trainer_position");
						driver.quit();break;
						
					case "Validate_details_of_Pilates_Teacher_position":
						
						context.setAttribute("fileName", "Validate_details_of_Pilates_Teacher_position");
						Employment.Validate_details_of_Pilates_Teacher_position(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_Pilates_Teacher_position");
						driver.quit();break;
						
					case "Validate_details_of_Hiit_Coach_position":
						
						context.setAttribute("fileName", "Validate_details_of_Hiit_Coach_position");
						Employment.Validate_details_of_Hiit_Coach_position(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_Hiit_Coach_position");
						driver.quit();break;
						
						
					case "Validate_moreinfo_popupwindow_of_GFP":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_GFP");
						Employment.Validate_moreinfo_popupwindow_of_Group_Fitness_position(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_GFP");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_Personal_TP":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_Personal_TP");
						Employment.Validate_moreinfo_popupwindow_of_Personal_TP(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_Personal_TP");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_Pilates_TP":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_Pilates_TP");
						Employment.Validate_moreinfo_popupwindow_of_Pilates_TP(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_Pilates_TP");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_HCP":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_HCP");
						Employment.Validate_moreinfo_popupwindow_of_HCP(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_HCP");
						driver.quit();break;
						
					case "Validate_details_of_Accounting":
						
						context.setAttribute("fileName", "Validate_details_of_Accounting");
						Employment.Validate_details_of_Accounting(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Job_short_des );
						context.setAttribute("fileName", "Validate_details_of_Accounting");
						driver.quit();break;
						
					case "Validate_details_of_Finance_and_T":
						
						context.setAttribute("fileName", "Validate_details_of_Finance_and_T");
						Employment.Validate_details_of_Finance_and_T(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Job_short_des );
						context.setAttribute("fileName", "Validate_details_of_Finance_and_T");
						driver.quit();break;
						
					case "Validate_details_of_HR":
						
						context.setAttribute("fileName", "Validate_details_of_HR");
						Employment.Validate_details_of_HR(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Job_short_des );
						context.setAttribute("fileName", "Validate_details_of_HR");
						driver.quit();break;
						
					case "Validate_details_of_IT":
						
						context.setAttribute("fileName", "Validate_details_of_IT");
						Employment.Validate_details_of_IT(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Job_short_des );
						context.setAttribute("fileName", "Validate_details_of_IT");
						driver.quit();break;
						
					case "Validate_details_of_Legal_and_A":
						
						context.setAttribute("fileName", "Validate_details_of_Legal_and_A");
						Employment.Validate_details_of_Legal_and_A(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Job_short_des );
						context.setAttribute("fileName", "Validate_details_of_Legal_and_A");
						driver.quit();break;
						
					case "Validate_details_of_RealEstate_and_D":
						
						context.setAttribute("fileName", "Validate_details_of_RealEstate_and_D");
						Employment.Validate_details_of_RealEstate_and_D(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Job_short_des );
						context.setAttribute("fileName", "Validate_details_of_RealEstate_and_D");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_Accounting":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_Accounting");
						Employment.Validate_moreinfo_popupwindow_of_Accounting(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Job_short_des, Job_long_des );
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_Accounting");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_Finance_and_T":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_Finance_and_T");
						Employment.Validate_moreinfo_popupwindow_of_Finance_and_T(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_Finance_and_T");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_Human_R":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_Human_R");
						Employment.Validate_moreinfo_popupwindow_of_Human_R(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_Human_R");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_IT":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_IT");
						Employment.Validate_moreinfo_popupwindow_of_IT(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_IT");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_Legal_and_A":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_Legal_and_A");
						Employment.Validate_moreinfo_popupwindow_of_Legal_and_A(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_Legal_and_A");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_RE_and_D":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_RE_and_D");
						Employment.Validate_moreinfo_popupwindow_of_RE_and_D(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_RE_and_D");
						driver.quit();break;
						
					case "Validate_GF_applyhere_button":
						
						context.setAttribute("fileName", "Validate_GF_applyhere_button");
						Employment.Validate_GF_applyhere_button(testdata.get("TextMessage").toString());
						context.setAttribute("fileName", "Validate_GF_applyhere_button");
						driver.quit();break;
						
					case "Validate_Pilates_T_applyhere_button":
						
						context.setAttribute("fileName", "Validate_Pilates_T_applyhere_button");
						Employment.Validate_Pilates_T_applyhere_button(testdata.get("TextMessage").toString());
						context.setAttribute("fileName", "Validate_Pilates_T_applyhere_button");
						driver.quit();break;
						
					case "Validate_Personal_T_applyhere_button":
						
						context.setAttribute("fileName", "Validate_Personal_T_applyhere_button");
						Employment.Validate_Personal_T_applyhere_button(testdata.get("TextMessage").toString());
						context.setAttribute("fileName", "Validate_Personal_T_applyhere_button");
						driver.quit();break;
						
					case "Validate_HIIT_C_applyhere_button":
						
						context.setAttribute("fileName", "Validate_HIIT_C_applyhere_button");
						Employment.Validate_HIIT_C_applyhere_button(testdata.get("TextMessage").toString());
						context.setAttribute("fileName", "Validate_HIIT_C_applyhere_button");
						driver.quit();break;
						
						
					case "Validate_applyhere_button_followingpos_text":
						
						context.setAttribute("fileName", "Validate_applyhere_button_followingpos_text");
						Employment.Validate_applyhere_button_followingpos_text(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3);
						context.setAttribute("fileName", "Validate_applyhere_button_followingpos_text");
						driver.quit();break;
						
					case "Validate_details_of_General_Manager":
						
						context.setAttribute("fileName", "Validate_details_of_General_Manager");
						Employment.Validate_details_of_General_Manager(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_General_Manager");
						driver.quit();break;
						
					case "Validate_details_of_Operations_Manager":
						
						context.setAttribute("fileName", "Validate_details_of_Operations_Manager");
						Employment.Validate_details_of_Operations_Manager(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_Operations_Manager");
						driver.quit();break;
						
					case "Validate_details_of_Personal_TD":
						
						context.setAttribute("fileName", "Validate_details_of_Personal_TD");
						Employment.Validate_details_of_Personal_TD(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_Personal_TD");
						driver.quit();break;
						
					case "Validate_details_of_Membership_Counselor":
						
						context.setAttribute("fileName", "Validate_details_of_Membership_Counselor");
						Employment.Validate_details_of_Membership_Counselor(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_Membership_Counselor");
						driver.quit();break;
						
					case "Validate_details_of_Personal_TMC":
						
						context.setAttribute("fileName", "Validate_details_of_Personal_TMC");
						Employment.Validate_details_of_Personal_TMC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_Personal_TMC");
						driver.quit();break;
						
					case "Validate_details_of_Club_Staff":
						
						context.setAttribute("fileName", "Validate_details_of_Club_Staff");
						Employment.Validate_details_of_Club_Staff(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_Club_Staff");
						driver.quit();break;
						
					case "Validate_details_of_League_SD":
						
						context.setAttribute("fileName", "Validate_details_of_League_SD");
						Employment.Validate_details_of_League_SD(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_League_SD");
						driver.quit();break;
						
					case "Validate_details_of_Equipment_Tech":
						
						context.setAttribute("fileName", "Validate_details_of_Equipment_Tech");
						Employment.Validate_details_of_Equipment_Tech(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_Equipment_Tech");
						driver.quit();break;
						
					case "Validate_details_of_HVAC_Building_M":
						
						context.setAttribute("fileName", "Validate_details_of_HVAC_Building_M");
						Employment.Validate_details_of_HVAC_Building_M(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_HVAC_Building_M");
						driver.quit();break;
						
					case "Validate_details_of_Pride_Janitor":
						
						context.setAttribute("fileName", "Validate_details_of_Pride_Janitor");
						Employment.Validate_details_of_Pride_Janitor(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des);
						context.setAttribute("fileName", "Validate_details_of_Pride_Janitor");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_GM":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_GM");
						Employment.Validate_moreinfo_popupwindow_of_GM(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_GM");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_OS":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_OS");
						Employment.Validate_moreinfo_popupwindow_of_OS(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_OS");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_PTD":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_PTD");
						Employment.Validate_moreinfo_popupwindow_of_PTD(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_PTD");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_MC":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_MC");
						Employment.Validate_moreinfo_popupwindow_of_MC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_MC");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_PTMC":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_PTMC");
						Employment.Validate_moreinfo_popupwindow_of_PTMC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_PTMC");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_CS":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_CS");
						Employment.Validate_moreinfo_popupwindow_of_CS(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_CS");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_LSD":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_LSD");
						Employment.Validate_moreinfo_popupwindow_of_LSD(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_LSD");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_ET":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_ET");
						Employment.Validate_moreinfo_popupwindow_of_ET(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_ET");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_HVAC_BM":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_HVAC_BM");
						Employment.Validate_moreinfo_popupwindow_of_HVAC_BM(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_HVAC_BM");
						driver.quit();break;
						
					case "Validate_moreinfo_popupwindow_of_PJ":
						
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_PJ");
						Employment.Validate_moreinfo_popupwindow_of_PJ(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3, input_data4, Job_short_des, Job_long_des);
						context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_PJ");
						driver.quit();break;
						
					case "Validate_applyhere_button_under_club_pos":
						
						context.setAttribute("fileName", "Validate_applyhere_button_under_club_pos");
						Employment.Validate_applyhere_button_under_club_pos(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, input_data3);
						context.setAttribute("fileName", "Validate_applyhere_button_under_club_pos");
						driver.quit();break;
						
						
					case "Validate_applyhere_button_under_corp_pos":
						
						context.setAttribute("fileName", "Validate_applyhere_button_under_corp_pos");
						Employment.Validate_applyhere_button_under_corp_pos(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1 );
						context.setAttribute("fileName", "Validate_applyhere_button_under_corp_pos");
						driver.quit();break;
						
						
					case "Validate_GF_btn_url_submit_app_text":
						
						context.setAttribute("fileName", "Validate_GF_btn_url_submit_app_text");
						Employment.Validate_GF_btn_url_submit_app_text(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3);
						context.setAttribute("fileName", "Validate_GF_btn_url_submit_app_text");
						driver.quit();break;
						
					case "Validate_HIIT_btn_url_submit_app_text_HC":
						
						context.setAttribute("fileName", "Validate_HIIT_btn_url_submit_app_text_HC");
						Employment.Validate_HIIT_btn_url_submit_app_text_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3);
						context.setAttribute("fileName", "Validate_HIIT_btn_url_submit_app_text_HC");
						driver.quit();break;
						
						
					case "Validate_AH_btn_url_submit_app_text_corp":
						
						context.setAttribute("fileName", "Validate_AH_btn_url_submit_app_text_corp");
						Employment.Validate_AH_btn_url_submit_app_text_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3 );
						context.setAttribute("fileName", "Validate_AH_btn_url_submit_app_text_corp");
						driver.quit();break;
						
						
					case "Validate_paragraph_under_emp_app_GF":
						
						context.setAttribute("fileName", "Validate_paragraph_under_emp_app_GF");
						Employment.Validate_paragraph_under_emp_app_GF(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, input_data4);
						context.setAttribute("fileName", "Validate_paragraph_under_emp_app_GF");
						driver.quit();break;
						
						
					case "Validate_paragraph_under_emp_app_HC":
						
						context.setAttribute("fileName", "Validate_paragraph_under_emp_app_HC");
						Employment.Validate_paragraph_under_emp_app_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, input_data4);
						context.setAttribute("fileName", "Validate_paragraph_under_emp_app_HC");
						driver.quit();break;
						
						
					case "Validate_paragraph_under_emp_app_corp":
						
						context.setAttribute("fileName", "Validate_paragraph_under_emp_app_corp");
						Employment.Validate_paragraph_under_emp_app_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, input_data4 );
						context.setAttribute("fileName", "Validate_paragraph_under_emp_app_corp");
						driver.quit();break;
						
						
					case "Validate_app_info_in_submit_page":
						
						context.setAttribute("fileName", "Validate_app_info_in_submit_page");
						Employment.Validate_app_info_in_submit_page(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, input_data4);
						context.setAttribute("fileName", "Validate_app_info_in_submit_page");
						driver.quit();break;
						
					case "Validate_app_info_in_submit_page_HC":
						
						context.setAttribute("fileName", "Validate_app_info_in_submit_page_HC");
						Employment.Validate_app_info_in_submit_page_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, input_data4);
						context.setAttribute("fileName", "Validate_app_info_in_submit_page_HC");
						driver.quit();break;
						
						
					case "Validate_app_info_in_submit_page_corp":
						
						context.setAttribute("fileName", "Validate_app_info_in_submit_page_corp");
						Employment.Validate_app_info_in_submit_page_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, input_data4 );
						context.setAttribute("fileName", "Validate_app_info_in_submit_page_corp");
						driver.quit();break;
						
						
					case "Validate_all_fields_in_submit_page":
						
						context.setAttribute("fileName", "Validate_all_fields_in_submit_page");
						Employment.Validate_all_fields_in_submit_page(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3);
						context.setAttribute("fileName", "Validate_all_fields_in_submit_page");
						driver.quit();break;
						
					case "Validate_all_fields_in_submit_page_HC":
						
						context.setAttribute("fileName", "Validate_all_fields_in_submit_page_HC");
						Employment.Validate_all_fields_in_submit_page_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3);
						context.setAttribute("fileName", "Validate_all_fields_in_submit_page_HC");
						driver.quit();break;
						
						
					case "Validate_all_fields_in_submit_page_corp":
						
						context.setAttribute("fileName", "Validate_all_fields_in_submit_page_corp");
						Employment.Validate_all_fields_in_submit_page_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3 );
						context.setAttribute("fileName", "Validate_all_fields_in_submit_page_corp");
						driver.quit();break;
						
						
					case "Validate_HowDidYouHear_abt_us_dropdown":
						
						context.setAttribute("fileName", "Validate_HowDidYouHear_abt_us_dropdown");
						Employment.Validate_HowDidYouHear_abt_us_dropdown(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, Dropdown_values);
						context.setAttribute("fileName", "Validate_HowDidYouHear_abt_us_dropdown");
						driver.quit();break;
						
					case "Validate_HowDidYouHear_abt_us_dropdown_HC":
						
						context.setAttribute("fileName", "Validate_HowDidYouHear_abt_us_dropdown_HC");
						Employment.Validate_HowDidYouHear_abt_us_dropdown_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, Dropdown_values);
						context.setAttribute("fileName", "Validate_HowDidYouHear_abt_us_dropdown_HC");
						driver.quit();break;
						
						
					case "Validate_HowuHear_abt_us_dropdown_corp":
						
						context.setAttribute("fileName", "Validate_HowuHear_abt_us_dropdown_corp");
						Employment.Validate_HowuHear_abt_us_dropdown_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3 , Dropdown_values);
						context.setAttribute("fileName", "Validate_HowuHear_abt_us_dropdown_corp");
						driver.quit();break;
						
						
					case "Validate_Radiobtn18YearsOld_options":
						
						context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options");
						Employment.Validate_Radiobtn18YearsOld_options(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3);
						context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options");
						driver.quit();break;
						
					case "Validate_Radiobtn18YearsOld_options_HC":
						
						context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_HC");
						Employment.Validate_Radiobtn18YearsOld_options_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3);
						context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_HC");
						driver.quit();break;
						
						
					case "Validate_Rdobtn18YrsOld_options_corp":
						
						context.setAttribute("fileName", "Validate_Rdobtn18YrsOld_options_corp");
						Employment.Validate_Rdobtn18YrsOld_options_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3 );
						context.setAttribute("fileName", "Validate_Rdobtn18YrsOld_options_corp");
						driver.quit();break;
						
						
						
					case "Validate_US_Canada_format":
						
						context.setAttribute("fileName", "Validate_US_Canada_format");
						Employment.Validate_US_Canada_format(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, input_data4);
						context.setAttribute("fileName", "Validate_US_Canada_format");
						driver.quit();break;
						
						
					case "Validate_US_Canada_format_HC":
						
						context.setAttribute("fileName", "Validate_US_Canada_format_HC");
						Employment.Validate_US_Canada_format_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, input_data4);
						context.setAttribute("fileName", "Validate_US_Canada_format_HC");
						driver.quit();break;
						
						
					case "Validate_US_format_corp":
						
						context.setAttribute("fileName", "Validate_US_format_corp");
						Employment.Validate_US_format_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, input_data4 );
						context.setAttribute("fileName", "Validate_US_format_corp");
						driver.quit();break;
						
						
					case "Validate_Miles_text":
						
						context.setAttribute("fileName", "Validate_Miles_text");
						Employment.Validate_Miles_text(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, input_data4);
						context.setAttribute("fileName", "Validate_Miles_text");
						driver.quit();break;
						
						
					case "Validate_Miles_text_in_HC":
						
						context.setAttribute("fileName", "Validate_Miles_text_in_HC");
						Employment.Validate_Miles_text_in_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, input_data4);
						context.setAttribute("fileName", "Validate_Miles_text_in_HC");
						driver.quit();break;
						
						
					case "Validate_phone_errorlabel":
						
						context.setAttribute("fileName", "Validate_phone_errorlabel");
						Employment.Validate_phone_errorlabel(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, input_data4);
						context.setAttribute("fileName", "Validate_phone_errorlabel");
						driver.quit();break;
						
					case "Validate_phone_errorlabel_HC":
						
						context.setAttribute("fileName", "Validate_phone_errorlabel_HC");
						Employment.Validate_phone_errorlabel_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, input_data4);
						context.setAttribute("fileName", "Validate_phone_errorlabel_HC");
						driver.quit();break;
						
						
						
					case "Validate_phone_errorlabel_corp":
						
						context.setAttribute("fileName", "Validate_phone_errorlabel_corp");
						Employment.Validate_phone_errorlabel_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, input_data4 );
						context.setAttribute("fileName", "Validate_phone_errorlabel_corp");
						driver.quit();break;
						
						
					case "Validate_Next_step_button_in_l1":
						
						context.setAttribute("fileName", "Validate_Next_step_button_in_l1");
						Employment.Validate_Next_step_button_in_l1(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3);
						context.setAttribute("fileName", "Validate_Next_step_button_in_l1");
						driver.quit();break;
						
						
					case "Validate_Next_step_button_in_l1_HC":
						
						context.setAttribute("fileName", "Validate_Next_step_button_in_l1_HC");
						Employment.Validate_Next_step_button_in_l1_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3);
						context.setAttribute("fileName", "Validate_Next_step_button_in_l1_HC");
						driver.quit();break;
						
						
					case "Validate_Next_step_btn_in_l1_corp":
						
						context.setAttribute("fileName", "Validate_Next_step_btn_in_l1_corp");
						Employment.Validate_Next_step_btn_in_l1_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3 );
						context.setAttribute("fileName", "Validate_Next_step_btn_in_l1_corp");
						driver.quit();break;
	
						
						
					case "Validate_input_in_all_fields_in_submit_page":
						
					context.setAttribute("fileName", "Validate_input_in_all_fields_in_submit_page");
					Employment.Validate_input_in_all_fields_in_submit_page(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode  );
					context.setAttribute("fileName", "Validate_input_in_all_fields_in_submit_page");
					driver.quit();break;
					
					
					case "Validate_input_in_all_fields_in_submit_page_HC":
						
					context.setAttribute("fileName", "Validate_input_in_all_fields_in_submit_page_HC");
					Employment.Validate_input_in_all_fields_in_submit_page_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode  );
					context.setAttribute("fileName", "Validate_input_in_all_fields_in_submit_page_HC");
					driver.quit();break;
					
					case "Validate_ip_in_all_fields_in_l1_corp":
						
						context.setAttribute("fileName", "Validate_ip_in_all_fields_in_l1_corp");
						Employment.Validate_ip_in_all_fields_in_l1_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode  );
						context.setAttribute("fileName", "Validate_ip_in_all_fields_in_l1_corp");
						driver.quit();break;
					
					
					case "Validate_RdoBtnList18YrsOld_No_popupalrt":
						
					context.setAttribute("fileName", "Validate_RdoBtnList18YrsOld_No_popupalrt");
					Employment.Validate_RdoBtnList18YrsOld_No_popupalrt(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3,Radiobtn18YearsOld  );
					context.setAttribute("fileName", "Validate_RdoBtnList18YrsOld_No_popupalrt");
					driver.quit();break;

					
					case "Validate_RdoBtnList18YrsOld_No_popupalrt_HC":
						
					context.setAttribute("fileName", "Validate_RdoBtnList18YrsOld_No_popupalrt_HC");
					Employment.Validate_RdoBtnList18YrsOld_No_popupalrt_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3,Radiobtn18YearsOld  );
					context.setAttribute("fileName", "Validate_RdoBtnList18YrsOld_No_popupalrt_HC");
					driver.quit();break;
					
					
					case "Validate_RdoBtn18YrsOld_No_alert_corp":
						
						context.setAttribute("fileName", "Validate_RdoBtn18YrsOld_No_alert_corp");
						Employment.Validate_RdoBtn18YrsOld_No_alert_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, Radiobtn18YearsOld );
						context.setAttribute("fileName", "Validate_RdoBtn18YrsOld_No_alert_corp");
						driver.quit();break;
					
					
					case "Validate_Next_step_in_Submit_app_page_l1":
						
					context.setAttribute("fileName", "Validate_Next_step_in_Submit_app_page_l1");
					Employment.Validate_Next_step_in_Submit_app_page_l1(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4  );
					context.setAttribute("fileName", "Validate_Next_step_in_Submit_app_page_l1");
					driver.quit();break;
					
					
					case "Validate_Next_step_in_Submit_app_page_l1_HC":
						
					context.setAttribute("fileName", "Validate_Next_step_in_Submit_app_page_l1_HC");
					Employment.Validate_Next_step_in_Submit_app_page_l1_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4  );
					context.setAttribute("fileName", "Validate_Next_step_in_Submit_app_page_l1_HC");
					driver.quit();break;
					
					
					case "Validate_Next_step_in_Submitpage_l1_corp":
						
						context.setAttribute("fileName", "Validate_Next_step_in_Submitpage_l1_corp");
						Employment.Validate_Next_step_in_Submitpage_l1_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4  );
						context.setAttribute("fileName", "Validate_Next_step_in_Submitpage_l1_corp");
						driver.quit();break;
					
					
					case "Validate_education_level_dropdown":
						
					context.setAttribute("fileName", "Validate_education_level_dropdown");
					Employment.Validate_education_level_dropdown(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4  );
					context.setAttribute("fileName", "Validate_education_level_dropdown");
					driver.quit();break;
					
					
					case "Validate_education_level_dropdown_HC":
						
					context.setAttribute("fileName", "Validate_education_level_dropdown_HC");
					Employment.Validate_education_level_dropdown_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4  );
					context.setAttribute("fileName", "Validate_education_level_dropdown_HC");
					driver.quit();break;
					
					case "Validate_education_level_dropdown_corp":
						
						context.setAttribute("fileName", "Validate_education_level_dropdown_corp");
						Employment.Validate_education_level_dropdown_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4  );
						context.setAttribute("fileName", "Validate_education_level_dropdown_corp");
						driver.quit();break;
					
					
					case "Validate_education_level_dropdown_all_values":
						
					context.setAttribute("fileName", "Validate_education_level_dropdown_all_values");
					Employment.Validate_education_level_dropdown_all_values(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown  );
					context.setAttribute("fileName", "Validate_education_level_dropdown_all_values");
					driver.quit();break;
					
					case "Validate_education_level_dropdown_all_values_HC":

					context.setAttribute("fileName", "Validate_education_level_dropdown_all_values_HC");
					Employment.Validate_education_level_dropdown_all_values_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown  );
					context.setAttribute("fileName", "Validate_education_level_dropdown_all_values_HC");
					driver.quit();break;
					
					
					case "Validate_edu_level_dd_all_values_corp":
						
						context.setAttribute("fileName", "Validate_edu_level_dd_all_values_corp");
						Employment.Validate_edu_level_dd_all_values_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown  );
						context.setAttribute("fileName", "Validate_edu_level_dd_all_values_corp");
						driver.quit();break;
					
					
					case "Validate_previous_next_step_buttons_l2":
						
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2");
					Employment.Validate_previous_next_step_buttons_l2(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4  );
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2");
					driver.quit();

					case "Validate_previous_next_step_buttons_l2_HC":
						
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_HC");
					Employment.Validate_previous_next_step_buttons_l2_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4  );
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_l2_HC");
					driver.quit();

					case "Validate_prev_next_step_btns_l22_corp":
						
						context.setAttribute("fileName", "Validate_prev_next_step_btns_l22_corp");
						Employment.Validate_prev_next_step_btns_l22_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4  );
						context.setAttribute("fileName", "Validate_prev_next_step_btns_l22_corp");
						driver.quit();break;					
					
					case "Validate_previous_step_button_l2":
						
					context.setAttribute("fileName", "Validate_previous_step_button_l2");
					Employment.Validate_previous_step_button_l2(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4  );
					context.setAttribute("fileName", "Validate_previous_step_button_l2");
					driver.quit();break;

					case "Validate_previous_step_button_l2_HC":
						
					context.setAttribute("fileName", "Validate_previous_step_button_l2_HC");
					Employment.Validate_previous_step_button_l2_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4  );
					context.setAttribute("fileName", "Validate_previous_step_button_l2_HC");
					driver.quit();break;
					

					case "Validate_prev_step_btn_l22_corp":
						
						context.setAttribute("fileName", "Validate_prev_step_btn_l22_corp");
						Employment.Validate_prev_step_btn_l22_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4  );
						context.setAttribute("fileName", "Validate_prev_step_btn_l22_corp");
						driver.quit();break;
					
					case "Validate_Next_step_button_l2":
						
					context.setAttribute("fileName", "Validate_Next_step_button_l2");
					Employment.Validate_Next_step_button_l2(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_Next_step_button_l2");
					driver.quit();break;
						

					case "Validate_Next_step_button_l2_HC":
						
					context.setAttribute("fileName", "Validate_Next_step_button_l2_HC");
					Employment.Validate_Next_step_button_l2_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_Next_step_button_l2_HC");
					driver.quit();break;

					case "Validate_Next_step_btn_l22_corp":
						
						context.setAttribute("fileName", "Validate_Next_step_btn_l22_corp");
						Employment.Validate_Next_step_btn_l22_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown  );
						context.setAttribute("fileName", "Validate_Next_step_btn_l22_corp");
						driver.quit();break;
					
					case "Validate_Exp_info_text_in_l3":
						
					context.setAttribute("fileName", "Validate_Exp_info_text_in_l3");
					Employment.Validate_Exp_info_text_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, input_data5 );
					context.setAttribute("fileName", "Validate_Exp_info_text_in_l3");
					driver.quit();break;
					

					case "Validate_Exp_info_text_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_HC");
					Employment.Validate_Exp_info_text_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, input_data5 );
					context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_HC");
					driver.quit();break;

					
					
					case "Validate_GP_AI_text_in_l3":
						
					context.setAttribute("fileName", "Validate_GP_AI_text_in_l3");
					Employment.Validate_GP_AI_text_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, input_data5 );
					context.setAttribute("fileName", "Validate_GP_AI_text_in_l3");
					driver.quit();
					
					case "Validate_Hiit_Cert_text_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_Hiit_Cert_text_in_l3_HC");
					Employment.Validate_Hiit_Cert_text_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, input_data5 );
					context.setAttribute("fileName", "Validate_Hiit_Cert_text_in_l3_HC");
					driver.quit();
					
					case "Validate_GP_AI_exp_dropdown_in_l3":
						
					context.setAttribute("fileName", "Validate_GP_AI_exp_dropdown_in_l3");
					Employment.Validate_GP_AI_exp_dropdown_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_GP_AI_exp_dropdown_in_l3");
					driver.quit();break;
					
					case "Validate_GP_AI_exp_dropdown_all_values_in_l3":
						
					context.setAttribute("fileName", "Validate_GP_AI_exp_dropdown_all_values_in_l3");
					Employment.Validate_GP_AI_exp_dropdown_all_values_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values );
					context.setAttribute("fileName", "Validate_GP_AI_exp_dropdown_all_values_in_l3");
					driver.quit();break;
					
					
					case "Validate_HIIT_exp_dropdown_all_values_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_HIIT_exp_dropdown_all_values_in_l3_HC");
					Employment.Validate_HIIT_exp_dropdown_all_values_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values );
					context.setAttribute("fileName", "Validate_HIIT_exp_dropdown_all_values_in_l3_HC");
					driver.quit();break;
					
					
					case "Validate_Hold_a_Cert_radio_buttons_in_l3":
						
					context.setAttribute("fileName", "Validate_Hold_a_Cert_radio_buttons_in_l3");
					Employment.Validate_Hold_a_Cert_radio_buttons_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_Hold_a_Cert_radio_buttons_in_l3");
					driver.quit();break;
					
					case "Validate_GF_Aerobics_CertfnInfo_link":
						
					context.setAttribute("fileName", "Validate_GF_Aerobics_CertfnInfo_link");
					Employment.Validate_GF_Aerobics_CertfnInfo_link(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_GF_Aerobics_CertfnInfo_link");
					driver.quit();break;
					
					case "Validate_Hold_a_Cert_radio_buttons_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_Hold_a_Cert_radio_buttons_in_l3_HC");
					Employment.Validate_Hold_a_Cert_radio_buttons_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_Hold_a_Cert_radio_buttons_in_l3_HC");
					driver.quit();break;
					
					case "Validate_CertfnInfo_link_HC":
						
					context.setAttribute("fileName", "Validate_CertfnInfo_link_HC");
					Employment.Validate_CertfnInfo_link_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_CertfnInfo_link_HC");
					driver.quit();break;
					
					
					case "Validate_CertfnInfo_window_HC":
						
						context.setAttribute("fileName", "Validate_CertfnInfo_window_HC");
						Employment.Validate_CertfnInfo_window_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_CertfnInfo_window_HC");
						driver.quit();break;
						
					
					case "Validate_bydefault_no_rdobtn_selected_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_bydefault_no_rdobtn_selected_in_l3_HC");
					Employment.Validate_bydefault_no_rdobtn_selected_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_bydefault_no_rdobtn_selected_in_l3_HC");
					driver.quit();break;
					
					case "Validate_yes_rdobtn_section_allfields_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_yes_rdobtn_section_allfields_in_l3_HC");
					Employment.Validate_yes_rdobtn_section_allfields_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, input_data5, input_data6 );
					context.setAttribute("fileName", "Validate_yes_rdobtn_section_allfields_in_l3_HC");
					driver.quit();break;
					
					
					case "Validate_Certification_section2_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_Certification_section2_in_l3_HC");
					Employment.Validate_Certification_section2_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, input_data5, input_data6 );
					context.setAttribute("fileName", "Validate_Certification_section2_in_l3_HC");
					driver.quit();break;
					
					
					case "Validate_Certification_section3_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_Certification_section3_in_l3_HC");
					Employment.Validate_Certification_section3_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, input_data5, input_data6 );
					context.setAttribute("fileName", "Validate_Certification_section3_in_l3_HC");
					driver.quit();break;
					
					case "Validate_Nomorethan_3sections_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_Nomorethan_3sections_in_l3_HC");
					Employment.Validate_Nomorethan_3sections_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, input_data5, input_data6 );
					context.setAttribute("fileName", "Validate_Nomorethan_3sections_in_l3_HC");
					driver.quit();break;
					
					
					case "Validate_previous_next_step_buttons_in_l3":
						
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l3");
					Employment.Validate_previous_next_step_buttons_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l3");
					driver.quit();break;
					
					
					case "Validate_previous_step_button_in_l3":
						
					context.setAttribute("fileName", "Validate_previous_step_button_in_l3");
					Employment.Validate_previous_step_button_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_previous_step_button_in_l3");
					driver.quit();break;
					
					case "Validate_next_step_button_in_l3":
						
						context.setAttribute("fileName", "Validate_next_step_button_in_l3");
						Employment.Validate_next_step_button_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_next_step_button_in_l3");
						driver.quit();break;
					
						
					case "Validate_emp_his_pre_emp_texts_in_l4":
						
						context.setAttribute("fileName", "Validate_emp_his_pre_emp_texts_in_l4");
						Employment.Validate_emp_his_pre_emp_texts_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_emp_his_pre_emp_texts_in_l4");
						driver.quit();break;
						
					case "Validate_radio_buttons_of_emp_his_in_l4":
						
						context.setAttribute("fileName", "Validate_radio_buttons_of_emp_his_in_l4");
						Employment.Validate_radio_buttons_of_emp_his_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_radio_buttons_of_emp_his_in_l4");
						driver.quit();break;
						
					case "Validate_upload_resume_checkbox_in_l4":
						
						context.setAttribute("fileName", "Validate_upload_resume_checkbox_in_l4");
						Employment.Validate_upload_resume_checkbox_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_upload_resume_checkbox_in_l4");
						driver.quit();break;
						
					case "Validate_upload_resume_section_in_l4":
						
						context.setAttribute("fileName", "Validate_upload_resume_section_in_l4");
						Employment.Validate_upload_resume_section_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, input_data5 );
						context.setAttribute("fileName", "Validate_upload_resume_section_in_l4");
						driver.quit();break;	
						
					case "Validate_upload_resumefile_l4":
						
						context.setAttribute("fileName", "Validate_upload_resumefile_l4");
						Employment.Validate_upload_resumefile_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, input_data5, File_name );
						context.setAttribute("fileName", "Validate_upload_resumefile_l4");
						
						fileName = (String) context.getAttribute("fileName");
						 Takescreenshot(fileName, testdata.get("TestScenario").toString());
	//					try {
	//						File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
	//								testdata.get("TestScenario").toString());
	//						ExtentTestManager.getTest().pass("File upload screenshot",
	//								MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
	//						
	//						} 
	//					catch (Exception e1) {
	//						System.out.println("File not found " + e1);
	//					}
						driver.quit();
						break;
						
					case "Validate_current_previous_emp_texts_in_l4":
						
						context.setAttribute("fileName", "Validate_current_previous_emp_texts_in_l4");
						Employment.Validate_current_previous_emp_texts_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, input_data5 );
						context.setAttribute("fileName", "Validate_current_previous_emp_texts_in_l4");
						driver.quit();break;
						
					case "Validate_all_input_fields_in_l4":
						
						context.setAttribute("fileName", "Validate_all_input_fields_in_l4");
						Employment.Validate_all_input_fields_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_all_input_fields_in_l4");
						driver.quit();break;
						
					case "Validate_all_input_fieldsofAddemployer2_in_l4":
						
						context.setAttribute("fileName", "Validate_all_input_fieldsofAddemployer2_in_l4");
						Employment.Validate_all_input_fieldsofAddemployer2_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_all_input_fieldsofAddemployer2_in_l4");
						driver.quit();break;
						
					case "Validate_all_input_fieldsofAddemployer3_in_l4":
						
						context.setAttribute("fileName", "Validate_all_input_fieldsofAddemployer3_in_l4");
						Employment.Validate_all_input_fieldsofAddemployer3_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_all_input_fieldsofAddemployer3_in_l4");
						driver.quit();break;
						
					case "Validate_enter_values_inallfields_in_l4":
						
						context.setAttribute("fileName", "Validate_enter_values_inallfields_in_l4");
						Employment.Validate_enter_values_inallfields_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button    );
						context.setAttribute("fileName", "Validate_enter_values_inallfields_in_l4");
						driver.quit();break;
						
					case "Validate_enter_values_inallfields_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_enter_values_inallfields_in_l4_HC");
					Employment.Validate_enter_values_inallfields_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button  );
					context.setAttribute("fileName", "Validate_enter_values_inallfields_in_l4_HC");
					driver.quit();break;
					
					
					case "Validate_ip_inallfields_in_l33_corp":
						
						context.setAttribute("fileName", "Validate_ip_inallfields_in_l33_corp");
						Employment.Validate_ip_inallfields_in_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button);
						context.setAttribute("fileName", "Validate_ip_inallfields_in_l33_corp");
						driver.quit();break;
					
						
					case "Validate_removebtn2_by_inputtingempr2_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_removebtn2_by_inputtingempr2_in_l4_HC");
					Employment.Validate_removebtn2_by_inputtingempr2_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button  );
					context.setAttribute("fileName", "Validate_removebtn2_by_inputtingempr2_in_l4_HC");
					driver.quit();break;
					
					case "Validate_removebtn2_by_inputtingempr2_in_l4":
						
						context.setAttribute("fileName", "Validate_removebtn2_by_inputtingempr2_in_l4");
						Employment.Validate_removebtn2_by_inputtingempr2_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button    );
						context.setAttribute("fileName", "Validate_removebtn2_by_inputtingempr2_in_l4");
						driver.quit();break;
						
					case "Validate_previous_next_step_buttons_in_l4":
						
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l4");
						Employment.Validate_previous_next_step_buttons_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l4");
						driver.quit();break;
						
						
					case "Validate_prev_next_step_btns_l33_corp":
						
						context.setAttribute("fileName", "Validate_prev_next_step_btns_l33_corp");
						Employment.Validate_prev_next_step_btns_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_prev_next_step_btns_l33_corp");
						driver.quit();break;
						
						
					case "Validate_add_emply_2_button_in_l4":
						
						context.setAttribute("fileName", "Validate_add_emply_2_button_in_l4");
						Employment.Validate_add_emply_2_button_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_add_emply_2_button_in_l4");
						driver.quit();break;
						
					case "Validate_add_emply_2_btn_l33_corp":
						
						context.setAttribute("fileName", "Validate_add_emply_2_btn_l33_corp");
						Employment.Validate_add_emply_2_btn_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_add_emply_2_btn_l33_corp");
						driver.quit();break;
						
						
					case "Validate_all_ip_fieldsofAddemplr2_l33_corp":
						
						context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr2_l33_corp");
						Employment.Validate_all_ip_fieldsofAddemplr2_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr2_l33_corp");
						driver.quit();break;
						
						
					case "Validate_all_ip_fieldsofAddemplr3_l33_corp":
						
						context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr3_l33_corp");
						Employment.Validate_all_ip_fieldsofAddemplr3_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr3_l33_corp");
						driver.quit();break;
						
						
					case "Validate_Next_btn_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_Next_btn_in_l4_HC");
					Employment.Validate_Next_btn_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box );
					context.setAttribute("fileName", "Validate_Next_btn_in_l4_HC");
					driver.quit();break;
					
					
					case "Validate_Next_btn_l33_corp":
						
						context.setAttribute("fileName", "Validate_Next_btn_l33_corp");
						Employment.Validate_Next_btn_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
						context.setAttribute("fileName", "Validate_Next_btn_l33_corp");
						driver.quit();break;
					
					case "Validate_No_Prev_Emp_RdoBtn_l33_corp":
						
						context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_l33_corp");
						Employment.Validate_No_Prev_Emp_RdoBtn_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_l33_corp");
						driver.quit();break;
						
					
					case "Validate_previous_step_btn_l33_corp":
						
						context.setAttribute("fileName", "Validate_previous_step_btn_l33_corp");
						Employment.Validate_previous_step_btn_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_previous_step_btn_l33_corp");
						driver.quit();break;
						
						
					case "Validate_removebtn2_by_ipingemplr2_l33_corp":
						
						context.setAttribute("fileName", "Validate_removebtn2_by_ipingemplr2_l33_corp");
						Employment.Validate_removebtn2_by_ipingemplr2_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown,  Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button);
						context.setAttribute("fileName", "Validate_removebtn2_by_ipingemplr2_l33_corp");
						driver.quit();break;
						
						
					case "Validate_Indicate_languages_text_l5_HC":
						
					context.setAttribute("fileName", "Validate_Indicate_languages_text_l5_HC");
					Employment.Validate_Indicate_languages_text_l5_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,input_data5, No_Prev_emp_chk_box );
					context.setAttribute("fileName", "Validate_Indicate_languages_text_l5_HC");
					driver.quit();break;
					
					
					case "Validate_langs_subheading_l44_corp":
						
						context.setAttribute("fileName", "Validate_langs_subheading_l44_corp");
						Employment.Validate_langs_subheading_l44_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, input_data5);
						context.setAttribute("fileName", "Validate_langs_subheading_l44_corp");
						driver.quit();break;
					
					case "Validate_all_languages_in_l5_HC":
						
					context.setAttribute("fileName", "Validate_all_languages_in_l5_HC");
					Employment.Validate_all_languages_in_l5_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,input_data5, No_Prev_emp_chk_box, Languages );
					context.setAttribute("fileName", "Validate_all_languages_in_l5_HC");
					driver.quit();break;
					
					
					case "Validate_all_langs_l44_corp":
						
						context.setAttribute("fileName", "Validate_all_langs_l44_corp");
						Employment.Validate_all_langs_l44_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
						context.setAttribute("fileName", "Validate_all_langs_l44_corp");
						driver.quit();break;
					
					
					case "Validate_bydefault_Eng_lang_issltd_in_l5_HC":
						
					context.setAttribute("fileName", "Validate_bydefault_Eng_lang_issltd_in_l5_HC");
					Employment.Validate_bydefault_Eng_lang_issltd_in_l5_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,input_data5, No_Prev_emp_chk_box, Languages );
					context.setAttribute("fileName", "Validate_bydefault_Eng_lang_issltd_in_l5_HC");
					driver.quit();break;
					
					
					case "Validate_autoselected_Eng_lang_l44_corp":
						
						context.setAttribute("fileName", "Validate_autoselected_Eng_lang_l44_corp");
						Employment.Validate_autoselected_Eng_lang_l44_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
						context.setAttribute("fileName", "Validate_autoselected_Eng_lang_l44_corp");
						driver.quit();break;
					
					
					case "Validate_select_desired_languages_in_l5_HC":
						
					context.setAttribute("fileName", "Validate_select_desired_languages_in_l5_HC");
					Employment.Validate_select_desired_languages_in_l5_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,input_data5, No_Prev_emp_chk_box, Languages );
					context.setAttribute("fileName", "Validate_select_desired_languages_in_l5_HC");
					driver.quit();break;
					
					
					
					case "Validate_select_desired_langs_l44_corp":
						
						context.setAttribute("fileName", "Validate_select_desired_langs_l44_corp");
						Employment.Validate_select_desired_langs_l44_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Languages);
						context.setAttribute("fileName", "Validate_select_desired_langs_l44_corp");
						driver.quit();break;
					
					
					case "Validate_previous_next_step_buttons_in_l5_HC":
						
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l5_HC");
					Employment.Validate_previous_next_step_buttons_in_l5_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,input_data5, No_Prev_emp_chk_box );
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l5_HC");
					driver.quit();break;
					
					
					
					case "Validate_prev_next_step_btns_l44_corp":
						
						context.setAttribute("fileName", "Validate_prev_next_step_btns_l44_corp");
						Employment.Validate_prev_next_step_btns_l44_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
						context.setAttribute("fileName", "Validate_prev_next_step_btns_l44_corp");
						driver.quit();break;
					
					
					case "Validate_previous_step_button_in_l5_HC":
						
					context.setAttribute("fileName", "Validate_previous_step_button_in_l5_HC");
					Employment.Validate_previous_step_button_in_l5_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,input_data5, No_Prev_emp_chk_box );
					context.setAttribute("fileName", "Validate_previous_step_button_in_l5_HC");
					driver.quit();break;
					
					
					
					case "Validate_prev_step_btn_l44_corp":
						
						context.setAttribute("fileName", "Validate_prev_step_btn_l44_corp");
						Employment.Validate_prev_step_btn_l44_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
						context.setAttribute("fileName", "Validate_prev_step_btn_l44_corp");
						driver.quit();break;
					
					
					case "Validate_Next_step_button_in_l5_HC":
						
					context.setAttribute("fileName", "Validate_Next_step_button_in_l5_HC");
					Employment.Validate_Next_step_button_in_l5_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box );
					context.setAttribute("fileName", "Validate_Next_step_button_in_l5_HC");
					driver.quit();break;
					
					
					case "Validate_Next_step_btn_l44_corp":
						
						context.setAttribute("fileName", "Validate_Next_step_btn_l44_corp");
						Employment.Validate_Next_step_btn_l44_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
						context.setAttribute("fileName", "Validate_Next_step_btn_l44_corp");
						driver.quit();break;
					
					
					case "Validate_text_COqualify_in_l6_HC":
						
					context.setAttribute("fileName", "Validate_text_COqualify_in_l6_HC");
					Employment.Validate_text_COqualify_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box, input_data5 );
					context.setAttribute("fileName", "Validate_text_COqualify_in_l6_HC");
					driver.quit();break;
					
					
					case "Validate_text_COqualify_l56_corp":
						
						context.setAttribute("fileName", "Validate_text_COqualify_l56_corp");
						Employment.Validate_text_COqualify_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, input_data5);
						context.setAttribute("fileName", "Validate_text_COqualify_l56_corp");
						driver.quit();break;
					
					
					case "Validate_all_fields_in_l6_HC":
						
						context.setAttribute("fileName", "Validate_all_fields_in_l6_HC");
						Employment.Validate_all_fields_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box );
						context.setAttribute("fileName", "Validate_all_fields_in_l6_HC");
						driver.quit();break;
						
						
					case "Validate_all_fields_l56_corp":
						
						context.setAttribute("fileName", "Validate_all_fields_l56_corp");
						Employment.Validate_all_fields_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Considered_for_chkbx);
						context.setAttribute("fileName", "Validate_all_fields_l56_corp");
						driver.quit();break;
					
						
						
					case "Validate_select_Worktime_interest_in_l6_HC":
						
					context.setAttribute("fileName", "Validate_select_Worktime_interest_in_l6_HC");
					Employment.Validate_select_Worktime_interest_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box , Work_time);
					context.setAttribute("fileName", "Validate_select_Worktime_interest_in_l6_HC");
					driver.quit();break;
					
					
			case "Validate_slt_Worktime_interest_l56_corp":
						
						context.setAttribute("fileName", "Validate_slt_Worktime_interest_l56_corp");
						Employment.Validate_slt_Worktime_interest_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Work_time);
						context.setAttribute("fileName", "Validate_slt_Worktime_interest_l56_corp");
						driver.quit();break;
					
					
					
					case "Validate_Considerfor_chkbox_in_l6_HC":
						
						context.setAttribute("fileName", "Validate_Considerfor_chkbox_in_l6_HC");
						Employment.Validate_Considerfor_chkbox_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box , input_data5);
						context.setAttribute("fileName", "Validate_Considerfor_chkbox_in_l6_HC");
						driver.quit();break;
						
						
					case "Validate_slt_desired_considerforchkbxs_l56_corp":
						
						context.setAttribute("fileName", "Validate_slt_desired_considerforchkbxs_l56_corp");
						Employment.Validate_slt_desired_considerforchkbxs_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Considered_for_chkbx);
						context.setAttribute("fileName", "Validate_slt_desired_considerforchkbxs_l56_corp");
						driver.quit();break;
						
						
						
					case "Validate_COs_asperCFchkbxsltn_l56_corp":
						
						context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l56_corp");
						Employment.Validate_COs_asperCFchkbxsltn_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Considered_for_chkbx);
						context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l56_corp");
						driver.quit();break;
						
						
						
					case "Validate_defaultvalueofCO_l56_corp":
						
						context.setAttribute("fileName", "Validate_defaultvalueofCO_l56_corp");
						Employment.Validate_defaultvalueofCO_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
						context.setAttribute("fileName", "Validate_defaultvalueofCO_l56_corp");
						driver.quit();break;
						
						
					case "Validate_input_date_to_begin_in_l6_HC":
						
						context.setAttribute("fileName", "Validate_input_date_to_begin_in_l6_HC");
						Employment.Validate_input_date_to_begin_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box , Date_to_begin);
						context.setAttribute("fileName", "Validate_input_date_to_begin_in_l6_HC");
						driver.quit();break;
						
						
					case "Validate_ip_date_to_begin_l56_corp":
						
						context.setAttribute("fileName", "Validate_ip_date_to_begin_l56_corp");
						Employment.Validate_ip_date_to_begin_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, Date_to_begin);
						context.setAttribute("fileName", "Validate_ip_date_to_begin_l56_corp");
						driver.quit();break;
						
						
					case "Validate_employedwithus_no_rdobtn_in_l6_HC":
						
						context.setAttribute("fileName", "Validate_employedwithus_no_rdobtn_in_l6_HC");
						Employment.Validate_employedwithus_no_rdobtn_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box , input_data5);
						context.setAttribute("fileName", "Validate_employedwithus_no_rdobtn_in_l6_HC");
						driver.quit();break;
						
						
						
					case "Validate_empdwithus_no_rdobtn_l56_corp":
						
						context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l56_corp");
						Employment.Validate_empdwithus_no_rdobtn_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, input_data5);
						context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l56_corp");
						driver.quit();break;
						
						
					case "Validate_basedonselections_text_in_l6_HC":
						
						context.setAttribute("fileName", "Validate_basedonselections_text_in_l6_HC");
						Employment.Validate_basedonselections_text_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box , input_data5);
						context.setAttribute("fileName", "Validate_basedonselections_text_in_l6_HC");
						driver.quit();break;
						
						
					case "Validate_basedonsltns_text_l56_corp":
						
						context.setAttribute("fileName", "Validate_basedonsltns_text_l56_corp");
						Employment.Validate_basedonsltns_text_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, input_data5);
						context.setAttribute("fileName", "Validate_basedonsltns_text_l56_corp");
						driver.quit();break;
						
						
					case "Validate_Club_locations_in_l6_HC":
						
						context.setAttribute("fileName", "Validate_Club_locations_in_l6_HC");
						Employment.Validate_Club_locations_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box , input_data5);
						context.setAttribute("fileName", "Validate_Club_locations_in_l6_HC");
						driver.quit();break;
						
						
					case "Validate_Club_locations_l56_corp":
						
						context.setAttribute("fileName", "Validate_Club_locations_l56_corp");
						Employment.Validate_Club_locations_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, input_data5);
						context.setAttribute("fileName", "Validate_Club_locations_l56_corp");
						driver.quit();break;
						
						
					case "Validate_Career_Opportunities_in_l6_HC":
						
						context.setAttribute("fileName", "Validate_Career_Opportunities_in_l6_HC");
						Employment.Validate_Career_Opportunities_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box , input_data5);
						context.setAttribute("fileName", "Validate_Career_Opportunities_in_l6_HC");
						driver.quit();break;
						
						
						
					case "Validate_Rehire_Questionnaire_sec_l56_corp":
						
						context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l56_corp");
						Employment.Validate_Rehire_Questionnaire_sec_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, input_data5);
						context.setAttribute("fileName", "Validate_Rehire_Questionnaire_sec_l56_corp");
						driver.quit();break;
						
						
					case "Validate_Rehire_Questionnaire_section_in_l6_HC":
						
						context.setAttribute("fileName", "Validate_Rehire_Questionnaire_section_in_l6_HC");
						Employment.Validate_Rehire_Questionnaire_section_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box , input_data5);
						context.setAttribute("fileName", "Validate_Rehire_Questionnaire_section_in_l6_HC");
						driver.quit();break;
						
						
					case "Validate_EmptHowResigned_dd_allvalues_in_l6_HC":
						
						context.setAttribute("fileName", "Validate_EmptHowResigned_dd_allvalues_in_l6_HC");
						Employment.Validate_EmptHowResigned_dd_allvalues_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box , EmploymentHowResigned_dd);
						context.setAttribute("fileName", "Validate_EmptHowResigned_dd_allvalues_in_l6_HC");
						driver.quit();break;
						
					case "Validate_Resigned_dd_allvalues_l56_corp":
						
						context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l56_corp");
						Employment.Validate_Resigned_dd_allvalues_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, EmploymentHowResigned_dd);
						context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l56_corp");
						driver.quit();break;
						
						
					case "Validate_previous_next_step_buttons_in_l6_HC":
						
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l6_HC");
					Employment.Validate_previous_next_step_buttons_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box );
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l6_HC");
					driver.quit();break;
						
					
					case "Validate_prev_next_step_btns_l56_corp":
						
						context.setAttribute("fileName", "Validate_prev_next_step_btns_l56_corp");
						Employment.Validate_prev_next_step_btns_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
						context.setAttribute("fileName", "Validate_prev_next_step_btns_l56_corp");
						driver.quit();break;
			
					
					
					case "Validate_previous_step_button_in_l6_HC":
						
					context.setAttribute("fileName", "Validate_previous_step_button_in_l6_HC");
					Employment.Validate_previous_step_button_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box );
					context.setAttribute("fileName", "Validate_previous_step_button_in_l6_HC");
					driver.quit();break;
					
					
					
					case "Validate_previous_step_btn_l56_corp":
						
						context.setAttribute("fileName", "Validate_previous_step_btn_l56_corp");
						Employment.Validate_previous_step_btn_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box);
						context.setAttribute("fileName", "Validate_previous_step_btn_l56_corp");
						driver.quit();break;
					
					case "Validate_next_btn_by_filling_all_fields_in_l6_HC":
						
					context.setAttribute("fileName", "Validate_next_btn_by_filling_all_fields_in_l6_HC");
					Employment.Validate_next_btn_by_filling_all_fields_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip   );
					context.setAttribute("fileName", "Validate_next_btn_by_filling_all_fields_in_l6_HC");
					driver.quit();break;
					
					
					case "Validate_next_btn_by_ip_all_fields_l56_corp":
						
						context.setAttribute("fileName", "Validate_next_btn_by_ip_all_fields_l56_corp");
						Employment.Validate_next_btn_by_ip_all_fields_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
						context.setAttribute("fileName", "Validate_next_btn_by_ip_all_fields_l56_corp");
						driver.quit();break;
					
					
					case "Validate_experience_details_texts_in_l3":
						
					context.setAttribute("fileName", "Validate_experience_details_texts_in_l3");
					Employment.Validate_experience_details_texts_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values, Aerobics_Instructor_Exp_DD, input_data5 );
					context.setAttribute("fileName", "Validate_experience_details_texts_in_l3");
					driver.quit();break;
						
					case "Validate_add_employer_btn_in_l3":
						
					context.setAttribute("fileName", "Validate_add_employer_btn_in_l3");
					Employment.Validate_add_employer_btn_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values, Aerobics_Instructor_Exp_DD );
					context.setAttribute("fileName", "Validate_add_employer_btn_in_l3");
					driver.quit();break;
					
					case "Validate_TimeP_ClubE_ClassesW_elements_in_l3":
						
					context.setAttribute("fileName", "Validate_TimeP_ClubE_ClassesW_elements_in_l3");
					Employment.Validate_TimeP_ClubE_ClassesW_elements_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values, Aerobics_Instructor_Exp_DD );
					context.setAttribute("fileName", "Validate_TimeP_ClubE_ClassesW_elements_in_l3");
					driver.quit();break;
					
					case "Validate_Addemployer_section2_allelements_in_l3":
						
					context.setAttribute("fileName", "Validate_Addemployer_section2_allelements_in_l3");
					Employment.Validate_Addemployer_section2_allelements_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values, Aerobics_Instructor_Exp_DD, input_data5,Checkbox_class_formats  );
					context.setAttribute("fileName", "Validate_Addemployer_section2_allelements_in_l3");
					driver.quit();break;
					
					case "Validate_Addemployer_section3_allelements_in_l3":
						
					context.setAttribute("fileName", "Validate_Addemployer_section3_allelements_in_l3");
					Employment.Validate_Addemployer_section3_allelements_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values, Aerobics_Instructor_Exp_DD, input_data5,Checkbox_class_formats  );
					context.setAttribute("fileName", "Validate_Addemployer_section3_allelements_in_l3");
					driver.quit();break;
					
					case "Validate_alert_nomorethan3_Employers_in_l3":
						
					context.setAttribute("fileName", "Validate_alert_nomorethan3_Employers_in_l3");
					Employment.Validate_alert_nomorethan3_Employers_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values, Aerobics_Instructor_Exp_DD, input_data5,Checkbox_class_formats  );
					context.setAttribute("fileName", "Validate_alert_nomorethan3_Employers_in_l3");
					driver.quit();break;
					
					case "Validate_class_formats_checkboxes_in_l3":
						
					context.setAttribute("fileName", "Validate_class_formats_checkboxes_in_l3");
					Employment.Validate_class_formats_checkboxes_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values, Aerobics_Instructor_Exp_DD, input_data5,Checkbox_class_formats  );
					context.setAttribute("fileName", "Validate_class_formats_checkboxes_in_l3");
					driver.quit();break;
					
					case "Validate_Time_period_dropdown_all_values_in_l3":
						
					context.setAttribute("fileName", "Validate_Time_period_dropdown_all_values_in_l3");
					Employment.Validate_Time_period_dropdown_all_values_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values, Aerobics_Instructor_Exp_DD, Time_period_DD  );
					context.setAttribute("fileName", "Validate_Time_period_dropdown_all_values_in_l3");
					driver.quit();break;
					
					case "Validate_Club_employer_dropdown_all_values_in_l3":
						
					context.setAttribute("fileName", "Validate_Club_employer_dropdown_all_values_in_l3");
					Employment.Validate_Club_employer_dropdown_all_values_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values, Aerobics_Instructor_Exp_DD, Club_Employer_DD  );
					context.setAttribute("fileName", "Validate_Club_employer_dropdown_all_values_in_l3");
					driver.quit();break;
					
					case "Validate_classperweek_enter_value_in_l3":
						
					context.setAttribute("fileName", "Validate_classperweek_enter_value_in_l3");
					Employment.Validate_classperweek_enter_value_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values, Aerobics_Instructor_Exp_DD, Class_per_week  );
					context.setAttribute("fileName", "Validate_classperweek_enter_value_in_l3");
					driver.quit();break;
					
					case "Validate_select_classformats_checkboxes_in_l3":
						
					context.setAttribute("fileName", "Validate_select_classformats_checkboxes_in_l3");
					Employment.Validate_select_classformats_checkboxes_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values, Aerobics_Instructor_Exp_DD,Checkbox_class_formats  );
					context.setAttribute("fileName", "Validate_select_classformats_checkboxes_in_l3");
					driver.quit();break;
					
					case "Validate_Aerobic_cert_texts_in_l3":
						
					context.setAttribute("fileName", "Validate_Aerobic_cert_texts_in_l3");
					Employment.Validate_Aerobic_cert_texts_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button, input_data5 );
					context.setAttribute("fileName", "Validate_Aerobic_cert_texts_in_l3");
					driver.quit();break;
					
					
					case "Validate_Add_cert_btn_in_l3":
						
					context.setAttribute("fileName", "Validate_Add_cert_btn_in_l3");
					Employment.Validate_Add_cert_btn_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_Add_cert_btn_in_l3");
					driver.quit();break;
					
					case "Validate_Aerobic_cert_all_fields_in_l3":
						
					context.setAttribute("fileName", "Validate_Aerobic_cert_all_fields_in_l3");
					Employment.Validate_Aerobic_cert_all_fields_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_Aerobic_cert_all_fields_in_l3");
					driver.quit();break;
					
					case "Validate_Aerobic_cert2_all_fields_in_l3":
						
					context.setAttribute("fileName", "Validate_Aerobic_cert2_all_fields_in_l3");
					Employment.Validate_Aerobic_cert2_all_fields_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_Aerobic_cert2_all_fields_in_l3");
					driver.quit();break;
					
					case "Validate_Aerobic_cert3_all_fields_in_l3":
						
					context.setAttribute("fileName", "Validate_Aerobic_cert3_all_fields_in_l3");
					Employment.Validate_Aerobic_cert3_all_fields_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_Aerobic_cert3_all_fields_in_l3");
					driver.quit();break;
					
					case "Validate_Aerobic_cert4_all_fields_in_l3":
						
					context.setAttribute("fileName", "Validate_Aerobic_cert4_all_fields_in_l3");
					Employment.Validate_Aerobic_cert4_all_fields_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_Aerobic_cert4_all_fields_in_l3");
					driver.quit();break;
					
					
					case "Validate_alert_no_more_than_4_cert_in_l3":
						
					context.setAttribute("fileName", "Validate_alert_no_more_than_4_cert_in_l3");
					Employment.Validate_alert_no_more_than_4_cert_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_alert_no_more_than_4_cert_in_l3");
					driver.quit();break;
					
					
					case "Validate_Choosefile_and_cert_format_txt_in_l3":
						
					context.setAttribute("fileName", "Validate_Choosefile_and_cert_format_txt_in_l3");
					Employment.Validate_Choosefile_and_cert_format_txt_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button, input_data5 );
					context.setAttribute("fileName", "Validate_Choosefile_and_cert_format_txt_in_l3");
					driver.quit();break;
					
					
					case "Validate_add_emplr_remove_img_btn_in_l3":
						
					context.setAttribute("fileName", "Validate_add_emplr_remove_img_btn_in_l3");
					Employment.Validate_add_emplr_remove_img_btn_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Dropdown_values, Aerobics_Instructor_Exp_DD, input_data5  );
					context.setAttribute("fileName", "Validate_add_emplr_remove_img_btn_in_l3");
					driver.quit();break;
					
					case "Validate_Aero_cert_remove_img_btn_in_l3":
						
					context.setAttribute("fileName", "Validate_Aero_cert_remove_img_btn_in_l3");
					Employment.Validate_Aero_cert_remove_img_btn_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button, input_data5 );
					context.setAttribute("fileName", "Validate_Aero_cert_remove_img_btn_in_l3");
					driver.quit();break;
					
					
					case "Validate_upload_cert_file_in_l3":
						
					context.setAttribute("fileName", "Validate_upload_cert_file_in_l3");
					Employment.Validate_upload_cert_file_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button, input_data5, File_name );
					context.setAttribute("fileName", "Validate_upload_cert_file_in_l3");
					
					 fileName = (String) context.getAttribute("fileName");
					 Takescreenshot(fileName, testdata.get("TestScenario").toString());
					
					driver.quit();
					break;
					
					
					case "Validate_CertifiedIn_dropdown_all_values_in_l3":
						
					context.setAttribute("fileName", "Validate_CertifiedIn_dropdown_all_values_in_l3");
					Employment.Validate_CertifiedIn_dropdown_all_values_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button, Certified_In_DD );
					context.setAttribute("fileName", "Validate_CertifiedIn_dropdown_all_values_in_l3");
					driver.quit();break;
					
					case "Validate_CertifiedIn_select_desiredvalue_in_l3":
						
					context.setAttribute("fileName", "Validate_CertifiedIn_select_desiredvalue_in_l3");
					Employment.Validate_CertifiedIn_select_desiredvalue_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button, Certified_In_DD );
					context.setAttribute("fileName", "Validate_CertifiedIn_select_desiredvalue_in_l3");
					driver.quit();break;
					
					case "Validate_IssuedBy_DD_enabled_in_l3":
						
					context.setAttribute("fileName", "Validate_IssuedBy_DD_enabled_in_l3");
					Employment.Validate_IssuedBy_DD_enabled_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button, Certified_In_DD );
					context.setAttribute("fileName", "Validate_IssuedBy_DD_enabled_in_l3");
					driver.quit();break;
					
					case "Validate_IssuedBy_DD_disabled_in_l3":
						
					context.setAttribute("fileName", "Validate_IssuedBy_DD_disabled_in_l3");
					Employment.Validate_IssuedBy_DD_disabled_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button, Certified_In_DD );
					context.setAttribute("fileName", "Validate_IssuedBy_DD_disabled_in_l3");
					driver.quit();break;
					
					
					
					case "Validate_Input_in_Cert_no_in_l3":
						
					context.setAttribute("fileName", "Validate_Input_in_Cert_no_in_l3");
					Employment.Validate_Input_in_Cert_no_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button, Certificate_No );
					context.setAttribute("fileName", "Validate_Input_in_Cert_no_in_l3");
					driver.quit();break;
					
					
					case "Validate_IssuedBy_dropdown_all_values_in_l3":
						
					context.setAttribute("fileName", "Validate_IssuedBy_dropdown_all_values_in_l3");
					Employment.Validate_IssuedBy_dropdown_all_values_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues );
					context.setAttribute("fileName", "Validate_IssuedBy_dropdown_all_values_in_l3");
					driver.quit();break;
					
					
					case "Validate_IssuedBy_dropdown_all_values_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_IssuedBy_dropdown_all_values_in_l3_HC");
					Employment.Validate_IssuedBy_dropdown_all_values_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Certification_IssuedByDPValues );
					context.setAttribute("fileName", "Validate_IssuedBy_dropdown_all_values_in_l3_HC");
					driver.quit();break;
					
					
					case "Validate_Upload_certificate_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_Upload_certificate_in_l3_HC");
					Employment.Validate_Upload_certificate_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, File_name );
					context.setAttribute("fileName", "Validate_Upload_certificate_in_l3_HC");
					driver.quit();break;
					
					case "Validate_Input_in_Cert_no_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_Input_in_Cert_no_in_l3_HC");
					Employment.Validate_Input_in_Cert_no_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Certificate_No );
					context.setAttribute("fileName", "Validate_Input_in_Cert_no_in_l3_HC");
					driver.quit();break;
					
					case "Validate_previous_next_step_buttons_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l3_HC");
					Employment.Validate_previous_next_step_buttons_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l3_HC");
					driver.quit();break;
					
					case "Validate_Fill_all_fields_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_Fill_all_fields_in_l3_HC");
					Employment.Validate_Fill_all_fields_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name , Hold_cert_GT_AC_ratio_button);
					context.setAttribute("fileName", "Validate_Fill_all_fields_in_l3_HC");
					driver.quit();break;
					
					case "Validate_previous_step_button_in_l3_HC":
					
					context.setAttribute("fileName", "Validate_previous_step_button_in_l3_HC");
					Employment.Validate_previous_step_button_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_previous_step_button_in_l3_HC");
					driver.quit();break;
					
					case "Validate_cert_remove_button1_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_cert_remove_button1_in_l3_HC");
					Employment.Validate_cert_remove_button1_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_cert_remove_button1_in_l3_HC");
					driver.quit();break;
					
					case "Validate_Nextstep_No_rdobtnselected_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_Nextstep_No_rdobtnselected_in_l3_HC");
					Employment.Validate_Nextstep_No_rdobtnselected_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_Nextstep_No_rdobtnselected_in_l3_HC");
					driver.quit();break;
					
					
					case "Validate_Next_step_button_in_l3_HC":
						
					context.setAttribute("fileName", "Validate_Next_step_button_in_l3_HC");
					Employment.Validate_Next_step_button_in_l3_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_Next_step_button_in_l3_HC");
					driver.quit();break;
					
					
					case "Validate_add_emply_2_button_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_add_emply_2_button_in_l4_HC");
					Employment.Validate_add_emply_2_button_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_add_emply_2_button_in_l4_HC");
					driver.quit();break;
					
					case "Validate_previous_step_button_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_previous_step_button_in_l4_HC");
					Employment.Validate_previous_step_button_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_previous_step_button_in_l4_HC");
					driver.quit();break;
					
					case "Validate_emp_his_pre_emp_texts_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_emp_his_pre_emp_texts_in_l4_HC");
					Employment.Validate_emp_his_pre_emp_texts_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_emp_his_pre_emp_texts_in_l4_HC");
					driver.quit();break;
					
					
					case "Validate_headings_texts_in_l33_corp":
						
						context.setAttribute("fileName", "Validate_headings_texts_in_l33_corp");
						Employment.Validate_headings_texts_in_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown  );
						context.setAttribute("fileName", "Validate_headings_texts_in_l33_corp");
						driver.quit();break;
					
					
					case "Validate_radio_buttons_of_emp_his_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_radio_buttons_of_emp_his_in_l4_HC");
					Employment.Validate_radio_buttons_of_emp_his_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_radio_buttons_of_emp_his_in_l4_HC");
					driver.quit();break;
					
					case "Validate_No_Prev_Emp_RdoBtn_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_in_l4_HC");
					Employment.Validate_No_Prev_Emp_RdoBtn_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_in_l4_HC");
					driver.quit();break;
					
					
					case "Validate_rdo_btns_of_emp_his_in_l33_corp":
						
						context.setAttribute("fileName", "Validate_rdo_btns_of_emp_his_in_l33_corp");
						Employment.Validate_rdo_btns_of_emp_his_in_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown  );
						context.setAttribute("fileName", "Validate_rdo_btns_of_emp_his_in_l33_corp");
						driver.quit();break;
					
					
					case "Validate_upload_resume_checkbox_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_upload_resume_checkbox_in_l4_HC");
					Employment.Validate_upload_resume_checkbox_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_upload_resume_checkbox_in_l4_HC");
					driver.quit();break;
					
					case "Validate_upload_resume_chkbx_in_l33_corp":
						
						context.setAttribute("fileName", "Validate_upload_resume_chkbx_in_l33_corp");
						Employment.Validate_upload_resume_chkbx_in_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown  );
						context.setAttribute("fileName", "Validate_upload_resume_chkbx_in_l33_corp");
						driver.quit();break;
					
					
					case "Validate_upload_resume_section_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_upload_resume_section_in_l4_HC");
					Employment.Validate_upload_resume_section_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button, input_data5 );
					context.setAttribute("fileName", "Validate_upload_resume_section_in_l4_HC");
					driver.quit();break;
					
					
					case "Validate_upload_resumefile_l4_HC":
						
					context.setAttribute("fileName", "Validate_upload_resumefile_l4_HC");
					Employment.Validate_upload_resumefile_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button, input_data5 );
					context.setAttribute("fileName", "Validate_upload_resumefile_l4_HC");
					driver.quit();break;
					
					
					case "Validate_upload_resume_l33_corp":
						
						context.setAttribute("fileName", "Validate_upload_resume_l33_corp");
						Employment.Validate_upload_resume_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , input_data5 , File_name);
						context.setAttribute("fileName", "Validate_upload_resume_l33_corp");
						driver.quit();break;
					
					
					case "Validate_upload_resume_sec_l33_corp":
						
						context.setAttribute("fileName", "Validate_upload_resume_sec_l33_corp");
						Employment.Validate_upload_resume_sec_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , input_data5 );
						context.setAttribute("fileName", "Validate_upload_resume_sec_l33_corp");
						driver.quit();break;
					
					
					case "Validate_current_previous_emp_texts_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_current_previous_emp_texts_in_l4_HC");
					Employment.Validate_current_previous_emp_texts_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button, input_data5 );
					context.setAttribute("fileName", "Validate_current_previous_emp_texts_in_l4_HC");
					driver.quit();break;
					
					case "Validate_cur_prev_emp_texts_l33_corp":
						
						context.setAttribute("fileName", "Validate_cur_prev_emp_texts_l33_corp");
						Employment.Validate_cur_prev_emp_texts_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , input_data5 );
						context.setAttribute("fileName", "Validate_cur_prev_emp_texts_l33_corp");
						driver.quit();break;
					
					
					case "Validate_all_input_fields_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_all_input_fields_in_l4_HC");
					Employment.Validate_all_input_fields_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_all_input_fields_in_l4_HC");
					driver.quit();break;
					
					
					case "Validate_all_ip_fields_l33_corp":
						
						context.setAttribute("fileName", "Validate_all_ip_fields_l33_corp");
						Employment.Validate_all_ip_fields_l33_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_all_ip_fields_l33_corp");
						driver.quit();break;
					
					
					case "Validate_all_input_fieldsofAddemployer2_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_all_input_fieldsofAddemployer2_in_l4_HC");
					Employment.Validate_all_input_fieldsofAddemployer2_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_all_input_fieldsofAddemployer2_in_l4_HC");
					driver.quit();break;
					
					
					case "Validate_all_input_fieldsofAddemployer3_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_all_input_fieldsofAddemployer3_in_l4_HC");
					Employment.Validate_all_input_fieldsofAddemployer3_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_all_input_fieldsofAddemployer3_in_l4_HC");
					driver.quit();break;
					
					case "Validate_previous_next_step_buttons_in_l4_HC":
						
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l4_HC");
					Employment.Validate_previous_next_step_buttons_in_l4_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button );
					context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l4_HC");
					driver.quit();break;
					
					case "Validate_filling_all_fields_in_l3":
						
					context.setAttribute("fileName", "Validate_filling_all_fields_in_l3");
					Employment.Validate_filling_all_fields_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name  );
					context.setAttribute("fileName", "Validate_filling_all_fields_in_l3");
					driver.quit();break;
					
					case "Validate_removebtn_by_inputtingaddemployer_in_l3":
						
					context.setAttribute("fileName", "Validate_removebtn_by_inputtingaddemployer_in_l3");
					Employment.Validate_removebtn_by_inputtingaddemployer_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats  );
					context.setAttribute("fileName", "Validate_removebtn_by_inputtingaddemployer_in_l3");
					driver.quit();break;
					
					case "Validate_removebtn_by_inputtingincert_sec_in_l3":
						
					context.setAttribute("fileName", "Validate_removebtn_by_inputtingincert_sec_in_l3");
					Employment.Validate_removebtn_by_inputtingincert_sec_in_l3(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data5  );
					context.setAttribute("fileName", "Validate_removebtn_by_inputtingincert_sec_in_l3");
					driver.quit();break;
					
					
					case "Validate_Next_btn_in_l4":
						
						context.setAttribute("fileName", "Validate_Next_btn_in_l4");
						Employment.Validate_Next_btn_in_l4_and_nav_to_l5(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button    );
						context.setAttribute("fileName", "Validate_Next_btn_in_l4");
						driver.quit();break;
					
					case "Validate_No_Previous_Employment_RdoBtn_in_l4":
						
						context.setAttribute("fileName", "Validate_No_Previous_Employment_RdoBtn_in_l4");
						Employment.Validate_No_Previous_Employment_RdoBtn_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_No_Previous_Employment_RdoBtn_in_l4");
						driver.quit();break;
						
					case "Validate_previous_step_buttons_in_l4":
						
						context.setAttribute("fileName", "Validate_previous_step_buttons_in_l4");
						Employment.Validate_previous_step_buttons_in_l4(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown );
						context.setAttribute("fileName", "Validate_previous_step_buttons_in_l4");
						driver.quit();break;
						
						
					case "Validate_Indicate_languages_text_l5":
						
						context.setAttribute("fileName", "Validate_Indicate_languages_text_l5");
						Employment.Validate_Indicate_languages_text_l5(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, input_data5   );
						context.setAttribute("fileName", "Validate_Indicate_languages_text_l5");
						driver.quit();break;
						
					case "Validate_all_languages_in_l5":
						
						context.setAttribute("fileName", "Validate_all_languages_in_l5");
						Employment.Validate_all_languages_in_l5(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, Languages   );
						context.setAttribute("fileName", "Validate_all_languages_in_l5");
						driver.quit();break;
						
						
					case "Validate_select_desired_languages_in_l5":
						
						context.setAttribute("fileName", "Validate_select_desired_languages_in_l5");
						Employment.Validate_select_desired_languages_in_l5(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, Languages   );
						context.setAttribute("fileName", "Validate_select_desired_languages_in_l5");
						driver.quit();break;
						
						
					case "Validate_bydefault_English_language_isselected_in_l5":
						
						context.setAttribute("fileName", "Validate_bydefault_English_language_isselected_in_l5");
						Employment.Validate_bydefault_English_language_isselected_in_l5(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, Languages   );
						context.setAttribute("fileName", "Validate_bydefault_English_language_isselected_in_l5");
						driver.quit();break;
						
					case "Validate_previous_next_step_buttons_in_l5":
						
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l5");
						Employment.Validate_previous_next_step_buttons_in_l5(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button   );
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l5");
						driver.quit();break;
						
					case "Validate_previous_step_button_in_l5":
						
						context.setAttribute("fileName", "Validate_previous_step_button_in_l5");
						Employment.Validate_previous_step_button_in_l5(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button   );
						context.setAttribute("fileName", "Validate_previous_step_button_in_l5");
						driver.quit();break;
						
					case "Validate_Next_step_button_in_l5":
						
						context.setAttribute("fileName", "Validate_Next_step_button_in_l5");
						Employment.Validate_Next_step_button_in_l5(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button   );
						context.setAttribute("fileName", "Validate_Next_step_button_in_l5");
						driver.quit();break;
						
					case "Validate_text_COqualify_in_l6":
						
						context.setAttribute("fileName", "Validate_text_COqualify_in_l6");
						Employment.Validate_text_COqualify_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, input_data5   );
						context.setAttribute("fileName", "Validate_text_COqualify_in_l6");
						driver.quit();break;
						
					case "Validate_all_fields_in_l6":
						
						context.setAttribute("fileName", "Validate_all_fields_in_l6");
						Employment.Validate_all_fields_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button   );
						context.setAttribute("fileName", "Validate_all_fields_in_l6");
						driver.quit();break;
						
					case "Validate_select_Worktime_interest_in_l6":
						
						context.setAttribute("fileName", "Validate_select_Worktime_interest_in_l6");
						Employment.Validate_select_Worktime_interest_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , Work_time  );
						context.setAttribute("fileName", "Validate_select_Worktime_interest_in_l6");
						driver.quit();break;
						
					case "Validate_Considerfor_chkbox_in_l6":
						
						context.setAttribute("fileName", "Validate_Considerfor_chkbox_in_l6");
						Employment.Validate_Considerfor_chkbox_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , input_data5  );
						context.setAttribute("fileName", "Validate_Considerfor_chkbox_in_l6");
						driver.quit();break;
						
					case "Validate_input_date_to_begin_in_l6":
						
						context.setAttribute("fileName", "Validate_input_date_to_begin_in_l6");
						Employment.Validate_input_date_to_begin_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , Date_to_begin  );
						context.setAttribute("fileName", "Validate_input_date_to_begin_in_l6");
						driver.quit();break;
						
						
					case "Validate_employedwithus_no_rdobtn_in_l6":
						
						context.setAttribute("fileName", "Validate_employedwithus_no_rdobtn_in_l6");
						Employment.Validate_employedwithus_no_rdobtn_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , input_data5  );
						context.setAttribute("fileName", "Validate_employedwithus_no_rdobtn_in_l6");
						driver.quit();break;
						
					case "Validate_basedonselections_text_in_l6":
						
						context.setAttribute("fileName", "Validate_basedonselections_text_in_l6");
						Employment.Validate_basedonselections_text_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , input_data5  );
						context.setAttribute("fileName", "Validate_basedonselections_text_in_l6");
						driver.quit();break;
						
						
					case "Validate_Club_locations_in_l6":
						
						context.setAttribute("fileName", "Validate_Club_locations_in_l6");
						Employment.Validate_Club_locations_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , input_data5  );
						context.setAttribute("fileName", "Validate_Club_locations_in_l6");
						driver.quit();break;
						
					case "Validate_Career_Opportunities_in_l6":
						
						context.setAttribute("fileName", "Validate_Career_Opportunities_in_l6");
						Employment.Validate_Career_Opportunities_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , input_data5  );
						context.setAttribute("fileName", "Validate_Career_Opportunities_in_l6");
						driver.quit();break;
					
					case "Validate_Rehire_Questionnaire_section_in_l6":
						
						context.setAttribute("fileName", "Validate_Rehire_Questionnaire_section_in_l6");
						Employment.Validate_Rehire_Questionnaire_section_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , input_data5  );
						context.setAttribute("fileName", "Validate_Rehire_Questionnaire_section_in_l6");
						driver.quit();break;
						
					case "Validate_EmploymentHowResigned_dd_allvalues_in_l6":
						
						context.setAttribute("fileName", "Validate_EmploymentHowResigned_dd_allvalues_in_l6");
						Employment.Validate_EmploymentHowResigned_dd_allvalues_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , EmploymentHowResigned_dd  );
						context.setAttribute("fileName", "Validate_EmploymentHowResigned_dd_allvalues_in_l6");
						driver.quit();break;				
						
						
					case "Validate_input_in_Rehire_Questionnaire_section_in_l6":
						
						context.setAttribute("fileName", "Validate_input_in_Rehire_Questionnaire_section_in_l6");
						Employment.Validate_input_in_Rehire_Questionnaire_section_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip   );
						context.setAttribute("fileName", "Validate_input_in_Rehire_Questionnaire_section_in_l6");
						driver.quit();break;
						
					case "Validate_ip_in_Rehire_Questionnaire_sec_in_l6_HC":
						
						context.setAttribute("fileName", "Validate_ip_in_Rehire_Questionnaire_sec_in_l6_HC");
						Employment.Validate_ip_in_Rehire_Questionnaire_sec_in_l6_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box , EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip  );
						context.setAttribute("fileName", "Validate_ip_in_Rehire_Questionnaire_sec_in_l6_HC");
						driver.quit();break;
						
						
					case "Validate_ip_in_RQ_sec_l56_corp":
						
						context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l56_corp");
						Employment.Validate_ip_in_RQ_sec_l56_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
						context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l56_corp");
						driver.quit();break;
						
						
					case "Validate_previous_next_step_buttons_in_l6":
						
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l6");
						Employment.Validate_previous_next_step_buttons_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button  );
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l6");
						driver.quit();break;
						
					case "Validate_previous_step_button_in_l6":
						
						context.setAttribute("fileName", "Validate_previous_step_button_in_l6");
						Employment.Validate_previous_step_button_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button );
						context.setAttribute("fileName", "Validate_previous_step_button_in_l6");
						driver.quit();break;
						
						
					case "Validate_next_button_by_filling_all_fields_in_l6":
						
						context.setAttribute("fileName", "Validate_next_button_by_filling_all_fields_in_l6");
						Employment.Validate_next_button_by_filling_all_fields_in_l6(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip   );
						context.setAttribute("fileName", "Validate_next_button_by_filling_all_fields_in_l6");
						driver.quit();break;
						
					case "Validate_paragraphs_in_l7":
						
						context.setAttribute("fileName", "Validate_paragraphs_in_l7");
						Employment.Validate_paragraphs_in_l7(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip , input_data6  );
						context.setAttribute("fileName", "Validate_paragraphs_in_l7");
						driver.quit();break;
						
					case "Validate_paragraphs_in_l7_HC":
						
					context.setAttribute("fileName", "Validate_paragraphs_in_l7_HC");
					Employment.Validate_paragraphs_in_l7_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip  , input_data6 );
					context.setAttribute("fileName", "Validate_paragraphs_in_l7_HC");
					driver.quit();break;
					
					
					case "Validate_paras_l67_corp":
						
						context.setAttribute("fileName", "Validate_paras_l67_corp");
						Employment.Validate_paras_l67_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data6);
						context.setAttribute("fileName", "Validate_paras_l67_corp");
						driver.quit();break;
					
					
						
					case "Validate_rdobtns_in_l7":
						
						context.setAttribute("fileName", "Validate_rdobtns_in_l7");
						Employment.Validate_rdobtns_in_l7(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip  );
						context.setAttribute("fileName", "Validate_rdobtns_in_l7");
						driver.quit();break;
						
						
					case "Validate_rdobtns_l67_corp":
						
						context.setAttribute("fileName", "Validate_rdobtns_l67_corp");
						Employment.Validate_rdobtns_l67_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
						context.setAttribute("fileName", "Validate_rdobtns_l67_corp");
						driver.quit();break;
						
						
					case "Validate_rdobtns_in_l7_HC":
						
						context.setAttribute("fileName", "Validate_rdobtns_in_l7_HC");
						Employment.Validate_rdobtns_in_l7_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip  );
						context.setAttribute("fileName", "Validate_rdobtns_in_l7_HC");
						driver.quit();break;
						
						
					case "Validate_all_form_section_in_l7":
						
						context.setAttribute("fileName", "Validate_all_form_section_in_l7");
						Employment.Validate_all_form_section_in_l7(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip  );
						context.setAttribute("fileName", "Validate_all_form_section_in_l7");
						driver.quit();break;
						
						
						
					case "Validate_all_form_sec_l67_corp":
						
						context.setAttribute("fileName", "Validate_all_form_sec_l67_corp");
						Employment.Validate_all_form_sec_l67_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
						context.setAttribute("fileName", "Validate_all_form_sec_l67_corp");
						driver.quit();break;
						
						
					case "Validate_all_form_section_in_l7_HC":
						
						context.setAttribute("fileName", "Validate_all_form_section_in_l7_HC");
						Employment.Validate_all_form_section_in_l7_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip  );
						context.setAttribute("fileName", "Validate_all_form_section_in_l7_HC");
						driver.quit();break;
						
						
					case "Validate_all_options_of_Gender_dd_in_l7":
						
						context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7");
						Employment.Validate_all_options_of_Gender_dd_in_l7(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd  );
						context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7");
						driver.quit();break;
						
						
						
					case "Validate_Gender_options_dd_l67_corp":
						
						context.setAttribute("fileName", "Validate_Gender_options_dd_l67_corp");
						Employment.Validate_Gender_options_dd_l67_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd);
						context.setAttribute("fileName", "Validate_Gender_options_dd_l67_corp");
						driver.quit();break;
						
						
					case "Validate_all_options_of_Gender_dd_in_l7_HC":
						
						context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_HC");
						Employment.Validate_all_options_of_Gender_dd_in_l7_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip , Gender_dd );
						context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_HC");
						driver.quit();break;
						
						
					case "Validate_all_options_of_RaceEthnicity_dd_in_l7":
						
						context.setAttribute("fileName", "Validate_all_options_of_RaceEthnicity_dd_in_l7");
						Employment.Validate_all_options_of_RaceEthnicity_dd_in_l7(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, RaceEthnicity_dd  );
						context.setAttribute("fileName", "Validate_all_options_of_RaceEthnicity_dd_in_l7");
						driver.quit();break;
						
						
					case "Validate_all_options_of_RaceEthnicity_dd_in_l7_HC":
						
						context.setAttribute("fileName", "Validate_all_options_of_RaceEthnicity_dd_in_l7_HC");
						Employment.Validate_all_options_of_RaceEthnicity_dd_in_l7_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip , RaceEthnicity_dd );
						context.setAttribute("fileName", "Validate_all_options_of_RaceEthnicity_dd_in_l7_HC");
						driver.quit();break;
						
						
					case "Validate_EOE_details_paragraphs_in_l7":
						
						context.setAttribute("fileName", "Validate_EOE_details_paragraphs_in_l7");
						Employment.Validate_EOE_details_paragraphs_in_l7(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip , input_data6 );
						context.setAttribute("fileName", "Validate_EOE_details_paragraphs_in_l7");
						driver.quit();break;
						
						
					case "Validate_RaceEthnicity_dd_options_l67_corp":
						
						context.setAttribute("fileName", "Validate_RaceEthnicity_dd_options_l67_corp");
						Employment.Validate_RaceEthnicity_dd_options_l67_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_RaceEthnicity_dd_options_l67_corp");
						driver.quit();break;
						
						
					case "Validate_EOE_details_paragraphs_in_l7_HC":
						
						context.setAttribute("fileName", "Validate_EOE_details_paragraphs_in_l7_HC");
						Employment.Validate_EOE_details_paragraphs_in_l7_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip , input_data6 );
						context.setAttribute("fileName", "Validate_EOE_details_paragraphs_in_l7_HC");
						driver.quit();break;
						
						
						
					case "Validate_EOE_details_paras_l67_corp":
						
						context.setAttribute("fileName", "Validate_EOE_details_paras_l67_corp");
						Employment.Validate_EOE_details_paras_l67_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data6);
						context.setAttribute("fileName", "Validate_EOE_details_paras_l67_corp");
						driver.quit();break;
						
						
					case "Validate_No_rdobtnof_form_section_in_l7":
						
						context.setAttribute("fileName", "Validate_No_rdobtnof_form_section_in_l7");
						Employment.Validate_No_rdobtnof_form_section_in_l7(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
						context.setAttribute("fileName", "Validate_No_rdobtnof_form_section_in_l7");
						driver.quit();break;
						
						
					case "Validate_No_rdobtnof_form_section_in_l7_HC":
						
						context.setAttribute("fileName", "Validate_No_rdobtnof_form_section_in_l7_HC");
						Employment.Validate_No_rdobtnof_form_section_in_l7_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip  );
						context.setAttribute("fileName", "Validate_No_rdobtnof_form_section_in_l7_HC");
						driver.quit();break;
						
						
						
					case "Validate_No_rdobtnof_l67_corp":
						
						context.setAttribute("fileName", "Validate_No_rdobtnof_l67_corp");
						Employment.Validate_No_rdobtnof_l67_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
						context.setAttribute("fileName", "Validate_No_rdobtnof_l67_corp");
						driver.quit();break;
						
						
					case "Validate_previous_next_step_buttons_in_l7":
						
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l7");
						Employment.Validate_previous_next_step_buttons_in_l7(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l7");
						driver.quit();break;
						
					case "Validate_previous_next_step_buttons_in_l7_HC":
						
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l7_HC");
						Employment.Validate_previous_next_step_buttons_in_l7_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip  );
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l7_HC");
						driver.quit();break;
						
						
						
						case "Validate_prev_next_step_btns_l67_corp":
							
							context.setAttribute("fileName", "Validate_prev_next_step_btns_l67_corp");
							Employment.Validate_prev_next_step_btns_l67_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
							context.setAttribute("fileName", "Validate_prev_next_step_btns_l67_corp");
							driver.quit();break;
						
						
					case "Validate_previous_step_button_in_l7":
						
						context.setAttribute("fileName", "Validate_previous_step_button_in_l7");
						Employment.Validate_previous_step_button_in_l7(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
						context.setAttribute("fileName", "Validate_previous_step_button_in_l7");
						driver.quit();break;
						
						
					case "Validate_previous_step_button_in_l7_HC":
						
						context.setAttribute("fileName", "Validate_previous_step_button_in_l7_HC");
						Employment.Validate_previous_step_button_in_l7_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip  );
						context.setAttribute("fileName", "Validate_previous_step_button_in_l7_HC");
						driver.quit();break;
						
						
					case "Validate_prev_step_btn_l67_corp":
						
						context.setAttribute("fileName", "Validate_prev_step_btn_l67_corp");
						Employment.Validate_prev_step_btn_l67_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
						context.setAttribute("fileName", "Validate_prev_step_btn_l67_corp");
						driver.quit();break;
						
						
					case "Validate_Next_step_button_in_l7":
						
						context.setAttribute("fileName", "Validate_Next_step_button_in_l7");
						Employment.Validate_Next_step_button_in_l7(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
						context.setAttribute("fileName", "Validate_Next_step_button_in_l7");
						driver.quit();break;
						
					case "Validate_Next_step_button_in_l7_HC":
						
						context.setAttribute("fileName", "Validate_Next_step_button_in_l7_HC");
						Employment.Validate_Next_step_button_in_l7_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip  );
						context.setAttribute("fileName", "Validate_Next_step_button_in_l7_HC");
						driver.quit();break;
						
						
					case "Validate_Next_step_btn_l67_corp":
						
						context.setAttribute("fileName", "Validate_Next_step_btn_l67_corp");
						Employment.Validate_Next_step_btn_l67_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
						context.setAttribute("fileName", "Validate_Next_step_btn_l67_corp");
						driver.quit();break;
						
						
					case "Validate_Navigation_to_l8":
						
						context.setAttribute("fileName", "Validate_Navigation_to_l8");
						Employment.Validate_Navigation_to_l8(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_Navigation_to_l8");
						driver.quit();break;
						
						
					case "Validate_Nav_to_78_corp":
						
						context.setAttribute("fileName", "Validate_Nav_to_78_corp");
						Employment.Validate_Nav_to_78_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_Nav_to_78_corp");
						driver.quit();break;
						
						
					case "Validate_Navigation_to_l8_HC":
						
						context.setAttribute("fileName", "Validate_Navigation_to_l8_HC");
						Employment.Validate_Navigation_to_l8_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd );
						context.setAttribute("fileName", "Validate_Navigation_to_l8_HC");
						driver.quit();break;
						
						
					case "Validate_AS_paragraphs_in_l8":
						
						context.setAttribute("fileName", "Validate_AS_paragraphs_in_l8");
						Employment.Validate_AS_paragraphs_in_l8(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_AS_paragraphs_in_l8");
						driver.quit();break;
						
						
					case "Validate_AS_paragraphs_in_l8_HC":
						
						context.setAttribute("fileName", "Validate_AS_paragraphs_in_l8_HC");
						Employment.Validate_AS_paragraphs_in_l8_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd , input_data6);
						context.setAttribute("fileName", "Validate_AS_paragraphs_in_l8_HC");
						driver.quit();break;
						
						
					case "Validate_AS_paras_l78_corp":
						
						context.setAttribute("fileName", "Validate_AS_paras_l78_corp");
						Employment.Validate_AS_paras_l78_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_AS_paras_l78_corp");
						driver.quit();break;
						

					case "Validate_acknmt_l78_corp":
						
						context.setAttribute("fileName", "Validate_acknmt_l78_corp");
						Employment.Validate_acknmt_l78_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_acknmt_l78_corp");
						driver.quit();break;

						
						
					case "Validate_input_in_Signedbynamefield_in_l8":
						
						context.setAttribute("fileName", "Validate_input_in_Signedbynamefield_in_l8");
						Employment.Validate_input_in_Signedbynamefield_in_l8(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_Navigation_to_l8");
						driver.quit();break;
						
						
					case "Validate_ip_in_Signname_l78_corp":
						
						context.setAttribute("fileName", "Validate_ip_in_Signname_l78_corp");
						Employment.Validate_ip_in_Signname_l78_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_ip_in_Signname_l78_corp");
						driver.quit();break;
						
						
					case "Validate_ip_in_Signedbyname_in_l8_HC":
						
						context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_HC");
						Employment.Validate_ip_in_Signedbyname_in_l8_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd );
						context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_HC");
						driver.quit();break;
						
						
					case "Validate_acknowledgement_in_l8":
						
						context.setAttribute("fileName", "Validate_acknowledgement_in_l8");
						Employment.Validate_acknowledgement_in_l8(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_acknowledgement_in_l8");
						driver.quit();break;
						
						
					case "Validate_acknowledgement_in_l8_HC":
						
						context.setAttribute("fileName", "Validate_acknowledgement_in_l8_HC");
						Employment.Validate_acknowledgement_in_l8_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd , input_data6);
						context.setAttribute("fileName", "Validate_acknowledgement_in_l8_HC");
						driver.quit();break;
						
						
					case "Validate_previous_next_step_buttons_in_l8":
						
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l8");
						Employment.Validate_previous_next_step_buttons_in_l8(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l8");
						driver.quit();break;
						
						
					case "Validate_prev_next_step_btns_l78_corp":
						
						context.setAttribute("fileName", "Validate_prev_next_step_btns_l78_corp");
						Employment.Validate_prev_next_step_btns_l78_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_prev_next_step_btns_l78_corp");
						driver.quit();break;
						
						
					case "Validate_previous_next_step_buttons_in_l8_HC":
						
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l8_HC");
						Employment.Validate_previous_next_step_buttons_in_l8_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd );
						context.setAttribute("fileName", "Validate_previous_next_step_buttons_in_l8_HC");
						driver.quit();break;
						
						
						
					case "Validate_prev_step_btn_l78_corp":
						
						context.setAttribute("fileName", "Validate_prev_step_btn_l78_corp");
						Employment.Validate_prev_step_btn_l78_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_prev_step_btn_l78_corp");
						driver.quit();break;
						
						
					case "Validate_previous_step_button_in_l8":
						
						context.setAttribute("fileName", "Validate_previous_step_button_in_l8");
						Employment.Validate_previous_step_button_in_l8(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_previous_step_button_in_l8");
						driver.quit();break;
						
						
					case "Validate_previous_step_button_in_l8_HC":
						
						context.setAttribute("fileName", "Validate_previous_step_button_in_l8_HC");
						Employment.Validate_previous_step_button_in_l8_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd );
						context.setAttribute("fileName", "Validate_previous_step_button_in_l8_HC");
						driver.quit();break;
						
						
					case "Validate_Next_btn_l78_corp":
						
						context.setAttribute("fileName", "Validate_Next_btn_l78_corp");
						Employment.Validate_Next_btn_l78_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_Next_btn_l78_corp");
						driver.quit();break;
						
						
					case "Validate_Next_button_in_l8_HC":
						
						context.setAttribute("fileName", "Validate_Next_button_in_l8_HC");
						Employment.Validate_Next_button_in_l8_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd );
						context.setAttribute("fileName", "Validate_Next_button_in_l8_HC");
						driver.quit();break;
						
						
					case "Validate_Next_button_in_l8":
						
						context.setAttribute("fileName", "Validate_Next_button_in_l8");
						Employment.Validate_Next_button_in_l8(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_Next_button_in_l8");
						driver.quit();break;
						
					case "Validate_heading_in_l9":
						
						context.setAttribute("fileName", "Validate_heading_in_l9");
						Employment.Validate_heading_in_l9(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_heading_in_l9");
						driver.quit();break;
						
						
						
					case "Validate_heading_in_l9_HC":
						
						context.setAttribute("fileName", "Validate_heading_in_l9_HC");
						Employment.Validate_heading_in_l9_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd, input_data6 );
						context.setAttribute("fileName", "Validate_heading_in_l9_HC");
						driver.quit();break;
						
						
						
					case "Validate_heading_l89_corp":
						
						context.setAttribute("fileName", "Validate_heading_l89_corp");
						Employment.Validate_heading_l89_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_heading_l89_corp");
						driver.quit();break;
						
					
					case "Validate_Rules_link_in_l9_HC":
						
						context.setAttribute("fileName", "Validate_Rules_link_in_l9_HC");
						Employment.Validate_Rules_link_in_l9_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd );
						context.setAttribute("fileName", "Validate_Rules_link_in_l9_HC");
						driver.quit();break;
						
					case "Validate_Rules_link_l89_corp":
						
						context.setAttribute("fileName", "Validate_Rules_link_l89_corp");
						Employment.Validate_Rules_link_l89_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_Rules_link_l89_corp");
						driver.quit();break;
						
						
					case "Validate_Rules_and_procedures_in_l9":
						
						context.setAttribute("fileName", "Validate_Rules_and_procedures_in_l9");
						Employment.Validate_Rules_and_procedures_in_l9(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_Rules_and_procedures_in_l9");
						driver.quit();break;
						
						
					case "Validate_Rules_and_procedures_in_l9_HC":
						
						context.setAttribute("fileName", "Validate_Rules_and_procedures_in_l9_HC");
						Employment.Validate_Rules_and_procedures_in_l9_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd, input_data6 );
						context.setAttribute("fileName", "Validate_Rules_and_procedures_in_l9_HC");
						driver.quit();break;
						
					case "Validate_Rules_pros_l89_corp":
						
						context.setAttribute("fileName", "Validate_Rules_pros_l89_corp");
						Employment.Validate_Rules_pros_l89_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_Rules_pros_l89_corp");
						driver.quit();break;
						
					case "Validate_ip_in_printname_dateandipaddress_in_l9":
						
						context.setAttribute("fileName", "Validate_ip_in_printname_dateandipaddress_in_l9");
						Employment.Validate_ip_in_printname_dateandipaddress_in_l9(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd, IP_Address);
						context.setAttribute("fileName", "Validate_ip_in_printname_dateandipaddress_in_l9");
						driver.quit();break;
						
					case "Validate_prtname_dateandipadd_l89_corp":
						
						context.setAttribute("fileName", "Validate_prtname_dateandipadd_l89_corp");
						Employment.Validate_prtname_dateandipadd_l89_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, IP_Address);
						context.setAttribute("fileName", "Validate_prtname_dateandipadd_l89_corp");
						driver.quit();break;
						
					case "Validate_ip_in_printname_dateandipadd_in_l9_HC":
						
						context.setAttribute("fileName", "Validate_ip_in_printname_dateandipadd_in_l9_HC");
						Employment.Validate_ip_in_printname_dateandipadd_in_l9_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd, IP_Address );
						context.setAttribute("fileName", "Validate_ip_in_printname_dateandipadd_in_l9_HC");
						driver.quit();break;
						
						
					case "Validate_Robert_Bryant_Signature_in_l9":
						
						context.setAttribute("fileName", "Validate_Robert_Bryant_Signature_in_l9");
						Employment.Validate_Robert_Bryant_Signature_in_l9(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_Robert_Bryant_Signature_in_l9");
						driver.quit();break;
						
					case "Validate_Robert_Bryant_Sign_in_l9_HC":
						
						context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_HC");
						Employment.Validate_Robert_Bryant_Sign_in_l9_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd, input_data6 );
						context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_HC");
						driver.quit();break;
						
						
						
					case "Validate_Robert_B_Sign_l89_corp":
						
						context.setAttribute("fileName", "Validate_Robert_B_Sign_l89_corp");
						Employment.Validate_Robert_B_Sign_l89_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_Robert_B_Sign_l89_corp");
						driver.quit();break;
						
						
					case "Validate_Iagree_textandbutton_in_l9":
						
						context.setAttribute("fileName", "Validate_Iagree_textandbutton_in_l9");
						Employment.Validate_Iagree_textandbutton_in_l9(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_Iagree_textandbutton_in_l9");
						driver.quit();break;
						
						
					case "Validate_Iagree_textandbtn_in_l9_HC":
						
						context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_HC");
						Employment.Validate_Iagree_textandbtn_in_l9_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd, input_data6 );
						context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_HC");
						driver.quit();break;
						
						
						
					case "Validate_Iagree_textandbtn_l89_corp":
						
						context.setAttribute("fileName", "Validate_Iagree_textandbtn_l89_corp");
						Employment.Validate_Iagree_textandbtn_l89_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_Iagree_textandbtn_l89_corp");
						driver.quit();break;
						
						
					case "Validate_Previous_step_button_in_l9":
						
						context.setAttribute("fileName", "Validate_Previous_step_button_in_l9");
						Employment.Validate_Previous_step_button_in_l9(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_Previous_step_button_in_l9");
						driver.quit();break;
						
						
					case "Validate_Previous_step_button_in_l9_HC":
						
						context.setAttribute("fileName", "Validate_Previous_step_button_in_l9_HC");
						Employment.Validate_Previous_step_button_in_l9_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd );
						context.setAttribute("fileName", "Validate_Previous_step_button_in_l9_HC");
						driver.quit();break;
						
					case "Validate_Prev_step_btn_l89_corp":
						
						context.setAttribute("fileName", "Validate_Prev_step_btn_l89_corp");
						Employment.Validate_Prev_step_btn_l89_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_Prev_step_btn_l89_corp");
						driver.quit();break;
						
					case "Validate_Iagreebtn_and_successful_submission_in_l9":
						
						context.setAttribute("fileName", "Validate_Iagreebtn_and_successful_submission_in_l9");
						Employment.Validate_Iagreebtn_and_successful_submission_in_l9(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_Iagreebtn_and_successful_submission_in_l9");
						driver.quit();break;
						
						
					case "Validate_Iagreebtn_and_succ_submsn_in_l9_HC":
						
						context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_HC");
						Employment.Validate_Iagreebtn_and_succ_submsn_in_l9_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd );
						context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_HC");
						driver.quit();break;
						
						
					case "Validate_Iagreebtn_and_succ_submsn_l89_corp":
						
						context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_l89_corp");
						Employment.Validate_Iagreebtn_and_succ_submsn_l89_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
						context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_l89_corp");
						driver.quit();break;
						
						
						
					case "Validate_Success_message_in_final_page":
						
						context.setAttribute("fileName", "Validate_Success_message_in_final_page");
						Employment.Validate_Success_message_in_final_page(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd, Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data6, Languages);
						context.setAttribute("fileName", "Validate_Success_message_in_final_page");
						driver.quit();break;
						
						
					case "Validate_Success_msg_in_final_page_HC":
						
						context.setAttribute("fileName", "Validate_Success_msg_in_final_page_HC");
						Employment.Validate_Success_msg_in_final_page_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd, input_data6 );
						context.setAttribute("fileName", "Validate_Success_msg_in_final_page_HC");
						driver.quit();break;
						
						
						
					case "Validate_Success_msg_corp":
						
						context.setAttribute("fileName", "Validate_Success_msg_corp");
						Employment.Validate_Success_msg_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_Success_msg_corp");
						driver.quit();break;
						
						
						
					case "Validate_print_button_in_print_emp_app_page":
						
						context.setAttribute("fileName", "Validate_print_button_in_print_emp_app_page");
						Employment.Validate_print_button_in_print_emp_app_page(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button ,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip,  Gender_dd, RaceEthnicity_dd, Aerobics_Instructor_Exp_DD, Time_period_DD, Club_Employer_DD,  Class_per_week,Checkbox_class_formats, Hold_cert_GT_AC_ratio_button, Certified_In_DD, Certification_IssuedByDPValues, Certificate_No, File_name, input_data6, Languages);
						context.setAttribute("fileName", "Validate_print_button_in_print_emp_app_page");
						driver.quit();break;
						
					case "Validate_printbtn_in_print_emp_app_page_HC":
						
						context.setAttribute("fileName", "Validate_printbtn_in_print_emp_app_page_HC");
						Employment.Validate_printbtn_in_print_emp_app_page_HC(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4 , E_EducationLeve_Dropdown,Dropdown_values,Certification_IssuedByDPValues,Certificate_No, File_name, Hold_cert_GT_AC_ratio_button,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button , No_Prev_emp_chk_box,Work_time,input_data5, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip ,Gender_dd ,RaceEthnicity_dd, input_data6 );
						context.setAttribute("fileName", "Validate_printbtn_in_print_emp_app_page_HC");
						driver.quit();break;
						
						
					case "Validate_prtbtn_in_prt_emp_app_page_corp":
						
						context.setAttribute("fileName", "Validate_prtbtn_in_prt_emp_app_page_corp");
						Employment.Validate_prtbtn_in_prt_emp_app_page_corp(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data2,input_data1,Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, input_data4, E_EducationLeve_Dropdown , File_name,  Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, No_Prev_emp_chk_box ,Languages,Work_time,Considered_for_chkbx, Date_to_begin, Everemployed_rdobtn,EmploymentHowResigned_dd,PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data6);
						context.setAttribute("fileName", "Validate_prtbtn_in_prt_emp_app_page_corp");
						driver.quit();break;
						
						
						case "Validate_next_button_l1":
						
						context.setAttribute("fileName", "Validate_next_button_l1");
						Employment.Validate_next_button_l1(testdata.get("TextMessage").toString(),Text_input, input_data, additional_input, input_data1, input_data2, Job_short_des, Url, input_data3, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode  );
						context.setAttribute("fileName", "Validate_next_button_l1");
						driver.quit();
						break;
						
	//					case "Group_Fitness_job":
	//					
	//					context.setAttribute("fileName", "Group_Fitness_job");
	//					Employment.Group_Fitness_apply_here(testdata.get("TextMessage").toString(),How_hear_abt_us, F_Name, L_Name, Email  , Phone , Address , Zipcode  , City , State , Radius_travel_to_work, Radiobtn18YearsOld);
	//					context.setAttribute("fileName", "Group_Fitness_job");
	//					driver.quit();
						
							
	//					*/
	
						
						
					default:
						driver.quit();
						break;
	
					}
	
					// EndTest
	//				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
					ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
					ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
					ExtentTestManager.endTest();
					ExtentManager.getInstance().flush();
					Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
					Log.info("Browser is closed");
	
	
				}
	
			} 
			catch (Exception e)
			{
				Thread.sleep(1000);
				ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				String stackTrace = Throwables.getStackTraceAsString(e);
				Log.error( stackTrace);
			
				
				String fileName = (String) context.getAttribute("fileName");
	
				try {
					File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
							testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().fail(e.getMessage(),
							MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
					ExtentTestManager.getTest().log(Status.FAIL, e);
					} 
				catch (Exception e1) {
					System.out.println("File not found " + e1);
									}
				ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");
	
	//			 Logout
				context.setAttribute("fileName", "Logout");
				if (com.test.user.All_scenarios.driver!=null)driver.quit();
				ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
				Log.info("Browser is closed");
	
				// EndTest
				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
				ExtentTestManager.endTest();
				ExtentManager.getInstance().flush();
				Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				throw new Exception(stackTrace);
			} 
			catch (AssertionError e) 
			{
				Thread.sleep(1000);
	//			System.out.println("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
				String stackTrace = Throwables.getStackTraceAsString(e);
				Log.error( stackTrace);
				
				String fileName = (String) context.getAttribute("fileName");
	
				try {
					File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
							testdata.get("TestScenario").toString());
					ExtentTestManager.getTest().fail(e.getMessage(),
							MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
					ExtentTestManager.getTest().log(Status.FAIL, e);
					} 
				catch (Exception e1)
				{
					System.out.println("File not found " + e1);
				}
				ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");
	
				// Logout
				context.setAttribute("fileName", "Logout");
				driver.quit();
				ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
				Log.info("Browser is closed");
	
				// EndTest
				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
				ExtentTestManager.endTest();
				ExtentManager.getInstance().flush();
				Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				
				throw new Exception(stackTrace);
				
			}
		}
	
	
		
		@DataProvider(name = "TestData")
		public static Object[][] gettestdate() throws IOException {
	
			Object[][] objectarry = null;
			java.util.List<Map<String, String>> completedata = com.Utility.ExcelReader.getdata("Employment");
	
			java.util.List<Map<String, String>> completedata1 = new ArrayList<Map<String,String>>();
			int j=0;
	
			for (int i = 0; i < completedata.size(); i++) {
				if(completedata.get(i).get("Run").toString().equalsIgnoreCase("Yes")) 
				{
				completedata1.add(j, completedata.get(i));
				j++;
				}
			}
			
			objectarry = new Object[completedata1.size()][1];
			
			for (int i = 0; i < completedata1.size(); i++) {
				objectarry[i][0] = completedata1.get(i);
			}
			return objectarry;
	
		}
	
		public void Takescreenshot(String fileName, String scenario) {
			try {
				File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
						scenario);
				ExtentTestManager.getTest().pass("File upload screenshot",
						MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
				
				} 
			catch (Exception e1) {
				System.out.println("File not found " + e1);
								}
		}
		
	}
