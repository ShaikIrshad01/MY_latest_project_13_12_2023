package com.test.user;


import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.testng.ITestContext;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.apache.commons.lang3.ObjectUtils.Null;
import org.apache.poi.hssf.record.PageBreakRecord.Break;
import org.testng.*;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.BasePackage.Base_Class;
import com.Utility.Log;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.extentReports.ExtentManager;
import com.extentReports.ExtentTestManager;
import com.google.common.base.Throwables;
import com.listeners.TestListener;

public class Career_Opportunities_CSC_scenarios extends Base_Class  {

	Base_Class Base_Class;
	com.pages.Home Home;
	com.pages.Joinnow joinnow;
	Log log;
	TestListener TestListener;
	com.Utility.ScreenShot screenShot;
	com.pages.Employment Employment;
	com.pages.FreePass FreePass;
	com.pages.CareerOpportunity CareerOpportunity;
	com.pages.Locations Locations;
	com.pages.CareerOpportunities_CSC CareerOpportunities_CSC;
	
	@BeforeSuite
	public void reference() {
		Base_Class = new Base_Class();
		log = new Log();
		TestListener = new TestListener();
		screenShot = new com.Utility.ScreenShot(null);
		Home = new com.pages.Home();
		joinnow = new com.pages.Joinnow();
		Employment = new com.pages.Employment();
		FreePass = new com.pages.FreePass();
		Locations = new com.pages.Locations();
		
		CareerOpportunity = new com.pages.CareerOpportunity();
		CareerOpportunities_CSC = new com.pages.CareerOpportunities_CSC();
		
	}
	
	@Test(dataProvider = "TestData")
	public void RUNALL(Map<Object, Object> testdata, ITestContext context) throws Throwable {

		try {

			if (testdata.get("Run").toString().equalsIgnoreCase("Yes")) {
				String fileName;
				ExtentTestManager.startTest(testdata.get("TestScenario").toString());
				ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " running Starting ***");
				Log.info("*** Running test method " + testdata.get("TestScenario").toString() + "...");
				ExtentTestManager.getTest().log(Status.PASS, "*** Running test method " + testdata.get("TestScenario").toString() + "...");
			
				String Change_brand_name=testdata.get("Change_brand_name").toString();
				if(testdata.get("TextMessage").toString().trim().equalsIgnoreCase("Change_Brand".trim())) {
					
					Base_Class.setup_Change_brand();
					if(!Change_brand_name.isBlank() && !Change_brand_name.isEmpty()) Base_Class.Change_Brand(Change_brand_name);
					
				else {
					
					throw new Exception("please provide brand name to change the brand");
				
					}
					
					if(!(driver.toString().contains("null"))) driver.quit();
					
					
				}
				
				else {
					Base_Class.setup();
				}
				
//				Base_Class.setup();

				ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered into Application URL ");

				String Dropdown_values=testdata.get("Dropdown_values").toString();
				
				String Country =testdata.get("Country").toString();
				String Ratesoramenities =testdata.get("Rates/amenities").toString();
				String Club_name =testdata.get("Club_name").toString();
				
				String Add_amenities =testdata.get("Add_amenities").toString();
				String Included_amenities =testdata.get("Included_amenities").toString();
			
				String Amount_details =testdata.get("Amount_details").toString();
				String rates_details =testdata.get("Rates_details").toString();
				String plan_rates =testdata.get("Plan_rates").toString();
				
				
				
				
				String Text_input =testdata.get("Text_input").toString();
	
				
				String Number_of_Persons1 =testdata.get("Number_of_Persons1").toString();
				String Initiation_Fee =testdata.get("Initiation_Fee").toString();
				String Billing_Frequency =testdata.get("Billing_Frequency").toString();				
				String Initial_Term =testdata.get("Initial_Term").toString();
				String Prepayment =testdata.get("Prepayment").toString();
				String First_Month_Dues =testdata.get("First_Month_Dues").toString();
				String Last_Month_Dues =testdata.get("Last_Month_Dues").toString();
				String Total_initial_Payment =testdata.get("Total_initial_Payment").toString();	
				String Annual_Fee_Per_Person =testdata.get("Annual_Fee_Per_Person").toString();
				
				String Everemployed_rdobtn =testdata.get("Everemployed_rdobtn").toString();
				String Date_to_begin =testdata.get("Date_to_begin").toString();
				String Languages =testdata.get("Languages").toString();
				String Work_time =testdata.get("Work_time").toString();
				String Url =testdata.get("Url").toString();
				String additional_input =testdata.get("additional_input").toString();
				String input_data =testdata.get("input_data").toString();
				String input_data1 =testdata.get("input_data1").toString();
				String input_data2 =testdata.get("input_data2").toString();
				String input_data3 =testdata.get("input_data3").toString();
				String input_data4 =testdata.get("input_data4").toString();
				String input_data5 =testdata.get("input_data5").toString();
				String input_data6 =testdata.get("input_data6").toString();
				String IP_Address =testdata.get("IP_Address").toString();
				
				String File_name =testdata.get("File_name").toString();
				
				String Job_short_des =testdata.get("Job_short_des").toString();
				String Job_long_des =testdata.get("Job_long_des").toString();
				String F_Name =testdata.get("F_Name").toString();
				String L_Name =testdata.get("L_Name").toString();
				String Full_name =testdata.get("Full_name").toString();
				String Phone =testdata.get("Member_Phone").toString();
				String Email =testdata.get("Email").toString();
				String Address =testdata.get("Member_address").toString();
//				job_short_des
				String City =testdata.get("Member_City").toString();
				
				String E_EducationLeve_Dropdown = testdata.get("E_EducationLeve_Dropdown").toString();

				String Aerobics_Instructor_Exp_DD = testdata.get("Aerobics_Instructor_Exp_DD").toString();
				String Time_period_DD = testdata.get("Time_period_DD").toString();
				String Club_Employer_DD = testdata.get("Club_Employer_DD").toString();
				String Class_per_week = testdata.get("Class_per_week").toString();
				
				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
				String PriorEmploymentWhyResigned_ip = testdata.get("PriorEmploymentWhyResigned_ip").toString();
				String EmploymentWhyLeaveCurrent_ip = testdata.get("EmploymentWhyLeaveCurrent_ip").toString();
				String EmploymentWhyReapply_ip = testdata.get("EmploymentWhyReapply_ip").toString();
				String EmploymentWhatLike_ip = testdata.get("EmploymentWhatLike_ip").toString();
				String EmploymentWhatDislike_ip = testdata.get("EmploymentWhatDislike_ip").toString();
				
				String EmploymentSuccess_ip = testdata.get("EmploymentSuccess_ip").toString();
				String EmploymentWhyResignInFuture_ip = testdata.get("EmploymentWhyResignInFuture_ip").toString();
				String Gender_dd = testdata.get("Gender_dd").toString();
				String RaceEthnicity_dd = testdata.get("RaceEthnicity_dd").toString();
//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
//				
				String Personal_Training_ExperienceDPValues = testdata.get("Personal_Training_ExperienceDPValues").toString();
				String Certification_IssuedByDPValues = testdata.get("Certification_IssuedByDPValues").toString();
				String Hold_cert_GT_AC_ratio_button = testdata.get("Hold_cert_GT_AC_ratio_button").toString();
				String Certified_In_DD = testdata.get("Certified_In_DD").toString();
				String Certificate_No = testdata.get("Certificate_No").toString();
				String Emp_gap = testdata.get("Emp_gap").toString();
				String Employer_name = testdata.get("Employer_name").toString();
				String Supervisor_name = testdata.get("Supervisor_name").toString();
				String From_date = testdata.get("From_date").toString();
				String To_date = testdata.get("To_date").toString();
				String Job_title = testdata.get("Job_title").toString();
				String Leaving_Reason = testdata.get("Leaving_Reason").toString();
				String Emp_details = testdata.get("Emp_details").toString();
				String Can_contact_radio_button = testdata.get("Can_contact_radio_button").toString();
				
				
				String Club_phone =testdata.get("Club_phone").toString();
				String Club_zip =testdata.get("Club_zip").toString();
				String Club_Address =testdata.get("Club_Address").toString();
				String Club_city =testdata.get("Club_city").toString();
//				
				String State =testdata.get("State").toString();
				String Zipcode =testdata.get("Member_Zipcode").toString();
				String Radius_travel_to_work =testdata.get("Radius_travel_to_work").toString();
				String How_hear_abt_us =testdata.get("How_hear_abt_us").toString();
				String Radiobtn18YearsOld =testdata.get("Radiobtn18YearsOld").toString();
				String Payment_type =testdata.get("Payment_type").toString();
				String Card_number  =testdata.get("Card_number").toString();
				
				String Ex_month =testdata.get("Ex_month").toString();
				String Ex_year  =testdata.get("Ex_year").toString();
				
				String Routing_number  =testdata.get("Routing_number").toString();
				String Account_number =testdata.get("Account_number").toString();
				String Card_name =testdata.get("Card_name").toString();
				String Checkbox_class_formats =testdata.get("Checkbox_class_formats").toString();

				String No_Prev_emp_chk_box =testdata.get("No_Prev_emp_chk_box").toString();
			
				String Considered_for_chkbx =testdata.get("Considered_for_chkbx").toString();
					
				
				

				
				
				
						
				switch (testdata.get("TextMessage").toString()) {
				
					
				// Career Opportunities Test cases
				
				case "Validate_About_dd_CO_option_CSC":
					
					context.setAttribute("fileName", "Validate_About_dd_CO_option_CSC");
					Home.Validate_About_dd_CO_option_CSC(testdata.get("TextMessage").toString());
					context.setAttribute("fileName", "Validate_About_dd_CO_option_CSC");
					driver.quit();break;
					
					
					
				case "CS_Validate_text_EmploymentApplication_PT":

					context.setAttribute("fileName", "CS_Validate_text_EmploymentApplication_PT");
					CareerOpportunities_CSC.TC_01_CS_Validate_text_EmploymentApplication_PT(testdata.get("TextMessage").toString(),Text_input);
					context.setAttribute("fileName", "CS_Validate_text_EmploymentApplication_PT");
					driver.quit();
					break;
						
					
				case "CS_Validate_Text_Below_EmploymentApp_PT":

					context.setAttribute("fileName", "CS_Validate_Text_Below_EmploymentApp_PT");
					CareerOpportunities_CSC.TC_02_CS_Validate_Text_Below_EmploymentApp_PT(testdata.get("TextMessage").toString(),Text_input);
					context.setAttribute("fileName", "CS_Validate_Text_Below_EmploymentApp_PT");
					driver.quit();
					break;

					
				case "CS_Validate_HL_NoticeatCollectionnUr_EmpAp_PT":

					context.setAttribute("fileName", "CS_Validate_HL_NoticeatCollectionnUr_EmpAp_PT");
					CareerOpportunities_CSC.TC_03_CS_Validate_HL_NoticeatCollectionnUr_EmpAp_PT(testdata.get("TextMessage").toString(),Text_input);
					context.setAttribute("fileName", "CS_Validate_HL_NoticeatCollectionnUr_EmpAp_PT");
					driver.quit();
					break;
					
				case "CS_Validate_Text_AppInfo_ContandLocInfo_PT":

					context.setAttribute("fileName", "CS_Validate_Text_AppInfo_ContandLocInfo_PT");
					CareerOpportunities_CSC.TC_04_CS_Validate_Text_AppInfo_ContandLocInfo_PT(testdata.get("TextMessage").toString(),Text_input);
					context.setAttribute("fileName", "CS_Validate_Text_AppInfo_ContandLocInfo_PT");
					driver.quit();
					break;
					
				case "CS_Validate_mandatoryFields_PT":

					context.setAttribute("fileName", "CS_Validate_mandatoryFields_PT");
					CareerOpportunities_CSC.TC_05_CS_Validate_mandatoryFields_PT(testdata.get("TextMessage").toString(),Text_input);
					context.setAttribute("fileName", "CS_Validate_mandatoryFields_PT");
					driver.quit();	
					break;
					
				case "CS_Validate_Dropdownvalues_HowDidUhearUs_PT":

					context.setAttribute("fileName", "CS_Validate_Dropdownvalues_HowDidUhearUs_PT");
					CareerOpportunities_CSC.TC_06_CS_Validate_Dropdownvalues_HowDidUhearUs_PT(testdata.get("TextMessage").toString(),Dropdown_values);
					context.setAttribute("fileName", "CS_Validate_Dropdownvalues_HowDidUhearUs_PT");
					driver.quit();	
					break;
					
				case "CS_Validate_Radiobutton_RU18_PT":

					context.setAttribute("fileName", "CS_Validate_Radiobutton_RU18_PT");
					CareerOpportunities_CSC.TC_07_CS_Validate_Radiobutton_RU18_PT(testdata.get("TextMessage").toString(),Dropdown_values);
					context.setAttribute("fileName", "CS_Validate_Radiobutton_RU18_PT");
					driver.quit();
					break;
					
				case "CS_validate_Text_FormatUSCanada_PT":

					context.setAttribute("fileName", "CS_validate_Text_FormatUSCanada_PT");
					CareerOpportunities_CSC.TC_08_CS_validate_Text_FormatUSCanada_PT(testdata.get("TextMessage").toString(),Text_input);
					context.setAttribute("fileName", "CS_validate_Text_FormatUSCanada_PT");
					driver.quit();
					break;
					
				case "CS_validate_Text_Miles":

					context.setAttribute("fileName", "CS_validate_Text_Miles");
					CareerOpportunities_CSC.TC_09_CS_validate_Text_Miles(testdata.get("TextMessage").toString(),Text_input);
					context.setAttribute("fileName", "CS_validate_Text_Miles");
					driver.quit();
					break;
					
				case "CS_Validate_ErrorMsg_CellPhone_PT":

					context.setAttribute("fileName", "CS_Validate_ErrorMsg_CellPhone_PT");
					CareerOpportunities_CSC.TC_10_CS_Validate_ErrorMsg_CellPhone_PT(testdata.get("TextMessage").toString(),Text_input);
					context.setAttribute("fileName", "CS_Validate_ErrorMsg_CellPhone_PT");
					driver.quit();
					break;
					
					
				case "CS_Validate_Button_NextStep_PT":

					context.setAttribute("fileName", "CS_Validate_Button_NextStep_PT");
					CareerOpportunities_CSC.TC_11_CS_Validate_Button_NextStep_PT(testdata.get("TextMessage").toString(),Text_input);
					context.setAttribute("fileName", "CS_Validate_Button_NextStep_PT");
					driver.quit();
					break;
					
				case "CS_Validate_Field_Input_PT":

					context.setAttribute("fileName", "CS_Validate_Field_Input_PT");
					CareerOpportunities_CSC.TC_12_CS_Validate_Field_Input_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode );
					context.setAttribute("fileName", "CS_Validate_Field_Input_PT");
					driver.quit();
					break;
					
					
				case "CS_Validate_Nextbutton_ClickofApplicantinfo_PT":

					context.setAttribute("fileName", "CS_Validate_Nextbutton_ClickofApplicantinfo_PT");
					CareerOpportunities_CSC.TC_13_CS_Validate_Nextbutton_ClickofApplicantinfo_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode );
					context.setAttribute("fileName", "CS_Validate_Nextbutton_ClickofApplicantinfo_PT");
					driver.quit();
					break;
					
				case "CS_Validate_Text_EducationInfo_PT":

					context.setAttribute("fileName", "CS_Validate_Text_EducationInfo_PT");
					CareerOpportunities_CSC.TC_14_CS_Validate_Text_EducationInfo_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input );
					context.setAttribute("fileName", "CS_Validate_Text_EducationInfo_PT");
					driver.quit();
					break;
					
					
					case "CS_Validate_Field_EducationLevel_PT":

					context.setAttribute("fileName", "CS_Validate_Field_EducationLevel_PT");
					CareerOpportunities_CSC.TC_15_CS_Validate_Field_EducationLevel_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input );
					context.setAttribute("fileName", "CS_Validate_Field_EducationLevel_PT");
					driver.quit();
					break;
					
					
					case "CS_Validate_DropdownValues_EducationLevel_PT":

					context.setAttribute("fileName", "CS_Validate_DropdownValues_EducationLevel_PT");
					CareerOpportunities_CSC.TC_16_CS_Validate_DropdownValues_EducationLevel_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input,E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "CS_Validate_DropdownValues_EducationLevel_PT");
					driver.quit();
					break;
					
					case "CS_Validate_url_clickofPersonalTrainerApplyhere_PT":

					context.setAttribute("fileName", "CS_Validate_url_clickofPersonalTrainerApplyhere_PT");
					CareerOpportunities_CSC.TC_17_CS_Validate_url_clickofPersonalTrainerApplyhere_PT(testdata.get("TextMessage").toString(),Text_input );
					context.setAttribute("fileName", "CS_Validate_url_clickofPersonalTrainerApplyhere_PT");
					driver.quit();
					break;
					
					
					case "CS_Verify_YouMustBe18Years_popup_OnselectingRaiodNo_PT":

					context.setAttribute("fileName", "CS_Verify_YouMustBe18Years_popup_OnselectingRaiodNo_PT");
					CareerOpportunities_CSC.TC_18_CS_Verify_YouMustBe18Years_popup_OnselectingRaiodNo_PT(testdata.get("TextMessage").toString(),Text_input,Dropdown_values );
					context.setAttribute("fileName", "CS_Verify_YouMustBe18Years_popup_OnselectingRaiodNo_PT");
					driver.quit();
					break;
					
					
					case "CS_Validate_EducationLevel_ButtonsPerviousNext_PT":

					context.setAttribute("fileName", "CS_Validate_EducationLevel_ButtonsPerviousNext_PT");
					CareerOpportunities_CSC.TC_19_CS_Validate_EducationLevel_ButtonsPerviousNext_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode );
					context.setAttribute("fileName", "CS_Validate_EducationLevel_ButtonsPerviousNext_PT");
					driver.quit();
					break;
					
					
					case "CS_Validate_PreviousPage_ClickofELPreviousbutton_PT":

					context.setAttribute("fileName", "CS_Validate_PreviousPage_ClickofELPreviousbutton_PT");
					CareerOpportunities_CSC.TC_20_CS_Validate_PreviousPage_ClickofELPreviousbutton_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,Text_input );
					context.setAttribute("fileName", "CS_Validate_PreviousPage_ClickofELPreviousbutton_PT");
					driver.quit();
					break;
					
					case "CS_Validate_NextPage_ClickofELNextbutton_PT":

					context.setAttribute("fileName", "CS_Validate_NextPage_ClickofELNextbutton_PT");
					CareerOpportunities_CSC.TC_21_CS_Validate_NextPage_ClickofELNextbutton_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "CS_Validate_NextPage_ClickofELNextbutton_PT");
					driver.quit();
					break;

					case "CS_Validate_Text_ExperienceInformation_Expinfo_PT":

						context.setAttribute("fileName", "CS_Validate_Text_ExperienceInformation_Expinfo_PT");
						CareerOpportunities_CSC.TC_22_CS_Validate_Text_ExperienceInformation_Expinfo_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Text_input );
						context.setAttribute("fileName", "CS_Validate_Text_ExperienceInformation_Expinfo_PT");
						driver.quit();
						break;
						
						case "CS_Validate_Text_ExperienceDetail_PT":

						context.setAttribute("fileName", "CS_Validate_Text_ExperienceDetail_PT");
						CareerOpportunities_CSC.TC_23_CS_Validate_Text_ExperienceDetail_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Text_input );
						context.setAttribute("fileName", "CS_Validate_Text_ExperienceDetail_PT");
						driver.quit();
						break;
						
						
						case "CS_Validate_Text_PersonalTrainer_PT":

						context.setAttribute("fileName", "CS_Validate_Text_PersonalTrainer_PT");
						CareerOpportunities_CSC.TC_24_CS_Validate_Text_PersonalTrainer_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Text_input );
						context.setAttribute("fileName", "CS_Validate_Text_ExperienceDetail_PT");
						driver.quit();
						break;

						case "CS_Validate_Field_PersonalTrainerCertificate_PT":

							context.setAttribute("fileName", "CS_Validate_Field_PersonalTrainerCertificate_PT");
							CareerOpportunities_CSC.TC_25_CS_Validate_Field_PersonalTrainerCertificate_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Text_input );
							context.setAttribute("fileName", "CS_Validate_Field_PersonalTrainerCertificate_PT");
							driver.quit();
							break;
						
						case "CS_Validate_Radio_HoldPersonalTrainer_PT":

							context.setAttribute("fileName", "CS_Validate_Radio_HoldPersonalTrainer_PT");
							CareerOpportunities_CSC.TC_26_CS_Validate_Radio_HoldPersonalTrainer_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Text_input );
							context.setAttribute("fileName", "CS_Validate_Radio_HoldPersonalTrainer_PT");
							driver.quit();
							break;
						
						case "CS_Validate_Link_PersonalTrainerCI_PT":

							context.setAttribute("fileName", "CS_Validate_Link_PersonalTrainerCI_PT");
							CareerOpportunities_CSC.TC_27_CS_Validate_Link_PersonalTrainerCI_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Text_input );
							context.setAttribute("fileName", "CS_Validate_Link_PersonalTrainerCI_PT");
							driver.quit();
							break;
							
						case "CS_Validate_Field_PersonalTrainingExp_PT":

							context.setAttribute("fileName", "CS_Validate_Field_PersonalTrainingExp_PT");
							CareerOpportunities_CSC.TC_28_CS_Validate_Field_PersonalTrainingExp_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Text_input );
							context.setAttribute("fileName", "CS_Validate_Field_PersonalTrainingExp_PT");
							driver.quit();
							break;
							
						case "CS_Validate_Dropdownvalues_PersonalTrainingExp_PT":
							context.setAttribute("fileName", "CS_Validate_Dropdownvalues_PersonalTrainingExp_PT");
							CareerOpportunities_CSC.TC_29_CS_Validate_Dropdownvalues_PersonalTrainingExp_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Text_input );
							context.setAttribute("fileName", "CS_Validate_Dropdownvalues_PersonalTrainingExp_PT");
							driver.quit();
							break;
							
							
							
						case "CS_Validate_Text_Pleaseselectnomorethan_PT":
							context.setAttribute("fileName", "CS_Validate_Text_Pleaseselectnomorethan_PT");
							CareerOpportunities_CSC.TC_30_CS_Validate_Text_Pleaseselectnomorethan_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Text_input );
							context.setAttribute("fileName", "CS_Validate_Text_Pleaseselectnomorethan_PT");
							driver.quit();
							break;

						case "CS_Validate_Fields_CertificationissuedCertificationNumber_PT":
							context.setAttribute("fileName", "CS_Validate_Fields_CertificationissuedCertificationNumber_PT");
							CareerOpportunities_CSC.TC_31_CS_Validate_Fields_CertificationissuedCertificationNumber_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Text_input );
							context.setAttribute("fileName", "CS_Validate_Fields_CertificationissuedCertificationNumber_PT");
							driver.quit();
							break;
						
							
						case "CS_Validate_DropdownValue_Certificationissued_PT":
							context.setAttribute("fileName", "CS_Validate_DropdownValue_Certificationissued_PT");
							CareerOpportunities_CSC.TC_32_CS_Validate_DropdownValue_Certificationissued_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
							context.setAttribute("fileName", "CS_Validate_DropdownValue_Certificationissued_PT");
							driver.quit();
							break;
						
						case "CS_Validate_Text_CertificateFilesDtl_PT":
							context.setAttribute("fileName", "CS_Validate_Text_CertificateFilesDtl_PT");
							CareerOpportunities_CSC.TC_33_CS_Validate_Text_CertificateFilesDtl_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
							context.setAttribute("fileName", "CS_Validate_Text_CertificateFilesDtl_PT");
							driver.quit();
							break;
							
							



						case "CS_Validate_ChooseFileUpload_PT":
							context.setAttribute("fileName", "CS_Validate_ChooseFileUpload_PT");
							CareerOpportunities_CSC.TC_34_CS_Validate_ChooseFileUpload_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
							context.setAttribute("fileName", "CS_Validate_ChooseFileUpload_PT");
							driver.quit();
							break;
						

		case "CS_Validate_SelectCertificate_Certinum_PT":
							context.setAttribute("fileName", "CS_Validate_SelectCertificate_Certinum_PT");
							CareerOpportunities_CSC.TC_35_CS_Validate_SelectCertificate_Certinum_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
							context.setAttribute("fileName", "CS_Validate_SelectCertificate_Certinum_PT");
							driver.quit();
							break;
						


case "CS_Validate_Button_AddCertificate_PT":
							context.setAttribute("fileName", "CS_Validate_Button_AddCertificate_PT");
							CareerOpportunities_CSC.TC_36_CS_Validate_Button_AddCertificate_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
							context.setAttribute("fileName", "CS_Validate_Button_AddCertificate_PT");
							driver.quit();
							break;
		

case "CS_Validate_Click_AddCertificate_PT":
							context.setAttribute("fileName", "CS_Validate_Click_AddCertificate_PT");
							CareerOpportunities_CSC.TC_37_CS_Validate_Click_AddCertificate_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
							context.setAttribute("fileName", "CS_Validate_Click_AddCertificate_PT");
							driver.quit();
							break;



case "CS_Validate_Button_RemoveIcon_PT":
							context.setAttribute("fileName", "CS_Validate_Button_RemoveIcon_PT");
							CareerOpportunities_CSC.TC_38_CS_Validate_Button_RemoveIcon_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
							context.setAttribute("fileName", "CS_Validate_Button_RemoveIcon_PT");
							driver.quit();
							break;



case "CS_Validate_Click_RemoveIcon_PT":
							context.setAttribute("fileName", "CS_Validate_Click_RemoveIcon_PT");
							CareerOpportunities_CSC.TC_39_CS_Validate_Click_RemoveIcon_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
							context.setAttribute("fileName", "CS_Validate_Click_RemoveIcon_PT");
							driver.quit();
							break;


case "CS_Validate_Click_PreviousExperInfopage_PT":
							context.setAttribute("fileName", "CS_Validate_Click_PreviousExperInfopage_PT");
							CareerOpportunities_CSC.TC_40_CS_Validate_Click_PreviousExperInfopage_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
							context.setAttribute("fileName", "CS_Validate_Click_PreviousExperInfopage_PT");
							driver.quit();
							break;




case "CS_Validate_Click_NextExperInfopage_PT":
							context.setAttribute("fileName", "CS_Validate_Click_NextExperInfopage_PT");
							CareerOpportunities_CSC.TC_41_CS_Validate_Click_NextExperInfopage_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues );
							context.setAttribute("fileName", "CS_Validate_Click_NextExperInfopage_PT");
							driver.quit();
							break;
	
							
							
							
							case "CS_Validate_Text_EmploymentHistory_PT":
									context.setAttribute("fileName", "CS_Validate_Text_EmploymentHistory_PT");
									CareerOpportunities_CSC.TC_42_CS_Validate_Text_EmploymentHistory_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
									context.setAttribute("fileName", "CS_Validate_Text_EmploymentHistory_PT");
									driver.quit();
									break;



		case "CS_Validate_Text_PreviousEmployment_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Text_PreviousEmployment_EH_PT");
									CareerOpportunities_CSC.TC_43_CS_Validate_Text_PreviousEmployment_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
									context.setAttribute("fileName", "CS_Validate_Text_PreviousEmployment_EH_PT");
									driver.quit();
									break;



		case "CS_Validate_Radioptn_PreEmploymentnIhvEmphis_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Radioptn_PreEmploymentnIhvEmphis_EH_PT");
									CareerOpportunities_CSC.TC_44_CS_Validate_Radioptn_PreEmploymentnIhvEmphis_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
									context.setAttribute("fileName", "CS_Validate_Radioptn_PreEmploymentnIhvEmphis_EH_PT");
									driver.quit();
									break;


		case "CS_Validate_Field_EmploymentGapExp_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Field_EmploymentGapExp_EH_PT");
									CareerOpportunities_CSC.TC_45_CS_Validate_Field_EmploymentGapExp_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
									context.setAttribute("fileName", "CS_Validate_Field_EmploymentGapExp_EH_PT");
									driver.quit();
									break;


		case "CS_Validate_Field_IWillUploadMyResume_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Field_IWillUploadMyResume_EH_PT");
									CareerOpportunities_CSC.TC_46_CS_Validate_Field_IWillUploadMyResume_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
									context.setAttribute("fileName", "CS_Validate_Field_IWillUploadMyResume_EH_PT");
									driver.quit();
									break;


		case "CS_Validate_Text_Resume_OnClickofIwillupload_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Text_Resume_OnClickofIwillupload_EH_PT");
									CareerOpportunities_CSC.TC_47_CS_Validate_Text_Resume_OnClickofIwillupload_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
									context.setAttribute("fileName", "CS_Validate_Text_Resume_OnClickofIwillupload_EH_PT");
									driver.quit();
									break;


		case "CS_Validate_Text_FileMustbfull_OnClickofIwillupload_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Text_FileMustbfull_OnClickofIwillupload_EH_PT");
									CareerOpportunities_CSC.TC_48_CS_Validate_Text_FileMustbfull_OnClickofIwillupload_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
									context.setAttribute("fileName", "CS_Validate_Text_FileMustbfull_OnClickofIwillupload_EH_PT");
									driver.quit();
									break;


		case "CS_Validate_Btn_ChooseFile_OnClickofIwillupload_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Btn_ChooseFile_OnClickofIwillupload_EH_PT");
									CareerOpportunities_CSC.TC_49_CS_Validate_Btn_ChooseFile_OnClickofIwillupload_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
									context.setAttribute("fileName", "CS_Validate_Btn_ChooseFile_OnClickofIwillupload_EH_PT");
									driver.quit();
									break;


		case "CS_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EH_PT":
									context.setAttribute("fileName", "CS_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EH_PT");
									CareerOpportunities_CSC.TC_50_CS_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
									context.setAttribute("fileName", "CS_Validate_UploadFile_ChooseFile_OnClickofIwillupload_EH_PT");
									driver.quit();
									break;
									
									case "CS_Validate_Text_EnterEmpHistory_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Text_EnterEmpHistory_EH_PT");
									CareerOpportunities_CSC.TC_51_CS_Validate_Text_EnterEmpHistory_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
									context.setAttribute("fileName", "CS_Validate_Text_EnterEmpHistory_EH_PT");
									driver.quit();
									break;
									
									case "CS_Validate_Text_PreviousEmployer1_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Text_PreviousEmployer1_EH_PT");
									CareerOpportunities_CSC.TC_52_CS_Validate_Text_PreviousEmployer1_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
									context.setAttribute("fileName", "CS_Validate_Text_PreviousEmployer1_EH_PT");
									driver.quit();
									break;
									
									case "CS_Validate_Fields_UnderPreviousEmployer1_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Fields_UnderPreviousEmployer1_EH_PT");
									CareerOpportunities_CSC.TC_53_CS_Validate_Fields_UnderPreviousEmployer1_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input );
									context.setAttribute("fileName", "CS_Validate_Fields_UnderPreviousEmployer1_EH_PT");
									driver.quit();
									break;	
									
									
									case "CS_Validate_FieldsInputs_UnderPreviousEmployer1_EH_PT":
									context.setAttribute("fileName", "CS_Validate_FieldsInputs_UnderPreviousEmployer1_EH_PT");
									CareerOpportunities_CSC.TC_54_CS_Validate_FieldsInputs_UnderPreviousEmployer1_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_FieldsInputs_UnderPreviousEmployer1_EH_PT");
									driver.quit();
									break;	
									
									
									case "CS_Validate_Text_BSpecific_NearReasonforLeaving_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Text_BSpecific_NearReasonforLeaving_EH_PT");
									CareerOpportunities_CSC.TC_55_CS_Validate_Text_BSpecific_NearReasonforLeaving_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_Text_BSpecific_NearReasonforLeaving_EH_PT");
									driver.quit();
									break;	
									
									
									case "CS_Validate_Text_ListofJobs_NearEmploymentDetail_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Text_ListofJobs_NearEmploymentDetail_EH_PT");
									CareerOpportunities_CSC.TC_56_CS_Validate_Text_ListofJobs_NearEmploymentDetail_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_Text_ListofJobs_NearEmploymentDetail_EH_PT");
									driver.quit();
									break;	
									
									case "CS_Validate_RadioOptions_CanbeContacted_EH_PT":
									context.setAttribute("fileName", "CS_Validate_RadioOptions_CanbeContacted_EH_PT");
									CareerOpportunities_CSC.TC_57_CS_Validate_RadioOptions_CanbeContacted_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_RadioOptions_CanbeContacted_EH_PT");
									driver.quit();
									break;	
									
									
									case "CS_Validate_Btn_AddEmployer2_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Btn_AddEmployer2_EH_PT");
									CareerOpportunities_CSC.TC_58_CS_Validate_Btn_AddEmployer2_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_Btn_AddEmployer2_EH_PT");
									driver.quit();
									break;	
									
									
									case "CS_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EH_PT");
									CareerOpportunities_CSC.TC_59_CS_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_Btn_RemoveEmp2_OnclickAddEmp2_EH_PT");
									driver.quit();
									break;	
									
									
									case "CS_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EH_PT");
									CareerOpportunities_CSC.TC_60_CS_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_Txt_PrevsEmp2_OnclickAddEmp2_EH_PT");
									driver.quit();
									break;	
									
									
									case "CS_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EH_PT");
									CareerOpportunities_CSC.TC_61_CS_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_Btn_AddEmplyer3_OnclickAddEmp2_EH_PT");
									driver.quit();
									break;	
									
									
									case "CS_Validate_Btn_RemovEmp3_OnclickAddEmp3_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Btn_RemovEmp3_OnclickAddEmp3_EH_PT");
									CareerOpportunities_CSC.TC_62_CS_Validate_Btn_RemovEmp3_OnclickAddEmp3_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_Btn_RemovEmp3_OnclickAddEmp3_EH_PT");
									driver.quit();
									break;	
									
									
									case "CS_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EH_PT");
									CareerOpportunities_CSC.TC_63_CS_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_Txt_PrevsEmp3_OnclickAddEmp3_EH_PT");
									driver.quit();
									break;	
									
										case "CS_Validate_OnClick_RemoveEmp3_EH_PT":
									context.setAttribute("fileName", "CS_Validate_OnClick_RemoveEmp3_EH_PT");
									CareerOpportunities_CSC.TC_64_CS_Validate_OnClick_RemoveEmp3_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_OnClick_RemoveEmp3_EH_PT");
									driver.quit();
									break;
									
									
											case "CS_Validate_OnClick_RemoveEmp2_EH_PT":
									context.setAttribute("fileName", "CS_Validate_OnClick_RemoveEmp2_EH_PT");
									CareerOpportunities_CSC.TC_65_CS_Validate_OnClick_RemoveEmp2_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_OnClick_RemoveEmp2_EH_PT");
									driver.quit();
									break;
									
									case "CS_Validate_Txt_ExpInfo_onClickPreviosbtn_EH_PT":
									context.setAttribute("fileName", "CS_Validate_Txt_ExpInfo_onClickPreviosbtn_EH_PT");
									CareerOpportunities_CSC.TC_66_CS_Validate_Txt_ExpInfo_onClickPreviosbtn_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_Txt_ExpInfo_onClickPreviosbtn_EH_PT");
									driver.quit();
									break;
									
									case "CS_Validate_onClickNextbtn_EH_PT":
									context.setAttribute("fileName", "CS_Validate_onClickNextbtn_EH_PT");
									CareerOpportunities_CSC.TC_67_CS_Validate_onClickNextbtn_EH_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_onClickNextbtn_EH_PT");
									driver.quit();
									break;
									
									case "CS_Validate_Text_LanguageSkills_LanguageSkills_PT":
									context.setAttribute("fileName", "CS_Validate_Text_LanguageSkills_LanguageSkills_PT");
									CareerOpportunities_CSC.TC_68_CS_Validate_Text_LanguageSkills_LanguageSkills_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_Text_LanguageSkills_LanguageSkills_PT");
									driver.quit();
									break;
									
									
									case "CS_Validate_Text_IncicateLang_LanguageSkills_PT":
									context.setAttribute("fileName", "CS_Validate_Text_IncicateLang_LanguageSkills_PT");
									CareerOpportunities_CSC.TC_69_CS_Validate_Text_IncicateLang_LanguageSkills_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_Text_IncicateLang_LanguageSkills_PT");
									driver.quit();
									break;
									
									
									case "CS_Validate_Languages_LanguageSkills_PT":
									context.setAttribute("fileName", "CS_Validate_Languages_LanguageSkills_PT");
									CareerOpportunities_CSC.TC_70_CS_Validate_Languages_LanguageSkills_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_Languages_LanguageSkills_PT");
									driver.quit();
									break;
									
									case "CS_Validate_OnClickPrvBtn_LanguageSkills_PT":
									context.setAttribute("fileName", "CS_Validate_OnClickPrvBtn_LanguageSkills_PT");
									CareerOpportunities_CSC.TC_71_CS_Validate_OnClickPrvBtn_LanguageSkills_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_OnClickPrvBtn_LanguageSkills_PT");
									driver.quit();
									break;
									
									
									case "CS_Validate_OnClickNextBtn_LanguageSkills_PT":
									context.setAttribute("fileName", "CS_Validate_OnClickNextBtn_LanguageSkills_PT");
									CareerOpportunities_CSC.TC_72_CS_Validate_OnClickNextBtn_LanguageSkills_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date );
									context.setAttribute("fileName", "CS_Validate_OnClickNextBtn_LanguageSkills_PT");
									driver.quit();
									break;							
							
									
									case "CS_Validate_Text_CareerOptions_CO_PT":
										context.setAttribute("fileName", "CS_Validate_Text_CareerOptions_CO_PT");
										CareerOpportunities_CSC.TC_73_CS_Validate_Text_CareerOptions_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
										context.setAttribute("fileName", "CS_Validate_Text_CareerOptions_CO_PT");
										driver.quit();
										break;					
							
							
									case "CS_Validate_Text_CrOpporUqualityfor_CO_PT":
										context.setAttribute("fileName", "CS_Validate_Text_CrOpporUqualityfor_CO_PT");
										CareerOpportunities_CSC.TC_74_CS_Validate_Text_CrOpporUqualityfor_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
										context.setAttribute("fileName", "CS_Validate_Text_CrOpporUqualityfor_CO_PT");
										driver.quit();
										break;					
							
							
									case "CS_Validate_Fieldson_CO_PT":
										context.setAttribute("fileName", "CS_Validate_Fieldson_CO_PT");
										CareerOpportunities_CSC.TC_75_CS_Validate_Fieldson_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
										context.setAttribute("fileName", "CS_Validate_Fieldson_CO_PT");
										driver.quit();
										break;					
									
									case "CS_Validate_RadioPartTimeFulltime_CO_PT":
										context.setAttribute("fileName", "CS_Validate_RadioPartTimeFulltime_CO_PT");
										CareerOpportunities_CSC.TC_76_CS_Validate_RadioPartTimeFulltime_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
										context.setAttribute("fileName", "CS_Validate_RadioPartTimeFulltime_CO_PT");
										driver.quit();
										break;					
									
									case "CS_Validate_CB_PersonalTrainer_CO_PT":
										context.setAttribute("fileName", "CS_Validate_CB_PersonalTrainer_CO_PT");
										CareerOpportunities_CSC.TC_77_CS_Validate_CB_PersonalTrainer_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
										context.setAttribute("fileName", "CS_Validate_CB_PersonalTrainer_CO_PT");
										driver.quit();
										break;					
									
							
									case "CS_Validate_RadioYesNo_RuNoworEverEmployed_CO_PT":
										context.setAttribute("fileName", "CS_Validate_RadioYesNo_RuNoworEverEmployed_CO_PT");
										CareerOpportunities_CSC.TC_78_CS_Validate_RadioYesNo_RuNoworEverEmployed_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
										context.setAttribute("fileName", "CS_Validate_RadioYesNo_RuNoworEverEmployed_CO_PT");
										driver.quit();
										break;					
									
							
									case "CS_Validate_Text_BasedonURsele_CO_PT":
										context.setAttribute("fileName", "CS_Validate_Text_BasedonURsele_CO_PT");
										CareerOpportunities_CSC.TC_79_CS_Validate_Text_BasedonURsele_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
										context.setAttribute("fileName", "CS_Validate_Text_BasedonURsele_CO_PT");
										driver.quit();
										break;					
									
							

									case "CS_Validate_Text_IfSReQuestionnaire_CO_PT":
										context.setAttribute("fileName", "CS_Validate_Text_IfSReQuestionnaire_CO_PT");
										CareerOpportunities_CSC.TC_80_CS_Validate_Text_IfSReQuestionnaire_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
										context.setAttribute("fileName", "CS_Validate_Text_IfSReQuestionnaire_CO_PT");
										driver.quit();
										break;					
									
							
									case "CS_Validate_Text_RehireQuestionnaire_CO_PT":
										context.setAttribute("fileName", "CS_Validate_Text_RehireQuestionnaire_CO_PT");
										CareerOpportunities_CSC.TC_81_CS_Validate_Text_RehireQuestionnaire_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
										context.setAttribute("fileName", "CS_Validate_Text_RehireQuestionnaire_CO_PT");
										driver.quit();
										break;	
							
							
							
									case "CS_Validate_Fields_UnderRehireQuestionnaire_CO_PT":
										context.setAttribute("fileName", "CS_Validate_Fields_UnderRehireQuestionnaire_CO_PT");
										CareerOpportunities_CSC.TC_82_CS_Validate_Fields_UnderRehireQuestionnaire_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date );
										context.setAttribute("fileName", "CS_Validate_Fields_UnderRehireQuestionnaire_CO_PT");
										driver.quit();
										break;	
							
							
									case "CS_Validate_FieldInputs_UnderRehireQuestionnaire_CO_PT":
										context.setAttribute("fileName", "CS_Validate_FieldInputs_UnderRehireQuestionnaire_CO_PT");
										CareerOpportunities_CSC.TC_83_CS_Validate_FieldInputs_UnderRehireQuestionnaire_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
										context.setAttribute("fileName", "CS_Validate_FieldInputs_UnderRehireQuestionnaire_CO_PT");
										driver.quit();
										break;	
							
							
									case "CS_Validate_Dropdown_HwdidUresignEmpwitUs_CO_PT":
										context.setAttribute("fileName", "CS_Validate_Dropdown_HwdidUresignEmpwitUs_CO_PT");
										CareerOpportunities_CSC.TC_84_CS_Validate_Dropdown_HwdidUresignEmpwitUs_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
										context.setAttribute("fileName", "CS_Validate_Dropdown_HwdidUresignEmpwitUs_CO_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_OnClickPrvBtn_CO_PT":
										context.setAttribute("fileName", "CS_Validate_OnClickPrvBtn_CO_PT");
										CareerOpportunities_CSC.TC_85_CS_Validate_OnClickPrvBtn_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
										context.setAttribute("fileName", "CS_Validate_OnClickPrvBtn_CO_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_OnClickNextBtn_CO_PT":
										context.setAttribute("fileName", "CS_Validate_OnClickNextBtn_CO_PT");
										CareerOpportunities_CSC.TC_86_CS_Validate_OnClickNextBtn_CO_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason );
										context.setAttribute("fileName", "CS_Validate_OnClickNextBtn_CO_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_Text_EqualOpportunityEmpy_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Text_EqualOpportunityEmpy_EOE_PT");
										CareerOpportunities_CSC.TC_87_CS_Validate_Text_EqualOpportunityEmpy_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
										context.setAttribute("fileName", "CS_Validate_Text_EqualOpportunityEmpy_EOE_PT");
										driver.quit();
										break;	
							
							
									case "CS_Validate_Text_TheCompanyisan_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Text_TheCompanyisan_EOE_PT");
										CareerOpportunities_CSC.TC_88_CS_Validate_Text_TheCompanyisan_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
										context.setAttribute("fileName", "CS_Validate_Text_TheCompanyisan_EOE_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_Text_CompletionOfForm_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Text_CompletionOfForm_EOE_PT");
										CareerOpportunities_CSC.TC_89_CS_Validate_Text_CompletionOfForm_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
										context.setAttribute("fileName", "CS_Validate_Text_CompletionOfForm_EOE_PT");
										driver.quit();
										break;	
										
									case "CS_Validate_Fields_EqualOEmpSection_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Fields_EqualOEmpSection_EOE_PT");
										CareerOpportunities_CSC.TC_90_CS_Validate_Fields_EqualOEmpSection_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason );
										context.setAttribute("fileName", "CS_Validate_Fields_EqualOEmpSection_EOE_PT");
										driver.quit();
										break;	
							
							
									case "CS_Validate_DDValues_WtisUrGender_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_DDValues_WtisUrGender_EOE_PT");
										CareerOpportunities_CSC.TC_91_CS_Validate_DDValues_WtisUrGender_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5 );
										context.setAttribute("fileName", "CS_Validate_DDValues_WtisUrGender_EOE_PT");
										driver.quit();
										break;	
							
							
							
									case "CS_Validate_DDValues_WtyourRaceEthnicOrigin_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_DDValues_WtyourRaceEthnicOrigin_EOE_PT");
										CareerOpportunities_CSC.TC_92_CS_Validate_DDValues_WtyourRaceEthnicOrigin_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
										context.setAttribute("fileName", "CS_Validate_DDValues_WtyourRaceEthnicOrigin_EOE_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_Text_HispanicorLatino_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Text_HispanicorLatino_EOE_PT");
										CareerOpportunities_CSC.TC_93_CS_Validate_Text_HispanicorLatino_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
										context.setAttribute("fileName", "CS_Validate_Text_HispanicorLatino_EOE_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_Text_WhiteNotHispanicorLatino_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Text_WhiteNotHispanicorLatino_EOE_PT");
										CareerOpportunities_CSC.TC_94_CS_Validate_Text_WhiteNotHispanicorLatino_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
										context.setAttribute("fileName", "CS_Validate_Text_WhiteNotHispanicorLatino_EOE_PT");
										driver.quit();
										break;	
							
							
									case "CS_Validate_Text_BlackorAfricanAmerican_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Text_BlackorAfricanAmerican_EOE_PT");
										CareerOpportunities_CSC.TC_95_CS_Validate_Text_BlackorAfricanAmerican_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
										context.setAttribute("fileName", "CS_Validate_Text_BlackorAfricanAmerican_EOE_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_Text_NativeHawaiianorOtherPacific_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Text_NativeHawaiianorOtherPacific_EOE_PT");
										CareerOpportunities_CSC.TC_96_CS_Validate_Text_NativeHawaiianorOtherPacific_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
										context.setAttribute("fileName", "CS_Validate_Text_NativeHawaiianorOtherPacific_EOE_PT");
										driver.quit();
										break;	
										
										
									case "CS_Validate_Text_AsianNotHispanicorLatino_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Text_AsianNotHispanicorLatino_EOE_PT");
										CareerOpportunities_CSC.TC_97_CS_Validate_Text_AsianNotHispanicorLatino_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
										context.setAttribute("fileName", "CS_Validate_Text_AsianNotHispanicorLatino_EOE_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_Text_AmericanIndianorAlaskanNative_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Text_AmericanIndianorAlaskanNative_EOE_PT");
										CareerOpportunities_CSC.TC_98_CS_Validate_Text_AmericanIndianorAlaskanNative_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
										context.setAttribute("fileName", "CS_Validate_Text_AmericanIndianorAlaskanNative_EOE_PT");
										driver.quit();
										break;	
										
									case "CS_Validate_Text_Allpersonswho_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Text_Allpersonswho_EOE_PT");
										CareerOpportunities_CSC.TC_99_CS_Validate_Text_Allpersonswho_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
										context.setAttribute("fileName", "CS_Validate_Text_Allpersonswho_EOE_PT");
										driver.quit();
										break;	
							
							
									case "CS_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE_PT");
										CareerOpportunities_CSC.TC_100_CS_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data4 );
										context.setAttribute("fileName", "CS_Validate_Radiobtn_DoyouwishtoCompleteThisForm_EOE_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_Fieldinputs_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_Fieldinputs_EOE_PT");
										CareerOpportunities_CSC.TC_101_CS_Validate_Fieldinputs_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
										context.setAttribute("fileName", "CS_Validate_Fieldinputs_EOE_PT");
										driver.quit();
										break;	
							
							
							
									case "CS_Validate_PreviBtn_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_PreviBtn_EOE_PT");
										CareerOpportunities_CSC.TC_102_CS_Validate_PreviBtn_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
										context.setAttribute("fileName", "CS_Validate_PreviBtn_EOE_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_NextBtn_EOE_PT":
										context.setAttribute("fileName", "CS_Validate_NextBtn_EOE_PT");
										CareerOpportunities_CSC.TC_103_CS_Validate_NextBtn_EOE_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
										context.setAttribute("fileName", "CS_Validate_NextBtn_EOE_PT");
										driver.quit();
										break;	
							
							
									case "CS_Validate_Text_ApplicationStatement_AS_PT":
										context.setAttribute("fileName", "CS_Validate_Text_ApplicationStatement_AS_PT");
										CareerOpportunities_CSC.TC_104_CS_Validate_Text_ApplicationStatement_AS_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
										context.setAttribute("fileName", "CS_Validate_Text_ApplicationStatement_AS_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_Text_ThisApplicationCompletePar_AS_PT":
										context.setAttribute("fileName", "CS_Validate_Text_ThisApplicationCompletePar_AS_PT");
										CareerOpportunities_CSC.TC_105_CS_Validate_Text_ThisApplicationCompletePar_AS_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4 );
										context.setAttribute("fileName", "CS_Validate_Text_ThisApplicationCompletePar_AS_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_input_FirstNameLastName_acknowledgeline_AS_PT":
										context.setAttribute("fileName", "CS_Validate_input_FirstNameLastName_acknowledgeline_AS_PT");
										CareerOpportunities_CSC.TC_106_CS_Validate_input_FirstNameLastName_acknowledgeline_AS_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_input_FirstNameLastName_acknowledgeline_AS_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_text_Iacknowledge_AS_PT":
										context.setAttribute("fileName", "CS_Validate_text_Iacknowledge_AS_PT");
										CareerOpportunities_CSC.TC_107_CS_Validate_text_Iacknowledge_AS_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_text_Iacknowledge_AS_PT");
										driver.quit();
										break;	
							
							
									case "CS_Validate_Previbtn_AS_PT":
										context.setAttribute("fileName", "CS_Validate_Previbtn_AS_PT");
										CareerOpportunities_CSC.TC_108_CS_Validate_Previbtn_AS_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Previbtn_AS_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_Nextbtn_AS_PT":
										context.setAttribute("fileName", "CS_Validate_Nextbtn_AS_PT");
										CareerOpportunities_CSC.TC_109_CS_Validate_Nextbtn_AS_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Nextbtn_AS_PT");
										driver.quit();
										break;	
							
									case "CS_Validate_Text_ArbitationnDispute_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_ArbitationnDispute_AandD_PT");
										CareerOpportunities_CSC.TC_110_CS_Validate_Text_ArbitationnDispute_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_ArbitationnDispute_AandD_PT");
										driver.quit();
										break;	
										
									case "CS_Validate_Text_Asaconditionofconsideration_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_Asaconditionofconsideration_AandD_PT");
										CareerOpportunities_CSC.TC_111_CS_Validate_Text_Asaconditionofconsideration_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_Asaconditionofconsideration_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Link_DisputeResolutionRulesandProcedures_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Link_DisputeResolutionRulesandProcedures_AandD_PT");
										CareerOpportunities_CSC.TC_112_CS_Validate_Link_DisputeResolutionRulesandProcedures_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Link_DisputeResolutionRulesandProcedures_AandD_PT");
										driver.quit();
										break;
									
									case "CS_Validate_Text_FITNESSINTERNATIONAL_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_FITNESSINTERNATIONAL_AandD_PT");
										CareerOpportunities_CSC.TC_113_CS_Validate_Text_FITNESSINTERNATIONAL_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_FITNESSINTERNATIONAL_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Text_IrecognizeThatDifferences_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_IrecognizeThatDifferences_AandD_PT");
										CareerOpportunities_CSC.TC_114_CS_Validate_Text_IrecognizeThatDifferences_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_IrecognizeThatDifferences_AandD_PT");
										driver.quit();
										break;
										
										
									case "CS_Validate_Text_IunderstandthatifIdofile_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_IunderstandthatifIdofile_AandD_PT");
										CareerOpportunities_CSC.TC_115_CS_Validate_Text_IunderstandthatifIdofile_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_IunderstandthatifIdofile_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Text_IFurtherUnderstandAgreeThat_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_IFurtherUnderstandAgreeThat_AandD_PT");
										CareerOpportunities_CSC.TC_116_CS_Validate_Text_IFurtherUnderstandAgreeThat_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_IFurtherUnderstandAgreeThat_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Text_IHvReadThisAgreeAndUnderstand_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_IHvReadThisAgreeAndUnderstand_AandD_PT");
										CareerOpportunities_CSC.TC_117_CS_Validate_Text_IHvReadThisAgreeAndUnderstand_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_IHvReadThisAgreeAndUnderstand_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Text_IAGreenAcknReceipt_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_IAGreenAcknReceipt_AandD_PT");
										CareerOpportunities_CSC.TC_118_CS_Validate_Text_IAGreenAcknReceipt_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_IAGreenAcknReceipt_AandD_PT");
										driver.quit();
										break;
										
										
									case "CS_Validate_Text_DateweekMonth_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_DateweekMonth_AandD_PT");
										CareerOpportunities_CSC.TC_119_CS_Validate_Text_DateweekMonth_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_DateweekMonth_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Text_PrintName_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_PrintName_AandD_PT");
										CareerOpportunities_CSC.TC_120_CS_Validate_Text_PrintName_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_PrintName_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Text_FitnessInternatlLLCagreestofollow_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_FitnessInternatlLLCagreestofollow_AandD_PT");
										CareerOpportunities_CSC.TC_121_CS_Validate_Text_FitnessInternatlLLCagreestofollow_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_FitnessInternatlLLCagreestofollow_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_ImgSign_RobertBryant_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_ImgSign_RobertBryant_AandD_PT");
										CareerOpportunities_CSC.TC_122_CS_Validate_ImgSign_RobertBryant_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_ImgSign_RobertBryant_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Text_ByClickingBelow_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_ByClickingBelow_AandD_PT");
										CareerOpportunities_CSC.TC_123_CS_Validate_Text_ByClickingBelow_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_ByClickingBelow_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Previbtn_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Previbtn_AandD_PT");
										CareerOpportunities_CSC.TC_124_CS_Validate_Previbtn_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Previbtn_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Btn_IAgree_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Btn_IAgree_AandD_PT");
										CareerOpportunities_CSC.TC_125_CS_Validate_Btn_IAgree_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Btn_IAgree_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Text_UrSubmittionWasSuccessful_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_UrSubmittionWasSuccessful_AandD_PT");
										CareerOpportunities_CSC.TC_126_CS_Validate_Text_UrSubmittionWasSuccessful_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_UrSubmittionWasSuccessful_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Text_ThankUforUrIntrest_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_ThankUforUrIntrest_AandD_PT");
										CareerOpportunities_CSC.TC_127_CS_Validate_Text_ThankUforUrIntrest_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_ThankUforUrIntrest_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Text_FitnessInternatiolLLC_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Text_FitnessInternatiolLLC_AandD_PT");
										CareerOpportunities_CSC.TC_128_CS_Validate_Text_FitnessInternatiolLLC_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Text_FitnessInternatiolLLC_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Btn_PrintUrApplication_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Btn_PrintUrApplication_AandD_PT");
										CareerOpportunities_CSC.TC_129_CS_Validate_Btn_PrintUrApplication_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Btn_PrintUrApplication_AandD_PT");
										driver.quit();
										break;
										
									case "CS_Validate_Last_Page_AandD_PT":
										context.setAttribute("fileName", "CS_Validate_Last_Page_AandD_PT");
										CareerOpportunities_CSC.TC_130_CS_Validate_Last_Page_AandD_PT(testdata.get("TextMessage").toString(),Dropdown_values, F_Name,L_Name,Email,Email,Phone,Address,Zipcode,E_EducationLeve_Dropdown,Personal_Training_ExperienceDPValues,Certification_IssuedByDPValues,Text_input,From_date,To_date,Leaving_Reason,input_data5,input_data4,Full_name );
										context.setAttribute("fileName", "CS_Validate_Last_Page_AandD_PT");
										driver.quit();
										break;
						
			
							

					
					// Apply Here - Irshad
					
					
					
				case "Validate_Navigate_to_CO_page_CSC":
					
					context.setAttribute("fileName", "Validate_Navigate_to_CO_page_CSC");
					Home.Validate_Navigate_to_CO_page_CSC(testdata.get("TextMessage").toString());
					context.setAttribute("fileName", "Validate_Navigate_to_CO_page_CSC");
					driver.quit();break;
					
					
				case "Validate_CO_heading_para":
					
					context.setAttribute("fileName", "Validate_CO_heading_para");
					CareerOpportunities_CSC.Validate_CO_heading_para(testdata.get("TextMessage").toString(), Text_input,input_data );
					context.setAttribute("fileName", "Validate_CO_heading_para");
					driver.quit();break;
					
					
				case "Validate_Club_positions":
					
					context.setAttribute("fileName", "Validate_Club_positions");
					CareerOpportunities_CSC.Validate_Club_positions(testdata.get("TextMessage").toString(), additional_input );
					context.setAttribute("fileName", "Validate_Club_positions");
					driver.quit();break;
					
				case "Validate_details_of_Personal_Trainer_position":
					
					context.setAttribute("fileName", "Validate_details_of_Personal_Trainer_position");
					CareerOpportunities_CSC.Validate_details_of_Personal_Trainer_position(testdata.get("TextMessage").toString(), additional_input, Job_short_des );
					context.setAttribute("fileName", "Validate_details_of_Personal_Trainer_position");
					driver.quit();break;
					
					
				case "Validate_details_of_Group_Fitness_position":
					
					context.setAttribute("fileName", "Validate_details_of_Group_Fitness_position");
					CareerOpportunities_CSC.Validate_details_of_Group_Fitness_position(testdata.get("TextMessage").toString(), additional_input, Job_short_des );
					context.setAttribute("fileName", "Validate_details_of_Group_Fitness_position");
					driver.quit();break;
					
					
				case "Validate_moreinfo_popupwindow_of_PTP":
					
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_PTP");
					CareerOpportunities_CSC.Validate_moreinfo_popupwindow_of_PTP(testdata.get("TextMessage").toString(), additional_input, Job_short_des, Job_long_des );
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_PTP");
					driver.quit();break;
					
					
				case "Validate_moreinfo_popupwindow_of_GFP":
					
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_GFP");
					CareerOpportunities_CSC.Validate_moreinfo_popupwindow_of_GFP(testdata.get("TextMessage").toString(), additional_input, Job_short_des, Job_long_des );
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_GFP");
					driver.quit();break;
					
									
				case "Validate_AH_btn_followingpos_text":
					
					context.setAttribute("fileName", "Validate_AH_btn_followingpos_text");
					CareerOpportunities_CSC.Validate_AH_btn_followingpos_text(testdata.get("TextMessage").toString(), additional_input, input_data );
					context.setAttribute("fileName", "Validate_AH_btn_followingpos_text");
					driver.quit();break;
					
					
				case "Validate_details_of_GM":
					
					context.setAttribute("fileName", "Validate_details_of_GM");
					CareerOpportunities_CSC.Validate_details_of_GM(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des );
					context.setAttribute("fileName", "Validate_details_of_GM");
					driver.quit();break;
					
					
				case "Validate_details_of_PTD":
					
					context.setAttribute("fileName", "Validate_details_of_PTD");
					CareerOpportunities_CSC.Validate_details_of_PTD(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des );
					context.setAttribute("fileName", "Validate_details_of_PTD");
					driver.quit();break;
					
					
				case "Validate_details_of_OM":
					
					context.setAttribute("fileName", "Validate_details_of_OM");
					CareerOpportunities_CSC.Validate_details_of_OM(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des );
					context.setAttribute("fileName", "Validate_details_of_OM");
					driver.quit();break;
					
					
				case "Validate_details_of_ET":
					
					context.setAttribute("fileName", "Validate_details_of_ET");
					CareerOpportunities_CSC.Validate_details_of_ET(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des );
					context.setAttribute("fileName", "Validate_details_of_ET");
					driver.quit();break;
					
				case "Validate_details_of_LSD":
					
					context.setAttribute("fileName", "Validate_details_of_LSD");
					CareerOpportunities_CSC.Validate_details_of_LSD(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des );
					context.setAttribute("fileName", "Validate_details_of_LSD");
					driver.quit();break;
					
				case "Validate_details_of_MC":
					
					context.setAttribute("fileName", "Validate_details_of_MC");
					CareerOpportunities_CSC.Validate_details_of_MC(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des );
					context.setAttribute("fileName", "Validate_details_of_MC");
					driver.quit();break;
					
				case "Validate_details_of_PTMC":
					
					context.setAttribute("fileName", "Validate_details_of_PTMC");
					CareerOpportunities_CSC.Validate_details_of_PTMC(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des );
					context.setAttribute("fileName", "Validate_details_of_PTMC");
					driver.quit();break;
					
				case "Validate_details_of_CS":
					
					context.setAttribute("fileName", "Validate_details_of_CS");
					CareerOpportunities_CSC.Validate_details_of_CS(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des );
					context.setAttribute("fileName", "Validate_details_of_CS");
					driver.quit();break;
					
				case "Validate_details_of_HVAC_BM":
					
					context.setAttribute("fileName", "Validate_details_of_HVAC_BM");
					CareerOpportunities_CSC.Validate_details_of_HVAC_BM(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des );
					context.setAttribute("fileName", "Validate_details_of_HVAC_BM");
					driver.quit();break;
					
				case "Validate_details_of_CP_J":
					
					context.setAttribute("fileName", "Validate_details_of_CP_J");
					CareerOpportunities_CSC.Validate_details_of_CP_J(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des );
					context.setAttribute("fileName", "Validate_details_of_CP_J");
					driver.quit();break;
					
					
				case "Validate_moreinfo_popupwindow_of_GM":
					
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_GM");
					CareerOpportunities_CSC.Validate_moreinfo_popupwindow_of_GM(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des, Job_long_des );
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_GM");
					driver.quit();break;
					
					
				case "Validate_moreinfo_popupwindow_of_OM":
					
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_OM");
					CareerOpportunities_CSC.Validate_moreinfo_popupwindow_of_OM(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des, Job_long_des );
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_OM");
					driver.quit();break;
					
					
				case "Validate_moreinfo_popupwindow_of_PTD":
					
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_PTD");
					CareerOpportunities_CSC.Validate_moreinfo_popupwindow_of_PTD(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des, Job_long_des );
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_PTD");
					driver.quit();break;
					
				case "Validate_moreinfo_popupwindow_of_MC":
					
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_MC");
					CareerOpportunities_CSC.Validate_moreinfo_popupwindow_of_MC(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des, Job_long_des );
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_MC");
					driver.quit();break;
					
					
				case "Validate_moreinfo_popupwindow_of_PTMC":
					
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_PTMC");
					CareerOpportunities_CSC.Validate_moreinfo_popupwindow_of_PTMC(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des, Job_long_des );
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_PTMC");
					driver.quit();break;
					
				case "Validate_moreinfo_popupwindow_of_CS":
					
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_CS");
					CareerOpportunities_CSC.Validate_moreinfo_popupwindow_of_CS(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des, Job_long_des );
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_CS");
					driver.quit();break;
					
				case "Validate_moreinfo_popupwindow_of_LSD":
					
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_LSD");
					CareerOpportunities_CSC.Validate_moreinfo_popupwindow_of_LSD(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des, Job_long_des );
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_LSD");
					driver.quit();break;
					
				case "Validate_moreinfo_popupwindow_of_ET":
					
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_ET");
					CareerOpportunities_CSC.Validate_moreinfo_popupwindow_of_ET(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des, Job_long_des );
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_ET");
					driver.quit();break;
					
				case "Validate_moreinfo_popupwindow_of_HVAC_BM":
					
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_HVAC_BM");
					CareerOpportunities_CSC.Validate_moreinfo_popupwindow_of_HVAC_BM(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des, Job_long_des );
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_HVAC_BM");
					driver.quit();break;
					
				case "Validate_moreinfo_popupwindow_of_CP_J":
					
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_CP_J");
					CareerOpportunities_CSC.Validate_moreinfo_popupwindow_of_CP_J(testdata.get("TextMessage").toString(), additional_input, input_data, input_data1, Job_short_des, Job_long_des );
					context.setAttribute("fileName", "Validate_moreinfo_popupwindow_of_CP_J");
					driver.quit();break;
					
					
				case "Validate_AH_btn_under_club_pos":
					
					context.setAttribute("fileName", "Validate_AH_btn_under_club_pos");
					CareerOpportunities_CSC.Validate_AH_btn_under_club_pos(testdata.get("TextMessage").toString(), additional_input, input_data );
					context.setAttribute("fileName", "Validate_AH_btn_under_club_pos");
					driver.quit();break;
					
					
				case "Validate_emp_para_AH":
					
					context.setAttribute("fileName", "Validate_emp_para_AH");
					CareerOpportunities_CSC.Validate_emp_para_AH(testdata.get("TextMessage").toString(), additional_input, input_data, Text_input );
					context.setAttribute("fileName", "Validate_emp_para_AH");
					driver.quit();break;
					
					
					
				case "Validate_App_info_text_AH":
					
					context.setAttribute("fileName", "Validate_App_info_text_AH");
					CareerOpportunities_CSC.Validate_App_info_text_AH(testdata.get("TextMessage").toString(), additional_input, input_data, Text_input );
					context.setAttribute("fileName", "Validate_App_info_text_AH");
					driver.quit();break;
					
					
				case "Validate_all_ip_fields_in_emp_page_AH":
					
					context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_AH");
					CareerOpportunities_CSC.Validate_all_ip_fields_in_emp_page_AH(testdata.get("TextMessage").toString(), additional_input, input_data );
					context.setAttribute("fileName", "Validate_all_ip_fields_in_emp_page_AH");
					driver.quit();break;
					
					
				case "Validate_Howdidyouhearaboutus_dd_AH":
					
					context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_AH");
					CareerOpportunities_CSC.Validate_Howdidyouhearaboutus_dd_AH(testdata.get("TextMessage").toString(), additional_input, input_data, Dropdown_values );
					context.setAttribute("fileName", "Validate_Howdidyouhearaboutus_dd_AH");
					driver.quit();break;
					
					
				case "Validate_Radiobtn18YearsOld_options_AH":
					
					context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_AH");
					CareerOpportunities_CSC.Validate_Radiobtn18YearsOld_options_AH(testdata.get("TextMessage").toString(), additional_input, input_data );
					context.setAttribute("fileName", "Validate_Radiobtn18YearsOld_options_AH");
					driver.quit();break;
					
					
				case "Validate_US_format_text_AH":
					
					context.setAttribute("fileName", "Validate_US_format_text_AH");
					CareerOpportunities_CSC.Validate_US_format_text_AH(testdata.get("TextMessage").toString(), additional_input, input_data, Text_input );
					context.setAttribute("fileName", "Validate_US_format_text_AH");
					driver.quit();break;
					
				case "Validate_Miles_text_AH":
					
					context.setAttribute("fileName", "Validate_Miles_text_AH");
					CareerOpportunities_CSC.Validate_Miles_text_AH(testdata.get("TextMessage").toString(), additional_input, input_data, Text_input );
					context.setAttribute("fileName", "Validate_Miles_text_AH");
					driver.quit();break;
					
				case "Validate_phone_errorlabel_AH":
					
					context.setAttribute("fileName", "Validate_phone_errorlabel_AH");
					CareerOpportunities_CSC.Validate_phone_errorlabel_AH(testdata.get("TextMessage").toString(), additional_input, input_data, Text_input );
					context.setAttribute("fileName", "Validate_phone_errorlabel_AH");
					driver.quit();break;
					
				case "Validate_Next_step_btn_in_l1_AH":
					
					context.setAttribute("fileName", "Validate_Next_step_btn_in_l1_AH");
					CareerOpportunities_CSC.Validate_Next_step_btn_in_l1_AH(testdata.get("TextMessage").toString(), additional_input, input_data );
					context.setAttribute("fileName", "Validate_Next_step_btn_in_l1_AH");
					driver.quit();break;
					
					
				case "Validate_input_in_all_fields_AH":
					
					context.setAttribute("fileName", "Validate_input_in_all_fields_AH");
					CareerOpportunities_CSC.Validate_input_in_all_fields_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode );
					context.setAttribute("fileName", "Validate_input_in_all_fields_AH");
					driver.quit();break;
					
					
				case "Validate_List18YrsOld_No_popupalrt_AH":
					
					context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_AH");
					CareerOpportunities_CSC.Validate_List18YrsOld_No_popupalrt_AH(testdata.get("TextMessage").toString(), additional_input, input_data, Radiobtn18YearsOld );
					context.setAttribute("fileName", "Validate_List18YrsOld_No_popupalrt_AH");
					driver.quit();break;
					
					
				case "Validate_Next_step_l1_AH":
					
					context.setAttribute("fileName", "Validate_Next_step_l1_AH");
					CareerOpportunities_CSC.Validate_Next_step_l1_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input );
					context.setAttribute("fileName", "Validate_Next_step_l1_AH");
					driver.quit();break;
					
					
					
				case "Validate_education_level_dd_AH":
					
					context.setAttribute("fileName", "Validate_education_level_dd_AH");
					CareerOpportunities_CSC.Validate_education_level_dd_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input );
					context.setAttribute("fileName", "Validate_education_level_dd_AH");
					driver.quit();break;
					
					
					
				case "Validate_edu_level_dd_allvalues_AH":
					
					context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_AH");
					CareerOpportunities_CSC.Validate_edu_level_dd_allvalues_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_edu_level_dd_allvalues_AH");
					driver.quit();break;
					
					
				case "Validate_previous_next_step_btns_l2_AH":
					
					context.setAttribute("fileName", "Validate_previous_next_step_btns_l2_AH");
					CareerOpportunities_CSC.Validate_previous_next_step_btns_l2_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input );
					context.setAttribute("fileName", "Validate_previous_next_step_btns_l2_AH");
					driver.quit();break;
					
					
				case "Validate_previous_step_btn_l2_AH":
					
					context.setAttribute("fileName", "Validate_previous_step_btn_l2_AH");
					CareerOpportunities_CSC.Validate_previous_step_btn_l2_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input );
					context.setAttribute("fileName", "Validate_previous_step_btn_l2_AH");
					driver.quit();break;
					
					
				case "Validate_Next_step_btn_l2_AH":
					
					context.setAttribute("fileName", "Validate_Next_step_btn_l2_AH");
					CareerOpportunities_CSC.Validate_Next_step_btn_l2_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_Next_step_btn_l2_AH");
					driver.quit();break;
					
					
					
				case "Validate_Exp_info_text_in_l3_AH":
					
					context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_AH");
					CareerOpportunities_CSC.Validate_Exp_info_text_in_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , input_data1);
					context.setAttribute("fileName", "Validate_Exp_info_text_in_l3_AH");
					driver.quit();break;
					
					
				case "Validate_sales_mngnt_exp_text_in_l3_AH":
					
					context.setAttribute("fileName", "Validate_sales_mngnt_exp_text_in_l3_AH");
					CareerOpportunities_CSC.Validate_sales_mngnt_exp_text_in_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , input_data1);
					context.setAttribute("fileName", "Validate_sales_mngnt_exp_text_in_l3_AH");
					driver.quit();break;
					
					
				case "Validate_Equipment_Techn_exp_heading_l3_AH":
					
					context.setAttribute("fileName", "Validate_Equipment_Techn_exp_heading_l3_AH");
					CareerOpportunities_CSC.Validate_Equipment_Techn_exp_heading_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , input_data1);
					context.setAttribute("fileName", "Validate_Equipment_Techn_exp_heading_l3_AH");
					driver.quit();break;
					
				case "Validate_all_dropdowns_in_l3_AH":
					
					context.setAttribute("fileName", "Validate_all_dropdowns_in_l3_AH");
					CareerOpportunities_CSC.Validate_all_dropdowns_in_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_all_dropdowns_in_l3_AH");
					driver.quit();break;
					
					
					
				case "Validate_all_options_FSE_dd_l3_AH":
					
					context.setAttribute("fileName", "Validate_all_options_FSE_dd_l3_AH");
					CareerOpportunities_CSC.Validate_all_options_FSE_dd_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values);
					context.setAttribute("fileName", "Validate_all_options_FSE_dd_l3_AH");
					driver.quit();break;
					
					
				case "Validate_all_options_PTSE_dd_l3_AH":
					
					context.setAttribute("fileName", "Validate_all_options_PTSE_dd_l3_AH");
					CareerOpportunities_CSC.Validate_all_options_PTSE_dd_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values);
					context.setAttribute("fileName", "Validate_all_options_PTSE_dd_l3_AH");
					driver.quit();break;
					
					
					
				case "Validate_all_options_ME_dd_l3_AH":
					
					context.setAttribute("fileName", "Validate_all_options_ME_dd_l3_AH");
					CareerOpportunities_CSC.Validate_all_options_ME_dd_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values);
					context.setAttribute("fileName", "Validate_all_options_ME_dd_l3_AH");
					driver.quit();break;
					
					
				case "Validate_all_options_BE_dd_l3_AH":
					
					context.setAttribute("fileName", "Validate_all_options_BE_dd_l3_AH");
					CareerOpportunities_CSC.Validate_all_options_BE_dd_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values);
					context.setAttribute("fileName", "Validate_all_options_BE_dd_l3_AH");
					driver.quit();break;
					
					
				case "Validate_all_options_YE_dd_l3_AH":
					
					context.setAttribute("fileName", "Validate_all_options_YE_dd_l3_AH");
					CareerOpportunities_CSC.Validate_all_options_YE_dd_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values);
					context.setAttribute("fileName", "Validate_all_options_YE_dd_l3_AH");
					driver.quit();break;
					
					
				case "Validate_selecting_all_dds_in_l3_AH":
					
					context.setAttribute("fileName", "Validate_selecting_all_dds_in_l3_AH");
					CareerOpportunities_CSC.Validate_selecting_all_dds_in_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values);
					context.setAttribute("fileName", "Validate_selecting_all_dds_in_l3_AH");
					driver.quit();break;
					
					
				case "Validate_Skills_section_l3_AH":
					
					context.setAttribute("fileName", "Validate_Skills_section_l3_AH");
					CareerOpportunities_CSC.Validate_Skills_section_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data2, input_data1);
					context.setAttribute("fileName", "Validate_Skills_section_l3_AH");
					driver.quit();break;
					
					
				case "Validate_select_Skills_l3_AH":
					
					context.setAttribute("fileName", "Validate_select_Skills_l3_AH");
					CareerOpportunities_CSC.Validate_select_Skills_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1);
					context.setAttribute("fileName", "Validate_select_Skills_l3_AH");
					driver.quit();break;
					
				case "Validate_Skills_2_section_l3_AH":
					
					context.setAttribute("fileName", "Validate_Skills_2_section_l3_AH");
					CareerOpportunities_CSC.Validate_Skills_2_section_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values,input_data2, input_data1);
					context.setAttribute("fileName", "Validate_Skills_2_section_l3_AH");
					driver.quit();break;
					
				case "Validate_select_Skills_2_l3_AH":
					
					context.setAttribute("fileName", "Validate_select_Skills_2_l3_AH");
					CareerOpportunities_CSC.Validate_select_Skills_2_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1);
					context.setAttribute("fileName", "Validate_select_Skills_2_l3_AH");
					driver.quit();break;
					
					
				case "Validate_Prev_next_btns_l3_AH":
					
					context.setAttribute("fileName", "Validate_Prev_next_btns_l3_AH");
					CareerOpportunities_CSC.Validate_Prev_next_btns_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_Prev_next_btns_l3_AH");
					driver.quit();break;
					
					
				case "Validate_Next_step_in_l3_AH":
					
					context.setAttribute("fileName", "Validate_Next_step_in_l3_AH");
					CareerOpportunities_CSC.Validate_Next_step_in_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2);
					context.setAttribute("fileName", "Validate_Next_step_in_l3_AH");
					driver.quit();break;
					
					
				case "Validate_Prev_step_in_l3_AH":
					
					context.setAttribute("fileName", "Validate_Prev_step_in_l3_AH");
					CareerOpportunities_CSC.Validate_Prev_step_in_l3_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown );
					context.setAttribute("fileName", "Validate_Prev_step_in_l3_AH");
					driver.quit();break;
					
					
					

				case "Validate_EmpHis_PreEmp_texts_in_l4_AH":
					
					context.setAttribute("fileName", "Validate_EmpHis_PreEmp_texts_in_l4_AH");
					CareerOpportunities_CSC.Validate_EmpHis_PreEmp_texts_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2);
					context.setAttribute("fileName", "Validate_EmpHis_PreEmp_texts_in_l4_AH");
					driver.quit();break;
					
					

				case "Validate_rdobtns_of_EmpHis_in_l4_AH":
					
					context.setAttribute("fileName", "Validate_rdobtns_of_EmpHis_in_l4_AH");
					CareerOpportunities_CSC.Validate_rdobtns_of_EmpHis_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2);
					context.setAttribute("fileName", "Validate_rdobtns_of_EmpHis_in_l4_AH");
					driver.quit();break;
					
					
				case "Validate_upload_res_chkbx_in_l4_AH":
					
					context.setAttribute("fileName", "Validate_upload_res_chkbx_in_l4_AH");
					CareerOpportunities_CSC.Validate_upload_res_chkbx_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2);
					context.setAttribute("fileName", "Validate_upload_res_chkbx_in_l4_AH");
					driver.quit();break;
					
					
					
				case "Validate_upload_res_section_in_l4_AH":
					
					context.setAttribute("fileName", "Validate_upload_res_section_in_l4_AH");
					CareerOpportunities_CSC.Validate_upload_res_section_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, input_data3);
					context.setAttribute("fileName", "Validate_upload_res_section_in_l4_AH");
					driver.quit();break;
					
					
					
				case "Validate_upload_res_file_l4_AH":
					
					context.setAttribute("fileName", "Validate_upload_res_file_l4_AH");
					CareerOpportunities_CSC.Validate_upload_res_file_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, input_data3, File_name);
					context.setAttribute("fileName", "Validate_upload_res_file_l4_AH");
					driver.quit();break;
					
					
				case "Validate_cur_prev_emp_texts_in_l4_AH":
					
					context.setAttribute("fileName", "Validate_cur_prev_emp_texts_in_l4_AH");
					CareerOpportunities_CSC.Validate_cur_prev_emp_texts_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, input_data3);
					context.setAttribute("fileName", "Validate_cur_prev_emp_texts_in_l4_AH");
					driver.quit();break;
					
					
				case "Validate_all_ip_fields_in_l4_AH":
					
					context.setAttribute("fileName", "Validate_all_ip_fields_in_l4_AH");
					CareerOpportunities_CSC.Validate_all_ip_fields_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2);
					context.setAttribute("fileName", "Validate_all_ip_fields_in_l4_AH");
					driver.quit();break;
					
					
					case "Validate_input_inallfields_in_l4_AH":
						
					context.setAttribute("fileName", "Validate_input_inallfields_in_l4_AH");
					CareerOpportunities_CSC.Validate_input_inallfields_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button);
					context.setAttribute("fileName", "Validate_input_inallfields_in_l4_AH");
					driver.quit();break;

					
					case "Validate_prev_next_step_btns_in_l4_AH":
						
						context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_AH");
						CareerOpportunities_CSC.Validate_prev_next_step_btns_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2);
						context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l4_AH");
						driver.quit();break;
						
						
					case "Validate_AddEmployer_2_btn_in_l4_AH":
						
						context.setAttribute("fileName", "Validate_AddEmployer_2_btn_in_l4_AH");
						CareerOpportunities_CSC.Validate_AddEmployer_2_btn_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2);
						context.setAttribute("fileName", "Validate_AddEmployer_2_btn_in_l4_AH");
						driver.quit();break;
						
						
						case "Validate_Next_btn_in_l4_AH":
							
						context.setAttribute("fileName", "Validate_Next_btn_in_l4_AH");
						CareerOpportunities_CSC.Validate_Next_btn_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box);
						context.setAttribute("fileName", "Validate_Next_btn_in_l4_AH");
						driver.quit();break;

						
					case "Validate_No_Prev_Emp_RdoBtn_in_l4_AH":
						
						context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_in_l4_AH");
						CareerOpportunities_CSC.Validate_No_Prev_Emp_RdoBtn_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2);
						context.setAttribute("fileName", "Validate_No_Prev_Emp_RdoBtn_in_l4_AH");
						driver.quit();break;
						
						
					case "Validate_prev_step_btn_in_l4_AH":
						
						context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_AH");
						CareerOpportunities_CSC.Validate_prev_step_btn_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2);
						context.setAttribute("fileName", "Validate_prev_step_btn_in_l4_AH");
						driver.quit();break;
						
						
					case "Validate_all_ip_fieldsofAddemplr2_in_l4_AH":
						
						context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr2_in_l4_AH");
						CareerOpportunities_CSC.Validate_all_ip_fieldsofAddemplr2_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2);
						context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr2_in_l4_AH");
						driver.quit();break;
						
						
					case "Validate_all_ip_fieldsofAddemplr3_in_l4_AH":
						
						context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr3_in_l4_AH");
						CareerOpportunities_CSC.Validate_all_ip_fieldsofAddemplr3_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2);
						context.setAttribute("fileName", "Validate_all_ip_fieldsofAddemplr3_in_l4_AH");
						driver.quit();break;
						
						
					case "Validate_removebtn2_by_ipingempr2_in_l4_AH":
						
					context.setAttribute("fileName", "Validate_removebtn2_by_ipingempr2_in_l4_AH");
					CareerOpportunities_CSC.Validate_removebtn2_by_ipingempr2_in_l4_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button);
					context.setAttribute("fileName", "Validate_removebtn2_by_ipingempr2_in_l4_AH");
					driver.quit();break;
						
					
					case "Validate_Ind_langs_text_l5_AH":
						
					context.setAttribute("fileName", "Validate_Ind_langs_text_l5_AH");
					CareerOpportunities_CSC.Validate_Ind_langs_text_l5_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, input_data3);
					context.setAttribute("fileName", "Validate_Ind_langs_text_l5_AH");
					driver.quit();break;
										
					
					case "Validate_all_langs_in_l5_AH":
						
					context.setAttribute("fileName", "Validate_all_langs_in_l5_AH");
					CareerOpportunities_CSC.Validate_all_langs_in_l5_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages);
					context.setAttribute("fileName", "Validate_all_langs_in_l5_AH");
					driver.quit();break;

					case "Validate_bydefault_Eng_lang_sltd_in_l5_AH":
						
					context.setAttribute("fileName", "Validate_bydefault_Eng_lang_sltd_in_l5_AH");
					CareerOpportunities_CSC.Validate_bydefault_Eng_lang_sltd_in_l5_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages);
					context.setAttribute("fileName", "Validate_bydefault_Eng_lang_sltd_in_l5_AH");
					driver.quit();break;
					
					case "Validate_slt_desired_langs_in_l5_AH":
						
					context.setAttribute("fileName", "Validate_slt_desired_langs_in_l5_AH");
					CareerOpportunities_CSC.Validate_slt_desired_langs_in_l5_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages);
					context.setAttribute("fileName", "Validate_slt_desired_langs_in_l5_AH");
					driver.quit();break;
					
					
					case "Validate_prev_next_step_btns_in_l5_AH":
						
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_AH");
					CareerOpportunities_CSC.Validate_prev_next_step_btns_in_l5_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box);
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l5_AH");
					driver.quit();break;
					
					
					case "Validate_prev_step_btn_in_l5_AH":
						
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_AH");
					CareerOpportunities_CSC.Validate_prev_step_btn_in_l5_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box);
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l5_AH");
					driver.quit();break;
					
					case "Validate_Next_step_btn_in_l5_AH":
						
					context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_AH");
					CareerOpportunities_CSC.Validate_Next_step_btn_in_l5_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages);
					context.setAttribute("fileName", "Validate_Next_step_btn_in_l5_AH");
					driver.quit();break;
					
					
					case "Validate_text_COqualify_in_l6_AH":
						
					context.setAttribute("fileName", "Validate_text_COqualify_in_l6_AH");
					CareerOpportunities_CSC.Validate_text_COqualify_in_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, input_data3);
					context.setAttribute("fileName", "Validate_text_COqualify_in_l6_AH");
					driver.quit();break;
					
					
					case "Validate_all_fields_in_l6_AH":
						
					context.setAttribute("fileName", "Validate_all_fields_in_l6_AH");
					CareerOpportunities_CSC.Validate_all_fields_in_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Considered_for_chkbx);
					context.setAttribute("fileName", "Validate_all_fields_in_l6_AH");
					driver.quit();break;
					
					
					case "Validate_slt_Worktime_l6_AH":
						
					context.setAttribute("fileName", "Validate_slt_Worktime_l6_AH");
					CareerOpportunities_CSC.Validate_slt_Worktime_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time);
					context.setAttribute("fileName", "Validate_slt_Worktime_l6_AH");
					driver.quit();break;
					
					case "Validate_slt_considerfor_chkbxs_l6_AH":
						
					context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_AH");
					CareerOpportunities_CSC.Validate_slt_considerfor_chkbxs_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages,Work_time, Considered_for_chkbx);
					context.setAttribute("fileName", "Validate_slt_considerfor_chkbxs_l6_AH");
					driver.quit();break;
					
					case "Validate_deslt_considerfor_chkbxs_l6_AH":
						
					context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_AH");
					CareerOpportunities_CSC.Validate_deslt_considerfor_chkbxs_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages,Work_time, Considered_for_chkbx);
					context.setAttribute("fileName", "Validate_deslt_considerfor_chkbxs_l6_AH");
					driver.quit();break;
					
					
					case "Validate_COs_asperCFchkbxsltn_l6_AH":
						
					context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_AH");
					CareerOpportunities_CSC.Validate_COs_asperCFchkbxsltn_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages,Work_time, Considered_for_chkbx);
					context.setAttribute("fileName", "Validate_COs_asperCFchkbxsltn_l6_AH");
					driver.quit();break;
					
					case "Validate_COs_asperCFchkbxdesltn_l6_AH":
						
					context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_AH");
					CareerOpportunities_CSC.Validate_COs_asperCFchkbxdesltn_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages,Work_time, Considered_for_chkbx, input_data4, input_data5);
					context.setAttribute("fileName", "Validate_COs_asperCFchkbxdesltn_l6_AH");
					driver.quit();break;
					
					
					case "Validate_defaultvalueofCO_l6_AH":
						
					context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_AH");
					CareerOpportunities_CSC.Validate_defaultvalueofCO_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages,input_data3);
					context.setAttribute("fileName", "Validate_defaultvalueofCO_l6_AH");
					driver.quit();break;
					
					
					case "Validate_ip_date_to_begin_l6_AH":
						
					context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_AH");
					CareerOpportunities_CSC.Validate_ip_date_to_begin_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages,Date_to_begin);
					context.setAttribute("fileName", "Validate_ip_date_to_begin_l6_AH");
					driver.quit();break;
					
					
					case "Validate_empdwithus_no_rdobtn_l6_AH":
						
					context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_AH");
					CareerOpportunities_CSC.Validate_empdwithus_no_rdobtn_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages,input_data3);
					context.setAttribute("fileName", "Validate_empdwithus_no_rdobtn_l6_AH");
					driver.quit();break;
					
					
					case "Validate_basedonsltns_text_l6_AH":
						
					context.setAttribute("fileName", "Validate_basedonsltns_text_l6_AH");
					CareerOpportunities_CSC.Validate_basedonsltns_text_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages,input_data3);
					context.setAttribute("fileName", "Validate_basedonsltns_text_l6_AH");
					driver.quit();break;
					
					
					case "Validate_Club_locations_l6_AH":
						
					context.setAttribute("fileName", "Validate_Club_locations_l6_AH");
					CareerOpportunities_CSC.Validate_Club_locations_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages,input_data3);
					context.setAttribute("fileName", "Validate_Club_locations_l6_AH");
					driver.quit();break;
					
					
					case "Validate_RQ_sec_l6_AH":
						
					context.setAttribute("fileName", "Validate_RQ_sec_l6_AH");
					CareerOpportunities_CSC.Validate_RQ_sec_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages,input_data3);
					context.setAttribute("fileName", "Validate_RQ_sec_l6_AH");
					driver.quit();break;
					
					
					case "Validate_Resigned_dd_allvalues_l6_AH":
						
					context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_AH");
					CareerOpportunities_CSC.Validate_Resigned_dd_allvalues_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages,EmploymentHowResigned_dd);
					context.setAttribute("fileName", "Validate_Resigned_dd_allvalues_l6_AH");
					driver.quit();break;
					
					case "Validate_ip_in_RQ_sec_l6_AH":
						
					context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_AH");
					CareerOpportunities_CSC.Validate_ip_in_RQ_sec_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip );
					context.setAttribute("fileName", "Validate_ip_in_RQ_sec_l6_AH");
					driver.quit();break;
					
					case "Validate_prev_next_step_btns_l6_AH":
						
					context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_AH");
					CareerOpportunities_CSC.Validate_prev_next_step_btns_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages);
					context.setAttribute("fileName", "Validate_prev_next_step_btns_l6_AH");
					driver.quit();break;
					
					case "Validate_prev_step_btn_in_l6_AH":
						
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_AH");
					CareerOpportunities_CSC.Validate_prev_step_btn_in_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages);
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l6_AH");
					driver.quit();break;
					
					
					case "Validate_next_btn_byipallfields_l6_AH":
						
					context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_AH");
					CareerOpportunities_CSC.Validate_next_btn_byipallfields_l6_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
					context.setAttribute("fileName", "Validate_next_btn_byipallfields_l6_AH");
					driver.quit();break;
					
					
					case "Validate_paras_in_l7_AH":
						
					context.setAttribute("fileName", "Validate_paras_in_l7_AH");
					CareerOpportunities_CSC.Validate_paras_in_l7_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data3);
					context.setAttribute("fileName", "Validate_paras_in_l7_AH");
					driver.quit();break;
					
					case "Validate_rdobtns_in_l7_AH":
						
					context.setAttribute("fileName", "Validate_rdobtns_in_l7_AH");
					CareerOpportunities_CSC.Validate_rdobtns_in_l7_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
					context.setAttribute("fileName", "Validate_rdobtns_in_l7_AH");
					driver.quit();break;
					
					case "Validate_all_form_sec_in_l7_AH":
						
					context.setAttribute("fileName", "Validate_all_form_sec_in_l7_AH");
					CareerOpportunities_CSC.Validate_all_form_sec_in_l7_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
					context.setAttribute("fileName", "Validate_all_form_sec_in_l7_AH");
					driver.quit();break;
					
					
					case "Validate_all_options_of_Gender_dd_in_l7_AH":
						
					context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_AH");
					CareerOpportunities_CSC.Validate_all_options_of_Gender_dd_in_l7_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd);
					context.setAttribute("fileName", "Validate_all_options_of_Gender_dd_in_l7_AH");
					driver.quit();break;
					
					
					case "Validate_all_options_of_RE_dd_in_l7_AH":
						
					context.setAttribute("fileName", "Validate_all_options_of_RE_dd_in_l7_AH");
					CareerOpportunities_CSC.Validate_all_options_of_RE_dd_in_l7_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, RaceEthnicity_dd);
					context.setAttribute("fileName", "Validate_all_options_of_RE_dd_in_l7_AH");
					driver.quit();break;
					
					
					case "Validate_EOE_details_paras_in_l7_AH":
						
					context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_AH");
					CareerOpportunities_CSC.Validate_EOE_details_paras_in_l7_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, input_data3);
					context.setAttribute("fileName", "Validate_EOE_details_paras_in_l7_AH");
					driver.quit();break;
					
					
					case "Validate_No_rdobtnof_form_sec_in_l7_AH":
						
					context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_AH");
					CareerOpportunities_CSC.Validate_No_rdobtnof_form_sec_in_l7_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
					context.setAttribute("fileName", "Validate_No_rdobtnof_form_sec_in_l7_AH");
					driver.quit();break;
					
					
					case "Validate_prev_next_step_btns_in_l7_AH":
						
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_AH");
					CareerOpportunities_CSC.Validate_prev_next_step_btns_in_l7_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l7_AH");
					driver.quit();break;
					
					
					
					case "Validate_prev_step_btn_in_l7_AH":
						
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_AH");
					CareerOpportunities_CSC.Validate_prev_step_btn_in_l7_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l7_AH");
					driver.quit();break;
					
					
					case "Validate_Next_step_btn_in_l7_AH":
						
					context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_AH");
					CareerOpportunities_CSC.Validate_Next_step_btn_in_l7_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip);
					context.setAttribute("fileName", "Validate_Next_step_btn_in_l7_AH");
					driver.quit();break;
					
					
					case "Validate_Nav_to_l8_AH":
						
					context.setAttribute("fileName", "Validate_Nav_to_l8_AH");
					CareerOpportunities_CSC.Validate_Nav_to_l8_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
					context.setAttribute("fileName", "Validate_Nav_to_l8_AH");
					driver.quit();break;
					
					
					case "Validate_AS_paras_in_l8_AH":
						
					context.setAttribute("fileName", "Validate_AS_paras_in_l8_AH");
					CareerOpportunities_CSC.Validate_AS_paras_in_l8_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data3);
					context.setAttribute("fileName", "Validate_AS_paras_in_l8_AH");
					driver.quit();break;
					
					case "Validate_ackmnt_in_l8_AH":
						
					context.setAttribute("fileName", "Validate_ackmnt_in_l8_AH");
					CareerOpportunities_CSC.Validate_ackmnt_in_l8_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data3);
					context.setAttribute("fileName", "Validate_ackmnt_in_l8_AH");
					driver.quit();break;
					
					case "Validate_ip_in_Signedbyname_in_l8_AH":
						
					context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_AH");
					CareerOpportunities_CSC.Validate_ip_in_Signedbyname_in_l8_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
					context.setAttribute("fileName", "Validate_ip_in_Signedbyname_in_l8_AH");
					driver.quit();break;
					
					case "Validate_prev_next_step_btns_in_l8_AH":
						
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_AH");
					CareerOpportunities_CSC.Validate_prev_next_step_btns_in_l8_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
					context.setAttribute("fileName", "Validate_prev_next_step_btns_in_l8_AH");
					driver.quit();break;
					
					case "Validate_Next_btn_in_l8_AH":
						
					context.setAttribute("fileName", "Validate_Next_btn_in_l8_AH");
					CareerOpportunities_CSC.Validate_Next_btn_in_l8_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
					context.setAttribute("fileName", "Validate_Next_btn_in_l8_AH");
					driver.quit();break;
					
					case "Validate_prev_step_btn_in_l8_AH":
						
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_AH");
					CareerOpportunities_CSC.Validate_prev_step_btn_in_l8_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
					context.setAttribute("fileName", "Validate_prev_step_btn_in_l8_AH");
					driver.quit();break;
					
					
					case "Validate_heading_in_l9_AH":
						
					context.setAttribute("fileName", "Validate_heading_in_l9_AH");
					CareerOpportunities_CSC.Validate_heading_in_l9_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data3);
					context.setAttribute("fileName", "Validate_heading_in_l9_AH");
					driver.quit();break;
					
					
					case "Validate_Rules_procedures_in_l9_AH":
						
					context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_AH");
					CareerOpportunities_CSC.Validate_Rules_procedures_in_l9_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data3);
					context.setAttribute("fileName", "Validate_Rules_procedures_in_l9_AH");
					driver.quit();break;
					
					
					case "Validate_ip_in_prtname_dateandipadd_in_l9_AH":
						
					context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_AH");
					CareerOpportunities_CSC.Validate_ip_in_prtname_dateandipadd_in_l9_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, IP_Address);
					context.setAttribute("fileName", "Validate_ip_in_prtname_dateandipadd_in_l9_AH");
					driver.quit();break;
					
					
					
					case "Validate_Robert_Bryant_Sign_in_l9_AH":
						
					context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_AH");
					CareerOpportunities_CSC.Validate_Robert_Bryant_Sign_in_l9_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data3);
					context.setAttribute("fileName", "Validate_Robert_Bryant_Sign_in_l9_AH");
					driver.quit();break;
					
					
					case "Validate_Iagree_textandbtn_in_l9_AH":
						
					context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_AH");
					CareerOpportunities_CSC.Validate_Iagree_textandbtn_in_l9_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data3);
					context.setAttribute("fileName", "Validate_Iagree_textandbtn_in_l9_AH");
					driver.quit();break;
					
					
					case "Validate_Prev_step_btn_in_l9_AH":
						
					context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_AH");
					CareerOpportunities_CSC.Validate_Prev_step_btn_in_l9_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
					context.setAttribute("fileName", "Validate_Prev_step_btn_in_l9_AH");
					driver.quit();break;
					
					case "Validate_Iagreebtn_and_succ_submsn_in_l9_AH":
						
					context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_AH");
					CareerOpportunities_CSC.Validate_Iagreebtn_and_succ_submsn_in_l9_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
					context.setAttribute("fileName", "Validate_Iagreebtn_and_succ_submsn_in_l9_AH");
					driver.quit();break;
					
					
					case "Validate_Success_msg_in_final_page_AH":
						
					context.setAttribute("fileName", "Validate_Success_msg_in_final_page_AH");
					CareerOpportunities_CSC.Validate_Success_msg_in_final_page_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data3);
					context.setAttribute("fileName", "Validate_Success_msg_in_final_page_AH");
					driver.quit();break;
					
					
					case "Validate_prtbtn_in_print_emp_app_page_AH":
						
					context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_AH");
					CareerOpportunities_CSC.Validate_prtbtn_in_print_emp_app_page_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd, input_data3);
					context.setAttribute("fileName", "Validate_prtbtn_in_print_emp_app_page_AH");
					driver.quit();break;
					
					
					case "Validate_Rules_link_in_l9_AH":
						
					context.setAttribute("fileName", "Validate_Rules_link_in_l9_AH");
					CareerOpportunities_CSC.Validate_Rules_link_in_l9_AH(testdata.get("TextMessage").toString(), additional_input, input_data, How_hear_abt_us,Radiobtn18YearsOld, F_Name, L_Name, Email  , Phone , Address , Zipcode, Text_input, E_EducationLeve_Dropdown , Dropdown_values, input_data1, input_data2, Emp_gap, Employer_name, Supervisor_name,From_date, To_date,Job_title,Leaving_Reason, Emp_details, Can_contact_radio_button, File_name, No_Prev_emp_chk_box, Languages, Work_time,Considered_for_chkbx,Date_to_begin,Everemployed_rdobtn, EmploymentHowResigned_dd, PriorEmploymentWhyResigned_ip, EmploymentWhyLeaveCurrent_ip, EmploymentWhyReapply_ip, EmploymentWhatLike_ip, EmploymentWhatDislike_ip, EmploymentSuccess_ip, EmploymentWhyResignInFuture_ip, Gender_dd, RaceEthnicity_dd);
					context.setAttribute("fileName", "Validate_Rules_link_in_l9_AH");
					driver.quit();break;
					
					
					
					
				default:
					driver.quit();
					break;

				}

				// EndTest
//				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
				ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
				ExtentTestManager.endTest();
				ExtentManager.getInstance().flush();
				Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				Log.info("Browser is closed");


			}

		} 
		catch (Exception e)
		{
			Thread.sleep(1000);
			ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
			Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
			String stackTrace = Throwables.getStackTraceAsString(e);
			Log.error( stackTrace);
		
			
			String fileName = (String) context.getAttribute("fileName");

			try {
				File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
						testdata.get("TestScenario").toString());
				ExtentTestManager.getTest().fail(e.getMessage(),
						MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
				ExtentTestManager.getTest().log(Status.FAIL, e);
				} 
			catch (Exception e1) {
				System.out.println("File not found " + e1);
								}
			ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");

//			 Logout
			context.setAttribute("fileName", "Logout");
			if (com.test.user.All_scenarios.driver!=null)driver.quit();
			ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
			Log.info("Browser is closed");

			// EndTest
			System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
			ExtentTestManager.endTest();
			ExtentManager.getInstance().flush();
			Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
			throw new Exception(stackTrace);
		} 
		catch (AssertionError e) 
		{
			Thread.sleep(1000);
//			System.out.println("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
			ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
			Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
			String stackTrace = Throwables.getStackTraceAsString(e);
			Log.error( stackTrace);
			
			String fileName = (String) context.getAttribute("fileName");

			try {
				File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
						testdata.get("TestScenario").toString());
				ExtentTestManager.getTest().fail(e.getMessage(),
						MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
				ExtentTestManager.getTest().log(Status.FAIL, e);
				} 
			catch (Exception e1)
			{
				System.out.println("File not found " + e1);
			}
			ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");

			// Logout
			context.setAttribute("fileName", "Logout");
			driver.quit();
			ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
			Log.info("Browser is closed");

			// EndTest
			System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
			ExtentTestManager.endTest();
			ExtentManager.getInstance().flush();
			Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
			
			throw new Exception(stackTrace);
			
		}
	}


	
	@DataProvider(name = "TestData")
	public static Object[][] gettestdate() throws IOException {

		Object[][] objectarry = null;
		java.util.List<Map<String, String>> completedata = com.Utility.ExcelReader.getdata("Career_opportunities_CSC");

		java.util.List<Map<String, String>> completedata1 = new ArrayList<Map<String,String>>();
		int j=0;

		for (int i = 0; i < completedata.size(); i++) {
			if(completedata.get(i).get("Run").toString().equalsIgnoreCase("Yes")) 
			{
			completedata1.add(j, completedata.get(i));
			j++;
			}
		}
		
		objectarry = new Object[completedata1.size()][1];
		
		for (int i = 0; i < completedata1.size(); i++) {
			objectarry[i][0] = completedata1.get(i);
		}
		return objectarry;

	}

	public void Takescreenshot(String fileName, String scenario) {
		try {
			File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
					scenario);
			ExtentTestManager.getTest().pass("File upload screenshot",
					MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
			
			} 
		catch (Exception e1) {
			System.out.println("File not found " + e1);
							}
	}
	
}


