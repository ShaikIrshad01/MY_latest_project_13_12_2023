package com.test.user;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.testng.ITestContext;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.apache.commons.lang3.ObjectUtils.Null;
import org.apache.poi.hssf.record.PageBreakRecord.Break;
import org.testng.*;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.BasePackage.Base_Class;
import com.Utility.Log;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.extentReports.ExtentManager;
import com.extentReports.ExtentTestManager;
import com.google.common.base.Throwables;
import com.listeners.TestListener;

public class Joinnow_CST_Scenarios extends Base_Class  {

	Base_Class Base_Class;
	com.pages.Home Home;
	com.pages.Joinnow joinnow;
	Log log;
	TestListener TestListener;
	com.Utility.ScreenShot screenShot;
	com.pages.Employment Employment;
	com.pages.FreePass FreePass;
	com.pages.CareerOpportunity CareerOpportunity;
	com.pages.Joinnow_CST Joinnow_CST;
	
	@BeforeSuite
	public void reference() {
		Base_Class = new Base_Class();
		log = new Log();
		TestListener = new TestListener();
		screenShot = new com.Utility.ScreenShot(null);
		Home = new com.pages.Home();
		joinnow = new com.pages.Joinnow();
		Employment = new com.pages.Employment();
		FreePass = new com.pages.FreePass();
		
		CareerOpportunity = new com.pages.CareerOpportunity();
		
		Joinnow_CST = new com.pages.Joinnow_CST();
		
	}
	
	@Test(dataProvider = "TestData")
	public void RUNALL(Map<Object, Object> testdata, ITestContext context) throws Throwable {

		try {

			if (testdata.get("Run").toString().equalsIgnoreCase("Yes")) {
				String fileName;
				ExtentTestManager.startTest(testdata.get("TestScenario").toString());
				ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " running Starting ***");
				Log.info("*** Running test method " + testdata.get("TestScenario").toString() + "...");
				ExtentTestManager.getTest().log(Status.PASS, "*** Running test method " + testdata.get("TestScenario").toString() + "...");
			
				String Change_brand_name=testdata.get("Change_brand_name").toString();
				if(testdata.get("TextMessage").toString().trim().equalsIgnoreCase("Change_Brand".trim())) {
					
					Base_Class.setup_Change_brand();
					if(!Change_brand_name.isBlank() && !Change_brand_name.isEmpty()) Base_Class.Change_Brand(Change_brand_name);
					
				else {
					
					throw new Exception("please provide brand name to change the brand");
				
					}
					
					driver.quit();
					
				}
				
				else {
					Base_Class.setup();
				}

				ExtentTestManager.getTest().log(Status.PASS, "Successfully Entered into Application URL ");


				String Dropdown_values=testdata.get("Dropdown_values").toString();

				String Country =testdata.get("Country").toString();
				String Ratesoramenities =testdata.get("Rates/amenities").toString();
				String Club_name =testdata.get("Club_name").toString();
				String Club_name1 =testdata.get("Club_name1").toString();
				String Add_amenities =testdata.get("Add_amenities").toString();
				String Included_amenities =testdata.get("Included_amenities").toString();
			
				String Amount_details =testdata.get("Amount_details").toString();
				String rates_details =testdata.get("Rates_details").toString();
				String plan_rates =testdata.get("Plan_rates").toString();
				
				
				
				
				String Text_input =testdata.get("Text_input").toString();
	
				
				String Number_of_Persons1 =testdata.get("Number_of_Persons1").toString();
				String Initiation_Fee =testdata.get("Initiation_Fee").toString();
				String Billing_Frequency =testdata.get("Billing_Frequency").toString();				
				String Initial_Term =testdata.get("Initial_Term").toString();
				String Prepayment =testdata.get("Prepayment").toString();
				String First_Month_Dues =testdata.get("First_Month_Dues").toString();
				String Last_Month_Dues =testdata.get("Last_Month_Dues").toString();
				String Total_initial_Payment =testdata.get("Total_initial_Payment").toString();	
				String Annual_Fee_Per_Person =testdata.get("Annual_Fee_Per_Person").toString();
				
				String Everemployed_rdobtn =testdata.get("Everemployed_rdobtn").toString();
				String Date_to_begin =testdata.get("Date_to_begin").toString();
				String Languages =testdata.get("Languages").toString();
				String Work_time =testdata.get("Work_time").toString();
				String Url =testdata.get("Url").toString();
				String additional_input =testdata.get("additional_input").toString();
				String input_data =testdata.get("input_data").toString();
				String input_data1 =testdata.get("input_data1").toString();
				String input_data2 =testdata.get("input_data2").toString();
				String input_data3 =testdata.get("input_data3").toString();
				String input_data4 =testdata.get("input_data4").toString();
				String input_data5 =testdata.get("input_data5").toString();
				String input_data6 =testdata.get("input_data6").toString();
				String input_data7 =testdata.get("input_data7").toString();
				String IP_Address =testdata.get("IP_Address").toString();
				
				String File_name =testdata.get("File_name").toString();
				
				String Job_short_des =testdata.get("Job_short_des").toString();
				String Job_long_des =testdata.get("Job_long_des").toString();
				String F_Name =testdata.get("F_Name").toString();
				String L_Name =testdata.get("L_Name").toString();
				
				String F_Name1 =testdata.get("F_Name1").toString();
				String L_Name1 =testdata.get("L_Name1").toString();
				
				String Full_name =testdata.get("Full_name").toString();
				String Phone =testdata.get("Member_Phone").toString();
				String Email =testdata.get("Email").toString();
				String Email1 =testdata.get("Email1").toString();
				String Address =testdata.get("Member_address").toString();
//				job_short_des
				String City =testdata.get("Member_City").toString();
				
				String E_EducationLeve_Dropdown = testdata.get("E_EducationLeve_Dropdown").toString();

				String Aerobics_Instructor_Exp_DD = testdata.get("Aerobics_Instructor_Exp_DD").toString();
				String Time_period_DD = testdata.get("Time_period_DD").toString();
				String Club_Employer_DD = testdata.get("Club_Employer_DD").toString();
				String Class_per_week = testdata.get("Class_per_week").toString();
				
				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
				String PriorEmploymentWhyResigned_ip = testdata.get("PriorEmploymentWhyResigned_ip").toString();
				String EmploymentWhyLeaveCurrent_ip = testdata.get("EmploymentWhyLeaveCurrent_ip").toString();
				String EmploymentWhyReapply_ip = testdata.get("EmploymentWhyReapply_ip").toString();
				String EmploymentWhatLike_ip = testdata.get("EmploymentWhatLike_ip").toString();
				String EmploymentWhatDislike_ip = testdata.get("EmploymentWhatDislike_ip").toString();
				
				String EmploymentSuccess_ip = testdata.get("EmploymentSuccess_ip").toString();
				String EmploymentWhyResignInFuture_ip = testdata.get("EmploymentWhyResignInFuture_ip").toString();
				String Gender_dd = testdata.get("Gender_dd").toString();
				String RaceEthnicity_dd = testdata.get("RaceEthnicity_dd").toString();
//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
//				String EmploymentHowResigned_dd = testdata.get("EmploymentHowResigned_dd").toString();
//				
				String Personal_Training_ExperienceDPValues = testdata.get("Personal_Training_ExperienceDPValues").toString();
				String Certification_IssuedByDPValues = testdata.get("Certification_IssuedByDPValues").toString();
				String Hold_cert_GT_AC_ratio_button = testdata.get("Hold_cert_GT_AC_ratio_button").toString();
				String Certified_In_DD = testdata.get("Certified_In_DD").toString();
				String Certificate_No = testdata.get("Certificate_No").toString();
				String Emp_gap = testdata.get("Emp_gap").toString();
				String Employer_name = testdata.get("Employer_name").toString();
				String Supervisor_name = testdata.get("Supervisor_name").toString();
				String From_date = testdata.get("From_date").toString();
				String To_date = testdata.get("To_date").toString();
				String Job_title = testdata.get("Job_title").toString();
				String Leaving_Reason = testdata.get("Leaving_Reason").toString();
				String Emp_details = testdata.get("Emp_details").toString();
				String Can_contact_radio_button = testdata.get("Can_contact_radio_button").toString();
				
				
				String Club_phone =testdata.get("Club_phone").toString();
				String Club_zip =testdata.get("Club_zip").toString();
				String Club_Address =testdata.get("Club_Address").toString();
				String Club_Address2 =testdata.get("Club_Address2").toString();
				String Club_city =testdata.get("Club_city").toString();
//				
				String State =testdata.get("State").toString();
				String Zipcode =testdata.get("Member_Zipcode").toString();
				String Radius_travel_to_work =testdata.get("Radius_travel_to_work").toString();
				String How_hear_abt_us =testdata.get("How_hear_abt_us").toString();
				String Radiobtn18YearsOld =testdata.get("Radiobtn18YearsOld").toString();
				String Payment_type =testdata.get("Payment_type").toString();
				String Card_number  =testdata.get("C_number").toString();
				
				String Payment_type_1 =testdata.get("Payment_type_1").toString();
				String Card_number_1  =testdata.get("C_number_1").toString();
				
				String Routing_number_1 =testdata.get("Routing_number_1").toString();
				String A_number_1  =testdata.get("A_number_1").toString();
				
				
				String Ex_month =testdata.get("Ex_month").toString();
				String Ex_year  =testdata.get("Ex_year").toString();
				
				String Ex1_month =testdata.get("Ex1_month").toString();
				String Ex1_year  =testdata.get("Ex1_year").toString();
				
				String Billing_Fname =testdata.get("Billing_Fname").toString();
				String Billing_Lname  =testdata.get("Billing_Lname").toString();
				
				String Routing_number  =testdata.get("Routing_number").toString();
				String A_number =testdata.get("A_number").toString();
				String Card_name =testdata.get("Card_name").toString();
				String Checkbox_class_formats =testdata.get("Checkbox_class_formats").toString();

				String No_Prev_emp_chk_box =testdata.get("No_Prev_emp_chk_box").toString();
				String MD_amount =testdata.get("MD_amount").toString();
				
				
				
				
						
				switch (testdata.get("TextMessage").toString()) {
				
					
				// Join Now Testcases
				
				case "Validate_joinnow_btn_CST":
					
					context.setAttribute("fileName", "Validate_joinnow_btn_CST");
					Home.Validate_joinnow_btn_CST(testdata.get("TextMessage").toString());
					context.setAttribute("fileName", "Validate_joinnow_btn_CST");
					driver.quit();break;
					
				case "Navigate_to_Joinnow_page":
					
					context.setAttribute("fileName", "Navigate_to_Joinnow_page");
					Home.Navigate_to_Joinnow_page(testdata.get("TextMessage").toString());
					context.setAttribute("fileName", "Navigate_to_Joinnow_page");
					driver.quit();break;

				case "Joinnow_searchclub_4steps":

					context.setAttribute("fileName", "Joinnow_searchclub_4steps");
					Joinnow_CST.Joinnow_searchclub_4steps(testdata.get("TextMessage").toString());
					context.setAttribute("fileName", "Joinnow_searchclub_4steps");
					driver.quit();break;

				case "Validate_joinnow_fields_buttons":
					
					context.setAttribute("fileName", "Validate_joinnow_fields_buttons");
					Joinnow_CST.Validate_joinnow_fields_buttons(testdata.get("TextMessage").toString());
					context.setAttribute("fileName", "Validate_joinnow_fields_buttons");
					driver.quit();break;

				case "Validate_country_values":

					context.setAttribute("fileName", "Validate_country_values");
					Joinnow_CST.Validate_country_values(testdata.get("TextMessage").toString(), Dropdown_values);
					context.setAttribute("fileName", "Validate_country_values");
					driver.quit();break;

//				case "ByStateorprovince_dropdown_ALL":
//
//					context.setAttribute("fileName", "ByStateorprovince_dropdown_ALL");
//					joinnow.Validate_ByStateorprovince_values_ALL(testdata.get("TextMessage").toString(), Dropdown_values, Country);
//					context.setAttribute("fileName", "ByStateorprovince_dropdown_ALL");
//					driver.quit();break;
//
//				case "ByStateorprovince_dropdown_CANADA":
//
//					context.setAttribute("fileName", "ByStateorprovince_dropdown_CANADA");
//					joinnow.Validate_ByStateorprovince_values_Canada(testdata.get("TextMessage").toString(), Dropdown_values, Country);
//					context.setAttribute("fileName", "ByStateorprovince_dropdown_CANADA");
//					driver.quit();break;
					
				case "Validate_ByStateorprovince_values_USA":

					context.setAttribute("fileName", "Validate_ByStateorprovince_values_USA");
					Joinnow_CST.Validate_ByStateorprovince_values_USA(testdata.get("TextMessage").toString(), Dropdown_values, Country);
					context.setAttribute("fileName", "Validate_ByStateorprovince_values_USA");
					driver.quit();break;
					
				case "Validate_listofclubs":

					context.setAttribute("fileName", "Validate_listofclubs");
					Joinnow_CST.Validate_listofclubs(testdata.get("TextMessage").toString(), Dropdown_values, Country);
					context.setAttribute("fileName", "Validate_listofclubs");
					driver.quit();break;

				case "Validate_club_details":

					context.setAttribute("fileName", "Validate_club_details");
					Joinnow_CST.Validate_club_details(testdata.get("TextMessage").toString(), Dropdown_values, Country);
					context.setAttribute("fileName", "Validate_club_details");
					driver.quit();break;
					
					
				case "Validate_clubs_buttons":

					context.setAttribute("fileName", "Validate_clubs_buttons");
					Joinnow_CST.Validate_clubs_buttons(testdata.get("TextMessage").toString(), Dropdown_values, Country);
					context.setAttribute("fileName", "Validate_clubs_buttons");
					driver.quit();break;

				case "Validate_club_ratesandamenities":

					context.setAttribute("fileName", "Validate_club_ratesandamenities");
					Joinnow_CST.Validate_club_ratesandamenities(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name);
					context.setAttribute("fileName", "Validate_club_ratesandamenities");
					driver.quit();break;
					
				case "Validate_club_rateplans":

					context.setAttribute("fileName", "Validate_club_rateplans");
					Joinnow_CST.Validate_club_rateplans(testdata.get("TextMessage").toString(), Dropdown_values, Country, Ratesoramenities, Club_name);
					context.setAttribute("fileName", "Validate_club_rateplans");
					driver.quit();break;
					
				case "Validate_club_Amenities":

					context.setAttribute("fileName", "Validate_club_Amenities");
					Joinnow_CST.Validate_club_Amenities(testdata.get("TextMessage").toString(), Dropdown_values, Country, Ratesoramenities, Club_name);
					context.setAttribute("fileName", "Validate_club_Amenities");
					driver.quit();break;

					
				case "Validate_joinnow_steptwo":

					context.setAttribute("fileName", "Validate_joinnow_steptwo");
					Joinnow_CST.Validate_joinnow_steptwo(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data);
					context.setAttribute("fileName", "Validate_joinnow_steptwo");
					driver.quit();break;
					
				case "Validate_slt_add_featues_homeclub":

					context.setAttribute("fileName", "Validate_slt_add_featues_homeclub");
					Joinnow_CST.Validate_slt_add_featues_homeclub(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data);
					context.setAttribute("fileName", "Validate_slt_add_featues_homeclub");
					driver.quit();break;
					
				case "Validate_Add_features_monthlyrates":

					context.setAttribute("fileName", "Validate_Add_features_monthlyrates");
					Joinnow_CST.Validate_Add_features_monthlyrates(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,input_data, Ratesoramenities);
					context.setAttribute("fileName", "Validate_Add_features_monthlyrates");
					driver.quit();break;
					
				case "Validate_monthlyrates_1stplan_details":

					context.setAttribute("fileName", "Validate_monthlyrates_1stplan_details");
					Joinnow_CST.Validate_monthlyrates_1stplan_details(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,input_data , plan_rates, Number_of_Persons1, Initiation_Fee, Billing_Frequency, Initial_Term, Prepayment);
					context.setAttribute("fileName", "Validate_monthlyrates_1stplan_details");
					driver.quit();break;
					
					
//				case "monthlyrates_secondplan_details":
//
//					context.setAttribute("fileName", "monthlyrates_secondplan_details");
//					joinnow.Validate_select_monthlyrates_secondplan_details(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, plan_rates, Number_of_Persons1, Initiation_Fee, Billing_Frequency, Initial_Term, Prepayment);
//					context.setAttribute("fileName", "monthlyrates_secondplan_details");
//					driver.quit();break;
					
				case "Validate_1stplan_menities_list":

					context.setAttribute("fileName", "Validate_1stplan_menities_list");
					Joinnow_CST.Validate_1stplan_menities_list(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,input_data,plan_rates, Included_amenities);
					context.setAttribute("fileName", "Validate_1stplan_menities_list");
					driver.quit();break;
					
//				case "monthlyrates_secondplan_add_amenities_list":
//
//					context.setAttribute("fileName", "monthlyrates_secondplan_add_amenities_list");
//					joinnow.Validate_select_monthlyrates_secondplan_add_amenities_list(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,plan_rates, Included_amenities, Add_amenities);
//					context.setAttribute("fileName", "monthlyrates_secondplan_add_amenities_list");
//					driver.quit();break;
//					
					
				case "Validate_MR_1stplan_yourdues_sec":

					context.setAttribute("fileName", "Validate_MR_1stplan_yourdues_sec");
					Joinnow_CST.Validate_MR_1stplan_yourdues_sec(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,input_data ,plan_rates, First_Month_Dues ,Last_Month_Dues ,Total_initial_Payment,Initial_Term);
					context.setAttribute("fileName", "Validate_MR_1stplan_yourdues_sec");
					driver.quit();break;
					
					
//				case "monthlyrates_secondplan_yourdues_section":
//
//					context.setAttribute("fileName", "monthlyrates_secondplan_yourdues_section");
//					joinnow.Validate_select_monthlyrates_secondplan_yourdues_section(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, plan_rates, First_Month_Dues, Last_Month_Dues ,Total_initial_Payment ,Annual_Fee_Per_Person);
//					context.setAttribute("fileName", "monthlyrates_secondplan_yourdues_section");
//					driver.quit();break;
//				/*	
					
				case "Validate_No_of_persons_dd_for_1stplan":

					context.setAttribute("fileName", "Validate_No_of_persons_dd_for_1stplan");
					Joinnow_CST.Validate_No_of_persons_dd_for_1stplan(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data , Text_input, plan_rates );
					context.setAttribute("fileName", "Validate_No_of_persons_dd_for_1stplan");
					driver.quit();break;
					
				case "Validate_Select_Noofpersons_dd":

					context.setAttribute("fileName", "Validate_Select_Noofpersons_dd");
					Joinnow_CST.Validate_Select_Noofpersons_dd(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data , Text_input, plan_rates );
					context.setAttribute("fileName", "Validate_Select_Noofpersons_dd");
					driver.quit();break;
					
					/*
					
				case "No_of_persons_dropdown_for_$46_99":

					context.setAttribute("fileName", "No_of_persons_dropdown_for_$46_99");
					joinnow.Validate_No_of_persons_dropdown_for_$46_99(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,Text_input, plan_rates );
					context.setAttribute("fileName", "No_of_persons_dropdown_for_$46_99");
					driver.quit();break;
					
					*/
					
				case "Validate_back_continue_btns_under_add_features":

					context.setAttribute("fileName", "Validate_back_continue_btns_under_add_features");
					Joinnow_CST.Validate_back_continue_btns_under_add_features(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name , input_data ,plan_rates );
					context.setAttribute("fileName", "Validate_back_continue_btns_under_add_features");
					driver.quit();break;
					
				case "Validate_back_btn_add_features":

					context.setAttribute("fileName", "Validate_back_btn_add_features");
					Joinnow_CST.Validate_back_btn_add_features(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,input_data, Text_input , plan_rates);
					context.setAttribute("fileName", "Validate_back_btn_add_features");
					driver.quit();break;
					
					
				case "Validate_continue_btn_add_features":

					context.setAttribute("fileName", "Validate_continue_btn_add_features");
					Joinnow_CST.Validate_continue_btn_add_features(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates );
					context.setAttribute("fileName", "Validate_continue_btn_add_features");
					driver.quit();break;
					
					
				case "Validate_club_details_under_YHClub":

					context.setAttribute("fileName", "Validate_club_details_under_YHClub");
					Joinnow_CST.Validate_club_details_under_YHClub(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data);
					context.setAttribute("fileName", "Validate_club_details_under_YHClub");
					driver.quit();break;
					
					
				case "Validate_disclaimers_under_yourhomeclub":

					context.setAttribute("fileName", "Validate_disclaimers_under_yourhomeclub");
					Joinnow_CST.Validate_disclaimers_under_yourhomeclub(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data , Text_input);
					context.setAttribute("fileName", "Validate_disclaimers_under_yourhomeclub");
					driver.quit();break;
					
					
				case "Validate_membership_h1_step3img":

					context.setAttribute("fileName", "Validate_membership_h1_step3img");
					Joinnow_CST.Validate_membership_h1_step3img(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1 );
					context.setAttribute("fileName", "Validate_membership_h1_step3img");
					driver.quit();break;
					

					case "Validate_all_sections_under_MPI_s3":

					context.setAttribute("fileName", "Validate_all_sections_under_MPI_s3");
					Joinnow_CST.Validate_all_sections_under_MPI_s3(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_all_sections_under_MPI_s3");
					driver.quit();break;
					
					
				case "Validate_all_fields_under_MI_section":

					context.setAttribute("fileName", "Validate_all_fields_under_MI_section");
					Joinnow_CST.Validate_all_fields_under_MI_section(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_all_fields_under_MI_section");
					driver.quit();break;
					
					
				case "Validate_all_fields_under_BI_section":

					context.setAttribute("fileName", "Validate_all_fields_under_BI_section");
					Joinnow_CST.Validate_all_fields_under_BI_section(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_all_fields_under_BI_section");
					driver.quit();break;
					
					
				case "Validate_allfields_BI_notsameas_MI":

					context.setAttribute("fileName", "Validate_allfields_BI_notsameas_MI");
					Joinnow_CST.Validate_allfields_BI_notsameas_MI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_allfields_BI_notsameas_MI");
					driver.quit();break;
					
					
				case "Validate_all_fields_selecting_creditcard_rdobtn":

					context.setAttribute("fileName", "Validate_all_fields_selecting_creditcard_rdobtn");
					Joinnow_CST.Validate_all_fields_selecting_creditcard_rdobtn(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_all_fields_selecting_creditcard_rdobtn");
					driver.quit();break;
					
					
				case "Validate_all_fields_selecting_checking_rdobtn":

					context.setAttribute("fileName", "Validate_all_fields_selecting_checking_rdobtn");
					Joinnow_CST.Validate_all_fields_selecting_checking_rdobtn(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_all_fields_selecting_checking_rdobtn");
					driver.quit();break;
					
				case "Validate_all_fields_selecting_savings_rdobtn":

					context.setAttribute("fileName", "Validate_all_fields_selecting_savings_rdobtn");
					Joinnow_CST.Validate_all_fields_selecting_savings_rdobtn(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_all_fields_selecting_savings_rdobtn");
					driver.quit();break;
					
					
					
				case "Validate_allfieldsCC_BI_nosameas_MI":

					context.setAttribute("fileName", "Validate_allfieldsCC_BI_nosameas_MI");
					Joinnow_CST.Validate_allfieldsCC_BI_nosameas_MI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_allfieldsCC_BI_nosameas_MI");
					driver.quit();break;
					
					
				case "Validate_allfieldsChecking_BI_notsameas_MI":

					context.setAttribute("fileName", "Validate_allfieldsChecking_BI_notsameas_MI");
					Joinnow_CST.Validate_allfieldsChecking_BI_notsameas_MI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_allfieldsChecking_BI_notsameas_MI");
					driver.quit();break;
					
				case "Validate_allfieldsSavings_BI_notsameas_MI":

					context.setAttribute("fileName", "Validate_allfieldsSavings_BI_notsameas_MI");
					Joinnow_CST.Validate_allfieldsSavings_BI_notsameas_MI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_allfieldsSavings_BI_notsameas_MI");
					driver.quit();break;
					

					
					
					
				case "Validate_usesameinfo_for_monthly_bill_chkbox":

					context.setAttribute("fileName", "Validate_usesameinfo_for_monthly_bill_chkbox");
					Joinnow_CST.Validate_usesameinfo_for_monthly_bill_chkbox(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_usesameinfo_for_monthly_bill_chkbox");
					driver.quit();break;
					
				case "Validate_select_EFT_chkbx":

					context.setAttribute("fileName", "Validate_select_EFT_chkbx");
					Joinnow_CST.Validate_select_EFT_chkbx(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_select_EFT_chkbx");
					driver.quit();break;

					
					
				case "Validate_allfields_2BI_notsameas_MI_EFT":

					context.setAttribute("fileName", "Validate_allfields_2BI_notsameas_MI_EFT");
					Joinnow_CST.Validate_allfields_2BI_notsameas_MI_EFT(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_allfields_2BI_notsameas_MI_EFT");
					driver.quit();break;
					
					
				case "Validate_Creditcardfields_EFT":

					context.setAttribute("fileName", "Validate_Creditcardfields_EFT");
					Joinnow_CST.Validate_Creditcardfields_EFT(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_Creditcardfields_EFT");
					driver.quit();break;
					
					
				case "Validate_Checkingfields_EFT":

					context.setAttribute("fileName", "Validate_Checkingfields_EFT");
					Joinnow_CST.Validate_Checkingfields_EFT(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_Checkingfields_EFT");
					driver.quit();break;
					
				case "Validate_Savingsfields_EFT":

					context.setAttribute("fileName", "Validate_Savingsfields_EFT");
					Joinnow_CST.Validate_Savingsfields_EFT(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_Savingsfields_EFT");
					driver.quit();break;
					
					
				case "Validate_CCfields_EFT_BI_notsameas_MI":

					context.setAttribute("fileName", "Validate_CCfields_EFT_BI_notsameas_MI");
					Joinnow_CST.Validate_CCfields_EFT_BI_notsameas_MI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_CCfields_EFT_BI_notsameas_MI");
					driver.quit();break;
					
					
				case "Validate_Checkingfields_EFT_BI_notsameas_MI":

					context.setAttribute("fileName", "Validate_Checkingfields_EFT_BI_notsameas_MI");
					Joinnow_CST.Validate_Checkingfields_EFT_BI_notsameas_MI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_Checkingfields_EFT_BI_notsameas_MI");
					driver.quit();break;
					
					
				case "Validate_Savingsfields_EFT_BI_notsameas_MI":

					context.setAttribute("fileName", "Validate_Savingsfields_EFT_BI_notsameas_MI");
					Joinnow_CST.Validate_Savingsfields_EFT_BI_notsameas_MI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_Savingsfields_EFT_BI_notsameas_MI");
					driver.quit();break;
					
					
					
				case "Validate_initial_payment_amounts":

					context.setAttribute("fileName", "Validate_initial_payment_amounts");
					Joinnow_CST.Validate_initial_payment_amounts(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data , Text_input,plan_rates, rates_details,Amount_details);
					context.setAttribute("fileName", "Validate_initial_payment_amounts");
					driver.quit();break;
					
					
				case "Validate_inc_amenities_under_IPA_sec":

					context.setAttribute("fileName", "Validate_inc_amenities_under_IPA_sec");
					Joinnow_CST.Validate_inc_amenities_under_IPA_sec(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,input_data, Text_input, plan_rates,Included_amenities);
					context.setAttribute("fileName", "Validate_inc_amenities_under_IPA_sec");
					driver.quit();break;
					
				case "Validate_Add_amenities":

					context.setAttribute("fileName", "Validate_Add_amenities");
					Joinnow_CST.Validate_Add_amenities(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,input_data, Text_input, plan_rates,Add_amenities);
					context.setAttribute("fileName", "Validate_Add_amenities");
					driver.quit();break;
					
					
				case "Validate_select_add_amenities":

					context.setAttribute("fileName", "Validate_select_add_amenities");
					Joinnow_CST.Validate_select_add_amenities(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,input_data, Text_input, plan_rates,Add_amenities);
					context.setAttribute("fileName", "Validate_select_add_amenities");
					driver.quit();break;
					
					
				case "Validate_details_in_homeclub_section":

					context.setAttribute("fileName", "Validate_details_in_homeclub_section");
					Joinnow_CST.Validate_details_in_homeclub_section(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input,Address, additional_input, plan_rates);
					context.setAttribute("fileName", "Validate_details_in_homeclub_section");
					driver.quit();break;
					
					
				case "Validate_back_and_Review_confirm_buttons":

					context.setAttribute("fileName", "Validate_back_and_Review_confirm_buttons");
					Joinnow_CST.Validate_back_and_Review_confirm_buttons(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_back_and_Review_confirm_buttons");
					driver.quit();break;
					
					
				case "Validate_back_button_in_step3":

					context.setAttribute("fileName", "Validate_back_button_in_step3");
					Joinnow_CST.Validate_back_button_in_step3(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_back_button_in_step3");
					driver.quit();break;

					
				case "Validate_filling_MI":

					context.setAttribute("fileName", "Validate_filling_MI");
					Joinnow_CST.Validate_filling_MI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode);
					context.setAttribute("fileName", "Validate_filling_MI");
					driver.quit();break;
					
					

				case "Validate_allsections_in_S3_for_4persons":

				context.setAttribute("fileName", "Validate_allsections_in_S3_for_4persons");
				Joinnow_CST.Validate_allsections_in_S3_for_4persons(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1);
				context.setAttribute("fileName", "Validate_allsections_in_S3_for_4persons");
				driver.quit();break;
					
				case "Validate_allfieldsof_AM_for4persons":

				context.setAttribute("fileName", "Validate_allfieldsof_AM_for4persons");
				Joinnow_CST.Validate_allfieldsof_AM_for4persons(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities);
				context.setAttribute("fileName", "Validate_allfieldsof_AM_for4persons");
				driver.quit();break;	
				
				case "Validate_filling_MI_for4persons":

				context.setAttribute("fileName", "Validate_filling_MI_for4persons");
				Joinnow_CST.Validate_filling_MI_for4persons(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5);
				context.setAttribute("fileName", "Validate_filling_MI_for4persons");
				driver.quit();break;
				
				
				case "Validate_IPA_for_Added_amenities":

				context.setAttribute("fileName", "Validate_IPA_for_Added_amenities");
				Joinnow_CST.Validate_IPA_for_Added_amenities(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5, rates_details,Amount_details);
				context.setAttribute("fileName", "Validate_IPA_for_Added_amenities");
				driver.quit();break;
				
				
				case "Validate_filling_CC_details":

					context.setAttribute("fileName", "Validate_filling_CC_details");
					Joinnow_CST.Validate_filling_CC_details(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates,Card_number,  Ex_year, Ex_month );
					context.setAttribute("fileName", "Validate_filling_CC_details");
					driver.quit();break;
					
				case "Validate_filling_CC_details_BInotsameasMI":

					context.setAttribute("fileName", "Validate_filling_CC_details_BInotsameasMI");
					Joinnow_CST.Validate_filling_CC_details_BInotsameasMI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates,Card_number,  Ex_year, Ex_month, Billing_Fname,Billing_Lname  );
					context.setAttribute("fileName", "Validate_filling_CC_details_BInotsameasMI");
					driver.quit();break;
					
					
					
				case "Validate_filling_Savings_details_BInotsameasMI":

					context.setAttribute("fileName", "Validate_filling_Savings_details_BInotsameasMI");
					Joinnow_CST.Validate_filling_Savings_details_BInotsameasMI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, Routing_number, A_number,  Billing_Fname,Billing_Lname);
					context.setAttribute("fileName", "Validate_filling_Savings_details_BInotsameasMI");
					driver.quit();break;
					
				case "Validate_filling_Checking_details_BInotsameasMI":

					context.setAttribute("fileName", "Validate_filling_Checking_details_BInotsameasMI");
					Joinnow_CST.Validate_filling_Checking_details_BInotsameasMI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, Routing_number, A_number, Billing_Fname,Billing_Lname);
					context.setAttribute("fileName", "Validate_filling_Checking_details_BInotsameasMI");
					driver.quit();break;					
				
					
				case "Validate_filling_Savings_details":

					context.setAttribute("fileName", "Validate_filling_Savings_details");
					Joinnow_CST.Validate_filling_Savings_details(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, Routing_number, A_number);
					context.setAttribute("fileName", "Validate_filling_Savings_details");
					driver.quit();break;
					
				case "Validate_filling_Checking_details":

					context.setAttribute("fileName", "Validate_filling_Checking_details");
					Joinnow_CST.Validate_filling_Checking_details(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, Routing_number, A_number);
					context.setAttribute("fileName", "Validate_filling_Checking_details");
					driver.quit();break;
					
					
				case "Validate_Review_confirm_btn":

					context.setAttribute("fileName", "Validate_Review_confirm_btn");
					Joinnow_CST.Validate_Review_confirm_btn(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6);
					context.setAttribute("fileName", "Validate_Review_confirm_btn");
					driver.quit();break;
					
					
				case "Validate_NavigatetoReviewpage_with_EFT":

					context.setAttribute("fileName", "Validate_NavigatetoReviewpage_with_EFT");
					Joinnow_CST.Validate_NavigatetoReviewpage_with_EFT(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, Payment_type_1, Card_number_1, Routing_number_1, A_number_1);
					context.setAttribute("fileName", "Validate_NavigatetoReviewpage_with_EFT");
					driver.quit();break;
					
					
					
				case "Validate_Nav_Review_EFT_BInotsameasMI":

					context.setAttribute("fileName", "Validate_Nav_Review_EFT_BInotsameasMI");
					Joinnow_CST.Validate_Nav_Review_EFT_BInotsameasMI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, Payment_type_1, Card_number_1, Routing_number_1, A_number_1, Billing_Fname,Billing_Lname);
					context.setAttribute("fileName", "Validate_Nav_Review_EFT_BInotsameasMI");
					driver.quit();break;
					
					
				case "Validate_Review_confirm_btn_BInotsameasMI":

					context.setAttribute("fileName", "Validate_Review_confirm_btn_BInotsameasMI");
					Joinnow_CST.Validate_Review_confirm_btn_BInotsameasMI(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, Billing_Fname, Billing_Lname);
					context.setAttribute("fileName", "Validate_Review_confirm_btn_BInotsameasMI");
					driver.quit();break;
					
				case "Validate_SSL_secured_field":

					context.setAttribute("fileName", "Validate_SSL_secured_field");
					Joinnow_CST.Validate_SSL_secured_field(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name,input_data, Text_input, plan_rates);
					context.setAttribute("fileName", "Validate_SSL_secured_field");
					driver.quit();break;
					
					
				case "Validate_Reviewheading_and_stepsimg_inpage4":

					context.setAttribute("fileName", "Validate_Reviewheading_and_stepsimg_inpage4");
					Joinnow_CST.Validate_Reviewheading_and_stepsimg_inpage4(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6);
					context.setAttribute("fileName", "Validate_Reviewheading_and_stepsimg_inpage4");
					driver.quit();break;
					
					
				case "Validate_all_sections_in_Reviewpage":

					context.setAttribute("fileName", "Validate_all_sections_in_Reviewpage");
					Joinnow_CST.Validate_all_sections_in_Reviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6);
					context.setAttribute("fileName", "Validate_all_sections_in_Reviewpage");
					driver.quit();break;	
			
				case "Validate_MI_in_Reviewpage":

					context.setAttribute("fileName", "Validate_MI_in_Reviewpage");
					Joinnow_CST.Validate_MI_in_Reviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6);
					context.setAttribute("fileName", "Validate_MI_in_Reviewpage");
					driver.quit();break;	
					
					
				case "Validate_Fname_underBIsection":

					context.setAttribute("fileName", "Validate_Fname_underBIsection");
					Joinnow_CST.Validate_Fname_underBIsection(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6);
					context.setAttribute("fileName", "Validate_Fname_underBIsection");
					driver.quit();break;
					
					
				case "Validate_Fname_underMonthlyDBIsection":

					context.setAttribute("fileName", "Validate_Fname_underMonthlyDBIsection");
					Joinnow_CST.Validate_Fname_underMonthlyDBIsection(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6);
					context.setAttribute("fileName", "Validate_Fname_underMonthlyDBIsection");
					driver.quit();break;
					
					
				case "Validate_payment_details_inreviewpage":

					context.setAttribute("fileName", "Validate_payment_details_inreviewpage");
					Joinnow_CST.Validate_payment_details_inreviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, Card_name);
					context.setAttribute("fileName", "Validate_payment_details_inreviewpage");
					driver.quit();break;					
					
					
				case "Validate_MDPI_details_inreviewpage":

					context.setAttribute("fileName", "Validate_MDPI_details_inreviewpage");
					Joinnow_CST.Validate_MDPI_details_inreviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, Card_name);
					context.setAttribute("fileName", "Validate_MDPI_details_inreviewpage");
					driver.quit();break;
					
					
				case "Validate_allsecs_inRP_for4persons":

					context.setAttribute("fileName", "Validate_allsecs_inRP_for4persons");
					Joinnow_CST.Validate_allsecs_inRP_for4persons(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6);
					context.setAttribute("fileName", "Validate_allsecs_inRP_for4persons");
					driver.quit();break;
					
					
				case "Validate_MI_inRP_for4persons":

					context.setAttribute("fileName", "Validate_MI_inRP_for4persons");
					Joinnow_CST.Validate_MI_inRP_for4persons(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6);
					context.setAttribute("fileName", "Validate_MI_inRP_for4persons");
					driver.quit();break;
					
					
				case "Validate_MDA_inreviewpage":

					context.setAttribute("fileName", "Validate_MDA_inreviewpage");
					Joinnow_CST.Validate_MDA_inreviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, MD_amount);
					context.setAttribute("fileName", "Validate_MDA_inreviewpage");
					driver.quit();break;
					
					
					
				case "Validate_IPA_section_inreviewpage":

					context.setAttribute("fileName", "Validate_IPA_section_inreviewpage");
					Joinnow_CST.Validate_IPA_section_inreviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, rates_details, Amount_details);
					context.setAttribute("fileName", "Validate_IPA_section_inreviewpage");
					driver.quit();break;
					
					
					
				case "Validate_IA_reviewpage":

					context.setAttribute("fileName", "Validate_IA_reviewpage");
					Joinnow_CST.Validate_IA_reviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, Included_amenities);
					context.setAttribute("fileName", "Validate_IA_reviewpage");
					driver.quit();break;
					
					
					
				case "Validate_YHC_inreviewpage":

					context.setAttribute("fileName", "Validate_YHC_inreviewpage");
					Joinnow_CST.Validate_YHC_inreviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, Club_Address, Club_Address2);
					context.setAttribute("fileName", "Validate_YHC_inreviewpage");
					driver.quit();break;
					
					
					
				case "Validate_CA_inreviewpage":

					context.setAttribute("fileName", "Validate_CA_inreviewpage");
					Joinnow_CST.Validate_CA_inreviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, input_data7);
					context.setAttribute("fileName", "Validate_CA_inreviewpage");
					driver.quit();break;
					
					
					
				case "Validate_continuebtn_inreviewpage":

					context.setAttribute("fileName", "Validate_continuebtn_inreviewpage");
					Joinnow_CST.Validate_continuebtn_inreviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6);
					context.setAttribute("fileName", "Validate_continuebtn_inreviewpage");
					driver.quit();break;
					
					
					
				case "Validate_sign_inreviewpage":

					context.setAttribute("fileName", "Validate_sign_inreviewpage");
					Joinnow_CST.Validate_sign_inreviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6);
					context.setAttribute("fileName", "Validate_sign_inreviewpage");
					driver.quit();break;
					
					
				case "Validate_MI_edit_inreviewpage":

					context.setAttribute("fileName", "Validate_MI_edit_inreviewpage");
					Joinnow_CST.Validate_MI_edit_inreviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, F_Name1, L_Name1);
					context.setAttribute("fileName", "Validate_MI_edit_inreviewpage");
					driver.quit();break;
					
					
				case "Validate_AM_edit_inreviewpage":

					context.setAttribute("fileName", "Validate_AM_edit_inreviewpage");
					Joinnow_CST.Validate_AM_edit_inreviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, Email1);
					context.setAttribute("fileName", "Validate_AM_edit_inreviewpage");
					driver.quit();break;
					
				case "Validate_BI_edit_inreviewpage":

					context.setAttribute("fileName", "Validate_BI_edit_inreviewpage");
					Joinnow_CST.Validate_BI_edit_inreviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, Billing_Fname, Billing_Lname,F_Name1, L_Name1);
					context.setAttribute("fileName", "Validate_BI_edit_inreviewpage");
					driver.quit();break;
					
					
					
				case "Validate_PI_edit_inreviewpage":

					context.setAttribute("fileName", "Validate_PI_edit_inreviewpage");
					Joinnow_CST.Validate_PI_edit_inreviewpage(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, Ex1_month,Ex1_year );
					context.setAttribute("fileName", "Validate_PI_edit_inreviewpage");
					driver.quit();break;
					
					
				case "Validate_MDBI_edit":

					context.setAttribute("fileName", "Validate_MDBI_edit");
					Joinnow_CST.Validate_MDBI_edit(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, Payment_type_1, Card_number_1, Routing_number_1, A_number_1, Billing_Fname,Billing_Lname , F_Name1, L_Name1);
					context.setAttribute("fileName", "Validate_MDBI_edit");
					driver.quit();break;
					
				case "Validate_MDPI_edit":

					context.setAttribute("fileName", "Validate_MDPI_edit");
					Joinnow_CST.Validate_MDPI_edit(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, Payment_type_1, Card_number_1, Routing_number_1, A_number_1, Billing_Fname,Billing_Lname ,Card_name );
					context.setAttribute("fileName", "Validate_MDPI_edit");
					driver.quit();break;
					
					
				case "Validate_IPA_edit":

					context.setAttribute("fileName", "Validate_IPA_edit");
					Joinnow_CST.Validate_IPA_edit(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, input_data2, input_data3, input_data4, input_data5,Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6, rates_details, Amount_details);
					context.setAttribute("fileName", "Validate_IPA_edit");
					driver.quit();break;
					
					
					
				case "Validate_YHC_edit":

					context.setAttribute("fileName", "Validate_YHC_edit");
					Joinnow_CST.Validate_YHC_edit(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, input_data, Text_input, plan_rates, input_data1, Add_amenities, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_year, Ex_month, Routing_number, A_number, input_data6,Club_name1 ,Club_Address, Club_Address2);
					context.setAttribute("fileName", "Validate_YHC_edit");
					driver.quit();break;
					
					
					
//				case "Validate_user_details_in_review_page":
//
//					context.setAttribute("fileName", "Validate_user_details_in_review_page");
//					joinnow.Validate_user_details_in_review_page(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, Text_input, plan_rates, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_month,  Ex_year, Routing_number , Account_number);
//					context.setAttribute("fileName", "Validate_user_details_in_review_page");
//					driver.quit();break;
//					
//				case "Validate_user_fullname_under_billingsection":
//
//					context.setAttribute("fileName", "Validate_user_fullname_under_billingsection");
//					joinnow.Validate_user_fullname_under_billingsection(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, Text_input, plan_rates, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_month,  Ex_year, Routing_number , Account_number);
//					context.setAttribute("fileName", "Validate_user_fullname_under_billingsection");
//					driver.quit();break;
//					
//				case "Validate_user_payment_info":
//
//					context.setAttribute("fileName", "Validate_user_payment_info");
//					joinnow.Validate_user_payment_info(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, Text_input, plan_rates, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_month,  Ex_year, Routing_number , Account_number, Card_name);
//					context.setAttribute("fileName", "Validate_user_payment_info");
//					driver.quit();break;
//					
//					
//					
//				case "Validate_user_fullname_under_monthlyduesbillingsection":
//
//					context.setAttribute("fileName", "Validate_user_fullname_under_monthlyduesbillingsection");
//					joinnow.Validate_user_fullname_under_monthlyduesbillingsection(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, Text_input, plan_rates, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_month,  Ex_year, Routing_number , Account_number);
//					context.setAttribute("fileName", "Validate_user_fullname_under_monthlyduesbillingsection");
//					driver.quit();break;
//					
//					
//				case "Validate_user_monthly_dues_payment_info":
//
//					context.setAttribute("fileName", "Validate_user_monthly_dues_payment_info");
//					joinnow.Validate_user_monthly_dues_payment_info(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, Text_input, plan_rates, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_month,  Ex_year, Routing_number , Account_number, Card_name, input_data);
//					context.setAttribute("fileName", "Validate_user_monthly_dues_payment_info");
//					driver.quit();break;
//					
//					
//					
//				case "Validate_Monthly_dues_amount":
//
//					context.setAttribute("fileName", "Validate_Monthly_dues_amount");
//					joinnow.Validate_Monthly_dues_amount(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, Text_input, plan_rates, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_month,  Ex_year, Routing_number , Account_number);
//					context.setAttribute("fileName", "Validate_Monthly_dues_amount");
//					driver.quit();break;
//					
//					
//				case "Validate_initial_payment_amount_section":
//
//					context.setAttribute("fileName", "Validate_initial_payment_amount_section");
//					joinnow.Validate_initial_payment_amount_section(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, Text_input, plan_rates, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_month,  Ex_year, Routing_number , Account_number, input_data, input_data1);
//					context.setAttribute("fileName", "Validate_initial_payment_amount_section");
//					driver.quit();break;
//					
//					
//					
//				case "Validate_Includeded_amenities_in_review_page":
//
//					context.setAttribute("fileName", "Validate_Includeded_amenities_in_review_page");
//					joinnow.Validate_Includeded_amenities_in_review_page(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, Text_input, plan_rates, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_month,  Ex_year, Routing_number , Account_number, Included_amenities);
//					context.setAttribute("fileName", "Validate_Includeded_amenities_in_review_page");
//					driver.quit();break;
//					
//					
//					
//				case "Validate_all_yourhomeclub_section_review_page":
//
//					context.setAttribute("fileName", "Validate_all_yourhomeclub_section_review_page");
//					joinnow.Validate_all_yourhomeclub_section_review_page(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, Text_input, plan_rates, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_month,  Ex_year, Routing_number , Account_number, input_data,additional_input, input_data1, Club_Address, Club_city, Club_zip, Club_phone);
//					context.setAttribute("fileName", "Validate_all_yourhomeclub_section_review_page");
//					driver.quit();break;
//					
//					
//				case "Validate_Membership_agreement_in_review_page":
//
//					context.setAttribute("fileName", "Validate_Membership_agreement_in_review_page");
//					joinnow.Validate_Membership_agreement_in_review_page(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, Text_input, plan_rates, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_month,  Ex_year, Routing_number , Account_number, additional_input);
//					context.setAttribute("fileName", "Validate_Membership_agreement_in_review_page");
//					driver.quit();break;
//					
//					
//				case "Validate_Previewagreement_and_Confirmandpay_buttons":
//
//					context.setAttribute("fileName", "Validate_Previewagreement_and_Confirmandpay_buttons");
//					joinnow.Validate_Previewagreement_and_Confirmandpay_buttons(testdata.get("TextMessage").toString(), Dropdown_values, Country, Club_name, Text_input, plan_rates, F_Name, L_Name, Phone,  Email,  Address,  City,  State,  Zipcode, Payment_type, Card_number,  Ex_month,  Ex_year, Routing_number , Account_number);
//					context.setAttribute("fileName", "Validate_Previewagreement_and_Confirmandpay_buttons");
//					driver.quit();break;

				
//					*/

					
					
				default:
					driver.quit();
					break;

				}

				// EndTest
//				System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
				ExtentTestManager.getTest().log(Status.PASS, "*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
				ExtentTestManager.endTest();
				ExtentManager.getInstance().flush();
				Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
				Log.info("Browser is closed");


			}

		} 
		catch (Exception e)
		{
			Thread.sleep(1000);
			ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
			Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
			String stackTrace = Throwables.getStackTraceAsString(e);
			Log.error( stackTrace);
		
			
			String fileName = (String) context.getAttribute("fileName");

			try {
				File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
						testdata.get("TestScenario").toString());
				ExtentTestManager.getTest().fail(e.getMessage(),
						MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
				ExtentTestManager.getTest().log(Status.FAIL, e);
				} 
			catch (Exception e1) {
				System.out.println("File not found " + e1);
								}
			ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");

//			 Logout
			context.setAttribute("fileName", "Logout");
			if (com.test.user.All_scenarios.driver!=null)driver.quit();
			ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
			Log.info("Browser is closed");

			// EndTest
			System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
			ExtentTestManager.endTest();
			ExtentManager.getInstance().flush();
			Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
			throw new Exception(stackTrace);
		} 
		catch (AssertionError e) 
		{
			Thread.sleep(1000);
//			System.out.println("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
			ExtentTestManager.getTest().log(Status.FAIL, "*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
			Log.error("*** Test execution " + testdata.get("TestScenario").toString() + " failed...");
			String stackTrace = Throwables.getStackTraceAsString(e);
			Log.error( stackTrace);
			
			String fileName = (String) context.getAttribute("fileName");

			try {
				File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
						testdata.get("TestScenario").toString());
				ExtentTestManager.getTest().fail(e.getMessage(),
						MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
				ExtentTestManager.getTest().log(Status.FAIL, e);
				} 
			catch (Exception e1)
			{
				System.out.println("File not found " + e1);
			}
			ExtentTestManager.getTest().log(Status.FAIL, "Test Failed");

			// Logout
			context.setAttribute("fileName", "Logout");
			driver.quit();
			ExtentTestManager.getTest().log(Status.PASS, "Browser is closed");
			Log.info("Browser is closed");

			// EndTest
			System.out.println(("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***"));
			ExtentTestManager.endTest();
			ExtentManager.getInstance().flush();
			Log.info("*** Test Suite " + testdata.get("TestScenario").toString() + " ending ***");
			
			throw new Exception(stackTrace);
			
		}
	}


	
	@DataProvider(name = "TestData")
	public static Object[][] gettestdate() throws IOException {

		Object[][] objectarry = null;
		java.util.List<Map<String, String>> completedata = com.Utility.ExcelReader.getdata("Joinnow_CST");

		java.util.List<Map<String, String>> completedata1 = new ArrayList<Map<String,String>>();
		int j=0;

		for (int i = 0; i < completedata.size(); i++) {
			if(completedata.get(i).get("Run").toString().equalsIgnoreCase("Yes")) 
			{
			completedata1.add(j, completedata.get(i));
			j++;
			}
		}
		
		objectarry = new Object[completedata1.size()][1];
		
		for (int i = 0; i < completedata1.size(); i++) {
			objectarry[i][0] = completedata1.get(i);
		}
		return objectarry;

	}

	public void Takescreenshot(String fileName, String scenario) {
		try {
			File file = new com.Utility.ScreenShot(driver).takeScreenShot(fileName,
					scenario);
			ExtentTestManager.getTest().pass("File upload screenshot",
					MediaEntityBuilder.createScreenCaptureFromPath(file.toString()).build());
			
			} 
		catch (Exception e1) {
			System.out.println("File not found " + e1);
							}
	}
	
}
